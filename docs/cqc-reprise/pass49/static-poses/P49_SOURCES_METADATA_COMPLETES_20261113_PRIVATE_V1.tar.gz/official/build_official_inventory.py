import csv,gzip,hashlib,io,json,os,pathlib,re,unicodedata,collections,datetime
OUT=pathlib.Path('/tmp/cqc-static-20261113/official');OUT.mkdir(parents=True,exist_ok=True)
BASE=pathlib.Path('/workspace/cqc-pass21-application/public/cqc/src')
CSV=pathlib.Path('/workspace/cqc-v3-recovered/preserved-files/CQC_SPRITES_REPRISE_V3/INVENTAIRE_COSTUMES_V3.csv')
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
def norm(s):
 s=unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().lower()
 return re.sub('[^a-z0-9]+','',s)
csvraw=read(CSV);historical=list(csv.DictReader(io.StringIO(csvraw.decode('utf-8-sig'))));assert len(historical)==416
native=json.loads(read(pathlib.Path('/tmp/cqc-static-20261113/inventory/CURRENT_NATIVE_OPTION_SOURCE_CANDIDATES_PRIVATE_V1.json')))['rows']
s=read(BASE/'cqc-pass39-raiden-dlc-index.js').decode();m=re.search(r'const\s+reviewedEntries\s*=\s*',s);dlc=json.JSONDecoder().raw_decode(s[m.end():])[0]
for x in dlc:
 if not any(r['uid']==x['uid']and r['id']==x['id']for r in native):native.append(dict(x,index='cqc-pass39-raiden-dlc-index.js',kind='reviewedEntries-direct-index'))
canon=[r for r in native if r.get('family')=='canonical'and r.get('provenance',{}).get('canonicalAppearanceAttested')is True]
aliases={'core__snake__alt__choco_chip':'mgs3-camo-chocolate-chip','core__snake__alt__flower':'mgs3-camo-flower','core__snake__alt__rock':'mgs3-camo-rock','core__snake__alt__mummy':'mgs3-camo-mummy','core__raiden__alt__standard_cyborg_body':'mgr_r00_standard'}
priority=['core__old_snake','core__meryl_mgs4','core__johnny_mgs4','core__liquid_ocelot','core__raiden','core__raiden_mgs4','core__vamp_mgs4','roster50__naomi_mgs4','core__armstrong','core__mistral','roster50__otacon_mgs4','core__snake','core__volgin','core__boss','archive__naked_delta','core__venom','core__quiet','core__snake_pw','core__kaz_pw','core__snake_mpo']
notes={
'core__old_snake':'MGS4/2014 Old Snake remains the same old body. Young-Snake FaceCamo is a worn mask, not a younger Solid Snake incarnation; retain 2014 equipment and body. OctoCamo patterns are not random recolours: use the actual documented pattern.',
'core__meryl_mgs4':'MGS4/2014 adult Meryl only. Wedding dress remains MGS4 Meryl, never MGS1 Meryl or Twin Snakes. Check hair and ceremony accessories against actual ending references.',
'core__johnny_mgs4':'MGS4/2014 Johnny/Akiba. Wedding attire is ivory, not a generic black tuxedo; Rat Patrol unmasked variant retains same period and body.',
'core__liquid_ocelot':'MGS4/2014 Liquid Ocelot only. Final-duel shirtless body and the canonical prosthetic-arm state require actual scene reference; do not substitute young Ocelot or MGS2 appearance.',
'core__raiden':'MGR/2018 Raiden. Separate documented DLC colours, armour constructions and wigs. Standard Body has existing mgr_r00_standard native poses; do not generate MGS4 Raiden as its substitute. Preserve each official visor/helmet and suit tie colour.',
'core__raiden_mgs4':'Original MGS4/2014 Raiden. Closed visor, Outer Haven damage and epilogue human-looking shell require their exact scenes, not an MGR chassis.',
'core__vamp_mgs4':'MGS4 Vamp only; long black coat is an outfit of this incarnation, not MGS2 Vamp.',
'roster50__naomi_mgs4':'MGS4/2014 Naomi only. Use actual blouse/skirt and accessories from the provided original art/scenes; preserve period hairstyle and adult proportions.',
'core__armstrong':'MGR Armstrong. Shirtless nanomachine state and full senator suit are separate documented outfits. Use same-period appearance references, not a generic cyborg.',
'core__mistral':'MGR Mistral with the native two-arm body configuration. Do not turn removed Dwarf Gekko arms into invented clothing; compare the actual game model.',
'roster50__otacon_mgs4':'MGS4/2014 Otacon. Nomad daily clothing versus wedding attire; the latter was historically marked already_covered and needs a source-pose presence check before regeneration.',
'core__snake':'Original MGS3 PS2/1964 Naked Snake, separate from Delta, Portable Ops, Peace Walker and Venom. Default Tiger Stripe may already be covered by Original/native nextgen. Camos use original named uniform patterns and required face-paint states. Ceremony eye injury/accessories require the actual scene.',
'core__volgin':'Original MGS3 PS2/1964 Volgin; greatcoat over canonical uniform. No Man on Fire or Delta substitution.',
'core__boss':'Original MGS3 PS2/1964 The Boss; cape/poncho appearance needs original game reference. Delta remains a separate UID.',
'archive__naked_delta':'Delta Naked Snake is a separate UID from original PS2 MGS3. Its patterns/bonus outfits must be verified against the Delta edition and corresponding unlocks; do not copy the PS2 texture and call it Delta.',
'core__venom':'MGSV TPP/1984 Venom retains horn, right-eye patch and left prosthetic appropriate to the documented outfit. Naked Snake DLC clothing remains worn by Venom; do not swap in Naked Snake 1964. Bonus Raiden/Cyborg Ninja are real released suits and already have native index entries.',
'core__quiet':'MGSV TPP Quiet. Sniper Wolf unlockable is a costume on Quiet, not the separate Sniper Wolf character. Use each actual XOF, metallic or cloak reference with neutral nonsexual stance.',
'core__snake_pw':'Peace Walker/1974 Big Boss, right-eye patch and actual MSF equipment. Battle Dress may be covered by Original. Check actual PW patterns, helmet and UT print; never replace by MGSV clothing. The previous cyborg LEFT correction refusal is a separate held invented costume, not permission to retry it.',
'core__kaz_pw':'Peace Walker/1974 Kaz only, not MGSV injured Kaz. The Date with Kaz swimsuit is a same-game bonus outfit; use a neutral nonsexual standing pose and actual attire reference.',
'core__snake_mpo':'Portable Ops/1970 Naked Snake only. Epilogue uniform must follow its own released-game reference and period face/eye state, not PW/MGS3 uniform.'}
rows=[];matched=set()
for i,h in enumerate(historical,1):
 hid=h['Identifiant'];uid,suffix=hid.split('__alt__',1);hits=[]
 for n in canon:
  if n['uid']!=uid:continue
  tokens={norm(n.get('label','')),norm(n.get('provenance',{}).get('costumeName','')),norm(n['id'])}
  stripped=re.sub(r'^(?:mgs[1-4]-(?:camo-)?|mgr-|mgsv-|pw-|survive-)','',n['id'])
  if norm(h['Variante'])in tokens or norm(suffix)in tokens|{norm(stripped)}or aliases.get(hid)==n['id']:hits.append(n)
 r00=hid=='core__raiden__alt__standard_cyborg_body'
 if r00:
  nativeMatches=[{'uid':uid,'id':'mgr_r00_standard','index':'cqc-pass31-raiden-r00.js','qualification':'Existing dedicated native16pose Standard Cyborg Body controller; first pose available for static-source review.'}]
 else:nativeMatches=[{'uid':n['uid'],'id':n['id'],'index':n.get('index'), 'label':n.get('label'),'metadata':n.get('metadata'),'preview':n.get('preview'),'provenance':n.get('provenance'),'assets':n.get('assets')}for n in hits]
 for n in hits:matched.add((n['uid'],n['id']))
 status='NATIVE_DESCRIPTOR_FOUND_RECHECK_STATIC_POSE'if nativeMatches else 'HISTORICAL_CANONICAL_CLAIM_REFERENCE_AND_POSE_REVIEW_PENDING'
 overlap=None
 if hid in ['core__snake__alt__tiger_stripe','core__snake_pw__alt__battle_dress']:overlap='Possible same outfit as this UID Original/native presentation; check actual pose before making a duplicate.'
 rows.append({'uid':uid,'id':'official--'+suffix.replace('_','-'),'historicalID':hid,'name':h['Personnage'],'game':h['Épisode'],'costume':h['Variante'],'category':h['Catégorie'],'sourceClassification':'historically-planned-official-or-story-equipment','historicalStatus':h['État'],'historicalPNGPack':h['Pack du PNG'],'historicalPNGPath':h['Fichier PNG'],'referenceURLs':[u.strip()for u in h['Sources'].split('|')if u.strip()],'historicalLimits':h['Limites'],'currentStatus':status,'nativeMatches':nativeMatches,'possibleOriginalOverlap':overlap,'newSpriteDeliveredThisPass':False,'newAnimationRequested':False,'samePeriodUIDRequired':True})
extra=[{'uid':n['uid'],'id':n['id'],'label':n.get('label'),'index':n.get('index'),'provenance':n.get('provenance'),'metadata':n.get('metadata'),'preview':n.get('preview'),'assets':n.get('assets'),'qualification':'Reviewed native canonical descriptor not matched to a historical416 row; preserve rather than regenerate.'}for n in canon if(n['uid'],n['id'])not in matched]
briefs=[]
for i,uid in enumerate(priority,1):
 allrows=[r for r in rows if r['uid']==uid];pending=[r for r in allrows if not r['nativeMatches']]
 briefs.append({'rank':i,'uid':uid,'name':allrows[0]['name'],'game':allrows[0]['game'],'scope':'One independently drawn transparent full-body neutral pose per missing documented costume; no animation, no image filters, no age/UID merging.','fidelityBrief':notes[uid],'bodyRule':'Preserve the exact Original identity/proportions and common body datum/floor from the current Original sprite. Do not derive height/placement from clothes or weapon bounding boxes. Numeric world height is not guessed here.','poseRule':'Face RIGHT, mild three-quarter fighting-game stance, full body/feet visible, no attack/action sequence, no repeated animation frames. Read the actual outfit reference before generation.','officialCostumesHistorical':len(allrows),'nativePoseCandidatesToReuse':len(allrows)-len(pending),'missingOrUnverifiedOfficialCostumes':pending,'referenceReviewRequiredBeforeGeneration':True,'referenceURLs':list(dict.fromkeys(u for r in pending for u in r['referenceURLs']))})
report={'schema':'cqc.static.official-costume-inventory/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input':{'path':str(CSV),'bytes':len(csvraw),'sha256':hashlib.sha256(csvraw).hexdigest()},'historicalRows':416,'historicalUIDs':len({r['uid']for r in rows}),'nativeCanonicalDescriptors':len(canon),'historicalRowsWithNativeMatches':sum(bool(r['nativeMatches'])for r in rows),'nativeExtraDescriptorsNotInHistoricalTable':len(extra),'pendingHistoricalRows':sum(not bool(r['nativeMatches'])for r in rows),'inventedFamiliesSeparate':['retro','nextgen','cyborg','survive','metalgear','tuxedo','zombie','furry'],'qualification':'The historical table lists documented/planned official story/equipment/bonus outfits. Its generated_reviewed field is a historical claim, not current PNG presence. Existing native descriptors are source reuse candidates, not newly drawn or newly browser-tested deliveries. Reference-pending rows must not be invented from memory or marked ready. Each base Original and each separate roster UID remains separate.','excludedCrossEraMappings':358,'samePeriodSourcePairs':[{'uid':'core__snake_mgs2','sourceUID':'roster51__pliskin_mgs2'},{'uid':'roster51__pliskin_mgs2','sourceUID':'core__snake_mgs2'},{'uid':'core__eva_mgs3','sourceUID':'npc53__tatyana_mgs3'},{'uid':'npc53__tatyana_mgs3','sourceUID':'core__eva_mgs3'}],'rows':rows,'nativeExtra':extra}
(OUT/'OFFICIAL_COSTUMES_416_CURRENT_RECONCILIATION_PRIVATE_V1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(OUT/'OFFICIAL_PRIORITY20_UID_SINGLE_POSE_BRIEFS_PRIVATE_V1.json').write_text(json.dumps({'schema':'cqc.static.official-priority20-briefs/1','rows':briefs,'qualification':report['qualification']},ensure_ascii=False,indent=2)+'\n')
with(OUT/'OFFICIAL_COSTUMES_416_CURRENT_RECONCILIATION_PUBLIC_V1.csv').open('w',encoding='utf-8-sig',newline='')as f:
 fields=['uid','id','name','game','costume','category','historicalStatus','currentStatus','nativeMatches','referenceURLs','possibleOriginalOverlap'];writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
 for r in rows:writer.writerow({k:json.dumps(r[k],ensure_ascii=False)if isinstance(r[k],list)else r[k]for k in fields})
print(json.dumps({k:v for k,v in report.items()if k not in ['rows','nativeExtra','qualification','input','inventedFamiliesSeparate','samePeriodSourcePairs']},ensure_ascii=False))
