import concurrent.futures,hashlib,html,json,pathlib,re,ssl,urllib.request,urllib.parse,datetime
OUT=pathlib.Path('/tmp/cqc-static-20261113/official');REF=OUT/'priority20-reference-downloads';REF.mkdir(exist_ok=True)
briefs=json.loads((OUT/'OFFICIAL_PRIORITY20_UID_SINGLE_POSE_BRIEFS_PRIVATE_V1.json').read_text())['rows']
allowed={'www.creativeuncut.com','www.metalgearsolid.be','images.pushsquare.com','static.wikia.nocookie.net','www.konami.com','img.youtube.com'}
def fetch(url):
 u=urllib.parse.urlparse(url);assert u.scheme=='https'and u.hostname in allowed
 req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 CQC reference inventory'})
 with urllib.request.urlopen(req,context=ssl.create_default_context(),timeout=18)as r:
  b=r.read(12000001);assert len(b)<=12000000
  return b,r.headers.get_content_type(),r.url
def one(br):
 uid=br['uid'];attempts=[];images=[]
 # Prefer publisher art or an original art image mirrored by established galleries.
 urls=br['referenceURLs'];selected=[]
 for url in urls:
  host=urllib.parse.urlparse(url).hostname
  if host in allowed and (re.search(r'\.(?:jpg|jpeg|png|gif|webp)(?:[/?]|$)',url,re.I)or host in ['www.creativeuncut.com','www.metalgearsolid.be']):selected.append(url)
  if len(selected)>=6:break
 for url in selected:
  if len(images)>=2:break
  try:
   b,t,actual=fetch(url)
   if t=='text/html':
    h=b.decode('utf-8','replace');sources=[html.unescape(x)for x in re.findall(r'<img[^>]+src=["\']([^"\']+)',h,re.I)]
    candidates=[urllib.parse.urljoin(actual,x)for x in sources if '/art/'in x and re.search(r'\.(?:jpg|png|webp)$',x,re.I)]
    if not candidates and urllib.parse.urlparse(url).hostname=='www.metalgearsolid.be':candidates=[urllib.parse.urljoin(actual,x)for x in sources if 'peace_walker'in x.lower()and re.search(r'\.(?:jpg|png|gif)$',x,re.I)]
    attempts.append({'url':url,'HTTP':200,'kind':'HTML-reference-page','imageCandidates':candidates[:5]})
    if not candidates:continue
    imageurl=candidates[0];b,t,actual=fetch(imageurl)
   else:imageurl=url
   if not t.startswith('image/'):attempts.append({'url':url,'kind':'not-image','contentType':t});continue
   digest=hashlib.sha256(b).hexdigest();suffix={'image/jpeg':'.jpg','image/png':'.png','image/gif':'.gif','image/webp':'.webp'}.get(t,'.image');target=REF/(uid+'-'+digest[:12]+suffix)
   if not target.exists():target.write_bytes(b)
   assert target.read_bytes()==b
   images.append({'referencePage':url,'imageURL':imageurl,'resolvedURL':actual,'path':str(target),'bytes':len(b),'sha256':digest,'contentType':t,'visualReview':'NOT_YET_VIEWED','outfitSpecificity':'Must compare image to exact requested costume before generation; a character reference alone does not establish all alternate outfits.'})
  except Exception as e:attempts.append({'url':url,'error':str(e)[:250]})
 return {'uid':uid,'images':images,'attempts':attempts,'needsVisualReview':True,'newSpriteGenerated':False}
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:rows=list(pool.map(one,briefs))
d={'schema':'cqc.static.priority20-downloaded-reference-evidence/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':rows,'imageCount':sum(len(r['images'])for r in rows),'UIDsWithDownloadedReference':sum(bool(r['images'])for r in rows),'credentialsUsed':False,'TLSVerified':True,'SourceOrGameFilesMutated':False}
(OUT/'PRIORITY20_REFERENCE_DOWNLOAD_RECEIPT_PRIVATE_V1.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'images':d['imageCount'],'UIDs':d['UIDsWithDownloadedReference'],'receipt':str(OUT/'PRIORITY20_REFERENCE_DOWNLOAD_RECEIPT_PRIVATE_V1.json')}))
