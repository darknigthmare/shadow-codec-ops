import os,json,csv,pathlib,datetime,hashlib,collections
B=pathlib.Path('/tmp/cqc-static-20261113');O=B/'official'
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb') as f:return f.read()
inv=json.loads(read(O/'OFFICIAL_COSTUMES_416_CURRENT_RECONCILIATION_PRIVATE_V1.json'))
catpath=B/'artists/official/OFFICIAL_ALL_CURRENT_SOURCE_CATALOG_PUBLIC_V1.json';catraw=read(catpath);cat=json.loads(catraw)
new={(x['uid'],x['id']):x for x in cat['entries']};pages={x['id']:x for x in cat['pages']}
newbyhistorical={x['officialHistoricalAlias']:x for x in cat['entries'] if x.get('officialHistoricalAlias')}
nativeproofpath=B/'catalog/EXISTING_NATIVE_OFFICIAL_STATIC_ENTRIES_PUBLIC_V1.json'
nativephysical={(x['uid'],x['costumeId']):x for x in json.loads(read(nativeproofpath))['entries']} if nativeproofpath.exists() else {}
r00path=O/'RAIDEN_R00_EXISTING_STATIC_SOURCE_PROOF_PRIVATE_V1.json';r00=json.loads(read(r00path)) if r00path.exists() else None
eqpath=O/'OFFICIAL_ORIGINAL_EQUIVALENCES_VERIFIED_PRIVATE_V1.json';eqs={(x['uid'],x['officialCostumeID']):x for x in json.loads(read(eqpath))['entries']} if eqpath.exists() else {}
aliasplans=json.loads(read(O/'SAME_UID_OFFICIAL_TUXEDO_PLANNED_ALIAS_PROPOSALS_PRIVATE_V1.json'))['aliases']
aliaskeys={(x['uid'],x['officialID']) for x in aliasplans}
cfgpath=O/'OFFICIAL_SAME_UID_EQUIPMENT_CONFIGURATION_ALIASES_PRIVATE_V1.json';cfgs={(x['uid'],x['officialCostumeID']):x for x in json.loads(read(cfgpath))['entries']} if cfgpath.exists() else {}
rows=[]
for r in inv['rows']:
 k=(r['uid'],r['id']);n=new.get(k) or newbyhistorical.get(r['historicalID']);cfg=cfgs.get(k)
 if cfg and not n:
  assert cfg['uid']==cfg['targetUID'], 'Never alias across UIDs'
  n=new.get((cfg['targetUID'],cfg['targetCostumeID']))
 matches=r['nativeMatches'];excluded=[];source=None;opts=[]
 state='REFERENCE_AND_STATIC_SOURCE_PENDING';reason='No verified static official Source mapping established yet; historical generated/needs_reference labels alone are not current physical Source proof.'
 if matches:
  assert all(m['uid']==r['uid'] for m in matches)
  opts=[{'uid':m['uid'],'costumeID':m['id'],'index':m['index'],'preview':{k:v for k,v in (m.get('preview') or {}).items() if k in ['file','sha256','rect','pivot','physicalPoseIndex','nativePoseKey']},'metadata':m.get('metadata')} for m in matches]
  state='EXISTING_NATIVE_OFFICIAL_OPTION_REUSE';reason='Exact same-UID canonical native option descriptor exists; reuse its established pose, do not redraw. Final physical Source/review gate remains Root responsibility.'
  for op in opts:
   physical=nativephysical.get((op['uid'],op['costumeID']))
   if physical:op['verifiedPhysicalSource']={'index':str(nativeproofpath),'source':physical['source'],'frame':{k:v for k,v in physical.get('frame',{}).items() if k in ['rect','pivot']},'reusedExistingStaticPose':True}
   elif r00 and op['uid']==r00['uid'] and op['costumeID']==r00['costumeID']:
    op['verifiedPhysicalSource']={'proof':str(r00path),'source':r00['source'],'frame':{k:v for k,v in r00['frame'].items() if k in ['rect','pivot','previewDatumX','previewStatureBounds']},'reusedExistingStaticPose':True}
  if all(o.get('verifiedPhysicalSource') for o in opts):reason='Exact same-UID native option and physical PNG SHA verified; reuse its existing RIGHT pose. No new drawing or animation; runtime admission remains separate.'
 if n:
  assert not matches,'New official unexpectedly duplicates a current native descriptor'
  p=pages[n['page']];source={'costumeID':n['id'],'sourceCatalogueKey':n['key'],'page':n['page'],'PNG':p['localPath'],'sha256':p['sha256'],'bytes':p['bytes'],'width':p['width'],'height':p['height'],'rect':n['rect'],'bodyDatumX':n['bodyDatumX'],'footDatumY':n['footDatumY'],'poseCount':1,'animationCount':0,'facing':'right'}
  state='NEW_STATIC_SOURCE_POSE_DRAWN_ROOT_REVIEW_PENDING';reason='Current pass has authored one Source pose after viewing cited references; historical ID is explicitly resolved to new costumeID. This is not animation/runtime completion.'
  if n['classification']=='corrected-original-pose':
   state='CORRECTED_ORIGINAL_SOURCE_POSE_DRAWN_ROOT_REVIEW_PENDING';reason='Attested official base costume maps to one newly corrected Original static Source; old original PNG preserved as historical reference, no duplicate official outfit and no animation modified.'
 if cfg and n:
  state='OFFICIAL_EQUIPMENT_CONFIGURATION_SOURCE_REUSED_ROOT_REVIEW_PENDING';reason=cfg['reason'];source['reusedPhysicalPose']=True;source['newDrawingCount']=0
 if k==('core__bigboss_sr','official--pre-transformation'):
  state='DISTINCT_FORM_STATIC_SOURCE_DRAWN_ROOT_REVIEW_PENDING' if n else 'DISTINCT_FORM_STATIC_REFERENCE_ATTESTED_RESERVED'
  reason='Root explicitly authorizes a separate HUMAN pretransformation static form from the readable small LEFT NES sprite. It never replaces the giant cyborg Original and never transfers its worldscale, physics, hitboxes or runtime admission. '+('One Source pose is now drawn with faithful lowdefinition RETRO palette; Root review pending.' if n else 'One RETRO-only pose reserved to D after reference was viewed by Root; no scope approval still needed.')
  excluded.append('Human form must never overwrite giant cyborg Original or inherit its worldheight/runtime geometry.')
 if r['possibleOriginalOverlap'] and not n and not matches:
  state='POSSIBLE_ORIGINAL_EQUIVALENCE_VISUAL_REVIEW_PENDING';reason=r['possibleOriginalOverlap']
 eq=eqs.get(k)
 if eq:
  assert not n and not matches
  state='ORIGINAL_EQUIVALENT_SOURCE_REUSED';reason=eq['review']['observations'];opts=[{'uid':eq['targetUID'],'costumeID':eq['targetCostumeID'],'index':'Original native pose','preview':{'file':eq['source']['path'],'sha256':eq['source']['sha256'],'rect':eq['source']['frameRect'],'pivot':eq['source']['pivot']},'verifiedPhysicalSource':{'proof':str(eqpath),'source':eq['source'],'reusedExistingStaticPose':True}}]
 planned=[]
 if k in aliaskeys and (n or matches) and not (r['uid']=='archive__naked_delta' and r['id']=='official--white-tuxedo'):
  planned=[{'family':'tuxedo','targetUID':r['uid'],'targetCostumeID':n['id'] if n else opts[0]['costumeID'],'status':'SAME_UID_SAME_PERIOD_OFFICIAL_SOURCE_ALIAS_PROPOSED_ROOT_REVIEW_PENDING','physicalSpriteCount':1}]
 if k==('archive__naked_delta','official--white-tuxedo'):excluded.append('White tuxedo remains its own distinct official sprite; black tuxedo alone supplies proposed planned tuxedo-family alias.')
 if k==('archive__captain','official--zombie-facepaint'):excluded.append('Official skull makeup does not complete invented decomposed zombie family.')
 if r['uid']=='archive__captain' and r['id'] in ['official--visitor','official--pyramid-head','official--ricky','official--divine-equine','official--stogie-bear']:excluded.append('Official head item on human custom avatar does not complete invented full-body furry, cyborg or Metal Gear families.')
 if k==('core__old_snake','official--octocamo-metal'):excluded.append('Metallic OctoCamo material does not complete invented Metal Gear or full cybernetic-chassis family.')
 if r['uid']=='archive__naked_delta' and r['id'] in ['official--sneaking-suit-pw','official--battle-dress-pw']:excluded.append('Official replica is worn by Delta UID; do not merge into 1974 Peace Walker Big Boss UID.')
 if k==('core__quiet','official--sniper-wolf'):excluded.append('Quiet official unlockable costume keeps Quiet identity; do not merge with the separate original Sniper Wolf character UID.')
 rows.append({'historicalID':r['historicalID'],'historicalUID':r['uid'],'historicalCostumeName':r['costume'],'historicalEpisode':r['game'],'reconciledOfficialID':r['id'],'targetUID':r['uid'],'targetCostumeID':n['id'] if n else opts[0]['costumeID'] if opts else None,'resolutionState':state,'resolutionReason':reason,'newSource':source,'nativeOptions':opts,'officialEquipmentConfigurationAlias':dict(cfg,proofPath=str(cfgpath)) if cfg else None,'plannedFamilyAliasProposals':planned,'excludedFalseAliases':excluded,'historicalStatusPreserved':r['historicalStatus'],'referenceURLs':r['referenceURLs'],'animationCount':0})
assert len(rows)==416 and len({x['historicalID'] for x in rows})==416
out={'schema':'cqc.static.official416.historical-id-map/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'counts':dict(collections.Counter(x['resolutionState'] for x in rows)),'inputCatalogue':{'path':str(catpath),'sha256':hashlib.sha256(catraw).hexdigest()},'rules':['HistoricalID is the Excel V3 identity; target UID never changes across ages/remakes.','Native descriptors are reused; generated Source and final runtime admission are separate states.','Exactly one pose per official outfit; aliases share a physical Source only for the exact same UID and period.','358 old cross-era/remake/body-transfer mappings remain excluded; only four same-period source pairs are separately documented, not merged.','Existing generic tuxedo labels alone do not certify canonical official outfit equivalence.'],'rows':rows,'globalExcludedMappings':inv['excludedCrossEraMappings'],'samePeriodPairsNotMerged':inv['samePeriodSourcePairs']}
p=O/'OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
c=O/'OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PUBLIC_V1.csv'
fields=['historicalID','historicalUID','historicalCostumeName','historicalEpisode','reconciledOfficialID','targetUID','targetCostumeID','resolutionState','resolutionReason','sourceSHA256','plannedFamilyAlias','excludedFalseAliases','animationCount']
with c.open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
 for r in rows:
  z={k:r.get(k) for k in fields};z['sourceSHA256']=r['newSource']['sha256'] if r['newSource'] else '|'.join(o.get('preview',{}).get('sha256','') for o in r['nativeOptions']);z['plannedFamilyAlias']='|'.join(a['family'] for a in r['plannedFamilyAliasProposals']);z['excludedFalseAliases']=' | '.join(r['excludedFalseAliases']);w.writerow(z)
print(json.dumps({'mapping':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(read(p)).hexdigest(),'counts':out['counts'],'CSV':str(c)},ensure_ascii=False))
