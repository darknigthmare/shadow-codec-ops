import json,urllib.request,urllib.parse,re,pathlib,hashlib,concurrent.futures,io
from PIL import Image
O=pathlib.Path('/tmp/cqc-static-20261113/official');D=O/'mgr-primary-full';D.mkdir(exist_ok=True);url='https://www.konami.com/mg/archive/mgr/jp/dlc/';a=json.load(open(O/'all-pending-reference-audit/ALL_PENDING_REFERENCE_URL_AUDIT_PRIVATE_V1.json'));row=next(r for r in a['results'] if r['url']==url);s=pathlib.Path(row['file']).read_text(errors='replace');urls=sorted(set(urllib.parse.urljoin(url,x)for x in re.findall('href=["\']([^"\']+)["\']',s,re.I)if x.endswith(('.jpg','.png'))));print('literalbiganchors',len(urls))
def get(u):
 try:
  b=urllib.request.urlopen(u,timeout=25).read();p=D/u.rsplit('/',1)[-1];p.write_bytes(b);im=Image.open(io.BytesIO(b));return {'url':u,'file':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'dimensions':list(im.size),'viewed':False}
 except Exception as e:return {'url':u,'error':str(e)}
r=list(concurrent.futures.ThreadPoolExecutor(max_workers=8).map(get,urls));(D/'MGR_PRIMARY_LINKED_FULL_IMAGES_PRIVATE_V1.json').write_text(json.dumps({'sourceURL':url,'literalAnchorsOnly':True,'images':r},ensure_ascii=False,indent=2)+'\n');print([(x['url'].rsplit('/',1)[-1],x.get('dimensions'),x.get('error'))for x in r])
