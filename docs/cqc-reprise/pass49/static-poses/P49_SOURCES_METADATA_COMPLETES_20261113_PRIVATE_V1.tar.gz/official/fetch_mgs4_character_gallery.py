import pathlib,urllib.request,urllib.parse,concurrent.futures,json,hashlib,io,re
from html.parser import HTMLParser
from PIL import Image
B=pathlib.Path('/tmp/cqc-static-20261113/official/metalgearsolidbe-gallery-discovery');root='https://www.metalgearsolid.be/'
class P(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.src=[]
 def handle_starttag(self,t,a):
  d=dict(a)
  if t=='a' and d.get('href'):self.links.append(d['href'])
  if t=='img' and d.get('src'):self.src.append(d['src'])
indexes=['https://www.metalgearsolid.be/metal_gear_solid_4_artworks_02.html'];pages=set();done=[]
while indexes and len(done)<2:
 u=indexes.pop(0)
 if u in done:continue
 try:
  dat=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=20).read();p=P();p.feed(dat.decode('utf8','replace'));done.append(u)
  for x in p.links:
   v=urllib.parse.urljoin(u,x);n=v.rsplit('/',1)[-1]
   if re.fullmatch('metal_gear_solid_4_artworks_[0-9]{3}\\.html',n):pages.add(v)
   elif re.fullmatch('metal_gear_solid_4_artworks_0[3]\\.html',n) and v not in done:indexes.append(v)
 except Exception as e:print('index error',u,str(e),flush=True)
def f(u):
 try:
  dat=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=20).read();p=P();p.feed(dat.decode('utf8','replace'));out=[]
  for s in p.src:
   url=urllib.parse.urljoin(u,s)
   if not re.search('/images/metal_gear_solid_4_art_g_[0-9]+\\.jpg$',url):continue
   b=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=20).read();im=Image.open(io.BytesIO(b));im.verify();path=B/(hashlib.sha256(url.encode()).hexdigest()[:14]+'-'+url.rsplit('/',1)[-1]);path.write_bytes(b);out.append({'galleryPage':u,'url':url,'file':str(path),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'dimensions':list(im.size),'viewed':False})
  return out
 except Exception as e:return [{'galleryPage':u,'error':str(e)}]
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:res=[r for rr in pool.map(f,sorted(pages)) for r in rr]
p=B/'MGS4_CHARACTER_GALLERY_IMAGE_RECEIPT_PRIVATE_V1.json';p.write_text(json.dumps({'indexesRead':done,'pagesFetched':len(pages),'images':res,'onlyLiteralGalleryLinks':True},ensure_ascii=False,indent=2)+'\n');print('indexes',done,'pages',len(pages),'images',sum('file' in x for x in res),flush=True)
for r in res:print(r.get('url'),r.get('file',''),r.get('error',''),flush=True)
