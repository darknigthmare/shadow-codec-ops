import urllib.request,pathlib,re,urllib.parse,json,hashlib,concurrent.futures,io
from PIL import Image
D=pathlib.Path('/tmp/cqc-static-20261113/official/pw-new-gallery');u='https://www.metalgearsolid.be/mgs_peace_walker_art_2.html';b=urllib.request.urlopen(u,timeout=25).read();(D/'actual-gallery2.html').write_bytes(b);s=b.decode('latin1');pages=sorted(set(urllib.parse.urljoin(u,x)for x in re.findall('href=["\']([^"\']+)["\']',s,re.I)if re.search('mgs_peace_walker_art_\\d+',x)))
def get(p):
 try:
  h=urllib.request.urlopen(p,timeout=25).read().decode('latin1');url=next(urllib.parse.urljoin(p,x)for x in re.findall('src=["\']([^"\']+)["\']',h,re.I)if 'mgs_peace_walker_g_art_' in x);b=urllib.request.urlopen(url,timeout=25).read();f=D/url.rsplit('/',1)[-1];f.write_bytes(b);im=Image.open(io.BytesIO(b));return {'galleryPage':p,'url':url,'file':str(f),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'dimensions':list(im.size),'viewed':False}
 except Exception as e:return {'galleryPage':p,'error':str(e)}
r=list(concurrent.futures.ThreadPoolExecutor(max_workers=8).map(get,pages));(D/'PW_ACTUAL_GALLERY2_RECEIPT_PRIVATE_V1.json').write_text(json.dumps({'sourceURL':u,'literalLinksOnly':True,'results':r},ensure_ascii=False,indent=2)+'\n');print('pages',len(pages));print([(x['galleryPage'].rsplit('/',1)[-1],x.get('dimensions'),x.get('error'))for x in r])
