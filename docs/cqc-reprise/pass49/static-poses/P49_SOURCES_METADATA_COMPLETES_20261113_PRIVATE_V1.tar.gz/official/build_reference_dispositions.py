import os,json,pathlib,hashlib,datetime,collections,csv
B=pathlib.Path('/tmp/cqc-static-20261113');O=B/'official'
def rd(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb') as f:return f.read()
map_path=O/'OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json';mapping=json.loads(rd(map_path));recon={r['historicalID']:r for r in json.loads(rd(O/'OFFICIAL_COSTUMES_416_CURRENT_RECONCILIATION_PRIVATE_V1.json'))['rows']};audit=json.loads(rd(O/'all-pending-reference-audit/ALL_PENDING_REFERENCE_URL_AUDIT_PRIVATE_V1.json'))
attempts=collections.defaultdict(list)
for r in audit['results']:
 for hid in r['rows']:attempts[hid].append({k:r[k] for k in ['url','httpStatus','finalURL','contentType','kind','file','bytes','sha256','dimensions','error','reason','retryAttempted'] if k in r})
for r in json.loads(rd(O/'html-derived-images/HTML_DERIVED_REFERENCE_IMAGE_FETCH_PRIVATE_V1.json'))['results']:
 for hid in r.get('rows',[]):
  attempts[hid].append(dict({k:r[k] for k in ['url','discoveredOn','file','bytes','sha256','dimensions','reason'] if k in r}, kind='IMAGE_NOT_YET_VIEWED' if r.get('status')=='IMAGE_DOWNLOADED_NOT_YET_VIEWED' else r.get('status','UNKNOWN')))
packets=collections.defaultdict(list)
for p in (O/'parallel-ready-jobs').glob('*.json'):
 d=json.loads(rd(p))
 for s in d.get('slots',[]):
  h=s.get('historicalID',s.get('historicalAlias'))
  if h:packets[h].append({'path':str(p),'ownership':d.get('ownership'),'costumeID':s['costumeID'],'observations':s.get('observations'),'references':([s['reference']] if s.get('reference') else s.get('references',[]))})
explicit={
'core__snake__alt__tuxedo':('REFERENCE_PARTIAL_TEXTURE_ONLY','The actual PS2 source is only a92×68 shoe texture, not a full tuxedo; accessible Delta tuxedos are a different era/remake UID. Planned invented Gala exists separately and does not resolve this official line.'),
'core__snake__alt__maintenance_uniform':('REFERENCE_PARTIAL_TEXTURE_ONLY','The available128×96 source is boot texture only, not the maintenance uniform or fullbody geometry.'),
'core__snake__alt__sneaking_suit':('REFERENCE_UV_TEXTURES_WITHOUT_FULLBODY','Body/arm/thigh/knee/boot UV textures are reachable, but no actual fullbody PS2 suit geometry has yet been visually attested; no clothing reconstructed blindly from UVs.'),
'core__snake__alt__snow':('REFERENCE_WRONG_PALETTE_OR_DEFAULT','Reached512×128 raw texture is olive, and reached fullbody official source is default TigerStripe; neither proves requested Snow fullbody palette.'),
'roster51__grayfox_tts__alt__visiere_ouverte':('REFERENCE_WRONG_APPEARANCE_STATE','Actual reached TTS fullbody art mgstts_art_g_0012.jpg has visor CLOSED; it cannot attest the requested open visor configuration.'),
'archive__virgil_at9__alt__deployed':('REFERENCE_WRONG_APPEARANCE_STATE','Reached image shows CLOSED pod; actual deployed open-pod joint/mechanism shape is not shown. No arbitrary unfolding invented.'),
'archive__elisa__alt__elisa_playable_trousers':('REFERENCE_BUST_ONLY','Reached190×284 illustration eli_ursula_j.jpg is a bust; trousers/shoes and fullbody are absent, so those garments cannot be inferred from it.'),
'core__raiden_mgs4__alt__outer_haven_damaged':('REFERENCE_CONCEPT_RETAIL_STATE_MISMATCH','Viewed official artbook p38 shows an early single-arm damaged concept; p39 has a coat concept. Historical retail notes attest armless black-coat/mouth-sword state but occlude arm ends and legs. Do not merge one-arm concept with armless retail.'),
'core__raiden_mgs4__alt__epilogue_human_shell':('REFERENCE_LOWER_BODY_OCCLUDED','Historical retail proof shows human-appearance torso above hospital bed but not trousers/feet. Viewed artbook pp36–39 does not provide final human-shell fullbody. Do not invent lower outfit.'),
'core__venom__alt__hospital_patient':('REFERENCE_FEET_OCCLUDED','Actual downloaded front/back patient screenshots1024×576 cut off the feet; no invented medical shoes or Ishmael gown.'),
'core__venom__alt__leather_jacket':('REFERENCE_EQUIPMENT_STATE_MISMATCH','Viewed actual fullbody leather outfit uses RED LEFT arm and no bandana, whereas this historical line explicitly requires silver arm+bandana. Need actual matching components/state before exact alias.'),
'core__venom__alt__tuxedo':('REFERENCE_EQUIPMENT_STATE_MISMATCH','Viewed actual tuxedo fullbody uses RED LEFT arm/no bandana; historical line requires HandOfJehuty+bandana. Tuxedo alone is attested but combined equipment state still needs proof.'),
'core__venom__alt__lil_chick_hat':('REFERENCE_EQUIPMENT_BODY_COLOR_MISMATCH','Viewed actual LilChick helmet screenshot uses olive fatigues; historical line says black fatigues. Helmet is attested; requested exact combined black-body state is not yet attested.'),
'core__old_snake__alt__octocamo_laughing':('REFERENCE_DOES_NOT_PROVE_REQUESTED_PATTERN','Viewed screenshot shows an OldSnake body wearing a beauty FaceCamo and ordinary camo, not a readable Laughing OctoCamo body pattern swatch.'),
'core__old_snake__alt__octocamo_gear':('REFERENCE_TOO_DARK_PARTIAL_BODY','Viewed crouched retail screenshot is dark and cuts lower legs; requested Gear pattern cannot be read reliably over full body.'),
'core__old_snake__alt__octocamo_haven':('REFERENCE_BACK_ONLY_PARTIAL_BODY','Viewed prone rear screenshot shows some Haven pattern on back/legs, but foreground/front, soles and face state remain occluded. No fullbody pattern extrapolation certified.'),
}
additional_path=O/'FINAL_ADDITIONAL_VISUAL_DISPOSITIONS_PRIVATE_V1.json'
additional={r['historicalID']:r for r in json.loads(rd(additional_path))['entries']} if additional_path.exists() else {}
targeted={}
targeted_paths=[B/'artists/a/pw-final-audit/msf/MSF16_TARGETED_REFERENCE_AUDIT_PRIVATE_V1.json',B/'artists/b/official/oldsnake-targeted-review/OLD_SNAKE_FINAL21_TARGETED_REVIEW_PRIVATE_V1.json',B/'artists/e/official/FINAL17_OFFICIAL_REFERENCE_REVIEW_AND_DELIVERY_PRIVATE_V1.json']
for pp in targeted_paths:
 if pp.exists():
  dd=json.loads(rd(pp))
  for tt in dd.get('rows',[]):
   tr=tt.get('reason') or (' '.join(x for x in [tt.get('missingEvidence'),tt.get('whyCurrentEvidenceDoesNotResolve')] if x))
   if tr:targeted[tt['historicalID']]={'path':str(pp),'reviewer':dd.get('reviewer'),'reason':tr,'status':tt.get('disposition',tt.get('status')),'requiresSeparateFullbodyRenderNecessarily':tt.get('requiresSeparateFullbodyRenderNecessarily')}
# Exact texture scarcity across remaining JF names was independently checked under Root's relaxed body+swatch rule.
pwpath=B/'artists/a/pw-final-audit/snake/PW_TARGETED_REFERENCE_AUDIT_PRIVATE_V1.json'
pwa=json.loads(rd(pwpath)) if pwpath.exists() else None
rows=[]
for m in mapping['rows']:
 h=m['historicalID'];r=recon[h];aa=attempts[h];pk=packets[h]
 if m['resolutionState'] not in ['REFERENCE_AND_STATIC_SOURCE_PENDING','BODY_FORM_CHANGE_SCOPE_REVIEW_PENDING']:
  state='RESOLVED_STATIC_SOURCE_OR_VERIFIED_REUSE';reason=m['resolutionReason']
 elif m['resolutionState']=='BODY_FORM_CHANGE_SCOPE_REVIEW_PENDING':
  state='BODY_FORM_CHANGE_SCOPE_REVIEW_PENDING';reason='Native UID is giant final mechanical SuperCyborg; actual human pre-transformation render is a distinct body-scale state, never substitute it for giant base without explicit body-state admission.'
 elif h in targeted:
  state='DEFERRED_AFTER_TARGETED_VISUAL_AUDIT';reason=targeted[h]['reason']
 elif h in additional:
  state=additional[h]['status'];reason=additional[h]['reason']
 elif pwa and m['historicalUID']=='core__snake_pw' and m['reconciledOfficialID'].startswith('official--jungle-fatigues-'):
  state='DEFERRED_EXACT_PRIMARY_CAMO_SWATCH_MISSING';reason='SameUID fullbody JungleFatigues template is available and was viewed. White and AUSCAM were created from actual readable references. For this specific remaining named pattern, no corresponding readable primary color/repeat/swatches were identified by targeted bounded audit; outfit name and unlock table alone do not prove the texture. Fullbody distinct render is NOT required; missing item is its exact pattern evidence.'
 elif h in explicit:state,reason=explicit[h]
 elif pk:
  state='VISUALLY_ATTESTED_PACKET_AWAITING_ARTIST_OR_OUTPUT';reason='Actual image references were viewed and a UID-specific packet is ready or reserved; see ownership and visible-region qualifications. No sprite is counted until exact PNG proposal exists.'
 elif any(x.get('kind')=='IMAGE_NOT_YET_VIEWED' for x in aa):
  state='DOWNLOADED_REFERENCE_REQUIRES_VISUAL_INSPECTION';reason='Actual image bytes and SHA are available, but this costume has not yet received a complete visual fullbody/state check. Download success is not costume proof.'
 elif any(x.get('kind')=='HTML_PAGE_FETCHED' for x in aa):
  state='DEFERRED_READABLE_COSTUME_IMAGE_NOT_YET_ATTESTED';reason='Historical HTML page was fetched but is not image proof. Candidate image downloads or accessible alternate gallery must supply the exact fullbody/state; CreativeUncut image endpoints reached403 despite page200.'
 elif aa:
  kinds=collections.Counter(x.get('kind') for x in aa);state='DEFERRED_HISTORICAL_REFERENCE_UNAVAILABLE';reason='All attempted historical references failed to supply a readable costume image: '+', '.join(f'{n}×{k}' for k,n in kinds.items())+'. HTTP/network responses and URLs are preserved below; no invented canonical substitute.'
 else:
  state='DEFERRED_NO_READABLE_FULLBODY_SOURCE_IN_CURRENT_AUDIT';reason='No readable fullbody/state image has been visually established in current pass; historical row/URLs alone are not source proof. Existing originals/native poses remain preserved.'
 rows.append({'historicalID':h,'uid':m['historicalUID'],'costumeID':m['reconciledOfficialID'],'costume':m['historicalCostumeName'],'currentMappingState':m['resolutionState'],'referenceDisposition':state,'reason':reason,'targetedVisualAudit':targeted.get(h),'additionalVisualAuditProof':str(additional_path) if h in additional else None,'PWTargetedAudit':str(pwpath) if pwa and m['historicalUID']=='core__snake_pw' else None,'historicalLimitsPreserved':r['historicalLimits'],'attemptedHistoricalReferences':aa,'preparedPackets':pk,'historicalReferenceURLs':r['referenceURLs'],'animationCount':0})
d={'schema':'cqc.static.official416-reference-dispositions/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputMap':{'path':str(map_path),'sha256':hashlib.sha256(rd(map_path)).hexdigest()},'counts':dict(collections.Counter(r['referenceDisposition'] for r in rows)),'qualification':'FROZEN final bounded source audit after all reserved Source proposals were written. No more research/generation in this pass. Deferred means exact source not attested through listed attempts, not claim that canonical outfit never exists. Downloaded-but-unviewed is explicitly unresolved. Static-source mapping controls completion; no animation/runtime completion.','rows':rows}
p=O/'OFFICIAL416_REFERENCE_DISPOSITIONS_PRIVATE_V1.json';p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
c=O/'OFFICIAL416_REFERENCE_DISPOSITIONS_PUBLIC_V1.csv'
with c.open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['historicalID','uid','costumeID','costume','currentMappingState','referenceDisposition','reason','attemptCount','packetCount']);w.writeheader()
 for r in rows:w.writerow({**{k:r[k]for k in w.fieldnames if k not in ['attemptCount','packetCount']},'attemptCount':len(r['attemptedHistoricalReferences']),'packetCount':len(r['preparedPackets'])})
print(json.dumps({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(rd(p)).hexdigest(),'counts':d['counts'],'CSV':str(c)}))
