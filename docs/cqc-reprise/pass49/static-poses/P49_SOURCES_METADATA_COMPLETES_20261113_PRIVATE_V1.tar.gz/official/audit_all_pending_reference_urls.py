import os,json,pathlib,urllib.request,urllib.error,urllib.parse,concurrent.futures,hashlib,io,datetime
from html.parser import HTMLParser
from PIL import Image
B=pathlib.Path('/tmp/cqc-static-20261113');O=B/'official';out=O/'all-pending-reference-audit';out.mkdir(exist_ok=True)
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb') as f:return f.read()
rows=json.loads(read(O/'OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json'))['rows'];pending=[r for r in rows if r['resolutionState'] in ['REFERENCE_AND_STATIC_SOURCE_PENDING','POSSIBLE_ORIGINAL_EQUIVALENCE_VISUAL_REVIEW_PENDING']]
by={}
for r in pending:
 for u in r['referenceURLs']:by.setdefault(u,[]).append(r['historicalID'])
class Images(HTMLParser):
 def __init__(self):super().__init__();self.urls=[];self.title=[];self.intitle=False
 def handle_starttag(self,t,a):
  d=dict(a)
  if t=='title':self.intitle=True
  if t in ['img','source']:
   for k in ['src','data-src','data-original']:
    if d.get(k):self.urls.append(d[k])
  if t=='meta' and d.get('property',d.get('name','')).lower() in ['og:image','twitter:image'] and d.get('content'):self.urls.append(d['content'])
 def handle_endtag(self,t):
  if t=='title':self.intitle=False
 def handle_data(self,d):
  if self.intitle:self.title.append(d)
def fetch(u):
 key=hashlib.sha256(u.encode()).hexdigest();p=out/(key+'.body')
 try:
  req=urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'})
  with urllib.request.urlopen(req,timeout=20) as resp:
   ct=resp.headers.get('Content-Type','');dat=resp.read(5*1024*1024+1);url=resp.geturl();status=resp.status
  clipped=len(dat)>5*1024*1024
  if clipped:dat=dat[:5*1024*1024]
  p.write_bytes(dat);r={'url':u,'rows':by[u],'httpStatus':status,'finalURL':url,'contentType':ct,'file':str(p),'bytes':len(dat),'sha256':hashlib.sha256(dat).hexdigest(),'bodyTruncated':clipped}
  try:
   im=Image.open(io.BytesIO(dat));im.verify();r.update({'kind':'IMAGE_NOT_YET_VIEWED','dimensions':list(im.size)})
  except Exception:
   if 'html' in ct or dat.lstrip().startswith((b'<!DOCTYPE',b'<html',b'<!doctype')):
    text=dat.decode('utf-8','replace');parser=Images();parser.feed(text);imgs=[]
    for s in parser.urls:
     v=urllib.parse.urljoin(url,s)
     if v.startswith(('http://','https://')) and not any(z in v.lower() for z in ['favicon','logo','avatar','doubleclick','tracking','sprite','icon','pixel.gif','facebook','googleads']):
      if v not in imgs:imgs.append(v)
    r.update({'kind':'HTML_PAGE_FETCHED','title':' '.join(parser.title)[:300],'candidateImageURLs':imgs[:30],'needsVisualSourceSelection':True})
   else:r['kind']='NON_IMAGE_REFERENCE_DOCUMENT_OR_RESPONSE'
  return r
 except urllib.error.HTTPError as e:return {'url':u,'rows':by[u],'kind':'HTTP_SOURCE_UNAVAILABLE','httpStatus':e.code,'reason':str(e),'retryAttempted':False}
 except Exception as e:return {'url':u,'rows':by[u],'kind':'NETWORK_OR_PARSE_UNAVAILABLE','reason':str(e),'retryAttempted':False}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 res=[]
 for i,r in enumerate(pool.map(fetch,by),1):
  res.append(r)
  if i%20==0:print('audited',i,'of',len(by),flush=True)
path=out/'ALL_PENDING_REFERENCE_URL_AUDIT_PRIVATE_V1.json';path.write_text(json.dumps({'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'historicalRowsAttempted':len(pending),'uniqueURLs':len(by),'results':res,'scope':'Read-only public reference requests using inherited network/CA, no secrets/auth bypass, no generation from unread images.'},ensure_ascii=False,indent=2)+'\n')
print('completed',len(res),'URLs for',len(pending),'rows',str(path),flush=True)
