import pathlib,urllib.request,urllib.parse,concurrent.futures,json,hashlib,io,re
from html.parser import HTMLParser
from PIL import Image
B=pathlib.Path('/tmp/cqc-static-20261113/official/metalgearsolidbe-gallery-discovery');links=json.load(open(B/'mgs4_art-links.json'));urls=[urllib.parse.urljoin('https://www.metalgearsolid.be/',u) for u in links if u.startswith('metal_gear_solid_4_artworks_')]
class P(HTMLParser):
 def __init__(self):super().__init__();self.src=[]
 def handle_starttag(self,t,attrs):
  d=dict(attrs)
  if t=='img' and d.get('src'):self.src.append({'src':d['src'],'alt':d.get('alt'),'title':d.get('title')})
def f(u):
 try:
  dat=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=20).read();p=P();p.feed(dat.decode('utf8','replace'));res=[]
  for x in p.src:
   url=urllib.parse.urljoin(u,x['src']);lower=url.lower()
   if '/images/' not in lower or not any(k in lower for k in ['mgs4','metal-gear-solid','metal_gear_solid']):continue
   if any(k in lower for k in ['banner','top-bar','menu','_p.','button','courbe']):continue
   try:
    b=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=20).read();im=Image.open(io.BytesIO(b));im.verify()
    if im.width<400 and im.height<400:continue
    path=B/(hashlib.sha256(url.encode()).hexdigest()[:14]+'-'+url.rsplit('/',1)[-1]);path.write_bytes(b);res.append({'galleryPage':u,'url':url,'file':str(path),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'dimensions':list(im.size),'alt':x['alt'],'title':x['title'],'viewed':False})
   except Exception as e:res.append({'galleryPage':u,'url':url,'error':str(e)})
  return res
 except Exception as e:return [{'galleryPage':u,'error':str(e)}]
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:res=[r for rr in pool.map(f,urls) for r in rr]
p=B/'MGS4_ACTUAL_GALLERY_IMAGE_RECEIPT_PRIVATE_V1.json';p.write_text(json.dumps({'pagesFetched':len(urls),'images':res,'onlyLiteralGalleryLinks':True},ensure_ascii=False,indent=2)+'\n');print('pages',len(urls),'images',sum('file' in x for x in res))
for r in res:print(r.get('dimensions'),r.get('url'),r.get('file',''),r.get('error',''))
