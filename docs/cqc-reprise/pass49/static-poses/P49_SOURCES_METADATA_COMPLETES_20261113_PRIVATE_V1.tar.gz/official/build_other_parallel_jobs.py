import os,json,pathlib,hashlib,datetime
B=pathlib.Path('/tmp/cqc-static-20261113');O=B/'official';D=O/'parallel-ready-jobs'
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb') as f:return f.read()
rs=json.loads(read(O/'OFFICIAL_COSTUMES_416_CURRENT_RECONCILIATION_PRIVATE_V1.json'))['rows'];by={(r['uid'],r['id']):r for r in rs}
refs=json.loads(read(O/'other2-official-refs/FETCH_RECEIPT_PRIVATE_V1.json'));rb={}
for r in refs:
 if r['status']=='DOWNLOADED_NOT_VIEWED':rb.setdefault((r['uid'],r['id']),[]).append(r)
specs=[
('core__meryl_mgs1',[
 ('official--sneaking-suit-integral','Actual PS1 Integral fullbody screenshot: dark charcoal segmented sneaking torso/gray-purple trousers, dark gloves/boots, thin blue forehead band, red short flared hair, belt/groin harness, right-side thigh/knee equipment. Preserve selected MGS1 Meryl identity, NOT MGS4 wedding or TTS face.'),
 ('official--deguisement-genome','Actual original PS1 encounter closeup plus overhead wholebody. Olive/khaki Genome uniform, dark tactical balaclava/helmet concealing face, fingerless gloves, original FAMAS shape visible in closeup. Keep selected Meryl adult female proportions under uniform, no generic male body. Tiny low-res wholebody means fine seams/boots are source-limited.')]),
('roster51__meryl_tts',[
 ('official--sneaking-suit','Fullbody original GameCube bonus render shows Snake LEFT and Meryl RIGHT. Use ONLY Meryl RIGHT: brown bob, NO headband, dark segmented torso/gloves, gray pants, dark belt/groin harness/thigh holster, black reinforced knees/boots. Keep selected TTS face distinct from PS1 Meryl.'),
 ('official--veste-fin','Actual GameCube ending closeup: Meryl wears orange/tan sleeveless padded vest with raised collar and rectangular chest pockets, short brown bob, no bandana. Lower legs occluded; retain selected TTS native pants/boots as closest interpretation, explicitly not certified from ending shot.')]),
('roster51__liquid_tts',[
 ('official--torse-nu-duel','Actual original GameCube fullbody back view and chest/face closeup: adult muscular bare torso, long blond hair, black gloves, brown trousers, dark belt and brown/tan tall boots. Remove original longcoat, keep exact TTS identity not PS1 Liquid; neutral nonsexual standing fight sprite, not punch/action. Official render also shows longcoat variant for face/body only.')]),
('core__volgin',[
 ('official--officer-greatcoat','Actual PS2 fullbody official retail render: long olive-gray double-breasted military greatcoat with dull gold buttons/epaulettes, broad red gloves, red boots, scarred heavy tall adult face/build. Preserve exact PS2 Volgin UID, not Delta/ManOnFire. Artist must compare native Original: if already exact greatcoat, report Original equivalence rather than duplicate.')]),
('core__olga_mgs2',[
 ('official--uniforme-plant','Original official MGS2 concept sheet TOP RIGHT shows Plant uniform full front/back: short cropped hair, button field jacket with chest pockets and sleeves, tucked baggy trousers and laced boots. BOTTOM panels show another ninja body: DO NOT copy that armor or merge with separate Ninja Olga UID. Source is monochrome: exact palette not independently attested, keep restrained ordinary olive field-uniform interpretation/qualify closest. Female adult Olga own selected Tanker face/build retained, no eyepatch.')])
]
for uid,slots in specs:
 orig=B/'artists/official'/(uid+'-original-right-reference.png')
 if not orig.exists():continue
 dat=read(orig);copy=D/(uid+'-original-right.png');copy.write_bytes(dat)
 jp=O/(uid+'-job-private.json');j=json.loads(read(jp)) if jp.exists() else {}
 ss=[]
 for cid,obs in slots:
  r=by[uid,cid];rr=rb.get((uid,cid),[])
  ss.append({'uid':uid,'costumeID':cid,'historicalID':r['historicalID'],'label':r['costume'],'classification':'official-same-period-costume','references':[{'path':q['file'],'url':q['url'],'sha256':q['sha256'],'bytes':q['bytes'],'viewedBy':'official_inventory','viewed':True} for q in rr],'observations':obs,'poseCount':1,'animationCount':0})
 obj={'schema':'cqc.static.official.parallel-ready-job/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'uid':uid,'name':by[uid,slots[0][0]]['name'],'incarnation':j.get('incarnation',by[uid,slots[0][0]]['game']),'ownership':'AVAILABLE_FOR_ROOT_ASSIGNMENT; official_inventory will not generate these UID pending coordination','originalSourceCopied':{'path':str(copy),'bytes':len(dat),'sha256':hashlib.sha256(dat).hexdigest(),'frame':j.get('originalPose',{}).get('frameRect'),'viewedByArtistRequired':True},'slots':ss,'atlas':{'posePerCostume':1,'maxLocalReferences':5,'maxSlots':9,'facing':'RIGHT','animations':False},'limits':['Artist must inspect Original copy and each chosen image before imagegen.','No cross-age/remake body/identity merges; preserve body/height/anatomical center, adapt only attested same-era costume.','If exact official outfit already equals Original, provide explicit physical Original-source reuse mapping instead of drawing.','Where source is monochrome/partial/lowres, qualify palette or hidden detail; do not certify absolute1:1.','One quiet neutral static pose per costume; no animation or combat admission.','Raw imagegen PNG bytes stay untouched; real dimensions/rects/bodyDatum/feet recorded, no CPU image editing.','Existing Source holds/refusals must never be retried; no blocked costume is included knowingly.'],'alreadyGeneratedByOfficialInventory':False}
 p=D/(uid+'-official-parallel-ready.json')
 if p.exists():
  print(str(p),'preserved existing packet');continue
 p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(str(p),len(ss))
