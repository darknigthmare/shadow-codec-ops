import pathlib,json,os,urllib.parse,urllib.request,urllib.error,hashlib,io,concurrent.futures
from html.parser import HTMLParser
from PIL import Image
B=pathlib.Path('/tmp/cqc-static-20261113/official');a=json.load(open(B/'all-pending-reference-audit/ALL_PENDING_REFERENCE_URL_AUDIT_PRIVATE_V1.json'))['results'];O=B/'html-derived-images';O.mkdir(exist_ok=True)
class P(HTMLParser):
 def __init__(self):super().__init__();self.urls=[]
 def handle_starttag(self,t,attrs):
  d=dict(attrs)
  if t in ['img','source']:
   for k in ['src','data-src','data-original']:
    if d.get(k):self.urls.append(d[k])
items={}
for r in a:
 if r['kind']!='HTML_PAGE_FETCHED':continue
 p=P();p.feed(pathlib.Path(r['file']).read_bytes().decode('utf-8','replace'))
 for s in p.urls:
  u=urllib.parse.urljoin(r['finalURL'],s);ul=u.lower()
  creative='creativeuncut.com' in ul and '/art/' in ul
  konami='konami.com' in ul and (any(x in ul for x in ['_pic','pic_','/pic/camo_unifo','/window/']) or ('/imgs/cate_collabo/ut/img_chara_' in ul))
  photos=any(x in ul for x in ['images.steamusercontent.com/ugc/','livedoor.blogimg.jp/tanukioyabun/','images.squarespace-cdn.com/','static.accelerated-ideas.com/generic/images/metalgearsolid5/','ameba.jp/user_images/'])
  if not u.startswith(('https://','http://')) or not (creative or konami or photos):continue
  if any(z in ul for z in ['thumb','/img_chara_01','_logo','header','_ti.','title','gnavi']):continue
  v=items.setdefault(u,{'url':u,'discoveredOn':[],'rows':[]})
  if r['url'] not in v['discoveredOn']:v['discoveredOn'].append(r['url'])
  for q in r['rows']:
   if q not in v['rows']:v['rows'].append(q)
def f(x):
 u=x['url'];p=O/(hashlib.sha256(u.encode()).hexdigest()+'.image')
 try:
  with urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=20) as resp:dat=resp.read(5*1024*1024+1)
  if len(dat)>5*1024*1024:return dict(x,status='TOO_LARGE_NOT_DOWNLOADED')
  im=Image.open(io.BytesIO(dat));im.verify();p.write_bytes(dat)
  return dict(x,status='IMAGE_DOWNLOADED_NOT_YET_VIEWED',file=str(p),bytes=len(dat),sha256=hashlib.sha256(dat).hexdigest(),dimensions=list(im.size))
 except Exception as e:return dict(x,status='IMAGE_REFERENCE_UNAVAILABLE',reason=str(e),retried=False)
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 res=[]
 for i,r in enumerate(pool.map(f,items.values()),1):
  res.append(r)
  if i%20==0:print('derived images',i,'/',len(items),flush=True)
p=O/'HTML_DERIVED_REFERENCE_IMAGE_FETCH_PRIVATE_V1.json';p.write_text(json.dumps({'results':res,'imagesNeedVisualReview':True,'photosAreLiteralHTMLAssetsNotGuessedURLs':True},ensure_ascii=False,indent=2)+'\n');print('DONE',len(res),sum(r['status']=='IMAGE_DOWNLOADED_NOT_YET_VIEWED' for r in res),str(p),flush=True)
