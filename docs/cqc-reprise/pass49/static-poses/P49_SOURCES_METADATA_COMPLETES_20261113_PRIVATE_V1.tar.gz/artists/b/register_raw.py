import hashlib,json,os,pathlib,sys
from PIL import Image
uid,filename,slot_text=sys.argv[1:4]
version=int(sys.argv[4])if len(sys.argv)>4 else 1
slots=json.loads(slot_text)
out=pathlib.Path('/tmp/cqc-static-20261113/artists/b')/uid;out.mkdir(parents=True,exist_ok=True)
p=pathlib.Path(filename);assert p.parent==pathlib.Path('/workspace/generated_images')and p.suffix=='.png'
with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:b=f.read()
dst=out/(uid+'-static-missing-raw-v'+str(version)+'.png')
if dst.exists():assert dst.read_bytes()==b
else:
 with dst.open('xb')as f:f.write(b)
assert hashlib.sha256(dst.read_bytes()).digest()==hashlib.sha256(b).digest()
im=Image.open(dst);assert im.mode=='RGBA';alpha=im.getchannel('A');cols=min(3,len(slots));rows=(len(slots)+cols-1)//cols
items=[]
for i,family in enumerate(slots):
 col=i%cols;row=i//cols;x0=im.width*col//cols;x1=im.width*(col+1)//cols;y0=im.height*row//rows;y1=im.height*(row+1)//rows
 cut=alpha.crop((x0,y0,x1,y1));bb=cut.point(lambda n:255 if n>16 else 0).getbbox();assert bb
 w=x1-x0;h=y1-y0
 foot=cut.crop((0,max(bb[1],bb[3]-20),w,bb[3])).point(lambda n:255 if n>127 else 0).getbbox()
 footX=(foot[0]+foot[2])/2 if foot else (bb[0]+bb[2])/2
 items.append({'index':i,'uid':uid,'costumeId':family,'frameRect':[x0,y0,w,h],'bodyBounds':[bb[0],bb[1],bb[2]-bb[0],bb[3]-bb[1]],'pivot':[footX/w,bb[3]/h],'footprint':{'floorY':bb[3],'centerX':footX,'method':'opaque-bottom20px-footprint'},'onePoseOnly':True,'facing':'right','frameOpaqueBoundsFit':bb[0]>0 and bb[1]>0 and bb[2]<w and bb[3]<h})
blank=[]
for i in range(len(slots),cols*rows):
 col=i%cols;row=i//cols;x0=im.width*col//cols;x1=im.width*(col+1)//cols;y0=im.height*row//rows;y1=im.height*(row+1)//rows
 aa=alpha.crop((x0,y0,x1,y1));hist=aa.histogram();blank.append({'cell':i,'alphaAbove16':sum(hist[17:]),'alphaExtrema':aa.getextrema()})
r={'schema':'cqc.static-onepose-generated/1','uid':uid,'version':version,'sourceGeneratorPath':str(p),'canonicalPath':str(dst),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'width':im.width,'height':im.height,'mode':im.mode,'alphaExtrema':alpha.getextrema(),'cornerRGBA':[im.getpixel(xy)for xy in[(0,0),(im.width-1,0),(0,im.height-1),(im.width-1,im.height-1)]],'cols':cols,'rows':rows,'slots':items,'emptyCells':blank,'QAstatus':'DRAWN_STATIC_CANDIDATE_AGENT_VISUAL_REVIEW_PENDING_ROOT','animations':False,'SourcePixelsModified':False}
receipt=out/('RAW_V'+str(version)+'_RECEIPT_PRIVATE.json');assert not receipt.exists();receipt.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r,ensure_ascii=False))
