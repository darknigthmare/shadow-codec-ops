import hashlib,json,os,pathlib,sys
base=pathlib.Path('/tmp/cqc-static-20261113/artists/b')
queue=pathlib.Path('/tmp/cqc-static-20261113/dispatch/PLANNED_READY_QUEUE_B_V1.json')
idx=int(sys.argv[1]); species=sys.argv[2]if len(sys.argv)>2 else 'personalized anthropomorphic woodland mammal'
observation=sys.argv[3]if len(sys.argv)>3 else ''
data=json.loads(queue.read_text());job=data['jobs'][idx];uid=job['uid'];out=base/'global'/uid;out.mkdir(parents=True,exist_ok=True)
assert not job.get('holds'), 'HOLD:do not generate'
src=pathlib.Path(job['originalPose']['file']); pin=job['originalPose']['assetProof']
before=src.stat()
with os.fdopen(os.open(src,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:raw=f.read()
assert hashlib.sha256(raw).hexdigest()==pin['sha256'] and len(raw)==pin['bytes'];assert src.stat()==before
ref=out/(uid+'-original-reference.png')
if ref.exists():assert ref.read_bytes()==raw
else:
 with ref.open('xb')as f:f.write(raw)
age=job.get('ageAndGeometry',{}).get('ageTreatment','')
young=(age.startswith('YOUTHFUL_') or uid in ['roster50__george_mgr','npc53__elsie_frances_acid'])
families=job['missingFamilies']; cols=min(3,len(families));rows=(len(families)+cols-1)//cols
layout=('SQUARE'if rows==cols else 'LANDSCAPE')+' transparent PNG, '+str(cols)+' columns x '+str(rows)+' rows, equalcells'
general='NEW STATIC COSTUME ATLAS, NOT animation. Attached multi-pose reference supplies exact identity and outfit/equipment ONLY, never copy its layout. Target '+job['name']+' / '+job['incarnation']+' / '+job['originalGame']+'. '+observation+' Produce exactly '+str(len(families))+' distinct FULLBODY figures, ONE neutralready pose per listedcostume, all front3/4 facingRIGHT. Preserve age, face/hair/skin/bodybuild, outfitpalette and identity; use the specifically provided edition, no cross-era substitution. Respect original posture if seated/wheelchair/flying/box/machine rather than forcinghumanstanding. '+layout+'. Each figure must fullyfititsowncell with generous24px transparent gutters, consistent localfootbaseline, head/ears/toes/weapons fullyvisible and no overlap. Leave unusedcells ENTIRELYtransparent. No text/labels/grid/backdrop/floor/shadow/haze/extras. Detailed crisp painted2D/2.5D fightinggameassets except explicitretro. Do not generate any existingcostume or anotherpose.'
weapon=job.get('loadoutQualification',{})
if weapon.get('visualFirearmPresent'):general+=' Preserve the ACTUALLYDRAWN firearm shape/accessories and grip fromreference, lowered/neutral notfiring; righttriggerhand,leftforeendsupport. Generic weapon metadata is not canon proof; invent no modelname, sword, magic or foreignloadout.'
else:general+=' Original has no verified visiblefirearm. Preserve any ACTUALLYDRAWN non-firearm equipment/blades/tools fromreference, or stayunarmed if referenceisunarmed; invent no addedgun or foreignweapon.'
if young:general+=' SAME YOUNG AGE asreference in EVERY human/furry style, childlikeproportions, fullycovered practicalclothing, no agingup, no sexualization and NO graphicinjury/gore.'
descs={
'retro':'A newlyAUTHORED retro16bitpixelartsprite fromscratch with deliberate hardpixelclusters/limitedpalette, exactidentity/outfitcodes; not blurred/downsampled reference.',
'nextgen':'A fullynew detailed highdefinition painted2D/2.5D rendering of exactoriginalidentity/costume, not pixelupscale.',
'cyborg':'TRUE personalized full-body MetalGearRising-style CYBERNETICCHASSIS, retainrecognizableface/hair/headgear but body is connected metalarmor, blackcarbon artificialmuscle, mechanical spine/hip/neck and elbow/knee/anklebearings, realmetalhands/feet, signaturepalette/utilitycodes. Not clothingwithneon or genericRaidenclone. Keep age and originalgeometry/personhood.',
'survive':'DITÉ EXPEDITION: sameincarnation in weathered patched originalpalette/outfit, salvagedoxygenbottle/filter+hose, functionalexpeditiongear/pack and protectivepads; coherent personalized postapocalypse, no unrelatedera outfit or loss ofidentity.',
'metalgear':'A REAL whollymechanical INDUSTRIAL METAL GEAR weapons/commandplatform using exactpersonalpalette/iconicmotifs: broad armoredTURRETCHASSIS, facetedmechanicalsensors, TWO heavy reverse-jointedREX/PeaceWalker hydrauliclegs with alljointsattached and groundedmachinefeet (adapt to originalnonhumangeometry if needed), rigidlymountedweapon/toolpods. NOT humanoidrobot/maninarmor, nohuman-shaped torso/waist/arms/hands/clothing/skin/face/hair/beard, noheldrifle. Clear giantwar-machine silhouette distinctfromcyborg. No organicbodyparts.',
'tuxedo':'GALA: tailoredblack/whiteformalwear adaptedtocharacter and age, sensibleboots and discreetidentityaccessories; keepface/headgear/hair, neutralpracticalfullycoveredpose. For machine/box use black-whiteformalpanelstyling/bowtie-like mechanicalmotif while preserving actualmachine/boxgeometry, not a humaninsuit.',
'zombie':('NON-GRAPHIC ageappropriate eerie costume: SAMEyoung/ambiguousage and body, palegraytiredcomplexion, subtlecloudyeyes, worn patchedoriginalclothing, no wounds/blood/exposedbone/ribs/missingtissue or adultbody. No violence.'if young else 'Clearly DECOMPOSED fictionaladult undead: recognizableface/hair/outfitpalette with graynecrosis/cloudyeyes, visiblemissingcheek/forearmtissue exposingjawbone/smallbone, a fewribedges through sidefabrictear, bonyhand, tornweatheredgear/drydarkstains. Keep chest/pelviscovered and neutralpose; no attack/ongoinginjury/bloodspray/nudity. If alreadycyborg/machine, decayed remainingorganicface or corroded cracked infectedmechanics instead of inventing humanflesh.'),
'furry':'FullyANTHROPOMORPHIC '+species+', realanimalmuzzle/ears/furbody/paws/tailadaptedintact to exactoriginalclothing/palette/equipment/headgear, personalizedrecognizableidentity, nothumanfacewithpastedears. Sameage/proportions, fullycovered practicaloutfit, nosexualization.'}
lines=[general]
for i,f in enumerate(families):lines.append('SLOT'+str(i)+' row'+str(i//cols+1)+' col'+str(i%cols+1)+' '+f.upper()+': '+descs[f])
prompt='\n'.join(lines)
record={'queueIndex':idx,'uid':uid,'name':job['name'],'missingFamilies':families,'referenceCopy':str(ref),'referenceSHA256':pin['sha256'],'SourceOriginalStatsUnchanged':True,'species':species,'youngSafetyOverride':young,'observation':observation,'cols':cols,'rows':rows,'prompt':prompt,'job':job}
(out/'PREPARED_JOB_PRIVATE_V1.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');(out/'PROMPT_V1.txt').write_text(prompt)
print(json.dumps({k:record[k]for k in ['queueIndex','uid','name','missingFamilies','referenceCopy','species','youngSafetyOverride','cols','rows']},ensure_ascii=False))
