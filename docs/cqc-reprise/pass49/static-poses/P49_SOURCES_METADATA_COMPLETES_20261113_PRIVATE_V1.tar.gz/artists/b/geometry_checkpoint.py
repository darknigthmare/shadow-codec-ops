import json,pathlib,hashlib,datetime,sys
import numpy as np
from PIL import Image
B=pathlib.Path('/tmp/cqc-static-20261113/artists/b')
Q=json.load(open('/tmp/cqc-static-20261113/dispatch/PLANNED_READY_QUEUE_B_V1.json'))['jobs']
limit=int(sys.argv[1])
overrides={
 'roster50__marv_mg2':{'retro':[0,0,418,407],'metalgear':[0,407,418,429]},
 'roster50__diane_mg1':{'metalgear':[0,418,418,411],'furry':[0,829,418,425]},
 'roster50__cecile_pw':{'retro':[0,0,512,486],'metalgear':[0,486,512,538],'survive':[1024,0,512,481],'furry':[1024,481,512,543]},
 'roster50__boris_mgr':{'retro':[0,0,418,406],'metalgear':[0,406,418,430]},
 'pass40__raiden_r00':{'survive':[512,0,478,512],'metalgear':[990,0,546,490],'furry':[1024,490,512,534]},
 'npc53__viggo_hach_acid':{'tuxedo':[418,418,418,430],'zombie':[836,418,418,430]},
 'npc53__paramedic_mpo':{'retro':[0,0,418,411],'metalgear':[0,411,418,425]},
 'npc53__mosquito_tpp':{'metalgear':[0,418,418,412],'furry':[0,830,418,424]},
 'npc53__carlos_esmeralda_mgs1':{'metalgear':[0,418,418,426],'furry':[0,844,418,410],'tuxedo':[418,418,418,432],'zombie':[836,418,418,432]},
 'core__quiet':{'metalgear':[0,0,1174,887],'zombie':[1174,0,600,887]},
 'core__olga_ninja':{'cyborg':[512,0,512,501],'furry':[512,501,512,523]},
 'core__clown':{'metalgear':[1024,0,512,501],'furry':[1024,501,512,523]},
 'completion__ronald_lensen':{'retro':[0,0,418,410],'metalgear':[0,410,418,426]},
 'completion44__zanzibar_mercenary_44':{'metalgear':[0,418,432,418],'tuxedo':[432,418,404,418]},
 'completion44__saintlogic_guard_44':{'metalgear':[1024,0,512,495],'furry':[1024,495,512,529]},
 'archive__social_agent':{'retro':[0,0,418,410],'metalgear':[0,410,418,420],'furry':[0,830,418,424]},
 'archive__naked_delta':{'metalgear':[1024,0,512,494],'furry':[1024,494,512,530]},
 'archive__dan_survive':{'metalgear':[1024,0,512,495],'furry':[1024,495,512,529]}
}
visual={'pass40__raiden_r00':['Zombie design incorrectly exposes bone-like ribs/hand despite already full cybernetic body; hold zombie for targeted Root review, prefer mechanical corrosion only.'], 'roster50__huey_pw':['All six inhabited/human/furry versions preserve seated powered wheelchair. Autonomous MG concept uses biped legs despite requested wheeled platform; Root review concept geometry.'], 'core__sundowner':['Zombie design incorrectly exposes bone-like ribs/hand despite already full cybernetic body; hold zombie for targeted Root review, prefer mechanical corrosion only.'], 'core__snake_mg2':['V1 background alpha contamination; V2 imagegen background-only repair preferred, V1 preserved byte-exact.']}
entries=[]
for i,j in enumerate(Q[:limit]):
 d=B/j['uid'];raw=d/('RAW_V2_RECEIPT_PRIVATE.json' if j['uid'] in ['core__snake_mg2','core__ocelot_mgs1'] else 'RAW_V1_RECEIPT_PRIVATE.json')
 if not raw.exists():continue
 r=json.loads(raw.read_text());p=d/'STATIC_GEOMETRY_PREFERRED_V1_PRIVATE.json'
 if not p.exists():
  a=np.array(Image.open(r['canonicalPath']).getchannel('A'))
  for s in r['slots']:
   rect=overrides.get(j['uid'],{}).get(s['costumeId'],s['frameRect']);x,y,w,h=rect;sub=a[y:y+h,x:x+w];ys,xs=np.where(sub>16);bb=[int(xs.min()),int(ys.min()),int(xs.max()+1-xs.min()),int(ys.max()+1-ys.min())]
   y7,x7=np.where(sub>127);floor=int(y7.max()+1) if len(y7) else bb[1]+bb[3];fy,fx=np.where((sub>127)&(np.indices(sub.shape)[0]>=floor-20));cx=float((fx.min()+fx.max()+1)/2) if len(fx) else bb[0]+bb[2]/2
   s.update(frameRect=rect,bodyBounds=bb,pivot=[cx/w,floor/h],footprint={'floorY':floor,'centerX':cx,'method':'opaque-bottom20px-footprint'},frameOpaqueBoundsFit=bool(bb[0]>0 and bb[1]>0 and bb[0]+bb[2]<w and bb[1]+bb[3]<h))
   s['needsCanvasEdgeReview']=bool((x==0 and (sub[:,0]>16).any())or(y==0 and (sub[0]>16).any())or(x+w==r['width'] and (sub[:,-1]>16).any())or(y+h==r['height'] and (sub[-1]>16).any()))
  r.update(schema='cqc.static-preferred-geometry/1',rawReceipt=str(raw),metadataOnly=True,SourcePixelsModified=False,geometryNotes=['Per-costume variable rectangles preserve entire original pixels and avoid neighboring antenna/ear bleed. No PNG raster editing.'],visualReviewNotes=visual.get(j['uid'],[]))
  p.write_text(json.dumps(r,indent=2)+'\n')
 pref=json.loads(p.read_text())
 entries.append({'queueIndex':i,'uid':j['uid'],'poses':len(r['slots']),'rawPath':r['canonicalPath'],'rawSHA256':r['sha256'],'geometryPath':str(p),'geometrySHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'geometryEdgeReviewEntries':[s['costumeId'] for s in pref['slots'] if s.get('needsCanvasEdgeReview')],'visualReviewNotes':pref.get('visualReviewNotes',[])})
obj={'schema':'cqc.static-artist-b-global-progress/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'queueUIDs':67,'targetPoses':419,'drawnUIDs':len(entries),'drawnPoses':sum(e['poses'] for e in entries),'newPNGs':len(entries),'moderationFailures':len(list((B/'global').glob('*/GENERATION_FAILURE_V1.json'))),'completedQueueIndices':[e['queueIndex'] for e in entries],'nextQueueIndex':limit,'entries':entries,'SourcePixelsModified':False,'animations':False,'RootReviewPending':True}
out=B/f'GLOBAL_B_PROGRESS_{limit}_PRIVATE_V1.json'
with out.open('x') as f:f.write(json.dumps(obj,indent=2)+'\n')
print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size,'drawnUIDs':obj['drawnUIDs'],'drawnPoses':obj['drawnPoses'],'moderationFailures':obj['moderationFailures']}))
