import os,pathlib,json,hashlib,datetime,sys
from PIL import Image
from io import BytesIO
from alpha_components import boxes
uid,src_name,species=sys.argv[1:4]
version=sys.argv[4]if len(sys.argv)>4 else'v1'
assert version in ['v1','v2-alpha']
jobp=pathlib.Path('/tmp/cqc-static-20261113/inventory/priority20-jobs')/(uid+'.json')
if jobp.exists():
 with os.fdopen(os.open(jobp,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:job=json.load(f)
else:
 with open('/tmp/cqc-static-20261113/dispatch/PLANNED_READY_QUEUE_C_V1.json')as f:q=json.load(f)
 job=next((j for j in q['jobs']if j['uid']==uid),None)
 if job is None:
  with open('/tmp/cqc-static-20261113/dispatch/REBALANCED_E_TAIL_TO_C_V1.json')as f:q=json.load(f)
  job=next(j for j in q['jobs']if j['uid']==uid)
families=job['missingFamilies'];cols=min(3,len(families));rows=(len(families)+cols-1)//cols
src=pathlib.Path(src_name);out=pathlib.Path('/tmp/cqc-static-20261113/artists/c')/uid;out.mkdir(parents=True,exist_ok=True)
oldReceipt=out/'RAW_V1_RECEIPT_PRIVATE.json';old=json.loads(oldReceipt.read_text())if oldReceipt.exists()else None
with os.fdopen(os.open(src,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:b=f.read()
p=out/(uid+'-static-missing-raw-'+version+'.png')
if p.exists():assert p.read_bytes()==b
else:p.write_bytes(b)
assert p.read_bytes()==b
im=Image.open(BytesIO(b));assert im.mode=='RGBA';width,height=im.size;alpha=im.getchannel('A').tobytes();cells=[]
for slot,family in enumerate(families):
 col=slot%cols;row=slot//cols;x0=col*width//cols;x1=(col+1)*width//cols;y0=row*height//rows;y1=(row+1)*height//rows;pts=[(x,y)for y in range(y0,y1)for x in range(x0,x1)if alpha[y*width+x]>16];assert pts
 left=min(x for x,y in pts);right=max(x for x,y in pts)+1;top=min(y for x,y in pts);bottom=max(y for x,y in pts)+1
 cells.append({'slot':slot,'outfit':family,'label':job['missingCostumes'][slot]['label'],'facing':'right','frameRect':{'x':x0,'y':y0,'width':x1-x0,'height':y1-y0},'strongAlphaBBox':[left,top,right,bottom],'footprint':{'x':(left+right)/2,'y':bottom},'strongPixelCount':len(pts),'sourceOnly':True})
isolated=boxes(alpha,width,height,len(families),cols,rows)
for cell,analysis in zip(cells,isolated):
 cell['gridRectProposal']=cell['frameRect'];cell.update(analysis);cell['framingMethod']='alpha16-connected-components-variable-bounds-proposal'
blank=[]
for slot in range(len(families),cols*rows):
 col=slot%cols;row=slot//cols;x0=col*width//cols;x1=(col+1)*width//cols;y0=row*height//rows;y1=(row+1)*height//rows;blank.append({'slot':slot,'strongPixels':sum(alpha[y*width+x]>16 for y in range(y0,y1)for x in range(x0,x1))})
generator=old['generatorPath']if old and src==p else str(src)
rec={'schema':'cqc.static.singlepose.artist-source/1','uid':uid,'name':job['name'],'incarnation':job['incarnation'],'createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(p),'generatorPath':generator,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'gitBlobOID':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'width':width,'height':height,'columns':cols,'rows':rows,'cells':cells,'emptySlotsAnalysis':blank,'newStaticPoses':len(families),'animations':False,'sourcePNGModified':False,'familySpecies':{'furry':species},'qualification':'Artist viewed reference and complete generated source. FrameRects use alpha16 components with variable bounds as proposals; Root must inspect geometry, costume fidelity and source ownership. No animation/gameplay admission.'}
receiptName='RAW_V2_COMPONENT_FRAMING_PRIVATE.json'if old else'RAW_V1_RECEIPT_PRIVATE.json';slotName='STATIC_SOURCE_SLOTS_PRIVATE_V2.json'if old else'STATIC_SOURCE_SLOTS_PRIVATE_V1.json'
if version=='v2-alpha':
 receiptName='RAW_V2_ALPHA_RECEIPT_PRIVATE.json';slotName='STATIC_SOURCE_SLOTS_PRIVATE_V2_ALPHA.json';rec.update(correction=True,preferredForFamilies=families,supersedesOnlySameFamiliesSourceV1=True)
(out/receiptName).write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n');(out/slotName).write_text(json.dumps({'columns':cols,'rows':rows,'cells':cells},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':rec['sha256'],'bytes':len(b),'poses':len(families),'bbox':[(x['outfit'],x['strongAlphaBBox'])for x in cells],'blanks':blank}))
prompt=pathlib.Path('/tmp/cqc-static-20261113/artists/c/global-prompts')/(uid+'.prompt.txt')
if prompt.exists() and not (out/'PROMPT_USED_V1.txt').exists():(out/'PROMPT_USED_V1.txt').write_bytes(prompt.read_bytes())
