import pathlib,sys,json,os,hashlib,datetime
from PIL import Image
from io import BytesIO
from alpha_components import boxes
uid,family,src_name=sys.argv[1:4]
b=pathlib.Path('/tmp/cqc-static-20261113/artists/c');d=b/uid;d.mkdir(exist_ok=True)
src=pathlib.Path(src_name)
with os.fdopen(os.open(src,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:data=f.read()
p=d/(uid+'-'+family+'-solo-raw-v2.png')
if p.exists():assert p.read_bytes()==data
else:p.write_bytes(data)
im=Image.open(BytesIO(data));assert im.mode=='RGBA';w,h=im.size;a=im.getchannel('A').tobytes();cell=boxes(a,w,h,1,1,1)[0];cell.update(slot=0,outfit=family,label=family,facing='right',sourceOnly=True)
r={'schema':'cqc.static.singlepose.artist-correction/1','uid':uid,'source':str(p),'generatorPath':str(src),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'gitBlobOID':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'width':w,'height':h,'columns':1,'rows':1,'cells':[cell],'newStaticPoses':1,'correction':True,'preferredForKey':uid+':'+family,'replacesOnlyFamily':family,'otherCostumesSourceUnchanged':True,'sourcePNGModified':False,'animations':False,'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qualification':'Solo generated image visually inspected; final Root art/geometry review pending. Source PNG untouched.'}
(d/(family.upper()+'_SOLO_V2_RECEIPT_PRIVATE.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');(d/('STATIC_'+family.upper()+'_SOLO_SLOTS_PRIVATE_V2.json')).write_text(json.dumps({'columns':1,'rows':1,'cells':[cell]},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'uid':uid,'family':family,'source':str(p),'sha256':r['sha256'],'bbox':cell['strongAlphaBBox']}))
