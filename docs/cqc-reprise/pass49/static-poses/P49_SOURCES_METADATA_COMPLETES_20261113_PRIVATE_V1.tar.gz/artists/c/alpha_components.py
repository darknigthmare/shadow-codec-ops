from collections import deque
def boxes(alpha,w,h,n,cols,rows):
 seen=bytearray(w*h);comps=[]
 for start in range(w*h):
  if alpha[start]<=16 or seen[start]:continue
  seen[start]=1;q=deque([start]);count=0;left=w;right=0;top=h;bottom=0;sx=0;sy=0
  while q:
   pos=q.popleft();y,x=divmod(pos,w);count+=1;sx+=x;sy+=y;left=min(left,x);right=max(right,x+1);top=min(top,y);bottom=max(bottom,y+1)
   for yy in range(max(0,y-1),min(h,y+2)):
    for xx in range(max(0,x-1),min(w,x+2)):
     k=yy*w+xx
     if not seen[k]and alpha[k]>16:seen[k]=1;q.append(k)
  comps.append({'count':count,'bbox':[left,top,right,bottom],'center':[sx/count,sy/count]})
 comps.sort(key=lambda c:-c['count']);assert len(comps)>=n and comps[n-1]['count']>1000,'Not enough isolated pose components'
 centers=[((s%cols+.5)*w/cols,(s//cols+.5)*h/rows)for s in range(n)];free=set(range(n));groups={}
 for c in comps[:n]:
  slot=min(free,key=lambda s:(c['center'][0]-centers[s][0])**2+(c['center'][1]-centers[s][1])**2);free.remove(slot);groups[slot]=[c]
 def distance(c,b):
  x,y=c['center'];return max(b[0]-x,0,x-b[2])**2+max(b[1]-y,0,y-b[3])**2
 for c in comps[n:]:
  slot=min(groups,key=lambda s:distance(c,groups[s][0]['bbox']));groups[slot].append(c)
 result=[]
 for s in range(n):
  gs=groups[s];l=min(c['bbox'][0]for c in gs);t=min(c['bbox'][1]for c in gs);r=max(c['bbox'][2]for c in gs);b=max(c['bbox'][3]for c in gs)
  feet=[x for yy in range(max(t,b-8),b)for x in range(l,r)if alpha[yy*w+x]>16]
  result.append({'slot':s,'strongAlphaBBox':[l,t,r,b],'strongPixelCount':sum(c['count']for c in gs),'componentCount':len(gs),'frameRect':{'x':max(0,l-2),'y':max(0,t-2),'width':min(w,r+2)-max(0,l-2),'height':min(h,b+2)-max(0,t-2)},'footprint':{'x':sum(feet)/len(feet)if feet else(l+r)/2,'y':b}})
 return result
