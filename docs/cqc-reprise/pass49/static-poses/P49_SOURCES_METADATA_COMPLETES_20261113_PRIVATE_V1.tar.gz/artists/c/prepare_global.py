import os,pathlib,json,hashlib,stat
BASE=pathlib.Path('/tmp/cqc-static-20261113/artists/c');REF=BASE/'global-references';REF.mkdir(exist_ok=True);PROMPT=BASE/'global-prompts';PROMPT.mkdir(exist_ok=True)
q=json.loads(pathlib.Path('/tmp/cqc-static-20261113/dispatch/PLANNED_READY_QUEUE_C_V1.json').read_text())
species=['brownblondbear','massiveblackraven','adultredpandascientist','blacklynx','graycyberneticfox','blackboarcosmonaut','camouflageoctopus','childwhitekitten','brownbeaverengineer','adultredpandascientist','snowlynx','seaotter','elderlybadger','baldeagle','brownferretengineer','grayjackalcommando','fennecfox','elderlygraywolf','olderbrownbear','infectedhyena','rescuersaintbernard','arcticlynx','raccoon','elderlyowl','silverfoxdigitalavatar','scorchedblackraven','brownriverotter','grayboar','falconpilot','adultlynx','darkjackal','elderlyservaldoctor','elderlygraywolf','paleanthrohorse','graybrownwolf','oldergraytiger','grayfox','heavywolverine','whitecyberfox','whiteanthropython','arcticwolf','copperocelot','redblackmongoose','elderlywhiteocelot','camouflagejaguar','blackboarcosmonaut','darkspideranthro','blondlioness','olderbrownwolf','snowleopardofficer','adultblondlynx','grayshepherdsoldier','grayravenrifleman','navyblueotter','browncoyotesoldier','brownweasel','grayfox','scorchedblackraven','oldgrizzlyofficer','grayjackaloperator','adultbrownotter','brownbaboonlikeguard','largeanthrogorilla','grayshepherdsoldier','whitegrayanthrohorse','adultgraywolfbeauty','adultbrownbear']
assert len(species)==len(q['jobs'])
def st(p):
 s=os.stat(p,follow_symlinks=False);return(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_atime_ns,s.st_blocks)
for i,j in enumerate(q['jobs']):
 p=pathlib.Path(j['originalPose']['file']);before=st(p);assert stat.S_ISREG(before[2])
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:b=f.read()
 assert st(p)==before
 assert hashlib.sha256(b).hexdigest()==j['originalPose']['assetProof']['sha256']
 dst=REF/(j['uid']+'-original-right.png')
 if dst.exists():assert dst.read_bytes()==b
 else:dst.write_bytes(b)
 (REF/(j['uid']+'-source-pin.json')).write_text(json.dumps({'source':str(p),'copy':str(dst),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'OriginalAllStatsUnchanged':True},indent=2)+'\n')
 j['referenceTMP']=str(dst);j['furrySpecies']=species[i]
 # Prompts are written after the artist has viewed each immutable TMP reference.
 (PROMPT/(j['uid']+'.job.json')).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'readyCopies':len(q['jobs']),'OriginalMutations':0,'referenceDir':str(REF),'jobsDir':str(PROMPT)}))
