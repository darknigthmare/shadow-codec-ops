import os,io,json,pathlib,hashlib,datetime
from PIL import Image
import numpy as np
n=pathlib.Path('/tmp/cqc-static-20261113');folder=n/'artists/root_recovery';source=pathlib.Path('/workspace/generated_images/exec-1a3aedca-28b9-48a8-a21e-67f9888f2820.png')
with os.fdopen(os.open(source,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:raw=f.read()
target=folder/'historical-three-static-raw-v1.png'
if not target.exists():target.write_bytes(raw)
assert target.read_bytes()==raw
im=Image.open(io.BytesIO(raw)).convert('RGBA');w,h=im.size;alpha=np.asarray(im)[:,:,3];sha=hashlib.sha256(raw).hexdigest();rows=[]
for slot,(uid,outfit,label)in enumerate([('roster50__stillman_mgs2','tuxedo','Gala'),('roster50__rose_mgs2','retro','Rétro'),('roster50__campbell_mgs1','retro','Rétro')]):
 x0=w*slot//3;x1=w*(slot+1)//3;y,x=np.where(alpha[:,x0:x1]>16);left=int(x.min())+x0;right=int(x.max())+x0;top=int(y.min());bottom=int(y.max());rect=[max(0,left-8),max(0,top-8),min(w,right+9)-max(0,left-8),min(h,bottom+9)-max(0,top-8)];ys,xs=np.where(alpha[max(0,bottom-10):bottom+1,x0:x1]>64);fp={'x':float(np.median(xs))+x0,'y':bottom+1}
 doc={'schema':'cqc.static-artist-source-slots/1','uid':uid,'version':1,'image':{'path':str(target),'sha256':sha,'width':w,'height':h,'generatorWorkspacePath':str(source)},'layout':{'columns':3,'rows':1},'slots':[{'slot':slot,'outfit':outfit,'label':label,'facing':'right','frameRect':dict(zip(['x','y','width','height'],rect)),'footprint':fp}],'qualification':'One new static costume pose. Three independent UID share one source atlas; no cross-era alias, animation or game admission. Visual review Root: complete neutral right-facing figure, correct incarnation cues; retro poses redrawn with deliberate pixel clusters. Stillman formal is authored, not official.'}
 path=folder/(uid+'_STATIC_SOURCE_SLOTS_PRIVATE_V1.json');path.write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n');rows.append({'uid':uid,'costumeId':outfit,'sourceSHA256':sha,'status':'approved','reviewer':'Root visual inspection of generated source','note':'Pose unique complète ; incarnation conservée. Costume inventé pour Stillman, réinterprétation rétro dessinée pour Rose et Campbell.'})
review=n/'catalog/ROOT_STATIC_ART_REVIEW_INDEX_PRIVATE_V1.json';r=json.loads(review.read_text());r['reviews']=[x for x in r['reviews']if(x['uid'],x['costumeId'])not in{(x['uid'],x['costumeId'])for x in rows}]+rows;review.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'source':str(target),'sha256':sha,'width':w,'height':h,'newPoses':3,'edgeAlpha16':int((alpha[0]>16).sum()+(alpha[-1]>16).sum()+(alpha[:,0]>16).sum()+(alpha[:,-1]>16).sum()),'alphaZeroPixels':int((alpha==0).sum())}))
