const results=await Promise.allSettled(batch.map(async d=>{
 try{
  if(!/^[a-z0-9_]+$/.test(d.uid))throw Error('Unsafe UID');
  const outdir='/tmp/cqc-static-20261113/artists/a/'+d.uid;
  const guard=await tools.exec_command({cmd:"python - <<'PY'\nimport pathlib,json\np=pathlib.Path('"+outdir+"');print(json.dumps({'existingTarget':(p/'"+d.uid+"-missing-singlepose-raw-v"+(d.version||1)+".png').exists(),'existingNoRetryHold':(p/'IMAGEGEN_MODERATION_NO_OUTPUT_PRIVATE_V1.json').exists()}))\nPY",max_output_tokens:150});
  const g=JSON.parse(guard.output);if(g.existingTarget||g.existingNoRetryHold)return {uid:d.uid,status:g.existingNoRetryHold?'SKIPPED_NO_RETRY_HOLD':'SKIPPED_EXISTING_SOURCE'};
  const result=await tools.image_gen__imagegen({transparent_background:true,referenced_image_paths:[d.reference],prompt:d.prompt});
  const path=result.output_hint?.match(/\/workspace\/generated_images\/exec-[a-f0-9-]+\.png/)?.[0];
  if(!path)throw Error('Imagegen output exists but hint lacks exact generator path; do not regenerate automatically');
  const reg=await tools.exec_command({cmd:'python /tmp/cqc-static-20261113/artists/a/register-static-atlas-a.py '+d.uid+' '+path+' '+(d.version||1)+' '+d.families.join(','),max_output_tokens:650});
  text(reg.output);generatedImage(result);
  return {uid:d.uid,status:'PNG_PRESERVED',path};
 }catch(e){
  const message=String(e),mod=message.includes('moderation_blocked');
  const out={schema:'cqc.static.imagegen-attempt/1',uid:d.uid,families:d.families,status:mod?'MODERATION_BLOCKED_NO_RETRY':'TECHNICAL_ERROR_NO_AUTOMATIC_RETRY',error:message.slice(0,3500),PNGCreated:mod?0:null,requestID:message.match(/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/)?.[0],noRetry:true};
  await tools.apply_patch('*** Begin Patch\n*** Add File: /tmp/cqc-static-20261113/artists/a/'+d.uid+'/IMAGEGEN_MODERATION_NO_OUTPUT_PRIVATE_V1.json\n+'+JSON.stringify(out,null,2).split('\n').join('\n+')+'\n*** End Patch');text(out);return out;
 }
}));
text(results.map(x=>x.status==='fulfilled'?x.value:{status:x.status,error:String(x.reason)}));
