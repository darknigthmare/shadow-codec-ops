import os, pathlib, json, hashlib, sys, datetime
from PIL import Image
import numpy as np
from scipy import ndimage

base=pathlib.Path('/tmp/cqc-static-20261113/artists/a/official/core__snake_pw')
gen=sys.argv[1]
version=int(sys.argv[2]) if len(sys.argv)>2 else 1
with os.fdopen(os.open(gen,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb') as f:
 raw=f.read()
dest=base/('core__snake_pw-official1-static-raw-v'+str(version)+'.png')
assert not dest.exists() or dest.read_bytes()==raw
if not dest.exists():dest.write_bytes(raw)
im=Image.open(dest).convert('RGBA'); w,h=im.size; a=np.asarray(im)[:,:,3]
labels,n=ndimage.label(a>16); comps=[]
for k,sl in enumerate(ndimage.find_objects(labels),1):
 if sl is None:continue
 m=labels[sl]==k; count=int(m.sum())
 if count<1000:continue
 yy,xx=np.nonzero(m)
 comps.append({'component':k,'pixels':count,'rect':[sl[1].start,sl[0].start,sl[1].stop-sl[1].start,sl[0].stop-sl[0].start],'centroid':[float(xx.mean()+sl[1].start),float(yy.mean()+sl[0].start)]})
job=json.loads(pathlib.Path('/tmp/cqc-static-20261113/official/parallel-ready-jobs/core__snake_pw-official1-miller-uniform-qualified-ready.json').read_text())
proof=json.loads((base/'REFERENCES_NOATIME_COPY_PROOF_PRIVATE_V1.json').read_text())
owns=comps; x=min(c['rect'][0] for c in owns); y=min(c['rect'][1] for c in owns); x1=max(c['rect'][0]+c['rect'][2] for c in owns); y1=max(c['rect'][1]+c['rect'][3] for c in owns)
subset=a[y+round((y1-y)*.5):y+round((y1-y)*.7),x:x1]>16; cy,cx=np.nonzero(subset)
bodyx=float(cx.mean()+x) if len(cx) else x+(x1-x)/2
s=job['slots'][0]
slot={'uid':job['uid'],'costumeID':s['costumeID'],'historicalID':s['historicalID'],'label':s['label'],'classification':s['classification'],'sourceRect':[x,y,x1-x,y1-y],'footDatumY':y1-1,'bodyDatumX':bodyx,'datumQualification':'Measured lower trunk center proposal; anatomical pelvis/sole datum awaits direct artist and Root review. No bounding-box scale admission.','poseCount':1,'animationCount':0,'facing':'right','originalSourceRetained':True}
edges={k:int((v>16).sum()) for k,v in {'top':a[0,:],'bottom':a[-1,:],'left':a[:,0],'right':a[:,-1]}.items()}
out={'schema':'cqc.static.official-generated-page-proposal/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'uid':job['uid'],'period':'1974 Big Boss/Naked Snake, original2010 PSP Metal Gear Solid: Peace Walker; official Miller Uniform unlock, same character body/head retained.','rawPNG':{'path':str(dest),'generatorPath':gen,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'width':w,'height':h,'rawPNGTransformed':False},'atlas':{'columns':1,'rows':1,'onePosePerCostume':True,'animations':False},'slots':[slot],'referenceSources':[dict(p,viewed=True,viewedBy='/root/static_artist_a')for p in proof],'referenceScope':{'identityAndUpperGarment':'Actual retail Snake PW bonusuniform screenshot; own native Original for body/identity continuity.','lowerGarment':'Actual original official PW Miller fullbody render art014, garments only; licensed toy not used in final generation.','wearerSeparation':'No Miller blonde head, sunglasses, watch or identity transferred to Snake; no character UID merge.','qualification':'Authored painted static adaptation using visible references. Full Snake retail bonusuniform mesh/UV/shader or unseen details are not certified 1:1.'},'visualReview':{'reviewer':'/root/static_artist_a — output review pending','newSpriteViewed':False,'referencesViewed':True,'sameIdentityAndPeriod':None,'sourceOnly':True,'limits':'One same-era static costume pose only. Existing Original and all old animations remain unchanged. No full retail Snake mesh/UV/shader pixel-exact certification. Root art/datum/catalog admission pending.'},'alphaAnalysis':{'min':int(a.min()),'max':int(a.max()),'alphaZero':int((a==0).sum()),'alphaAbove16':int((a>16).sum()),'mainComponentsAbove16':len(comps),'edgeForegroundAbove16':sum(edges.values()),'edgeForegroundAbove16BySide':edges,'components':comps,'weakAlphaResidue1to16Present':bool(((a>0)&(a<=16)).any()),'qualification':'Analysis only; exact rawPNG preserved without CPU editing.'},'SourcePixelsEditedByCPU':False,'ASWrites':False,'GitWrites':False,'runtimeAdmitted':False,'RootAdmission':'PENDING','newAnimations':0}
p=base/('CORE__SNAKE_PW_OFFICIAL1_ARTIFACT_PROPOSAL_PRIVATE_V'+str(version)+'.json')
p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'uid':job['uid'],'rawPNG':out['rawPNG'],'proposal':str(p),'poses':1,'mainComponents':len(comps),'edgeForegroundAbove16':sum(edges.values())}))
