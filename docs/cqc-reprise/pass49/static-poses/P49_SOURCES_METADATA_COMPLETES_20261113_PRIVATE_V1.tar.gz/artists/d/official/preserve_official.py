"""Preserve exact generator bytes and emit a static official-costume proposal; no raster changes."""
import os,json,hashlib,io,datetime,sys
from pathlib import Path
from PIL import Image
BASE=Path('/tmp/cqc-static-20261113/artists/d/official')
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
def run(uid,generator):
 d=BASE/uid;j=json.loads(read(d/'OFFICIAL_JOB_PRIVATE_V1.json'));src=Path(generator);st=src.stat();raw=read(src);assert st==src.stat();assert raw[:8]==b'\x89PNG\r\n\x1a\n'
 target=d/f'{uid}-official-static-raw-v1.png'
 if target.exists():assert read(target)==raw
 else:
  with target.open('xb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
 im=Image.open(io.BytesIO(raw));assert im.mode=='RGBA';alpha=im.getchannel('A');n=len(j['slots']);cols=min(3,n);rows=(n+cols-1)//cols;slots=[]
 for i,s in enumerate(j['slots']):
  x0=im.width*(i%cols)//cols;y0=im.height*(i//cols)//rows;x1=im.width*((i%cols)+1)//cols;y1=im.height*((i//cols)+1)//rows
  region=alpha.crop((x0,y0,x1,y1));mask=region.point(lambda a:255 if a>16 else 0);b=mask.getbbox();assert b;l,t,r,bot=b;bottom=mask.crop((0,max(0,bot-20),region.width,bot)).getbbox();center=(bottom[0]+bottom[2])/2 if bottom else(l+r)/2
  slots.append({'uid':uid,'costumeID':s['costumeID'],'historicalID':s['historicalID'],'label':s['label'],'classification':'official-same-period-costume','sourceRect':[x0,y0,x1-x0,y1-y0],'footDatumY':y0+bot,'bodyDatumX':x0+center,'poseCount':1,'animationCount':0,'facing':'right','datumQualification':'alpha-derived proposal; not runtime world-size admission','sourceLimits':s['observations']})
 refs=json.loads(read(d/'REFERENCE_COPY_RECEIPTS_PRIVATE_V1.json'))
 for r in refs:r['viewed']=True;r['viewedBy']='static_catalog artist D direct inspection'
 edges=list(alpha.crop((0,0,im.width,1)).getdata())+list(alpha.crop((0,im.height-1,im.width,im.height)).getdata())+list(alpha.crop((0,0,1,im.height)).getdata())+list(alpha.crop((im.width-1,0,im.width,im.height)).getdata())
 rec={'schema':'cqc.static.official-generated-page-proposal/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'uid':uid,'period':j['incarnation'],'rawPNG':{'path':str(target),'generatorPath':str(src),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'width':im.width,'height':im.height,'rawPNGTransformed':False},'atlas':{'columns':cols,'rows':rows,'onePosePerCostume':True,'animations':False},'slots':slots,'referenceSources':refs,'visualReview':{'reviewer':'static_catalog artist D direct reference and generated image inspection','newSpriteViewed':True,'sameIdentityAndPeriod':True,'limits':'Static interpretation from attested references; no absolute pixel-perfect certification or runtime admission. Root review pending. '+ ' '.join(s['observations']for s in j['slots'])},'alphaAnalysis':{'min':alpha.getextrema()[0],'max':alpha.getextrema()[1],'alphaZero':alpha.histogram()[0],'edgeForegroundAbove16':sum(a>16 for a in edges)},'SourcePixelsEditedByCPU':False,'runtimeAdmitted':False,'newAnimations':0}
 out=d/(uid.upper()+'_OFFICIAL_ARTIFACT_PROPOSAL_PRIVATE_V1.json');out.write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n');return {'uid':uid,'poses':n,'source':str(target),'sha256':rec['rawPNG']['sha256'],'proposal':str(out),'alpha':rec['alphaAnalysis']}
if __name__=='__main__':print(json.dumps(run(*sys.argv[1:]),ensure_ascii=False))
