"""Worker D metadata and alpha analysis only. No PNG pixel editing or publishing."""
from pathlib import Path
import datetime,hashlib,io,json,os,re
from PIL import Image
ROOT=Path('/tmp/cqc-static-20261113');BASE=ROOT/'artists/d'
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
def write_json(p,data):
 p=Path(p);temp=p.with_name(p.name+'.writing');raw=(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode()
 with temp.open('xb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
 os.replace(temp,p)
def job(uid):return next(j for j in json.loads(read(ROOT/'dispatch/PLANNED_READY_QUEUE_D_V1.json'))['jobs']if j['uid']==uid)
def prepare(uid):
 j=job(uid);d=BASE/uid;d.mkdir(parents=True,exist_ok=True)
 guard=json.loads(read(ROOT/'dispatch/HOLD_GUARDS_CURRENT_PUBLIC_V1.json'))
 forbidden={x['family']for x in guard.get('guards',[])if x['uid']==uid};assert not forbidden.intersection(c['id']for c in j['missingCostumes']),'Current family hold must not be generated'
 source=Path(j['originalPose']['file']);before=source.stat();b=read(source);after=source.stat();assert before==after
 assert hashlib.sha256(b).hexdigest()==j['originalPose']['assetProof']['sha256']
 target=d/'original-right-reference.png'
 if target.exists():assert read(target)==b
 else:
  with target.open('xb')as f:f.write(b)
 if not(d/'JOB_PRIVATE_V1.json').exists():write_json(d/'JOB_PRIVATE_V1.json',j)
 return {'uid':uid,'reference':str(target),'costumes':j['missingCostumes'],'ageAndGeometry':j.get('ageAndGeometry'),'holds':j.get('holds'),'furryConcept':j.get('furryConcept'),'loadout':j.get('loadoutQualification'),'guardRead':True}
def preserve(uid,generator,version=1):
 j=job(uid);d=BASE/uid;d.mkdir(parents=True,exist_ok=True);source=Path(generator);target=d/f'{uid}-static-missing-raw-v{version}.png';working=source if source.exists()else target;before=working.stat();b=read(working);assert working.stat()==before
 if working!=source:
  receipt=d/f'RAW_V{version}_RECEIPT_PRIVATE.json'
  old=json.loads(read(receipt if receipt.exists()else d/f'STATIC_GEOMETRY_PREFERRED_V{version}_PRIVATE.json'));assert old.get('sha256',old.get('sourceSHA256'))==hashlib.sha256(b).hexdigest()and old['sourceGeneratorPath']==str(source)
 if target.exists():assert read(target)==b
 else:
  with target.open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())
 im=Image.open(io.BytesIO(b));assert im.mode=='RGBA','No transparency channel'
 a=im.getchannel('A');costumes=j['missingCostumes'];scopefile=d/f'PAGE_V{version}_SLOT_SCOPE_PRIVATE.json'
 if scopefile.exists():
  scope=json.loads(read(scopefile));costumes=[c for c in costumes if c['id']in scope['families']];assert costumes
 cols=min(3,len(costumes));rows=(len(costumes)+cols-1)//cols;slots=[];empty=[]
 gridfile=d/f'SOURCE_GRID_OVERRIDE_PRIVATE_V{version}.json'
 if gridfile.exists():
  grid=json.loads(read(gridfile));cols=grid['cols'];rows=grid['rows'];assert cols*rows>=len(costumes)and cols*rows<=9
 rectfile=d/f'SOURCE_SLOT_RECTS_OVERRIDE_PRIVATE_V{version}.json';rectoverrides=json.loads(read(rectfile)).get('rects',{})if rectfile.exists()else{}
 for i in range(cols*rows):
  col=i%cols;row=i//cols;x0=im.width*col//cols;y0=im.height*row//rows;x1=im.width*(col+1)//cols;y1=im.height*(row+1)//rows
  if str(i)in rectoverrides:
   x0,y0,rw,rh=rectoverrides[str(i)];x1=x0+rw;y1=y0+rh;assert 0<=x0<x1<=im.width and 0<=y0<y1<=im.height
  # This is alpha inspection only; the input PNG bytes are never rewritten.
  region=a.crop((x0,y0,x1,y1));mask=region.point(lambda v:255 if v>16 else 0);bbox=mask.getbbox()
  if i>=len(costumes):empty.append({'slot':i,'strongAlphaBBox':bbox,'expectedEmpty':True});continue
  c=costumes[i];assert bbox,'Missing visible costume figure'
  l,t,r,bot=bbox;bottom=mask.crop((0,max(0,bot-20),region.width,bot)).getbbox();center=(bottom[0]+bottom[2])/2 if bottom else(l+r)/2
  slots.append({'index':i,'uid':uid,'costumeId':c['id'],'family':c.get('family',c['id']),'label':c['label'],'frameRect':[x0,y0,x1-x0,y1-y0],'bodyBounds':[l,t,r-l,bot-t],'pivot':[center/(x1-x0),bot/(y1-y0)],'footprint':{'floorY':bot,'centerX':center,'method':'opaque-bottom20px-midpoint-proposed'},'opaqueBBoxAtAlpha16':[l,t,r,bot],'onePoseOnly':True,'facing':'right','RootReviewPending':True})
 sha=hashlib.sha256(b).hexdigest();record={'schema':'cqc.static-preferred-frame-geometry/1','uid':uid,'preferredRawVersion':version,'sourceCanonicalPath':str(target),'sourceGeneratorPath':str(source),'sourceSHA256':sha,'sourceBytes':len(b),'gitBlobOID':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'width':im.width,'height':im.height,'cols':cols,'rows':rows,'slots':slots,'emptyCells':empty,'alphaExtrema':a.getextrema(),'corners':[im.getpixel(p)for p in[(0,0),(im.width-1,0),(0,im.height-1),(im.width-1,im.height-1)]],'geometryOnly':True,'RootAdmissionPending':True,'SourcePixelsModified':False,'animationsGenerated':False,'artistVisualReview':'Generated page seen; identities/outfit variety/one pose checked. Source anchors are alpha proposals, no canonical world-size or 1:1 certification.','createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 path=d/f'STATIC_GEOMETRY_PREFERRED_V{version}_PRIVATE.json';write_json(path,record)
 progress=load_progress();progress['completed']=[c for c in progress['completed']if c['uid']!=uid]+[{'uid':uid,'poses':len(j['missingCostumes']),'pagePoses':len(costumes),'version':version,'source':str(target),'sha256':sha,'metadata':str(path),'status':'DRAWN_CANDIDATE_PENDING_ROOT'}];progress['pendingUIDs']=[u for u in progress['pendingUIDs']if u!=uid];progress['atUTC']=record['createdAtUTC'];write_json(BASE/'PROGRESS_PRIVATE_V1.json',progress)
 return {'uid':uid,'poses':len(costumes),'source':str(target),'sha256':sha,'metadata':str(path),'emptyCellsClean':all(e['strongAlphaBBox']is None for e in empty),'alphaExtrema':a.getextrema()}
def load_progress():return json.loads(read(BASE/'PROGRESS_PRIVATE_V1.json'))
def block(uid,error):
 d=BASE/uid;d.mkdir(parents=True,exist_ok=True);r={'schema':'cqc.static.generation-refusal/1','uid':uid,'families':[c['id']for c in job(uid)['missingCostumes']],'error':str(error),'PNGCreated':False,'noRetry':True,'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};write_json(d/'GENERATION_BLOCKED_NO_RETRY_PRIVATE_V1.json',r);p=load_progress();p['blocked'].append(r);p['pendingUIDs']=[u for u in p['pendingUIDs']if u!=uid];write_json(BASE/'PROGRESS_PRIVATE_V1.json',p)
if __name__=='__main__':
 import sys
 action=sys.argv[1];args=sys.argv[2:]
 if action=='prepare':print(json.dumps(prepare(*args),ensure_ascii=False))
 elif action=='preserve':
  if len(args)==3:args[2]=int(args[2])
  print(json.dumps(preserve(*args),ensure_ascii=False))
 elif action=='block':block(*args)
