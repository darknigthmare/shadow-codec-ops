import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const N='/tmp/cqc-static-20261113',out=path.join(N,'artists/e/existing-retro2');
const input=JSON.parse(fs.readFileSync(path.join(N,'inventory/ORIGINAL24_EXISTING_STATIC_PART_COMPOSITIONS_AUDIT_PRIVATE_V1.json'),'utf8'));
let targets;for(let n=0;n<40;n++){try{targets=await(await fetch('http://127.0.0.1:9224/json/list')).json();break;}catch{await new Promise(r=>setTimeout(r,200));}}
const target=targets?.find(x=>x.type==='page');assert(target,'Own Chromium CDP target missing');
const ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
let serial=0;const pending=new Map(),exceptions=[];
ws.addEventListener('message',({data})=>{const m=JSON.parse(data);if(m.id){const p=pending.get(m.id);if(p){pending.delete(m.id);m.error?p.reject(new Error(m.error.message)):p.resolve(m.result);}}else if(m.method==='Runtime.exceptionThrown')exceptions.push(m.params.exceptionDetails);});
const call=(method,params={},timeout=60000)=>new Promise((resolve,reject)=>{const id=++serial;pending.set(id,{resolve,reject});ws.send(JSON.stringify({id,method,params}));setTimeout(()=>{if(pending.has(id)){pending.delete(id);reject(new Error('CDP timeout '+method));}},timeout).unref();});
const evaluate=async(expression,awaitPromise=false)=>{const r=await call('Runtime.evaluate',{expression,awaitPromise,returnByValue:true});if(r.exceptionDetails)throw new Error(r.exceptionDetails.text+':'+r.exceptionDetails.exception?.description);return r.result.value;};

const status=await evaluate('CQC_PASS21_NATIVE_MACHINE_REGISTRATION.status()');console.log(JSON.stringify(status));ws.close();process.exit(0);