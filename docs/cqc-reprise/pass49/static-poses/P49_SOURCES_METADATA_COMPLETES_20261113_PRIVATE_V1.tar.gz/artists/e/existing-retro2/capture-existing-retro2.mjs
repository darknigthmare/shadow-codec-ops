import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const N='/tmp/cqc-static-20261113',out=path.join(N,'artists/e/existing-retro2');
const input=JSON.parse(fs.readFileSync(path.join(N,'inventory/ORIGINAL24_EXISTING_STATIC_PART_COMPOSITIONS_AUDIT_PRIVATE_V1.json'),'utf8'));
let targets;for(let n=0;n<40;n++){try{targets=await(await fetch('http://127.0.0.1:9224/json/list')).json();break;}catch{await new Promise(r=>setTimeout(r,200));}}
const target=targets?.find(x=>x.type==='page');assert(target,'Own Chromium CDP target missing');
const ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
let serial=0;const pending=new Map(),exceptions=[];
ws.addEventListener('message',({data})=>{const m=JSON.parse(data);if(m.id){const p=pending.get(m.id);if(p){pending.delete(m.id);m.error?p.reject(new Error(m.error.message)):p.resolve(m.result);}}else if(m.method==='Runtime.exceptionThrown')exceptions.push(m.params.exceptionDetails);});
const call=(method,params={},timeout=60000)=>new Promise((resolve,reject)=>{const id=++serial;pending.set(id,{resolve,reject});ws.send(JSON.stringify({id,method,params}));setTimeout(()=>{if(pending.has(id)){pending.delete(id);reject(new Error('CDP timeout '+method));}},timeout).unref();});
const evaluate=async(expression,awaitPromise=false)=>{const r=await call('Runtime.evaluate',{expression,awaitPromise,returnByValue:true});if(r.exceptionDetails)throw new Error(r.exceptionDetails.text+':'+r.exceptionDetails.exception?.description);return r.result.value;};

await call('Page.enable');await call('Runtime.enable');await call('Emulation.setEmulatedMedia',{features:[{name:'prefers-reduced-motion',value:'reduce'}]});
const rows=[];
for(const uid of ['completion__mk2_mgs4','completion__dwarf_gekko_mgs4']){
 try{
  const r=await evaluate(`(async()=>{const actor={uid:${JSON.stringify(uid)},costume:'retro-msx'},run=globalThis.CQC_PASS21_MACHINE_COSTUME_RUNTIME;if(!run?.has(actor))throw Error('Existing costume runtime missing');const ready=await run.whenReady(actor,{face:1});if(ready!==true||!run.ready(actor,1))throw Error('Existing costume Source notready');const cv=document.createElement('canvas');cv.width=cv.height=1024;const ctx=cv.getContext('2d');ctx.clearRect(0,0,1024,1024);const draw=run.drawFitted(ctx,actor,{x:0,y:0,width:1024,height:1024,padding:40},1,{action:'idle',frame:0,time:0,phaseProgress:0,reducedMotion:true});if(draw!==true)throw Error('Existing costume draw failed');const p=ctx.getImageData(0,0,1024,1024).data;let opaque=0,edges=0,x0=1024,y0=1024,x1=-1,y1=-1;for(let y=0;y<1024;y++)for(let x=0;x<1024;x++)if(p[(y*1024+x)*4+3]>16){opaque++;x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);if(x===0||y===0||x===1023||y===1023)edges++;}if(opaque<100)throw Error('Empty existing costume rendering');return{uid:actor.uid,costume:'retro-msx',family:'retro',label:'Rétro',facing:'right',reducedMotion:true,nativeReady:run.ready(actor,1),bodyBounds:[x0,y0,x1-x0+1,y1-y0+1],opaquePixels:opaque,opaqueCanvasEdgePixels:edges,PNG:cv.toDataURL('image/png')};})()`,true);
  const raw=Buffer.from(r.PNG.split(',')[1],'base64');delete r.PNG;const file=path.join(out,uid+'-existing-retro-right-idle-reference.png');fs.writeFileSync(file,raw);r.file=file;r.bytes=raw.length;r.sha256=(await import('node:crypto')).createHash('sha256').update(raw).digest('hex');r.width=r.height=1024;r.frameRect=[0,0,1024,1024];r.pivot=[(r.bodyBounds[0]+r.bodyBounds[2]/2)/1024,(r.bodyBounds[1]+r.bodyBounds[3])/1024];r.status='EXISTING_DRAWN_RETRO_NATIVE_COMPOSITE_REUSED';rows.push(r);console.log(JSON.stringify(r));
 }catch(error){const r={uid,status:'NOT_CAPTURED',reason:String(error.message||error)};rows.push(r);console.log(JSON.stringify(r));}
}
fs.writeFileSync(path.join(out,'STATIC_EXISTING_RETRO2_COMPOSITES_PRIVATE_V1.json'),JSON.stringify({schema:'cqc.static.existing-retro-native-composites/1',atUTC:new Date().toISOString(),rows,qualification:'Existing retro-msx native machine-costume Source rendered once at reduced-motion RIGHT idle.No new artwork,no originalPNG/graph/animation edits;display nameRétro preserved;source IDhistoricalretro-msx retained only as provenance.'},null,2)+'\n');
ws.close();process.exit(0);
