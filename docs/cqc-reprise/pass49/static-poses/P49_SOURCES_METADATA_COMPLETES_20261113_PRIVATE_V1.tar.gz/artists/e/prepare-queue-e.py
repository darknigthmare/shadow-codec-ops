import json,os,pathlib,hashlib,sys
base=pathlib.Path('/tmp/cqc-static-20261113/artists/e');q=json.load(open('/tmp/cqc-static-20261113/dispatch/PLANNED_READY_QUEUE_E_V1.json'));guards=json.load(open('/tmp/cqc-static-20261113/dispatch/HOLD_GUARDS_CURRENT_PUBLIC_V1.json'))['guards']
assert 0 <= int(sys.argv[1]) < int(sys.argv[2]) <= 47,'E tail47–66 reassigned toA/C;do not prepare/generate'
for j in q['jobs'][int(sys.argv[1]):int(sys.argv[2])]:
 uid=j['uid'];d=base/uid;d.mkdir(exist_ok=True);ref=j['originalPose'];src=ref['file'];st=os.stat(src);fd=os.open(src,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as f:b=f.read()
 assert hashlib.sha256(b).hexdigest()==ref['assetProof']['sha256'];assert os.stat(src).st_atime_ns==st.st_atime_ns
 p=d/'original-right-reference.png'
 if not p.exists():p.write_bytes(b)
 else:assert p.read_bytes()==b
 ref['file']=str(p);hold=[g for g in guards if g['uid']==uid];forbidden={g['family'] for g in hold};j['missingFamilies']=[f for f in j['missingFamilies'] if f not in forbidden];j['missingCostumes']=[c for c in j['missingCostumes'] if c['family'] not in forbidden];j['currentHoldGuardsApplied']=hold;(d/'JOB_PRIVATE_V1.json').write_text(json.dumps(j,ensure_ascii=False,indent=2));print(json.dumps({'uid':uid,'name':j['name'],'incarnation':j['incarnation'],'ageAndGeometry':j.get('ageAndGeometry'),'missingFamilies':j['missingFamilies'],'holds':hold,'reference':str(p)},ensure_ascii=False))
