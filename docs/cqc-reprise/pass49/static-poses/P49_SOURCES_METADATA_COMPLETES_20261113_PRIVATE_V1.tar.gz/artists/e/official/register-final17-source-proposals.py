from pathlib import Path
import datetime, hashlib, io, json, os
import numpy as np
from PIL import Image
from scipy import ndimage
E=Path('/tmp/cqc-static-20261113/artists/e/official')
D=E/'final17-reference-review'
def rb(p):
    fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
    with os.fdopen(fd,'rb') as f: return f.read()
receipt=json.loads(rb(E/'FINAL17_NEW_RAW_PRESERVATION_RECEIPT_PRIVATE_V1.json'))
packages=[
 ('DELTA_FINAL4','archive__naked_delta',receipt['sources'][0],['spider','ga-ko-mask','kerotan-mask','sunglasses'],[D/'7e895ab43d322077c5db.source',D/'primary-pdf-images/extracted-001.png',D/'official--sneaking-suit-pw.jpg',D/'official--crocodile-suit.jpg',D/'archive__naked_delta-original-right-reference.png']),
 ('PS2_TUXEDO','core__snake',receipt['sources'][1],['tuxedo'],[D/'core__snake-original-right-source.png']+[D/'targeted-ps2-textures'/n for n in ['sna_mgs3_txd_jacket.bmp.png','sna_mgs3_txd_shirt.bmp.png','sna_mgs3_txd_vest.bmp.png','sna_mgs3_txd_leg.bmp.png']]),
 ('PS2_MAINTENANCE','core__snake',receipt['sources'][2],['maintenance-uniform'],[D/'core__snake-original-right-source.png']+[D/'targeted-ps2-textures'/n for n in ['sna_mnt_body_def.bmp.png','sna_mnt_foot_def.bmp.png','sna_mnt_arm_def.bmp.png','sna_mnt_shl_def.bmp.png']]),
 ('PS2_SNEAKING_SUIT','core__snake',receipt['sources'][3],['sneaking-suit'],[D/'core__snake-original-right-source.png']+[D/'seen-ps2'/n for n in ['4-sna_ss_body.bmp.png','5-sna_ss_arm.bmp.png','6-sna_ss_thigh.bmp.png','7-sna_ss_knee.bmp.png','8-sna_ss_boots.bmp.png']])
]
labels={'spider':'Spider','ga-ko-mask':'GA-KO Mask — Sneaking Suit (PW ver.)','kerotan-mask':'Kerotan Mask — Sneaking Suit (PW ver.)','sunglasses':'Sunglasses — Crocodile Suit','tuxedo':'Tuxedo','maintenance-uniform':'Maintenance','sneaking-suit':'Sneaking Suit'}
for kind,uid,raw,names,refs in packages:
    if (E/(kind+'_ARTIFACT_PROPOSAL_PRIVATE_V1.json')).exists(): continue
    b=rb(raw['path']); assert hashlib.sha256(b).hexdigest()==raw['sha256']
    im=Image.open(io.BytesIO(b)).convert('RGBA'); a=np.asarray(im)[:,:,3]
    lab,n=ndimage.label(a>16); sizes=np.bincount(lab.ravel()); boxes=ndimage.find_objects(lab)
    ids=sorted([i for i in range(1,n+1) if sizes[i]>=500],key=lambda i:(boxes[i-1][0].start//512,boxes[i-1][1].start))
    assert len(ids)==len(names),(kind,len(ids))
    slots=[]
    for index,(costume,ident) in enumerate(zip(names,ids)):
        yy,xx=np.where(lab==ident); x=max(0,int(xx.min())-3); y=max(0,int(yy.min())-3)
        right=min(im.width,int(xx.max())+4); bottom=min(im.height,int(yy.max())+4)
        band=max(5,round((int(yy.max())-int(yy.min())+1)*.08))
        fy,fx=np.where((lab==ident)&(a>128)&(np.indices(a.shape)[0]>=int(yy.max())+1-band))
        footX=(int(fx.min())+int(fx.max())+1)/2; footY=int(yy.max())+1
        slots.append({'uid':uid,'costumeID':'official--'+costume,'historicalAlias':uid+'__alt__'+costume.replace('-','_'),'label':labels[costume],'classification':'official-same-period-costume','sourceRect':[x,y,right-x,bottom-y],'footDatumY':footY,'bodyDatumX':footX,'pivot':[(footX-x)/(right-x),(footY-y)/(bottom-y)],'poseCount':1,'facing':'right','animationCount':0})
    referenceRows=[{'path':str(p),'bytes':len(rb(p)),'sha256':hashlib.sha256(rb(p)).hexdigest(),'viewed':True} for p in refs]
    if kind=='DELTA_FINAL4':
        referenceRows[0].update(URL='https://i0.wp.com/intoindiegames.com/wp-content/uploads/IIG-MGS-uniforms-00015.jpg?resize=1536%2C864&ssl=1',subject='Actual Delta in-game labeled SPIDER fullbody.')
        referenceRows[1].update(URL='https://cdn.uc.assets.prezly.com/f8b1d528-a641-457d-b72b-9e1371c5a77a/-/inline/no/KONAMI%20Pressemeldung%20MGS%20Delta%20-%20Releasedatum.pdf',subject='Embedded image1 from page3 of KONAMI13Feb2025 press release, extracted without artwork edits. Actual labeled DLC face/equipment closeups. OriginalPDF SHA6e0bd03332b1479dfa079a24e6cbd689349cc40886f5a221b6cc2dd226dd4aae preserved.')
        limits='Sunglasses uses CrocodileSuit collar/body combination shown in primary promo; masks use Delta PWVer replica body, remain1964 Delta UID. Not actual1974 PW BigBoss.'
    else:
        for ref in referenceRows[1:]:
            ref.update(URL='https://raw.githubusercontent.com/dotlessone/MGS3-PS2-Textures/main/Tri-Dumped/Snake%20Eater/Europe/'+Path(ref['path']).name,subject='Actual extracted original European PS2 texture named clothing piece. No Delta body or palette substitution.')
        limits=names[0]+' construction/palette from actually viewed original European PS2 clothing-piece textures projected on sameUID body. Exact unseen final retail3D garment topology and subpixel seams are not independently certified.'
    proposal={
      'schema':'cqc.static.official-generated-page-proposal/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'uid':uid,
      'rawPNG':dict(raw,width=im.width,height=im.height,rawPNGTransformed=False),
      'atlas':{'columns':3 if len(names)==4 else 1,'rows':2 if len(names)==4 else 1,'onePosePerCostume':True,'animations':False},
      'slots':slots,'referenceSources':referenceRows,
      'visualReview':{'reviewer':'static_inventory / artist E','newSpriteViewed':True,'referencesViewed':True,'sameIdentityAndPeriod':True,'sourceOnly':True,'observed':'All selected fullbody RIGHT poses present; observed costume palette/construction/equipment distinguished. Same selected incarnation retained, no duplicated animations.','limits':'Reference-derived drawn interpretation, not certified pixel1:1/UV or retail3D extraction. Root admission pending. '+limits},
      'alphaAnalysis':{'alpha0':int((a==0).sum()),'alpha1to16':int(((a>0)&(a<=16)).sum()),'mainComponentsAbove16':len(ids),'expectedFigures':len(names),'sourceImageEdgeForegroundAbove16':int((a[0]>16).sum()+(a[-1]>16).sum()+(a[:,0]>16).sum()+(a[:,-1]>16).sum()),'qualification':'Analysis only; exact PNG bytes retained, no CPU pixel edits.'},
      'SourcePixelsEditedByCPU':False,'ASWrites':False,'GitWrites':False,'runtimeAdmitted':False,'RootAdmission':'PENDING'
    }
    p=E/(kind+'_ARTIFACT_PROPOSAL_PRIVATE_V1.json'); p.write_text(json.dumps(proposal,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'proposal':str(p),'rawPNG':proposal['rawPNG'],'slots':slots,'QA':proposal['alphaAnalysis']},ensure_ascii=False))
