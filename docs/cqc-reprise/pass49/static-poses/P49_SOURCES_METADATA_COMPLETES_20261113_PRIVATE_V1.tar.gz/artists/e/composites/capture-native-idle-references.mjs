import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const N='/tmp/cqc-static-20261113',out=path.join(N,'artists/e/composites');
const input=JSON.parse(fs.readFileSync(path.join(N,'inventory/ORIGINAL24_EXISTING_STATIC_PART_COMPOSITIONS_AUDIT_PRIVATE_V1.json'),'utf8'));
let targets;for(let n=0;n<40;n++){try{targets=await(await fetch('http://127.0.0.1:9224/json/list')).json();break;}catch{await new Promise(r=>setTimeout(r,200));}}
const target=targets?.find(x=>x.type==='page');assert(target,'Own Chromium CDP target missing');
const ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
let serial=0;const pending=new Map(),exceptions=[];
ws.addEventListener('message',({data})=>{const m=JSON.parse(data);if(m.id){const p=pending.get(m.id);if(p){pending.delete(m.id);m.error?p.reject(new Error(m.error.message)):p.resolve(m.result);}}else if(m.method==='Runtime.exceptionThrown')exceptions.push(m.params.exceptionDetails);});
const call=(method,params={},timeout=60000)=>new Promise((resolve,reject)=>{const id=++serial;pending.set(id,{resolve,reject});ws.send(JSON.stringify({id,method,params}));setTimeout(()=>{if(pending.has(id)){pending.delete(id);reject(new Error('CDP timeout '+method));}},timeout).unref();});
const evaluate=async(expression,awaitPromise=false)=>{const r=await call('Runtime.evaluate',{expression,awaitPromise,returnByValue:true});if(r.exceptionDetails)throw new Error(r.exceptionDetails.text+':'+r.exceptionDetails.exception?.description);return r.result.value;};
await call('Page.enable');await call('Runtime.enable');await call('Emulation.setDeviceMetricsOverride',{width:1200,height:1000,deviceScaleFactor:1,mobile:false});await call('Emulation.setEmulatedMedia',{features:[{name:'prefers-reduced-motion',value:'reduce'}]});
await call('Page.navigate',{url:'http://127.0.0.1:8149/native/modules/unified-versus-v055.html'});
let ready=false;for(let n=0;n<120;n++){try{ready=await evaluate('!!globalThis.CQC_PASS18_MACHINES?.originalRigSnapshot && !!globalThis.CQC_PASS40_FENRIR_CANDIDATE');if(ready)break;}catch{}await new Promise(r=>setTimeout(r,250));}
assert(ready,'Current game renderer/Root Fenrir admission did not initialize');
const initial=await evaluate('({bridge:globalThis.CQC_PASS18_MACHINES.status(),fenrir:globalThis.CQC_PASS40_FENRIR_CANDIDATE.status(),url:location.href})');fs.writeFileSync(path.join(out,'CURRENT_RENDERER_INITIAL_STATUS_PRIVATE_V1.json'),JSON.stringify(initial,null,2)+'\n');
const rows=[];
for(const item of input.rows){
 const uid=item.uid;let result;
 try{
  result=await evaluate(`(async()=>{const uid=${JSON.stringify(uid)},bridge=globalThis.CQC_PASS18_MACHINES;const snapshot=bridge.originalRigSnapshot(uid);if(!snapshot)throw Error('No current exact Original rig snapshot');const load=await bridge.whenReady(uid,{face:1});if(load!==true||!bridge.ready(uid,{face:1}))throw Error('Native Source not decoded and ready');const canvas=document.createElement('canvas');canvas.width=1024;canvas.height=1024;const ctx=canvas.getContext('2d');ctx.clearRect(0,0,1024,1024);const draw=bridge.drawFitted(ctx,uid,{x:0,y:0,width:1024,height:1024,padding:32},1,{action:'idle',frame:0,time:0,phaseProgress:0,reducedMotion:true});if(draw!==true)throw Error('Native draw returned false');const pixels=ctx.getImageData(0,0,1024,1024).data;let count=0,x0=1024,y0=1024,x1=-1,y1=-1,edges=0;for(let y=0;y<1024;y++)for(let x=0;x<1024;x++)if(pixels[(y*1024+x)*4+3]>16){count++;x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);if(x===0||y===0||x===1023||y===1023)edges++;}if(count<100)throw Error('Empty native draw');return{uid,face:1,action:'idle',frame:0,reducedMotion:matchMedia('(prefers-reduced-motion: reduce)').matches,nativeReady:bridge.ready(uid,{face:1}),sourceRigSnapshot:snapshot,opaquePixels:count,opaqueCanvasEdgePixels:edges,bodyBounds:[x0,y0,x1-x0+1,y1-y0+1],PNG:canvas.toDataURL('image/png')};})()`,true);
  const raw=Buffer.from(result.PNG.split(',')[1],'base64');delete result.PNG;const file=path.join(out,uid+'-original-right-neutral-reference.png');fs.writeFileSync(file,raw);result.file=file;result.bytes=raw.length;result.sha256=(await import('node:crypto')).createHash('sha256').update(raw).digest('hex');result.status=result.opaqueCanvasEdgePixels===0?'CAPTURED_NATIVE_IDLE_CURRENT_RIG':'CAPTURED_NATIVE_IDLE_EDGE_REVIEW_REQUIRED';fs.writeFileSync(path.join(out,uid+'-current-native-rig-snapshot-private-v1.json'),JSON.stringify(result,null,2)+'\n');rows.push(result);console.log(JSON.stringify({uid,status:result.status,bytes:result.bytes,bounds:result.bodyBounds}));
 }catch(error){result={uid,status:'NOT_CAPTURED',reason:String(error.message||error)};rows.push(result);console.log(JSON.stringify(result));}
 fs.writeFileSync(path.join(out,'ORIGINAL24_NATIVE_IDLE_REFERENCE_PROGRESS_PRIVATE_V1.json'),JSON.stringify({schema:'cqc.static.original-native-reference-captures/1',rows,exceptions,qualification:'Existing current application renderer at reduced-motion RIGHT idle. New reference composites, no original Source PNG edits, no new drawn Original or animation, no game integration.'},null,2)+'\n');
}
console.log('COMPLETE',rows.length);ws.close();process.exit(0);
