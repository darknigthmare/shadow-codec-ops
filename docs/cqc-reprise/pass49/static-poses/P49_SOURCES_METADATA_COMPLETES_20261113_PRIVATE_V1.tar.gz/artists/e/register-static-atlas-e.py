import os,pathlib,json,hashlib,sys,datetime
from PIL import Image
import numpy as np
from scipy import ndimage
uid,generated=sys.argv[1:3]
version=int(sys.argv[3])if len(sys.argv)>3 else 1
base=pathlib.Path('/tmp/cqc-static-20261113/artists/e');out=base/uid;out.mkdir(parents=True,exist_ok=True)
jobpath=out/'JOB_PRIVATE_V1.json'
if jobpath.exists():job=json.loads(jobpath.read_text())
else:
 queues=[pathlib.Path('/tmp/cqc-static-20261113/artists/e/composites/ORIGINAL24_GENERATION_JOBS_WITH_COMPLETE_REFERENCE_PRIVATE_V1.json'),pathlib.Path('/tmp/cqc-static-20261113/dispatch/PLANNED_READY_QUEUE_E_V1.json')]
 job=next(x for q in queues for x in json.loads(q.read_text())['jobs']if x['uid']==uid)
with os.fdopen(os.open(generated,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:raw=f.read()
dest=out/(uid+'-missing-singlepose-raw-v'+str(version)+'.png')
assert not dest.exists() or dest.read_bytes()==raw
if not dest.exists():dest.write_bytes(raw)
im=Image.open(dest).convert('RGBA');w,h=im.size;a=np.asarray(im)[:,:,3];hist=np.bincount(a.ravel(),minlength=256)
families=sys.argv[4].split(',')if len(sys.argv)>4 and sys.argv[4]else job['missingFamilies'];cols=min(3,len(families));rows=(len(families)+cols-1)//cols
labels,n=ndimage.label(a>16);components=[]
for ident,slices in enumerate(ndimage.find_objects(labels),1):
 if slices is None:continue
 mask=labels[slices]==ident;pixels=int(np.count_nonzero(mask))
 if pixels<500:continue
 ys,xs=np.nonzero(mask);cx=float(xs.mean()+slices[1].start);cy=float(ys.mean()+slices[0].start)
 col=min(cols-1,int(cx*cols/w));row=min(rows-1,int(cy*rows/h));index=row*cols+col
 components.append({'id':ident,'pixels':pixels,'bbox':[slices[1].start,slices[0].start,slices[1].stop,slices[0].stop],'centroid':[cx,cy],'proposedSlot':index})
slots=[]
for i,family in enumerate(families):
 owned=[c for c in components if c['proposedSlot']==i]
 if not owned:
  slots.append({'index':i,'family':family,'status':'MISSING_COMPONENT_HOLD'});continue
 x0=min(c['bbox'][0]for c in owned);y0=min(c['bbox'][1]for c in owned);x1=max(c['bbox'][2]for c in owned);y1=max(c['bbox'][3]for c in owned)
 nominal=[round((i%cols)*w/cols),round((i//cols)*h/rows),round((i%cols+1)*w/cols),round((i//cols+1)*h/rows)]
 crosses=x0<nominal[0] or x1>nominal[2] or y0<nominal[1] or y1>nominal[3]
 slots.append({'index':i,'uid':uid,'costumeId':family,'family':family,'label':next(x['label']for x in job['missingCostumes']if x['id']==family),'incarnation':job['incarnation'],'originalDesign':True,'canonicalCostume':False,'frameCount':1,'pose':'neutral-ready','facing':1,'frame':{'file':dest.name,'rect':[x0,y0,x1-x0,y1-y0],'pivot':[0.5,1.0],'sourceFootFloorYProposed':y1},'pivotQualification':'Bounding midpoint only, awaits Root body/sole datum review. No game worldHeight or runtime admission.','nominalCellXYXY':nominal,'mainComponentIDs':[c['id']for c in owned],'mainComponentCount':len(owned),'mainComponentsCrossNominalCell':crosses,'status':'GENERATED_STATIC_SOURCE_AWAITING_ROOT_REVIEW'})
result={'schema':'cqc.static-costume-atlas-source/1','generatedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'uid':uid,'name':job['name'],'incarnation':job['incarnation'],'staticOnly':True,'animationGenerated':False,'poseCount':len(families),'animationFramesPerCostume':1,'image':{'path':str(dest),'generatorPath':generated,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'width':w,'height':h,'sourcePixelsModified':False},'reference':job['originalPose'],'layout':{'columns':cols,'rows':rows,'slotOrder':families,'variableFrameRectsRequired':True},'slots':slots,'status':'GENERATED_STATIC_SOURCE_AWAITING_ROOT_ART_AND_CATALOG_REVIEW','runtimeOrAnimationAdmission':False,'ASWrites':False,'GitWrites':False}
(out/('STATIC_SOURCE_SLOTS_PRIVATE_V'+str(version)+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
qa={'schema':'cqc.static-atlas-measured-qa/1','sourceSHA256':result['image']['sha256'],'counts':{'alpha0':int(hist[0]),'alpha1to16':int(hist[1:17].sum()),'alpha17to254':int(hist[17:255].sum()),'alpha255':int(hist[255])},'mainAlpha16Components':components,'allExpectedSlotsHaveComponents':all(s.get('status')!='MISSING_COMPONENT_HOLD'for s in slots),'unusedCellMainComponents':[c for c in components if c['proposedSlot']>=len(families)],'slotsRequiringVariableCuts':[s['index']for s in slots if s.get('mainComponentsCrossNominalCell')],'sourceReencodedOrCropped':False,'RootArtReview':False,'qualification':'Geometry proposal only. PNG exact; no filters, alpha edits, cropping or painting performed. Fine pixel alpha/pose identity and anatomy still require visual Root review.'}
(out/('STATIC_ALPHA_GEOMETRY_QA_PRIVATE_V'+str(version)+'.json')).write_text(json.dumps(qa,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'uid':uid,'path':str(dest),'generatorPath':generated,'bytes':len(raw),'sha256':result['image']['sha256'],'poses':len(families),'mainComponents':len(components),'unusedComponents':len(qa['unusedCellMainComponents']),'variableCutSlots':qa['slotsRequiringVariableCuts']}))
