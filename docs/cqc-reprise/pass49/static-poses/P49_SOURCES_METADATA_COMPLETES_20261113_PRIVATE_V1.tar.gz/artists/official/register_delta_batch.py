import os,json,pathlib,subprocess,sys
base=pathlib.Path('/tmp/cqc-static-20261113')
uid='archive__naked_delta'; tag,gen,*ids=sys.argv[1:]
fd=os.open(base/'official/OFFICIAL_COSTUMES_416_CURRENT_RECONCILIATION_PRIVATE_V1.json',os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
with os.fdopen(fd) as f: rows=json.load(f)['rows']
by={r['id']:r for r in rows if r['uid']==uid}
refs=json.loads((base/'official/delta-all-official-refs/FETCH_RECEIPT_PRIVATE_V1.json').read_text()); refby={r['id']:r for r in refs}
slots=[{'uid':uid,'costumeID':k,'historicalAlias':by[k]['historicalID'],'label':by[k]['costume'],'classification':'official-same-game-retail-uniform'} for k in ids]
if 'official--tuxedo' in ids:
 slots[ids.index('official--tuxedo')]['plannedFamilyAliasProposal']='tuxedo'
spec={'uid':uid,'period':'Delta remake,1964 Naked Snake own face,pre-eye-injury,two healthy eyes','generatorPath':gen,'rawFilename':uid+'-'+tag+'-raw-v1.png','proposalFilename':'DELTA_'+tag.upper().replace('-','_')+'_ARTIFACT_PROPOSAL_PRIVATE_V1.json','columns':2,'rows':1 if len(ids)==2 else 2,'slots':slots,'referenceSources':[{'path':refby[k]['file'],'URL':refby[k]['url'],'sha256':refby[k]['sha256'],'viewed':True,'subject':by[k]['costume']+' actual retail Delta modelviewer'} for k in ids]+[{'path':str(base/'artists/official/archive__naked_delta-original-right-reference.png'),'viewed':True,'subject':'Current selected Delta body/identity/art direction'}],'visualReview':{'reviewer':'official_inventory','newSpritesViewed':True,'retailReferencesViewed':True,'sameIdentityAndPeriod':True,'sourceOnly':True,'limits':'Pose adapted to face RIGHT. Fine textiles, insignia lettering and hidden back surfaces are interpreted from the visible retail screenshots, not pixel-certified. Exact generator output preserved; tiny colored/weak-alpha edge residue may need Root Source review.'}}
p=base/'artists/official'/('DELTA_'+tag.upper().replace('-','_')+'_REGISTRATION_SPEC_PRIVATE_V1.json');p.write_text(json.dumps(spec,ensure_ascii=False,indent=2)+'\n')
subprocess.run(['python',str(base/'artists/official/register_static_page.py'),str(p)],check=True)
