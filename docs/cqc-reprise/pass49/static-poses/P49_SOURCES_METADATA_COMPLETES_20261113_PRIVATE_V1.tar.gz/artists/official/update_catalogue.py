import json,pathlib,hashlib,datetime,os
OUT=pathlib.Path('/tmp/cqc-static-20261113/artists/official')
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
pages=[];entries=[];proofs=[];seen=set()
proposal_paths = list(OUT.glob('*_ARTIFACT_PROPOSAL_PRIVATE_V*.json')) + list((OUT.parent/'root_official').glob('*_ARTIFACT_PROPOSAL_PRIVATE_V*.json'))
for artist in ['a','b','c','d','e']:
 extra=OUT.parent/artist/'official'
 if extra.exists(): proposal_paths.extend(extra.rglob('*_ARTIFACT_PROPOSAL_PRIVATE_V*.json'))
preferred={}
for pp in sorted(set(proposal_paths)):
 aa=json.loads(read(pp))
 if aa.get('preferredForKey'):
  kk=aa['preferredForKey']
  if kk not in preferred or aa.get('atUTC','')>preferred[kk][1]:preferred[kk]=(str(pp),aa.get('atUTC',''))
for p in sorted(set(proposal_paths)):
 raw=read(p);a=json.loads(raw);png=a['rawPNG'];b=read(pathlib.Path(png['path']));assert len(b)==png['bytes']and hashlib.sha256(b).hexdigest()==png['sha256'];pageid=pathlib.Path(png['path']).stem;assert pageid not in seen;seen.add(pageid)
 pages.append({'id':pageid,'file':pathlib.Path(png['path']).name,'localPath':png['path'],'bytes':len(b),'sha256':png['sha256'],'width':png['width'],'height':png['height'],'columns':a['atlas']['columns'],'rows':a['atlas']['rows'],'rawPNGTransformed':False})
 proofs.append({'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 for s in a['slots']:
  key=s['uid']+':'+s['costumeID']
  if key in preferred and preferred[key][0]!=str(p):continue
  assert key not in {x['key']for x in entries}
  entries.append({'key':key,'uid':s['uid'],'id':s['costumeID'],'label':s['label'],'classification':s['classification'],'page':pageid,'rect':s['sourceRect'],'bodyDatumX':s['bodyDatumX'],'footDatumY':s['footDatumY'],'facing':'right','poseCount':1,'animationCount':0,'officialHistoricalAlias':s.get('historicalAlias',s.get('historicalID')),'plannedFamilyAliases':[s['plannedFamilyAliasProposal']] if s.get('plannedFamilyAliasProposal') else [],'artistOrigin':str(p.parent.relative_to(OUT.parent)),'canonicalAppearanceState':s.get('canonicalAppearanceState'),'correction':bool(a.get('correction')),'sourceLimits':s.get('sourceLimits'),'preferredForKey':a.get('preferredForKey'),'referenceSources':a.get('referenceSources',[]),'artStatus':'DRAWN_SINGLE_POSE_PENDING_ROOT_REVIEW','runtimeAdmitted':False})
d={'schema':'cqc.static.official-current-source-catalog/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pages':pages,'entries':entries,'counts':{'rawPNGs':len(pages),'logicalSinglePoseSprites':len(entries),'official':sum(x['classification'].startswith('official')for x in entries),'invented':sum(not x['classification'].startswith('official') and x['classification']!='corrected-original-pose' for x in entries),'correctedOriginal':sum(x['classification']=='corrected-original-pose' for x in entries),'UIDs':len({x['uid']for x in entries}),'animations':0},'qualification':'Raw imagegen PNGs preserved exactly. Each entry is one logical sprite with a source rectangle, never an animation. Source art and final Root acceptance are distinct; no A/S or gameplay integration is claimed. Official variant existence/references are attested, but retailUV/pixel-perfect accuracy is not certified.'}
catalog=OUT/'OFFICIAL_ALL_CURRENT_SOURCE_CATALOG_PUBLIC_V1.json';catalog.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
h={'schema':'cqc.static.official-current-artist-handoff/1','atUTC':d['atUTC'],'counts':d['counts'],'catalogue':{'path':str(catalog),'bytes':catalog.stat().st_size,'sha256':hashlib.sha256(read(catalog)).hexdigest()},'artifactProposals':proofs,'rawPNGs':[dict(p,localPath=p['localPath'])for p in pages],'newRuntimeAdmissions':0,'newAnimations':0,'ASWrites':False,'GitWrites':False,'SourcePixelsEditedByCPU':False,'notes':['MGS3PS2ceremony has a canonicalRIGHTeyepatch appearance-state exception; all default/inventedMGS3preinjury costumes retain two eyes.','MetalOctoCamofinish is not a fullcyborg or inventedMetalGearfamily substitute.','Sourceweakalpha residues and variableAABBs are disclosed perpage. Root must review before final admission.','TuxedoMGS3 and unreadable references remain pending; no false canon generated.']};p=OUT/'OFFICIAL_ALL_CURRENT_HANDOFF_PRIVATE_V1.json';p.write_text(json.dumps(h,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'counts':h['counts'],'catalogue':h['catalogue'],'handoff':str(p)}))
