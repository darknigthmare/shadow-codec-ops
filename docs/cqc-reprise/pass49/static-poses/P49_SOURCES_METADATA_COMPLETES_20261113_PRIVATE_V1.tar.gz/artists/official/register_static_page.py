"""Preserve an exact generated PNG and propose per-pose source rectangles; no edits."""
import os,pathlib,json,io,hashlib,datetime,sys
from PIL import Image
import numpy as np
import scipy.ndimage as ndi
OUT=pathlib.Path('/tmp/cqc-static-20261113/artists/official')
spec=json.loads(pathlib.Path(sys.argv[1]).read_text());src=pathlib.Path(spec['generatorPath']);assert src.parent==pathlib.Path('/workspace/generated_images')and src.suffix=='.png'
with os.fdopen(os.open(src,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:b=f.read()
dst=OUT/spec['rawFilename'];assert dst.suffix=='.png'and dst.parent==OUT
if dst.exists():assert dst.read_bytes()==b
else:dst.write_bytes(b)
im=Image.open(io.BytesIO(b));assert im.mode=='RGBA';a=np.array(im.getchannel('A'));labels,n=ndi.label(a>16);sizes=np.bincount(labels.ravel());boxes=ndi.find_objects(labels)
large=[i for i in range(1,len(sizes))if sizes[i]>=5000]
large.sort(key=lambda i:(int(((boxes[i-1][0].start+boxes[i-1][0].stop)/2)/(im.height/spec.get('rows',1))),boxes[i-1][1].start))
assert len(large)==len(spec['slots']),(len(large),len(spec['slots']))
entries=[]
for slot,i in zip(spec['slots'],large):
 box=boxes[i-1];x0,y0,x1,y1=box[1].start,box[0].start,box[1].stop,box[0].stop
 entries.append(dict(slot,sourceRect=[x0,y0,x1-x0,y1-y0],footDatumY=y1,bodyDatumX=slot.get('bodyDatumX',(x0+x1)/2),poseCount=1,facing='right',animationCount=0))
rec={'schema':'cqc.static.official-generated-page-proposal/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'uid':spec['uid'],'period':spec['period'],'rawPNG':{'path':str(dst),'generatorPath':str(src),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'width':im.width,'height':im.height,'rawPNGTransformed':False},'atlas':{'columns':spec['columns'],'rows':spec.get('rows',1),'onePosePerCostume':True,'animations':False},'slots':entries,'referenceSources':spec['referenceSources'],'visualReview':spec['visualReview'],'alphaAnalysis':{'min':int(a.min()),'max':int(a.max()),'alphaZero':int((a==0).sum()),'alphaAbove16':int((a>16).sum()),'mainComponentsAbove16':len(large),'edgeForegroundAbove16':int((a[0,:]>16).sum()+(a[-1,:]>16).sum()+(a[:,0]>16).sum()+(a[:,-1]>16).sum()),'weakAlphaResidue1to7Present':bool(((a>0)&(a<=7)).any()),'qualification':'Exact Source PNG retained. Alpha mask used for analysis only, not to edit/export pixels. Background/ownership review and final acceptance belong to Root.'},'SourcePixelsEditedByCPU':False,'ASWrites':False,'GitWrites':False,'runtimeAdmitted':False,'RootAdmission':'PENDING'}
p=OUT/spec['proposalFilename'];p.write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'proposal':str(p),'proposalBytes':p.stat().st_size,'proposalSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'raw':rec['rawPNG'],'rects':[r['sourceRect']for r in entries],'edge':rec['alphaAnalysis']['edgeForegroundAbove16']}))
