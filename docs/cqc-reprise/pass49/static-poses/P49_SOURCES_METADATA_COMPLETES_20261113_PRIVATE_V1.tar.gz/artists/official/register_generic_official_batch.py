import os,json,pathlib,subprocess,sys
base=pathlib.Path('/tmp/cqc-static-20261113');uid,tag,gen,*ids=sys.argv[1:]
fd=os.open(base/'official/OFFICIAL_COSTUMES_416_CURRENT_RECONCILIATION_PRIVATE_V1.json',os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
with os.fdopen(fd) as f: rows=json.load(f)['rows']
by={r['id']:r for r in rows if r['uid']==uid};refs=[]
for n in ['other-official-refs','other2-official-refs']:
 refs+=json.loads((base/'official'/n/'FETCH_RECEIPT_PRIVATE_V1.json').read_text())
refby={r['id']:r for r in refs if r['uid']==uid and r['status']=='DOWNLOADED_NOT_VIEWED'}
slots=[{'uid':uid,'costumeID':k,'historicalAlias':by[k]['historicalID'],'label':by[k]['costume'],'classification':'official-item-on-selected-custom-avatar' if uid=='archive__captain' else 'official-same-game-retail-uniform'} for k in ids]
orig=base/'artists/official'/(uid+'-original-right-reference.png')
spec={'uid':uid,'period':by[ids[0]]['game']+' exact selected UID, no cross-era substitution','generatorPath':gen,'rawFilename':uid+'-'+tag+'-raw-v1.png','proposalFilename':uid.upper().replace('__','_')+'_'+tag.upper().replace('-','_')+'_ARTIFACT_PROPOSAL_PRIVATE_V1.json','columns':3 if len(ids)==3 else 2,'rows':1 if len(ids) in [2,3] else 2,'slots':slots,'referenceSources':[{'path':refby[k]['file'],'URL':refby[k]['url'],'sha256':refby[k]['sha256'],'viewed':True,'subject':by[k]['costume']+' actual released-game accessory screenshot'} for k in ids]+[{'path':str(orig),'viewed':True,'subject':'Current selected UID original body/identity/art direction'}],'visualReview':{'reviewer':'official_inventory','newSpritesViewed':True,'referencesViewed':True,'sameIdentityAndPeriod':True,'sourceOnly':True,'limits':('One right-facing neutral pose per outfit. Fine print/lettering and unseen surfaces are interpretation, not certified pixel-perfect retail UV. Exact generator pixels preserved.' + (' Official items are applied to selected curated customizable male Captain avatar body; source female avatar establishes ITEM geometry/pattern only, not whole outfit or gender. Headgear/paint replaces mutually exclusive default beanie/respirator.' if uid=='archive__captain' else ' Exact selected same-era UID, no cross-era substitution.'))}}
p=base/'artists/official'/(uid+'-'+tag+'-registration-private.json');p.write_text(json.dumps(spec,ensure_ascii=False,indent=2)+'\n')
subprocess.run(['python',str(base/'artists/official/register_static_page.py'),str(p)],check=True)
