import collections,datetime,hashlib,io,json,os
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
from scipy import ndimage
B=Path('/tmp/cqc-static-20261113');C=B/'catalog'
OUT=C/'FRAME_SELECTION_CORRECTIONS_PRIVATE_V1.json'
def rb(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as f:return f.read()
def rd(p):return json.loads(rb(p))
audit=rd(B/'inventory/FINAL_PLANNED_STATIC_COVERAGE_AUDIT_PRIVATE_V1.json')
manifest=rd(C/'manifest-all381.json');by={(e['uid'],e['costumeId']):e for e in manifest['entries']}
spec={
'core__ocelot_mgs2':{'metalgear':(430,0,1150,1024),'furry':(1150,0,1536,1024)},
'core__johnny_mgs4':{'zombie':(0,490,768,1024)},
'core__screaming_mantis':{'retro':(0,0,512,460),'cyborg':(512,0,1024,460),'survive':(1024,0,1536,460),'metalgear':(0,460,535,1024),'zombie':(535,460,1024,1024),'furry':(1024,460,1536,1024)},
'core__bloody_brad':{'survive':(450,0,900,500),'metalgear':(900,0,1536,500)},
'core__pyro':{'survive':(470,0,940,500),'metalgear':(940,0,1536,500)},
'core__solidus':{'survive':(470,0,940,490)},
'core__liquid':{'survive':(0,0,660,490),'zombie':(0,490,768,1024),'furry':(768,490,1536,1024)},
'archive__paz':{'furry':(512,490,1024,1024)},
'archive__coldman':{'metalgear':(0,512,610,1024),'zombie':(610,512,1024,1024)},
'archive__reeve':{'retro':(0,0,512,480),'cyborg':(512,0,900,480),'metalgear':(900,0,1536,480),'tuxedo':(0,480,512,1024),'zombie':(512,480,1024,1024),'furry':(1024,480,1536,1024)},
'archive__snake_tts':{'metalgear':(940,0,1536,500)},
'completion44__diamond_dogs_scout_44':{'furry':(1024,490,1536,1024)},
'roster51__mantis_tts':{'survive':(500,0,870,480),'metalgear':(870,0,1536,480),'furry':(1024,480,1536,1024)},
'core__old_snake':{'zombie':(980,0,1536,1024)}
}
def simplify(points,tolerance):
 if len(points)<3:return points
 a=np.array(points[0]);b=np.array(points[-1]);p=np.array(points);v=b-a
 t=np.clip(((p-a)@v)/(float(v@v) or 1),0,1);dist=np.sqrt(((p-(a+t[:,None]*v))**2).sum(1));i=int(dist.argmax())
 if dist[i]<=tolerance:return [points[0],points[-1]]
 return simplify(points[:i+1],tolerance)[:-1]+simplify(points[i:],tolerance)
def gutter(first,second,rect):
 x,y,w,h=rect;leftmin=np.where(first,np.arange(first.shape[1])[None,:],100000).min(1);leftmax=np.where(first,np.arange(first.shape[1])[None,:],-1).max(1);rightmin=np.where(second,np.arange(second.shape[1])[None,:],100000).min(1);rightmax=np.where(second,np.arange(second.shape[1])[None,:],-1).max(1)
 valid=(leftmax>=0)&(rightmax>=0);ys=np.where(valid)[0]
 if ((rightmin[valid]-leftmax[valid]-1)<4).any():raise ValueError('No safe gutter')
 mids=(leftmax[ys]+rightmin[ys])/2
 vals=np.interp(np.arange(y,y+h+1),ys,mids);return [[float(np.clip(v,x,x+w)),float(yy)] for yy,v in zip(range(y,y+h+1),vals)]
corrections=[];checks=[]
for uid,costumes in spec.items():
 finding=next(f for f in audit['frameSelectionVisualReview']['findings'] if f['uid']==uid)
 path=Path(finding['sourcePNG']);b=rb(path);sha=hashlib.sha256(b).hexdigest();im=Image.open(io.BytesIO(b)).convert('RGBA');a=np.asarray(im)[:,:,3];lab,n=ndimage.label(a>16);sizes=np.bincount(lab.ravel());boxes=ndimage.find_objects(lab);centers=ndimage.center_of_mass(a,lab,range(1,n+1))
 eligible=[i for i in range(1,n+1) if sizes[i]>=20]
 large=[i for i in range(1,n+1) if sizes[i]>=500]
 for costume,roi in costumes.items():
  e=by[uid,costume];assert e['source']['sha256']==sha
  x0,y0,x1,y1=roi;ids=[i for i in eligible if x0<=centers[i-1][1]<x1 and y0<=centers[i-1][0]<y1]
  assert ids,(uid,costume)
  target=np.isin(lab,ids);yy,xx=np.where(target);lx=max(0,int(xx.min())-3);ty=max(0,int(yy.min())-3);rx=min(im.width,int(xx.max())+4);byy=min(im.height,int(yy.max())+4);rect=[lx,ty,rx-lx,byy-ty]
  poly=None
  if uid=='core__ocelot_mgs2':
   mg=lab==max(large,key=lambda i:sizes[i]);furry=lab==max(large,key=lambda i:centers[i-1][1]);human=lab==min(large,key=lambda i:centers[i-1][1])
   if costume=='metalgear':left=gutter(human,mg,rect);right=gutter(mg,furry,rect)
   else:left=gutter(mg,furry,rect);right=[[rx,ty],[rx,byy]]
   points=simplify(left,1.5)+list(reversed(simplify(right,1.5)))
   poly=[[(px-lx)/(rx-lx),(py-ty)/(byy-ty)] for px,py in points]
  elif uid=='core__solidus':
   other=lab==max(large,key=lambda i:centers[i-1][1]);right=gutter(target,other,rect);points=[[lx,ty]]+simplify(right,1.5)+[[lx,byy]];poly=[[(px-lx)/(rx-lx),(py-ty)/(byy-ty)] for px,py in points]
  # Analytical display mask only. No PNG output or raster modification.
  mask=np.zeros(a.shape,bool)
  if poly:
   v=Image.new('1',(rect[2],rect[3]),0);dr=ImageDraw.Draw(v);dr.polygon([(px*rect[2],py*rect[3]) for px,py in poly],fill=1);mask[ty:byy,lx:rx]=np.asarray(v,dtype=bool)
  else:mask[ty:byy,lx:rx]=True
  missing=int((target&~mask).sum());foreign=int((np.isin(lab,[i for i in large if i not in ids])&mask).sum());assert not missing,(uid,costume,'cut',missing);assert not foreign,(uid,costume,'foreign',foreign)
  footY=int(yy.max())+1;band=max(5,round((int(yy.max())-int(yy.min())+1)*.08));fy,fx=np.where(target&(a>128)&(np.indices(a.shape)[0]>=footY-band));footX=(int(fx.min())+int(fx.max())+1)/2
  pivot=[(footX-lx)/rect[2],(footY-ty)/rect[3]];assert all(0<=v<=1 for v in pivot)
  old=e['frame'];row={'uid':uid,'costumeId':costume,'sourceSHA256':sha,'rect':rect,'frameRect':rect,'footprint':{'x':footX,'y':footY},'pivot':pivot,'reviewer':'static_inventory / artist E','reason':finding['visualFinding'],'sourcePNG':str(path),'sourceURL':e['source']['src'],'sourceDimensions':[im.width,im.height],'previousRect':old['rect'],'previousPivot':old.get('pivot'),'actualWholeSourceViewed':True,'proof':{'alphaThreshold':16,'wholePoseComponentIDs':ids,'completeSelectedForegroundPixels':int(target.sum()),'selectedForegroundPixelsOmitted':missing,'foreignLargeComponentPixelsIncluded':foreign,'footprintMethod':'Standing contact/support midpoint in bottom8% of selected full silhouette at alpha>128; footY one pixel past actual full silhouette bottom. Visually checked in renderer.','PNGBytes':len(b),'rawPixelsModified':False},'status':'PENDING_RENDERED_CORRECTION_VERIFICATION'}
  if poly:row['clipPolygon']=poly
  corrections.append(row);checks.append({'uid':uid,'costumeId':costume,'rect':rect,'footprint':row['footprint'],'polygonVertices':len(poly) if poly else 0,'targetMissing':missing,'foreignLarge':foreign})
d={'schema':'cqc.static.catalog-frame-selection-corrections/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceManifestAtUTC':manifest['createdAtUTC'],'scope':'32 costume display frames for14UIDs only. Exact source PNGs unchanged. Original imports, builds, indices and art reviews not modified.','coordinateSystem':{'rect':'Absolute source PNG pixel coordinates x,y,width,height.','footprint':'Absolute source PNG x/y support datum.','pivot':'Normalized footprint within rect.','clipPolygon':'Normalized0..1 coordinates relative to rect, matching catalogue render clipPath.'},'corrections':corrections,'verification':{'state':'PENDING_RENDER_CAPTURE','sourcePNGEdits':False,'indexWrites':False,'buildOrImportCalled':False,'newGenerationCalled':False,'allSelectedAlpha16ForegroundPreserved':True,'foreignLargeComponentPixelsIncluded':0,'analyticalChecks':checks}}
OUT.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'file':str(OUT),'corrections':len(corrections),'UIDs':len(spec),'polygonCount':sum('clipPolygon'in x for x in corrections),'checks':checks},ensure_ascii=False))
