import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
const base='/tmp/cqc-static-20261113',file=base+'/catalog/FRAME_SELECTION_CORRECTIONS_PRIVATE_V1.json';
const data=JSON.parse(fs.readFileSync(file,'utf8'));
const targets=await(await fetch('http://127.0.0.1:9224/json/list')).json();
const target=targets.find(x=>x.type==='page');assert(target);
const ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise((r,j)=>{ws.addEventListener('open',r,{once:true});ws.addEventListener('error',j,{once:true});});
let serial=0;const pending=new Map();ws.addEventListener('message',({data})=>{const m=JSON.parse(data);if(!m.id)return;const p=pending.get(m.id);if(!p)return;pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);});
const call=(method,params={})=>new Promise((resolve,reject)=>{const id=++serial;pending.set(id,{resolve,reject});ws.send(JSON.stringify({id,method,params}));});
const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;};
await call('Page.enable');await call('Runtime.enable');await call('Emulation.setDeviceMetricsOverride',{width:1440,height:1720,deviceScaleFactor:1,mobile:false});
await call('Page.navigate',{url:'http://127.0.0.1:8150/index.html'});
for(let n=0;n<60;n++){try{if(await ev('document.readyState==="complete"'))break;}catch{}await new Promise(r=>setTimeout(r,100));}
const renders=[],captures=[];
for(let start=0;start<data.corrections.length;start+=16){
 const entries=data.corrections.slice(start,start+16);
 const rows=await ev(`(async()=>{
  const {placement}=await import('/manifest-model.mjs');
  document.title='Private corrected-frame verification';document.body.innerHTML='';
  const css=document.createElement('style');css.textContent='*{box-sizing:border-box}body{margin:0;padding:18px;background:#151d25;color:#e6eff5;font:12px sans-serif}h1{font-size:18px;margin:0 0 12px}.grid{display:grid;grid-template-columns:repeat(4,340px);gap:12px}.card{border:1px solid #496078;padding:8px;background:#202c39;height:403px}.label{height:24px;font-size:11px;overflow:hidden}.stage{width:320px;height:360px;background-color:#33404b;background-image:linear-gradient(45deg,#3b4956 25%,transparent25%),linear-gradient(-45deg,#3b4956 25%,transparent25%),linear-gradient(45deg,transparent75%,#3b4956 75%),linear-gradient(-45deg,transparent75%,#3b4956 75%);background-size:20px20px;background-position:0 0,0 10px,10px -10px,-10px0px}';document.head.append(css);
  const h=document.createElement('h1');h.textContent='32 cadres corrigés — preuve du rendu réel du catalogue — page '+${JSON.stringify(start/16+1)};document.body.append(h);const grid=document.createElement('div');grid.className='grid';document.body.append(grid);
  const rows=[];
  for(const e of ${JSON.stringify(entries)}){
   const card=document.createElement('div');card.className='card';const label=document.createElement('div');label.className='label';label.textContent=e.uid+' / '+e.costumeId;card.append(label);const stage=document.createElement('div');stage.className='stage';const cv=document.createElement('canvas');cv.width=320;cv.height=360;stage.append(cv);card.append(stage);grid.append(card);
   const img=new Image();img.src=e.sourceURL.startsWith('/')?e.sourceURL:'/'+e.sourceURL;await img.decode();
   const frame={rect:e.rect,pivot:e.pivot},p=placement(frame,320,360),c=cv.getContext('2d');c.imageSmoothingEnabled=e.costumeId!=='retro';c.save();
   if(e.clipPolygon){c.beginPath();e.clipPolygon.forEach(([x,y],i)=>{const xx=p.x+x*e.rect[2]*p.scale,yy=p.y+y*e.rect[3]*p.scale;i?c.lineTo(xx,yy):c.moveTo(xx,yy)});c.closePath();c.clip('evenodd');}
   c.drawImage(img,...e.rect,p.x,p.y,p.width,p.height);c.restore();
   const a=c.getImageData(0,0,320,360).data;let edges=0,fg=0;for(let y=0;y<360;y++)for(let x=0;x<320;x++){if(a[(y*320+x)*4+3]>16){fg++;if(x===0||x===319||y===0||y===359)edges++;}}
   rows.push({uid:e.uid,costumeId:e.costumeId,sourceDecoded:true,sourceNaturalDimensions:[img.naturalWidth,img.naturalHeight],canvasForegroundAbove16:fg,canvasEdgeForegroundAbove16:edges,placement:p});
  }
  await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));return rows;
 })()`);
 renders.push(...rows);
 const shot=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});const bytes=Buffer.from(shot.data,'base64');const filename=base+'/catalog/qa/FRAME_CORRECTION_RENDER_'+String(start/16+1).padStart(2,'0')+'_PRIVATE_V1.png';fs.writeFileSync(filename,bytes);captures.push({path:filename,bytes:bytes.length,sha256:crypto.createHash('sha256').update(bytes).digest('hex'),startIndex:start,count:entries.length,actualBrowserCapture:true});
}
assert.equal(renders.length,32);assert(renders.every(x=>x.sourceDecoded&&x.canvasForegroundAbove16>100&&x.canvasEdgeForegroundAbove16===0));
data.verification={...data.verification,state:'RENDERED_SOURCE_DECODE_AND_CANVAS_EDGE_PASS_VISUAL_REVIEW_PENDING',actualCataloguePlacementUsed:true,renderedPoses:32,allSourcesDecoded:true,allCanvasEdgeForegroundAbove16Zero:true,renders,captures,renderMethod:'Own Chromium CDP9224; actual catalogue placement function and identical normalized display clip semantics. Screenshots are application QA evidence, not modified source PNGs.'};
for(const e of data.corrections){e.status='RENDERED_CORRECTION_PENDING_FINAL_VISUAL_REVIEW';e.proof.browserRender=renders.find(r=>r.uid===e.uid&&r.costumeId===e.costumeId);e.proof.renderCapture=captures[Math.floor(data.corrections.indexOf(e)/16)].path;}
fs.writeFileSync(file,JSON.stringify(data,null,2)+'\n');console.log(JSON.stringify({file,renders:32,captures,canvasEdgesAllZero:true}));ws.close();
