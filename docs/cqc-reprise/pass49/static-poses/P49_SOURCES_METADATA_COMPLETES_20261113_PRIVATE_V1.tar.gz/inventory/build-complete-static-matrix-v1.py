import os,pathlib,json,gzip,hashlib,collections,urllib.parse,datetime,csv,re
N=pathlib.Path('/tmp/cqc-static-20261113');OUT=N/'inventory';A=pathlib.Path('/workspace/cqc-pass21-application/public/cqc');C=OUT/'original-contracts381'
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
def fileName(v):
 if isinstance(v,dict):
  if isinstance(v.get('nativePathParts'),list):return '/'.join(v['nativePathParts'])
  return None
 return v if isinstance(v,str)else None
def localPath(v):
 s=fileName(v)
 if not s:return None
 if s.startswith(('http:','https:')):
  p=urllib.parse.unquote(urllib.parse.urlsplit(s).path);s='assets/'+p.split('/assets/',1)[1]if'/assets/'in p else None
 if not s:return None
 p=pathlib.Path(s)if s.startswith('/')else A/s
 return p if p.exists()and p.is_file()else None
cache={}
manifest=json.loads(read(A/'runtime-manifest.json'));manifestSHA=collections.defaultdict(list)
for entry in manifest['files']:
 if entry.get('sha256')and entry['path'].endswith(('.png','.webp')):manifestSHA[entry['sha256']].append(A/entry['path'])
def assetProof(v,expected=None):
 p=localPath(v)
 matchedAlias=False
 if p is None and expected in manifestSHA:
  p=next((q for q in manifestSHA[expected]if q.exists()and q.is_file()),None);matchedAlias=p is not None
 if p is None:return{'sourceFile':v,'localPresent':False,'expectedSHA256':expected,'qualification':'Immutable indexed Source pointer;local bytes not yet matched.'}
 key=str(p)
 if key not in cache:
  before=p.stat();b=read(p);after=p.stat();assert before==after,str(p)
  kind='PNG'if b[:8]==b'\x89PNG\r\n\x1a\n'else'WEBP'if b[:4]==b'RIFF'and b[8:12]==b'WEBP'else'OTHER'
  cache[key]={'file':str(p),'sourceFile':v,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'format':kind,'localPresent':True,'sourceStatsPreserved':True,'dimensions':[int.from_bytes(b[16:20],'big'),int.from_bytes(b[20:24],'big')]if kind=='PNG'else None}
 out=dict(cache[key]);out['sourceFile']=v;out['resolvedByManifestSHA256Alias']=matchedAlias;out['expectedSHA256']=expected;out['SHA256Matches']=expected is None or expected==out['sha256'];return out
def poseFromSprite(sp):
 if not isinstance(sp,dict):return None
 frames=(sp.get('actions',{}).get('idle')or{}).get('frames')or[]
 if not frames:return None
 f=frames[0]
 if not isinstance(f,dict)or not f.get('file'):return None
 proof=assetProof(f['file'],f.get('sha256'));return {'file':proof.get('file')or fileName(f['file']),'frameRect':f.get('rect'),'pivot':f.get('pivot'),'clipPolygon':f.get('clipPolygon'),'assetProof':proof,'isFallback':False,'sourceReview':sp.get('review'),'referenceStatus':sp.get('referenceStatus'),'canonicalBodyAppearanceAttested':sp.get('canonicalBodyAppearanceAttested'),'presentationReconstruction':sp.get('presentationReconstruction',False),'qualification':'Existing authored native idle frame;no new visual/1:1 certification.'}
S=json.loads(read(OUT/'EXCEL_V9_STATIC_INPUTS_PRIVATE_V1.json'));base=S['P46 Huit familles'];contracts={p.name.removesuffix('.json.gz'):json.loads(gzip.decompress(read(p)))for p in C.glob('*.json.gz')};assert len(contracts)==381
ageIndex={};coveredCanonicalFullChassis=set()
queuePath=N/'recovered-core/original-paths/tmp/cqc-zc-20261109/inventory/ZC_ALL_MISSING676_SOURCE_ONLY_QUEUE_PUBLIC_V2.json'
for r in json.loads(read(queuePath))['rows']:
 if r.get('duplicateCanonicalFullChassisExcludedFromGeneration'):coveredCanonicalFullChassis.add(r['uid'])
 old=ageIndex.setdefault(r['uid'],{})
 for k in ['ageTreatment','ageNote','geometryKind','bodyBuild','geometryRoute','partialProsthesisFullChassisStillEligible']:
  if r.get(k)and(not old.get(k)or k=='ageTreatment'and'YOUTHFUL'in r[k]):old[k]=r[k]
 old['duplicateCanonicalFullChassisExcludedFromGeneration']=r['uid']in coveredCanonicalFullChassis
priority=json.loads(read(OUT/'STATIC_PRIORITY20_JOBS_PUBLIC_V1.json'))['jobs'];priorityBy={j['uid']:j for j in priority};uidOrder=[j['uid']for j in priority]+[uid for uid in contracts if uid not in priorityBy]
native=json.loads(read(OUT/'CURRENT_NATIVE_OPTION_SOURCE_CANDIDATES_PRIVATE_V1.json'))['rows'];nativeBy=collections.defaultdict(list)
def rank(x):
 m=re.search(r'pass(\d+)',x['index']);return int(m.group(1))if m else 0
native.sort(key=rank)
for r in native:nativeBy[(r['uid'],r['family'])].append(r)
sourceBy={}
for j in priority:
 for r in j['existingCostumes']:
  if r['reason']=='P48_RIGHT_IDLE_DRAWN_REUSE_STATIC_NEEDS_CROP_QA':sourceBy[(j['uid'],r['family'])]=r
previews=json.loads(read(OUT/'P48_SOURCE_ONLY_STATIC_PREVIEW_CANDIDATES_PRIVATE_V1.json'))['poses'];previewBy={(r['uid'],r['family']):r for r in previews}
labels={'original':'Original','retro':'Rétro','nextgen':'Nouvelle génération','cyborg':'Châssis cybernétique','survive':'Expédition Dité','metalgear':'Metal Gear','tuxedo':'Tenue de soirée','zombie':'Zombie','furry':'Furry'}
orig={};rows=[];byUID={u:[]for u in uidOrder};missingOriginal=[]
for uid in uidOrder:
 d=contracts[uid];sp=d.get('sprite');pose=poseFromSprite(sp);orig[uid]=pose
 state='EXISTING_DRAWN_POSE'if pose and pose['assetProof']['localPresent']and pose['assetProof']['SHA256Matches']else'ORIGINAL_NATIVE_PARTS_OR_SOURCE_REVIEW_PENDING'
 if not pose:missingOriginal.append({'uid':uid,'name':d['fighter']['name'],'visualKind':d['fighter'].get('visual',{}).get('kind'),'reason':'No sprite field in Original contract; review existing machine-part graph before generating an Original duplicate.'})
 r={'uid':uid,'name':d['fighter']['name'],'incarnation':(sp or{}).get('incarnation')or d['fighter'].get('ep'),'id':'original','family':'original','label':'Original','type':'original-incarnation-source','status':state,'generationRequired':False,'sourcePose':pose,'coversFamilies':[],'qualification':'Original existing native pose reused. Original parts-only entries require a compositor/source check and are not automatically missing or certified.'};rows.append(r);byUID[uid].append(r)
for old in base:
 uid=old['uid'];family=old['famille'];status=old['statutInventaire'];current=nativeBy.get((uid,family),[]);pose=None;sourceCandidate=None;review=False;applicable=status!='SANS_OBJET';required=False;hold=None
 if uid in ['core__fear','core__eva_mgs3']and family=='cyborg':state='GENERATION_MODERATION_HOLD';hold='Protected historic service refusal: no retry/rephrase/alternate pipeline.'
 elif family=='cyborg'and uid in coveredCanonicalFullChassis:
  state='COVERED_BY_ORIGINAL_POSE';pose=orig[uid];byUID[uid][0]['coversFamilies'].append(family)
 elif status=='HOLD_HISTORIQUE':state='HISTORICAL_HOLD_SCOPE_REVIEW_PENDING';hold=old.get('holds')or'Historical hold without explicit cause in this sheet; review exact scope before generating.'
 elif not applicable:state='NOT_APPLICABLE_BASELINE'
 elif status.startswith('ORIGINAL_'):
  state='COVERED_BY_ORIGINAL_POSE';pose=orig[uid];byUID[uid][0]['coversFamilies'].append(family)
 elif current:
  sourceCandidate=current[-1];f=sourceCandidate.get('preview')
  if isinstance(f,dict)and f.get('file'):
   proof=assetProof(f['file'],f.get('sha256')or next((a.get('sha256')for a in sourceCandidate['assets']if fileName(a.get('file'))==fileName(f['file'])),None));remote=next((a.get('url')for a in sourceCandidate['assets']if a.get('sha256')==proof.get('expectedSHA256')and a.get('url')),None);proof['immutableSourceURL']=remote;pose={'file':proof.get('file')or remote or fileName(f['file']),'frameRect':f.get('rect'),'pivot':f.get('pivot'),'clipPolygon':f.get('clipPolygon'),'assetProof':proof,'isFallback':False}
  ar=sourceCandidate.get('artReview')or{};flags=all(ar.get(k)is True for k in ['MGRDesignReviewed','fullCyberneticBodyReviewed','personalizedDesignReviewed'])
  review=family=='cyborg'and not flags and rank(sourceCandidate)<40
  if pose and orig[uid]and pose.get('frameRect')==orig[uid].get('frameRect')and pose['assetProof'].get('sha256')==orig[uid]['assetProof'].get('sha256'):review=True;state='BODY_ALIAS_TO_ORIGINAL_NEEDS_REVIEW'
  elif pose and pose['assetProof']['localPresent']and pose['assetProof']['SHA256Matches']and not review:state='EXISTING_INDEPENDENT_SOURCE_POSE'
  elif pose and pose['assetProof'].get('immutableSourceURL')and not review:state='EXISTING_REVIEWED_REMOTE_SOURCE_POSE'
  elif review:state='EXISTING_SOURCE_NEEDS_FULL_CHASSIS_QUALITY_REVIEW'
  else:state='EXISTING_INDEXED_SOURCE_POSE_FETCH_OR_PARTS_REVIEW_PENDING'
 elif(uid,family)in sourceBy:
  state='P48_DRAWN_RIGHT_IDLE_NEEDS_STATIC_CROP_QA';sourceCandidate=sourceBy[(uid,family)]
  if(uid,family)in previewBy:
   p=previewBy[(uid,family)];f=p['pose'];pose={'file':f['file'],'frameRect':f['rect'],'pivot':f['pivot'],'clipPolygon':f.get('clipPolygon'),'expectedSHA256':f['sha256'],'sourceCommit':f['sourceCommit'],'isFallback':False,'qualification':p['geometryStage']}
 elif status.startswith('NATIF')or status=='SOURCE_EXISTANTE_NON_BRANCHEE':state='EXISTING_SOURCE_EXPECTED_LOOKUP_PENDING'
 else:state='MISSING_STATIC_POSE';required=True
 r={'uid':uid,'name':old['personnage'],'incarnation':old['epoque'],'id':sourceCandidate.get('id',family)if isinstance(sourceCandidate,dict)else family,'family':family,'label':labels[family],'type':'style-reinterpretation'if family in ['retro','nextgen']else'original-character-costume','status':state,'generationRequired':required,'applicable':applicable,'sourcePose':pose,'sourceCandidate':sourceCandidate,'qualityReviewRequired':review,'hold':hold,'baselineStatus':status,'qualification':'One static pose only. Source presence does not imply animations/gameplay admission; existing candidates are reviewed/recovered before duplicate generation.'};rows.append(r);byUID[uid].append(r)
characters=[];jobs=[]
for uid in uidOrder:
 d=contracts[uid];sp=d.get('sprite')or{};rs=byUID[uid];p=orig[uid];j={'uid':uid,'name':d['fighter']['name'],'incarnation':sp.get('incarnation')or d['fighter'].get('ep'),'originalGame':sp.get('game')or d['fighter'].get('ep'),'originalPose':priorityBy[uid]['originalPose']if uid in priorityBy else p,'missingCostumes':[{k:r[k]for k in ['id','family','label','type']}for r in rs if r['generationRequired']],'missingFamilies':[r['family']for r in rs if r['generationRequired']],'holds':[{'family':r['family'],'reason':r['hold']}for r in rs if r.get('hold')],'singlePoseAtlas':{'columns':3,'rows':3,'maxPoses':9,'animations':False},'referenceCopyPolicy':'Copy Original Source via O_NOATIME into owned TMP before passing to imagegen/view; preserve Original bytes/stats.','fidelityScope':'Exact selected UID/incarnation. No another-age costumes or cross-era appearance merging.','ageAndGeometry':ageIndex.get(uid,{'ageTreatment':'Review exact incarnation/Original reference; no age inference from generic renderer default.','geometryKind':d['fighter'].get('visual',{}).get('kind'),'bodyBuild':d['fighter'].get('visual',{}).get('body')}),'referenceSources':sp.get('review',{}).get('sources',[]),'originalWorldHeightReference':d.get('worldHeight'),'loadoutQualification':{'visualFirearmPresent':sp.get('visualFirearmPresent'),'gameAdaptationWeaponDefault':d['fighter'].get('visual',{}).get('weapon'),'qualification':'Generic versus weapon metadata is not canonical loadout evidence. Preserve the actually drawn Original and source-incarnation references; unarmed NPCs must not acquire a supposed official firearm.'},'furryConcept':'No specific species attested by this inventory; Root chooses a personalized original adaptation, never claims it is a released official costume.'}
 if uid in priorityBy:j.update({k:priorityBy[uid][k]for k in ['identityObservations','equipment','referenceURLs','furryConcept']})
 jobs.append(j);characters.append({'uid':uid,'name':j['name'],'incarnation':j['incarnation'],'originalPose':p,'costumes':rs,'missingPoseCount':len(j['missingCostumes'])})
summary={'schema':'cqc.static.full-roster-inventory/1','createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'381UID;Original plus8established families;official outfits supplied by separate source-reviewed inventory.','characters':381,'rows':len(rows),'newStaticGenerationRows':sum(r['generationRequired']for r in rows),'statusCounts':dict(collections.Counter(r['status']for r in rows)),'missingByFamily':dict(collections.Counter(r['family']for r in rows if r['generationRequired'])),'OriginalPartsReviewPending':len(missingOriginal),'uniqueLocalAssetsReadExact':len(cache),'allSourceReadsNoAtime':True,'sourceMutation':False,'animationsGenerated':False,'fidelityCertified':False}
for name,data in [('STATIC_ALL381_MATRIX_PRIVATE_V1.json',{'summary':summary,'characters':characters,'rows':rows}),('STATIC_ALL381_GENERATION_JOBS_PUBLIC_V1.json',{'summary':summary,'jobs':jobs}),('ORIGINAL24_NATIVE_PARTS_REVIEW_PENDING_PRIVATE_V1.json',{'qualification':'These are not declared missing art. Review their existing machine-part graph/renderer before new generation.','rows':missingOriginal}),('STATIC_LOCAL_ASSET_SHA_PROOFS_PRIVATE_V1.json',{'qualification':'Whole-byte PNG/WebP signatures and hashes from existing local Sources; no new visual QA.','rows':list(cache.values())})]:
 (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
shards=OUT/'uid-shards20';shards.mkdir(exist_ok=True)
for start in range(0,len(jobs),20):
 part=jobs[start:start+20];(shards/f'lot-{start//20+1:02d}.json').write_text(json.dumps({'schema':'cqc.static.uid-lot20/1','batch':start//20+1,'characters':len(part),'generationPoses':sum(len(j['missingCostumes'])for j in part),'jobs':part},ensure_ascii=False,indent=2)+'\n')
(OUT/'STATIC_COMPLETE_INVENTORY_SUMMARY_PUBLIC_V1.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False))
