import os,json,io,collections,concurrent.futures
from pathlib import Path
import numpy as np
from PIL import Image
from scipy import ndimage
B=Path('/tmp/cqc-static-20261113');C=B/'catalog';A=Path('/workspace/cqc-pass21-application/public/cqc')
def rb(p):
 f=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(f,'rb') as h:return h.read()
m=json.loads(rb(C/'manifest-all381.json'));groups=collections.defaultdict(list)
for e in m['entries']:
 if e['origin']=='official' or not e.get('source') or not e.get('frame'):continue
 s=e['source'];n=s['src'];p=Path(s['localPath']) if s.get('localPath') else A/n[8:] if n.startswith('/native/') else B/'artists/e/composites'/n[10:] if n.startswith('/captures/') else C/n
 groups[str(p)].append(e)
def job(item):
 p,es=item;a=np.asarray(Image.open(io.BytesIO(rb(p))).convert('RGBA'))[:,:,3];lab,n=ndimage.label(a>200);sizes=np.bincount(lab.ravel());boxes=ndimage.find_objects(lab);out=[]
 for e in es:
  if e['frame'].get('clipPolygon'):continue
  x,y,w,h=e['frame']['rect'];x,y,w,h=map(int,[x,y,w,h]);sub=lab[y:y+h,x:x+w];ids,cts=np.unique(sub,return_counts=True)
  for ident,inside in zip(ids,cts):
   if ident==0 or inside<500:continue
   outside=int(sizes[ident]-inside)
   if outside<20 or outside/max(1,int(sizes[ident]))<0.001:continue
   bb=boxes[ident-1];componentRect=[bb[1].start,bb[0].start,bb[1].stop-bb[1].start,bb[0].stop-bb[0].start]
   out.append({'uid':e['uid'],'costumeID':e['costumeId'],'family':e['family'],'path':p,'rect':[x,y,w,h],'opaqueComponentRect':componentRect,'opaqueInsideFrame':int(inside),'opaqueOutsideFrame':outside,'outsideRatio':outside/int(sizes[ident]),'status':'OPAQUE_COMPONENT_CONTINUES_BEYOND_SELECTED_RECT_REQUIRES_REVIEW'})
 return out
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for n,r in enumerate(pool.map(job,groups.items()),1):
  results.extend(r)
  if n%200==0:print('opaque component checks',n,flush=True)
P=B/'inventory/FINAL_PLANNED_STATIC_COVERAGE_AUDIT_PRIVATE_V1.json';d=json.loads(rb(P));d['opaqueFrameContinuationAnalysis']={'thresholdAlpha':200,'minimumForegroundInside':500,'minimumOutsidePixels':20,'minimumOutsideRatio':0.001,'sourcePathsRead':len(groups),'suspects':results,'qualification':'An opaque connected component extending beyond a selected rectangle is a crop-review signal, not automatic anatomical failure. Explicit normalized polygon clips are excluded because they intentionally select a partial page component.'};d['summary']['opaqueFrameContinuationSuspects']=len(results);P.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'suspects':len(results),'first':results[:10]},ensure_ascii=False),flush=True)
