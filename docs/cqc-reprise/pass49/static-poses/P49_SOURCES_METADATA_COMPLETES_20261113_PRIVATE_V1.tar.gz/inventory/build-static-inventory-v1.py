import os, pathlib, json, io, zipfile, xml.etree.ElementTree as E, collections, re, hashlib
OUT=pathlib.Path('/tmp/cqc-static-20261113/inventory');OUT.mkdir(parents=True,exist_ok=True)
A=pathlib.Path('/workspace/cqc-pass21-application/public/cqc')
WB=pathlib.Path('/workspace/cqc-reprise-20261109/livraison-v9/CQC_SUIVI_P48_NOV9_ETAPES_PUBLIC_V9.xlsx')
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
def sheets():
 z=zipfile.ZipFile(io.BytesIO(read(WB)));ns={'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'};ss=[]
 if 'xl/sharedStrings.xml'in z.namelist():ss=[''.join(x.itertext())for x in E.fromstring(z.read('xl/sharedStrings.xml'))]
 rels={x.attrib['Id']:x.attrib['Target'].lstrip('/')for x in E.fromstring(z.read('xl/_rels/workbook.xml.rels'))};result={}
 for sh in E.fromstring(z.read('xl/workbook.xml')).find('x:sheets',ns):
  name=sh.attrib['name'];t=rels[sh.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']];t=t if t.startswith('xl/')else'xl/'+t;rows=[]
  for row in E.fromstring(z.read(t)).findall('x:sheetData/x:row',ns):
   d={}
   for c in row.findall('x:c',ns):
    v=c.find('x:v',ns);v=v.text if v is not None else ''.join(c.find('x:is',ns).itertext())if c.find('x:is',ns)is not None else''
    d[c.attrib['r'].rstrip('0123456789')]=ss[int(v)]if c.attrib.get('t')=='s'else v
   rows.append(d)
  if name in ['P46 Huit familles','P46 Cinq familles','P47 V8 Étapes']:
   headers=rows[0];result[name]=[{v:r.get(k,'')for k,v in headers.items()}for r in rows[1:]]
  elif name in ['Index_statiques','Natifs_indexés','Historique_costumes','CSV_Costumes_V3']:result[name]=rows
 return result
S=sheets();matrix=S['P46 Huit familles'];assert len(matrix)==3048 and len({r['uid']for r in matrix})==381
decoder=json.JSONDecoder();parsed=[];parseFailures=[]
for p in sorted((A/'src').glob('*.js')):
 if not any(w in p.name for w in ['costume','native-batch-index','pass48-reviewed','native-wardrobe-index','dlc-index','gala','retro','cyborg-refinements']):continue
 text=read(p).decode();patterns=[r'\b(?:const|let|var)\s+(?:entries|reviewedEntry|reviewedEntries|additions|addition|catalogue|data|index)\s*=\s*',r'root\.CQC_[A-Z0-9_]+\s*=\s*',r'\bentries\s*:\s*']
 seen=set()
 for pat in patterns:
  for m in re.finditer(pat,text):
   pos=m.end()
   if pos in seen:continue
   seen.add(pos);prefix=text[pos:]
   try:
    if prefix.startswith('JSON.parse('):
     enc,end=decoder.raw_decode(prefix[len('JSON.parse('):]);value=json.loads(enc)
    else:value,end=decoder.raw_decode(prefix)
   except Exception:continue
   parsed.append((p.name,m.start(),value))
def familyOf(x):
 return x.get('family')or x.get('sprite',{}).get('costumeConcept',{}).get('family')or x.get('id')if x.get('id')in ['retro','nextgen','cyborg','metalgear','survive','tuxedo','zombie','furry']else x.get('family')or x.get('sprite',{}).get('costumeConcept',{}).get('family')
found=[]
def inspect(v,file):
 if isinstance(v,list):
  for x in v:inspect(x,file)
 elif isinstance(v,dict):
  if isinstance(v.get('uid'),str)and isinstance(v.get('option'),dict):
   o=v['option'];sp=o.get('sprite')or{};files={}
   for a in (sp.get('actions')or{}).values():
    for f in a.get('frames')or[]:
     if isinstance(f,dict)and f.get('file'):files[f['file']]={'file':f['file'],'sha256':f.get('sha256')}
   if sp.get('file'):files[sp['file']]={'file':sp['file'],'sha256':sp.get('sha256')}
   first=next((a.get('frames',[{}])[0]for k,a in (sp.get('actions')or{}).items()if k=='idle'and a.get('frames')),None)
   found.append({'uid':v['uid'],'id':o.get('id'),'family':familyOf(o),'label':o.get('label'),'kind':'direct-option','index':file,'hasSprite':bool(sp),'hasMachineParts':bool(o.get('machineParts')),'artReview':o.get('assetReview')or sp.get('review'),'provenance':o.get('provenance'),'assets':list(files.values()),'preview':first,'spriteUID':sp.get('uid')})
  elif isinstance(v.get('uid'),str)and isinstance(v.get('id'),str)and isinstance(v.get('metadata'),dict)and isinstance(v.get('assets'),list):
   found.append({'uid':v['uid'],'id':v['id'],'family':v.get('family')or v['id'],'label':v.get('label'),'kind':'lazy-index','index':file,'hasSprite':True,'hasMachineParts':False,'artReview':v.get('review'),'provenance':v.get('provenance'),'assets':v['assets'],'preview':v.get('preview'),'metadata':v.get('metadata')})
  else:
   for key in ['entries','additions','options']:
    if key in v:
     if key=='entries'and isinstance(v[key],dict):
      for uid,entry in v[key].items():
       if isinstance(entry,dict)and isinstance(entry.get('options'),list):
        for option in entry['options']:
         if option.get('id')!='original'and(option.get('sprite')or option.get('machineParts')):inspect({'uid':uid,'option':option},file)
     else:inspect(v[key],file)
for file,pos,data in parsed:inspect(data,file)
dedup={}
for x in found:
 k=(x['uid'],x['id'],x['index']);dedup[k]=x
found=list(dedup.values())
(OUT/'CURRENT_NATIVE_OPTION_SOURCE_CANDIDATES_PRIVATE_V1.json').write_text(json.dumps({'schema':'cqc.static.native-source-candidates/1','qualification':'Static literal JSON extraction from current local JS. Presence/preview provenance candidates, not decoded geometry or a new art approval.','rows':found},ensure_ascii=False,indent=2)+'\n')
(OUT/'EXCEL_V9_STATIC_INPUTS_PRIVATE_V1.json').write_text(json.dumps(S,ensure_ascii=False,indent=2)+'\n')
counts={fam:dict(collections.Counter(r['statutInventaire']for r in matrix if r['famille']==fam))for fam in sorted({r['famille']for r in matrix})}
print(json.dumps({'matrixRows':len(matrix),'characters':381,'baselineStatuses':counts,'nativeOptions':len(found),'nativeFamilies':dict(collections.Counter(x['family']for x in found)),'indices':dict(collections.Counter(x['index']for x in found))},ensure_ascii=False))
