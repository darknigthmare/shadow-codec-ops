import os,pathlib,json,hashlib,csv,collections
N=pathlib.Path('/tmp/cqc-static-20261113');OUT=N/'inventory';CORE=N/'recovered-core/original-paths/tmp/cqc-zc-20261109';A=pathlib.Path('/workspace/cqc-pass21-application/public/cqc')
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
S=json.loads(read(OUT/'EXCEL_V9_STATIC_INPUTS_PRIVATE_V1.json'));rows=S['P46 Huit familles'];native=json.loads(read(OUT/'CURRENT_NATIVE_OPTION_SOURCE_CANDIDATES_PRIVATE_V1.json'))['rows']
briefs=json.loads(read(CORE/'references/ZC_20_CANONICAL_IDENTITY_FIDELITY_BRIEFS_PRIVATE_V2.json'))['briefs'];raw=list(csv.DictReader(read(pathlib.Path('/workspace/cqc-reprise-20261109/livraison-v9/P48_RAW36_SOURCE_PUBLIC_V9.csv')).decode('utf-8-sig').splitlines()))
rawKeys={}
for r in raw:
 # Stable actual headings, never guess an animation admission.
 uid=r.get('UID')or r.get('uid');fam=r.get('Famille')or r.get('famille');side=r.get('Direction')or r.get('direction')
 if uid and fam:rawKeys.setdefault((uid,fam),[]).append(r)
if not rawKeys:
 state=json.loads(read(pathlib.Path('/workspace/cqc-reprise-20261109/livraison-v9/P48_ETAT_REEL_PUBLIC_V9.json')))
 for r in state['rows']:
  if r.get('paireDessinee'):rawKeys[(r['uid'],r['famille'])]=[{'preferredVersions':r['versionsPreferees'],'rawGitCommit':r['sourceRawGitCommit'],'sourceArtExisting':True}]
by={(r['uid'],r['famille']):r for r in rows};nativeby=collections.defaultdict(list)
for r in native:nativeby[(r['uid'],r['family'])].append(r)
labels={'retro':'Rétro','nextgen':'Nouvelle génération','cyborg':'Châssis cybernétique','survive':'Expédition Dité','metalgear':'Metal Gear','tuxedo':'Tenue de soirée','zombie':'Zombie','furry':'Furry'}
jobs=[];refdir=OUT/'priority20-original-references';refdir.mkdir(exist_ok=True)
for identity in briefs:
 uid=identity['uid'];b=json.loads(read(CORE/'compiler/generation-contracts'/(uid+'--SOURCE_CONTRACT_BRIEF_PRIVATE_V3.json')));pose=b['originalSprite']['idleFrames']['RIGHT'];p=pathlib.Path(pose['applicationPath']);rawPNG=read(p);assert hashlib.sha256(rawPNG).hexdigest()==pose['sha256'];copy=refdir/(uid+'-original-right.png')
 if copy.exists():assert read(copy)==rawPNG
 else:copy.write_bytes(rawPNG)
 missing=[];existing=[];holds=[]
 for family in labels:
  old=by[(uid,family)];status=old['statutInventaire'];current=nativeby.get((uid,family),[])
  if status=='HOLD_HISTORIQUE':holds.append({'family':family,'qualification':'Historical hold needs exact scope review; no automatic generation in this batch.','baseline':old});continue
  if status=='SANS_OBJET':existing.append({'family':family,'reason':'NOT_APPLICABLE_BASELINE'});continue
  if status.startswith('ORIGINAL_'):existing.append({'family':family,'reason':'ORIGINAL_COVERS_THIS_STYLE_OR_BODY','originalPose':pose});continue
  if current:existing.append({'family':family,'reason':'NATIVE_SOURCE_POSE_REGISTERED_REVIEW_TO_REUSE','options':current});continue
  if (uid,family)in rawKeys:existing.append({'family':family,'reason':'P48_RIGHT_IDLE_DRAWN_REUSE_STATIC_NEEDS_CROP_QA','rawSources':rawKeys[(uid,family)],'animationOrLEFTBlockDoesNotInvalidateIdle':True});continue
  if status.startswith('NATIF')or status=='SOURCE_EXISTANTE_NON_BRANCHEE':existing.append({'family':family,'reason':'EXISTING_SOURCE_EXPECTED_NEEDS_LOOKUP_NOT_AUTO_REGENERATED','baseline':old});continue
  missing.append({'id':family,'label':labels[family],'type':'style-reinterpretation'if family in ['retro','nextgen']else'original-character-costume','onePoseOnly':True,'originalBaselineStatus':status})
 jobs.append({'priority':identity['priority'],'uid':uid,'name':identity['name'],'incarnation':identity['targetOriginalIncarnation'],'originalGame':identity['originalGame'],'missingCostumes':missing,'missingFamilies':[r['id']for r in missing],'existingCostumes':existing,'holds':holds,'originalPose':{'file':str(copy),'sourceApplicationPath':str(p),'sha256':pose['sha256'],'frameRect':pose['rect'],'pivot':pose['pivot'],'poseExists':True,'isFallback':False},'identityObservations':identity['observations'],'equipment':b['canonicalEquipmentFromOriginalContract'],'referenceURLs':identity['sourceURLs'],'furryConcept':'No specific animal species attested by this brief; Root must select a personalized coherent adaptation rather than claim a pre-established species.','singlePoseAtlas':{'columns':3,'rows':3,'posesPerCostume':1,'maxCostumesPerPage':9,'generateOriginalAgain':False,'animations':False},'qualification':'Only clearly missing eight-family poses are queued. Existing indexed/source-only idle poses are not regenerated; canonical official additions come from separate source-reviewed official inventory.'})
out={'schema':'cqc.static.priority20-jobs/1','scope':'one pose per missing costume, no animation','characters':20,'missingCostumePoses':sum(len(j['missingCostumes'])for j in jobs),'jobs':jobs};path=OUT/'STATIC_PRIORITY20_JOBS_PUBLIC_V1.json';path.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(read(path)).hexdigest(),'characters':20,'missingCostumePoses':out['missingCostumePoses'],'jobs':[{k:j[k]for k in ['uid','missingFamilies']}for j in jobs]},ensure_ascii=False))
