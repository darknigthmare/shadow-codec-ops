#!/usr/bin/env python3
"""Independent read-only raster/coverage audit; writes only its own report."""
import collections, concurrent.futures, datetime, hashlib, io, json, math, os
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw

BASE=Path('/tmp/cqc-static-20261113')
CAT=BASE/'catalog'
APP=Path('/workspace/cqc-pass21-application/public/cqc')
OUT=BASE/'inventory/FINAL_PLANNED_STATIC_COVERAGE_AUDIT_PRIVATE_V1.json'
PINS=[]
def read(p,pin=False):
    p=Path(p); before=p.stat()
    fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
    with os.fdopen(fd,'rb') as f: b=f.read()
    after=p.stat()
    if before!=after: raise ValueError('Source metadata changed during read: '+str(p))
    if pin:PINS.append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mtimeNs':before.st_mtime_ns,'atimeNs':before.st_atime_ns})
    return b
def load(p,pin=False):return json.loads(read(p,pin))
def identify(e):return {'uid':e['uid'],'costumeID':e['costumeId'],'family':e['family'],'origin':e['origin']}
def source_path(s):
    if s.get('localPath'):return Path(s['localPath'])
    v=s.get('src','')
    if v.startswith('/native/'):return APP/v[len('/native/'):]
    if v.startswith('/captures/'):return BASE/'artists/e/composites'/v[len('/captures/'):]
    if v and not v.startswith('/') and '://' not in v:return CAT/v
    return None

manifest=load(CAT/'manifest-all381.json',True)
matrix=load(BASE/'inventory/STATIC_ALL381_CATALOG_COMPACT_PUBLIC_V1.json',True)
guards=load(BASE/'dispatch/HOLD_GUARDS_CURRENT_PUBLIC_V1.json',True)
regindex=load(CAT/'ACTIVE_ARTIST_REGISTRATIONS_PRIVATE_V1.json',True)
rootreviews=load(CAT/'ROOT_STATIC_ART_REVIEW_INDEX_PRIVATE_V1.json',True)
guardmap={(g['uid'],g['family']):g for g in guards['guards']}
entries=manifest['entries'];planned=[e for e in entries if e['origin']!='official'];official=[e for e in entries if e['origin']=='official']
byfamily=collections.defaultdict(list)
for e in planned:byfamily[e['uid'],e['family']].append(e)
aliases={(a['uid'],a['family']):a for a in manifest['aliasesCoveredByOriginal']}
excluded={(a['uid'],a['family']):a for a in manifest['notApplicableExcluded']}
rows=[];coverage_errors=[];guard_metadata=[]
for r in matrix['rows']:
    key=(r['uid'],r['family']);es=byfamily.get(key,[])
    row={'uid':r['uid'],'family':r['family'],'inventoryCostumeID':r['id']}
    matches=len(es)+int(key in aliases)+int(key in excluded)
    if matches!=1:
        row['coverage']='INVALID_MULTIPLE_OR_NO_RESOLUTION';coverage_errors.append(dict(row,resolutions=matches));rows.append(row);continue
    if key in excluded:row['coverage']='NOT_APPLICABLE_BASELINE'
    elif key in aliases:
        original=byfamily.get((r['uid'],'original'),[])
        valid=len(original)==1 and bool(original[0].get('source')) and bool(original[0].get('frame')) and aliases[key]['coveredBy']==r['uid']+':original'
        row.update(coverage='COVERED_BY_SAME_UID_ORIGINAL' if valid else 'INVALID_ORIGINAL_ALIAS',aliasTarget=aliases[key]['coveredBy'])
        if not valid:coverage_errors.append(row.copy())
    else:
        e=es[0];row.update(costumeID=e['costumeId'],catalogStatus=e['status'])
        if e.get('source') and e.get('frame'):
            row.update(coverage='GUARDED_EXISTING_CONCEPT_RESERVED' if key in guardmap else 'LOCAL_POSE_SOURCE_PRESENT',sourceSHA256=e['source'].get('sha256'))
        elif key in guardmap:row['coverage']='GUARDED_WITHOUT_SOURCE'
        else:row['coverage']='UNGUARDED_SOURCE_OR_FRAME_MISSING';coverage_errors.append(row.copy())
        if key in guardmap and e.get('generationRequired'):guard_metadata.append({'uid':e['uid'],'costumeID':e['costumeId'],'issue':'Historical generationRequired remains true under active generationGuard; no generation is authorized.'})
    rows.append(row)

receipts={}
for item in regindex['registrations']:
    p=Path(item['receipt'] if isinstance(item,dict) else item)
    reg=load(p)
    receipts[str(Path(reg['canonicalPath']))]=reg

groups=collections.defaultdict(list);path_errors=[]
for e in entries:
    if not e.get('source'):continue
    p=source_path(e['source'])
    if p is None or not p.is_absolute() or p.resolve(strict=False)!=p:
        path_errors.append(dict(identify(e),source=e['source'],issue='Unresolved, remote or symlink source'));continue
    groups[str(p)].append(e)

def raster_job(item):
    path,es=item;p=Path(path);out={'path':path,'entryCount':len(es),'plannedEntries':sum(e['origin']!='official' for e in es),'errors':[],'frameIssues':[],'edgeReserves':[],'physicalFrames':[]}
    try:
        b=read(p);sha=hashlib.sha256(b).hexdigest();out.update(bytes=len(b),sha256=sha)
        im=Image.open(io.BytesIO(b));im.load();out.update(format=im.format,width=im.width,height=im.height,decoded=True)
        if im.format!='PNG':out['errors'].append('Not PNG')
        rgba=np.array(im.convert('RGBA'));alpha=rgba[:,:,3]
        out.update(alpha0=int((alpha==0).sum()),alphaMax=int(alpha.max()))
        for e in es:
            info=identify(e);s=e['source'];fr=e.get('frame') or {};rect=fr.get('rect')
            for k,actual in [('sha256',sha),('width',im.width),('height',im.height)]:
                if s.get(k)!=actual:out['errors'].append(dict(info,issue='Declared '+k+' mismatch',declared=s.get(k),actual=actual))
            if not s.get('verified'):out['errors'].append(dict(info,issue='Source not marked verified'))
            if not isinstance(rect,list) or len(rect)!=4 or any(not isinstance(v,(int,float)) or not math.isfinite(v) for v in rect):out['frameIssues'].append(dict(info,issue='Invalid rect',rect=rect));continue
            x,y,w,h=rect
            if any(int(v)!=v for v in rect) or x<0 or y<0 or w<=0 or h<=0 or x+w>im.width or y+h>im.height:out['frameIssues'].append(dict(info,issue='Out-of-bounds/noninteger rect',rect=rect));continue
            x,y,w,h=map(int,rect);arr=rgba[y:y+h,x:x+w].copy();mask=arr[:,:,3]>16
            # Draw an analytical mask only. Never save, crop or transform a PNG.
            poly=fr.get('clipPolygon');holes=fr.get('clipHoles')
            if poly:
                # Catalogue clip paths use normalized coordinates relative to the selected frame.
                c=Image.new('1',(w,h),0);dr=ImageDraw.Draw(c)
                dr.polygon([(float(px)*w,float(py)*h) for px,py in poly],fill=1)
                for hole in holes or []:dr.polygon([(float(px)*w,float(py)*h) for px,py in hole],fill=0)
                cm=np.array(c,dtype=bool);arr[~cm]=0;mask=arr[:,:,3]>16
            count=int(mask.sum());opaque=arr[:,:,3]>200
            if count<30:out['frameIssues'].append(dict(info,issue='Empty or effectively empty frame',foregroundAbove16=count,rect=rect))
            if e.get('facing')!='right':out['frameIssues'].append(dict(info,issue='Facing not declared RIGHT',facing=e.get('facing')))
            pivot=fr.get('pivot')
            if pivot is not None and (not isinstance(pivot,list) or len(pivot)!=2 or any(not isinstance(v,(int,float)) or not math.isfinite(v) for v in pivot)):out['frameIssues'].append(dict(info,issue='Invalid pivot',pivot=pivot))
            edges={'top':int(mask[0].sum()),'bottom':int(mask[-1].sum()),'left':int(mask[:,0].sum()),'right':int(mask[:,-1].sum())}
            opedges={'top':int(opaque[0].sum()),'bottom':int(opaque[-1].sum()),'left':int(opaque[:,0].sum()),'right':int(opaque[:,-1].sum())}
            # Boundary contact is a reserve, not proof of a cut, because many explicit frames are tight body bounds.
            source_edges={k:edges[k] for k,on in [('top',y==0),('bottom',y+h==im.height),('left',x==0),('right',x+w==im.width)] if on and edges[k]}
            if source_edges:out['edgeReserves'].append(dict(info,rect=rect,sourceImageEdgeForeground=source_edges,frameOpaqueEdges=opedges))
            if count:
                yy,xx=np.where(mask);trim=arr[yy.min():yy.max()+1,xx.min():xx.max()+1].copy();trim[trim[:,:,3]<=16]=0
                digest=hashlib.sha256(str(trim.shape).encode()+trim.tobytes()).hexdigest()
                out['physicalFrames'].append(dict(info,sourceSHA256=sha,rect=rect,clipPolygon=poly,clipHoles=holes,pixelIdentitySHA256=digest,foregroundAbove16=count))
        if es[0]['source'].get('kind')=='generated-atlas':
            reg=receipts.get(path)
            if not reg:out['errors'].append('Generated source lacks active registration receipt')
            else:
                out['attribution']={'receipt':reg.get('receiptPath'),'originalRawSource':reg['source']['path'],'rawSHA256':reg['source']['sha256'],'canonicalReadback':reg.get('exactCanonicalReadback')}
                if reg['source']['sha256']!=sha or reg['source']['bytes']!=len(b):out['errors'].append('Registration bytes/SHA mismatch')
        else:out['attribution']={'kind':es[0]['source'].get('kind'),'qualification':'Existing native/local source selected by inventory or exact private overlay; authoritative attribution remains in pinned catalogue/inventory.'}
    except Exception as ex:out['errors'].append(type(ex).__name__+': '+str(ex));out['decoded']=False
    return out

assets=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    for n,result in enumerate(pool.map(raster_job,groups.items()),1):
        assets.append(result)
        if n%100==0:print(json.dumps({'PNGread':n,'of':len(groups)}),flush=True)

exact=collections.defaultdict(list);pixels=collections.defaultdict(list)
for a in assets:
    for f in a['physicalFrames']:
        if f['origin']=='official':continue
        exact[(f['sourceSHA256'],json.dumps(f['rect']),json.dumps(f['clipPolygon']),json.dumps(f['clipHoles']))].append(f)
        pixels[f['pixelIdentitySHA256']].append(f)
duplicates=[]
for kind,mapping in [('same-source-and-frame',exact),('same-trimmed-RGBA-pixels',pixels)]:
    for key,v in mapping.items():
        if len(v)>1:duplicates.append({'kind':kind,'poses':v,'qualification':'Potential unjustified physical duplicate; compare same-UID family alias and actual identity provenance before calling it an error.'})
for a in assets:a.pop('physicalFrames',None)
missing=[identify(e) for e in planned if not e.get('source') or not e.get('frame')]
official_status={'entries':len(official),'sourceAndFramePresent':sum(bool(e.get('source')) and bool(e.get('frame')) for e in official),'statusCounts':dict(collections.Counter(e['status'] for e in official)),'qualification':'Separate historical official costume workflow continues; not included in3429 planned family coverage or missing-producible assertion.'}
counts=collections.Counter(r['coverage'] for r in rows)
asset_errors=[{'path':a['path'],'errors':a['errors']} for a in assets if a['errors']]
frame_errors=[dict(path=a['path'],**e) for a in assets for e in a['frameIssues']]
pins_unchanged=[]
for pin in PINS:
    b=read(pin['path']);pins_unchanged.append({'path':pin['path'],'unchanged':hashlib.sha256(b).hexdigest()==pin['sha256']})
report={'schema':'cqc.static.planned-coverage-independent-audit/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'auditor':'static_inventory / artist E independent read-only coverage audit','manifestAtUTC':manifest['createdAtUTC'],'scope':'381 UIDs x9 planned Original/family rows. Official same-period extras separated. No generation, build, import or mutation of prior index.','inputs':PINS,'inputSnapshotUnchangedAtEnd':pins_unchanged,'summary':{'plannedRows':len(rows),'plannedPhysicalEntries':len(planned),'sameUIDOriginalAliases':len(aliases),'notApplicable':len(excluded),'coverageCounts':dict(counts),'sourceMissing':len(missing),'sourceMissingOutsideKnownGuards':sum((e['uid'],e['family']) not in guardmap for e in missing),'sourcePresentGuardedConcepts':counts['GUARDED_EXISTING_CONCEPT_RESERVED'],'uniquePNGPathsRead':len(assets),'rasterReadOrSHAErrors':len(asset_errors),'frameStructuralErrors':len(frame_errors),'potentialPhysicalDuplicateGroups':len(duplicates),'indexMetadataInconsistencies':len(guard_metadata),'plannedNoUngardedMissingPose':not coverage_errors},'coverageErrors':coverage_errors,'guardedWithoutSources':missing,'heldMetadataReservations':guard_metadata,'rasterErrors':asset_errors,'sourcePathErrors':path_errors,'frameStructuralErrors':frame_errors,'physicalDuplicateCandidates':duplicates,'sourceEdgeReservations':[dict(path=a['path'],poses=a['edgeReserves']) for a in assets if a['edgeReserves']],'officialWorkflowSnapshot':official_status,'perPlannedRowCoverage':rows,'PNGAssetAudit':assets,'limitations':['PNG bytes, signatures, decoding, dimensions, exact rect bounds, nonempty visible frame and pixel-identity checks are independent analytical checks. This is not an artistic certification of every body, costume or reference.','Contact between opaque pixels and an analytically tight frame edge is not by itself proof of anatomical clipping. Source-image-edge reservations require visual inspection.','Drawing interpretation of canonical/reference material is distinct from a certified 1:1 retail model extraction. Root art review statuses remain authoritative.','No image generated or raster edited; all protected reads use O_NOATIME/O_NOFOLLOW. No Source/game/worksheet/index mutations, import, build or Git actions.'],'generationCalled':False,'buildOrImportCalled':False,'sourcePixelsEdited':False,'priorIndexesModified':False}
OUT.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'report':str(OUT),'summary':report['summary'],'official':official_status,'inputSnapshotStable':all(x['unchanged'] for x in pins_unchanged)},ensure_ascii=False),flush=True)
