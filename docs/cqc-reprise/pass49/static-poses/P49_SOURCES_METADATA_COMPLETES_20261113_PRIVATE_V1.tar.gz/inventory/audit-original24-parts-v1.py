import os,pathlib,json,re,hashlib,collections,datetime
N=pathlib.Path('/tmp/cqc-static-20261113/inventory');A=pathlib.Path('/workspace/cqc-pass21-application/public/cqc');R=A/'src';dec=json.JSONDecoder()
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
names=['cqc-machine-parts-catalog-v1.js','cqc-pass16-machine-catalog.js','cqc-pass18-machine-catalog.js','cqc-pass19-gekko-catalog.js','cqc-pass28-missing-machine.js','cqc-pass40-fenrir-data-v1.js','cqc-pass40-fenrir-admission-v1.js']
objects=[];sourcePins=[]
for name in names:
 p=R/name;b=read(p);s=b.decode();sourcePins.append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 patterns=[r'(?:window|root|globalThis)\.CQC_[A-Z0-9_]+\s*=\s*',r'\b(?:const|let|var)\s+\w+\s*=\s*'];seen=set()
 for pat in patterns:
  for m in re.finditer(pat,s):
   if m.end()in seen:continue
   seen.add(m.end())
   try:value,end=dec.raw_decode(s[m.end():])
   except:continue
   if isinstance(value,dict):objects.append({'file':name,'assignment':m.group(0),'value':value})
machines={};bindings={};states={};fenrir=None;admission=None
for rec in objects:
 d=rec['value']
 if isinstance(d.get('machines'),list):
  for machine in d['machines']:machines[machine['id']]={'definition':machine,'catalogue':rec['file']}
 if isinstance(d.get('playable'),dict):bindings.update(d['playable'])
 if isinstance(d.get('states'),dict):states.update(d['states'])
 if d.get('schema')=='cqc.fenrir.runtime-data/2':fenrir=d
 if d.get('schema')=='cqc.fenrir.native-admission/1':admission=d
 # Hammerhead mappings are explicit quoted JSON local constants.
 if rec['assignment'].startswith('const playableMappings=')or'playableMappings' in rec['assignment']:bindings.update(d)
manifest=json.loads(read(A/'runtime-manifest.json'));shaPaths=collections.defaultdict(list)
for row in manifest['files']:
 if row.get('sha256')and row['path'].endswith('.png'):shaPaths[row['sha256']].append(A/row['path'])
cache={}
def sourceProof(src):
 s=src.get('file');p=A/s if isinstance(s,str)and not s.startswith(('http:','https:'))else None
 if not p or not p.is_file():p=next((q for q in shaPaths.get(src.get('sha256'),[])if q.is_file()),None)
 if p is None:return {'source':src,'localPresent':False,'qualification':'Source descriptor exists; resolve its immutable URL or private preserved art before static export.'}
 if str(p)not in cache:
  before=p.stat();b=read(p);after=p.stat();assert before==after
  cache[str(p)]={'file':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'nativePNG':b[:8]==b'\x89PNG\r\n\x1a\n','dimensions':[int.from_bytes(b[16:20],'big'),int.from_bytes(b[20:24],'big')],'sourceStatsPreserved':True}
 proof=dict(cache[str(p)]);proof['localPresent']=True;proof['expectedSHA256']=src.get('sha256');proof['SHA256Matches']=not src.get('sha256')or src['sha256']==proof['sha256'];return proof
pending=json.loads(read(N/'ORIGINAL24_NATIVE_PARTS_REVIEW_PENDING_PRIVATE_V1.json'))['rows'];rows=[]
for orig in pending:
 uid=orig['uid'];ids=bindings.get(uid);basis='Explicit playable mapping from existing native catalogue data'
 if not ids and uid in machines:
  ids=[uid,uid+'_right']if uid+'_right'in machines else[uid,uid];basis='Exact named existing machine definitions; installer includes these playable mappings'
 faces=[]
 if ids:
  for side,rig in zip(['left','right'],ids):
   item=machines.get(rig)
   if not item:faces.append({'side':side,'rigID':rig,'definitionPresent':False});continue
   d=item['definition'];partIDs={p['id']for p in d['parts']};sourceIDs={p['id']for p in d['sources']};badParents=[p['id']for p in d['parts']if p.get('parent')and p['parent']not in partIDs];badSources=[p['id']for p in d['parts']if p.get('source')and p['source']not in sourceIDs]
   faces.append({'side':side,'rigID':rig,'edition':d.get('edition'),'definitionPresent':True,'catalogue':item['catalogue'],'sourceCount':len(d['sources']),'partCount':len(d['parts']),'sources':[sourceProof(s)for s in d['sources']],'parentReferencesPresent':not badParents,'sourceReferencesPresent':not badSources,'badParents':badParents,'badSources':badSources,'sourceQualification':d.get('sourceQualification')or d.get('documentaryQualifications'),'neutralGraphAvailable':True,'exactCurrentRuntimePoseNotCaptured':True,'staticCompositionRoute':'Use existing CQC_PASS18_MACHINES.originalRigSnapshot(uid).cameras and existing native renderer at reduced-motion idle; preserve current rig-fix installation order. Do not rebuild approximate transforms from this unpatched literal.'})
 elif uid=='pass19__fenrir_mgr'and fenrir:
  m=fenrir['map'];faces=[{'side':side,'rigID':'FenrirNative18_'+side,'definitionPresent':True,'sourceCount':len(m['sources']),'partCount':len(m['facings'][side]),'sources':[sourceProof(s)for s in m['sources']],'nativeAdmission':admission,'staticCompositionRoute':'Use existing FENRIR_V3_CONTROLLER/P40 native renderer with its retained18part joints at neutral reduced-motion idle. No new drawing required.','exactCurrentRuntimePoseNotCaptured':True}for side in ['left','right']]
 else:basis='No matching native graph located in audited sources; further source lookup required'
 local=all(s.get('localPresent')and s.get('nativePNG')and s.get('SHA256Matches')for face in faces for s in face.get('sources',[]))if faces else False
 rows.append({'uid':uid,'name':orig['name'],'status':'EXISTING_NATIVE_PARTS_STATIC_COMPOSITION_AVAILABLE'if faces and all(f.get('definitionPresent')for f in faces)else'NATIVE_PART_GRAPH_LOOKUP_PENDING','mappingBasis':basis,'faces':faces,'allSourcesLocalExact':local,'newDrawingRequired':False if faces else None,'newStaticCompositeExported':False,'fidelityQualification':'Existing source parts are available, not a new visual/junction/perspective certification. AI authored-VR forms are explicitly original representations, not attested physical bodies.'})
out={'schema':'cqc.static.original24-part-composition-audit/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':rows,'counts':dict(collections.Counter(r['status']for r in rows)),'localExactRows':sum(r['allSourcesLocalExact']for r in rows),'uniquePNGSourceFilesReadExact':len(cache),'sourcePins':sourcePins,'ASSourcePixelsOrStatsMutated':False,'newArtGenerated':False,'newCompositeExported':False,'runtimeExecuted':False};p=N/'ORIGINAL24_EXISTING_STATIC_PART_COMPOSITIONS_AUDIT_PRIVATE_V1.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(read(p)).hexdigest(),'counts':out['counts'],'localExactRows':out['localExactRows'],'uniquePNGSourceFilesReadExact':len(cache)}))
