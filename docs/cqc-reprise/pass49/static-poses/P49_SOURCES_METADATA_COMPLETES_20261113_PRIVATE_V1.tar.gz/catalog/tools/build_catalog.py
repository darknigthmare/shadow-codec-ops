#!/usr/bin/env python3
"""Build a static-only review catalogue from explicit jobs and exact source pages."""
import argparse,datetime,hashlib,json,os,pathlib,struct

ROOT=pathlib.Path('/tmp/cqc-static-20261113')
APP=pathlib.Path('/workspace/cqc-pass21-application/public/cqc')
CAT=ROOT/'catalog'
FAMILY_LABELS={'original':'Tenue d’origine','retro':'Rétro','nextgen':'Nouvelle génération','tuxedo':'Gala','cyborg':'Châssis cybernétique','metalgear':'Metal Gear','survive':'Expédition Dité','zombie':'Décomposition','furry':'Animal totémique'}
_cache={}
def read(p):
 p=pathlib.Path(p)
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
def load(p):return json.loads(read(p))
def path_text(value):
 if isinstance(value,str):return value
 if isinstance(value,dict)and isinstance(value.get('nativePathParts'),list):
  parts=value['nativePathParts']
  if all(isinstance(x,str)and x not in('','..','.')and '/'not in x and '\\'not in x for x in parts):return '/'.join(parts)
 return None
def asset_info(value,sha=None):
 name=path_text(value)
 if not name:return None
 p=pathlib.Path(name)
 if not p.is_absolute():p=APP/p
 if not p.is_relative_to(APP)or p.resolve(strict=False)!=p or not p.is_file():return None
 if p not in _cache:
  before=p.stat();b=read(p);after=p.stat()
  if before!=after:raise ValueError('Source metadata changed')
  if b[:8]!=b'\x89PNG\r\n\x1a\n' or b[12:16]!=b'IHDR':return None
  width,height=struct.unpack('>II',b[16:24]);_cache[p]={'src':'/native/'+p.relative_to(APP).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'width':width,'height':height,'verified':True,'localPath':str(p)}
 info=_cache[p]
 if sha and info['sha256']!=sha:return None
 return dict(info)
def references(option):
 return [{'url':r['url'],'scope':r.get('scope','')}for r in option.get('provenance',{}).get('sources',[])if isinstance(r,dict)and isinstance(r.get('url'),str)]
def base(job,costume_id,family,label,origin):
 game=job.get('originalGame')or job.get('incarnation')or'Époque à préciser'
 era=job.get('eraLabel')or game.split('(')[0].split(',')[0].strip()
 return {'uid':job['uid'],'character':job.get('name',job['uid']),'era':era,'incarnation':job.get('incarnation',game),'costumeId':costume_id,'costume':label,'family':family,'origin':origin,'status':'review','facing':'right','references':[]}
def original_entry(job):
 pose=job.get('originalPose')or{};e=base(job,'original','original',FAMILY_LABELS['original'],'original')
 info=asset_info(pose.get('sourceApplicationPath')or pose.get('applicationPath')or pose.get('file'),pose.get('sha256'))
 rect=pose.get('frameRect')or pose.get('rect')
 if pose.get('poseExists')and not pose.get('isFallback')and info and rect:
  e.update(status='drawn',source=dict(info,kind='native-frame'),frame={'rect':rect,'pivot':pose.get('pivot',[.5,1])},verification='Existing original right-facing source PNG and exact frame; no new animation admission.')
 else:e.update(status='missing',note='La tenue d’origine doit disposer de sa propre pose dessinée.')
 return e
def native_entry(job,costume):
 family=costume['family'];options=costume.get('options')or[];option=options[0]if options else{}
 e=base(job,option.get('id',family),family,option.get('label',FAMILY_LABELS.get(family,family)),'official'if family=='canonical'or option.get('provenance',{}).get('canonicalAppearanceAttested')else'invented')
 e['references']=references(option)
 preview=option.get('preview')or{};name=path_text(preview.get('file'));sha=preview.get('sha256')
 if not sha:
  sha=next((a.get('sha256')for a in option.get('assets',[])if path_text(a.get('file'))==name),None)
 info=asset_info(name,sha);rect=preview.get('rect')
 source_uid=option.get('provenance',{}).get('sourceUID',job['uid'])
 if info and rect and option.get('hasSprite')and source_uid==job['uid']:
  frame={'rect':rect,'pivot':preview.get('pivot',[.5,1])}
  for field in ['clipPolygon','clipHoles','footprint']:
   if preview.get(field):frame[field]=preview[field]
  bounds=preview.get('previewStatureBounds')
  if bounds:frame['bodyBounds']=[rect[0]+bounds['left'],rect[1]+bounds['top'],bounds['right']-bounds['left'],bounds['bottom']-bounds['top']]
  e.update(source=dict(info,kind='native-frame'),frame=frame,status='drawn',verification='Existing native preview frame; source bytes verified for this static catalogue. No new animation/game admission.')
 else:e['note']='Une pose est signalée dans les archives ; son cadre et sa source restent à rapprocher.'
 return e
def build_jobs(jobs):
 entries=[];aliases=[]
 for job in jobs:
  original=original_entry(job);entries.append(original)
  for missing in job.get('missingCostumes',[]):
   family=missing.get('family',missing['id']);e=base(job,missing['id'],family,missing.get('label',FAMILY_LABELS.get(family,missing['id'])),'official'if missing.get('type')in['canonical','official','canonical-costume','official-costume']else'invented');e['status']='missing';entries.append(e)
  for costume in job.get('existingCostumes',[]):
   if costume.get('reason')=='ORIGINAL_COVERS_THIS_STYLE_OR_BODY':
    original.setdefault('coversFamilies',[]).append(costume['family']);aliases.append({'uid':job['uid'],'family':costume['family'],'coveredBy':job['uid']+':original','reason':'Same incarnation original already supplies the requested body/style.'});continue
   entries.append(native_entry(job,costume))
  for hold in job.get('holds',[]):
   family=hold.get('family')if isinstance(hold,dict)else None
   for e in entries:
    if e['uid']==job['uid']and e['family']==family:e['note']='Dossier suspendu ; aucune nouvelle génération lancée.'
 return entries,aliases
def build_matrix(data,captures=None):
 captures=captures or {}
 flagsPath=CAT/'KNOWN_ORIGINAL_POSE_REVIEW_FLAGS_PRIVATE_V1.json';originalFlags=load(flagsPath).get('flags',{})if flagsPath.exists()else{}
 entries=[];aliases=[];excluded=[]
 for row in data['rows']:
  if row.get('aliasOf')or row.get('status')=='COVERED_BY_ORIGINAL_POSE':
   aliases.append({'uid':row['uid'],'family':row['family'],'coveredBy':row['uid']+':original','reason':'Same incarnation original supplies this style/body.'});continue
  if row.get('applicable')is False or row.get('status')=='NOT_APPLICABLE_BASELINE':
   excluded.append({'uid':row['uid'],'family':row['family'],'status':row['status']});continue
  origin='original'if row['family']=='original'else'official'if row['family']=='canonical'or row.get('type')in['canonical-costume','official','official-costume']else'invented'
  e=base(row,row['id'],row['family'],FAMILY_LABELS['original']if row['family']=='original'else row.get('label',row['id']),origin)
  e.update(inventoryStatus=row['status'],generationRequired=row.get('generationRequired',False))
  pose=row.get('sourcePose')or{};proof=pose.get('assetProof')or{}
  info=asset_info(pose.get('file'),proof.get('sha256')or proof.get('expectedSHA256'))
  if info and pose.get('frameRect')and not pose.get('isFallback'):
   frame={'rect':pose['frameRect'],'pivot':pose.get('pivot',[.5,1])}
   for name in ['clipPolygon','clipHoles','bodyBounds','footprint']:
    if pose.get(name):frame[name]=pose[name]
   e.update(status='drawn',source=dict(info,kind='native-frame'),frame=frame)
   e['references']=[{'url':s['url'],'scope':s.get('scope','')}for s in pose.get('sourceReview',{}).get('sources',[])if isinstance(s,dict)and isinstance(s.get('url'),str)]
  elif row['family']=='original'and row['uid']in captures:
   cap=captures[row['uid']];p=pathlib.Path(cap['file']);allowed=ROOT/'artists/e/composites';assert p.is_relative_to(allowed)and p.resolve(strict=True)==p
   raw=read(p);assert hashlib.sha256(raw).hexdigest()==cap['sha256']and cap['nativeReady']and cap['opaqueCanvasEdgePixels']==0
   e.update(status='drawn',source={'kind':'native-composite','src':'/captures/'+p.name,'sha256':cap['sha256'],'width':cap['width'],'height':cap['height'],'verified':True},frame={'rect':cap['frameRect'],'pivot':cap['pivot'],'bodyBounds':cap['bodyBounds']},note='Vue neutre du renderer existant et de ses parties natives. Aucun nouveau dessin Original ni animation.',verification=cap['qualification'])
  elif row.get('generationRequired'):
   e.update(status='missing',note='Cette tenue attend sa pose dessinée.')
  else:
   e['status']='review'
   if row['status']=='EXISTING_REVIEWED_REMOTE_SOURCE_POSE':e['note']='Le dessin est archivé ; sa planche distante reste à raccorder.'
   elif 'HOLD'in row['status']:e['note']='Dossier suspendu ; aucune nouvelle génération lancée.'
   elif row['family']=='original':e['note']='La vue complète et les éléments de cette incarnation restent à rapprocher.'
   else:e['note']='Un dessin est signalé dans les archives ; son cadre reste à vérifier.'
  if row['family']=='original'and row['uid']in originalFlags:e.update(status='review',note=originalFlags[row['uid']])
  entries.append(e)
 by={(e['uid'],e['costumeId']):e for e in entries}
 for alias in aliases:
  original=by.get((alias['uid'],'original'))
  if original:original.setdefault('coversFamilies',[]).append(alias['family'])
 return entries,aliases,excluded
def generated_entries(entries,registrations,review_index):
 by={(e['uid'],e['costumeId']):e for e in entries};reviews={(r['uid'],r['costumeId']):r for r in review_index.get('reviews',[])}
 for item in registrations:
  regpath=item['receipt']if isinstance(item,dict)else item
  reg=load(regpath)
  if reg.get('schema')!='cqc.static-source-page-registration/1'or reg.get('stage')!='source_png_registered'or not reg.get('exactCanonicalReadback'):raise ValueError('Incomplete source registration')
  p=pathlib.Path(reg['canonicalPath']);assert p.is_relative_to(CAT/'assets/source-pages')and p.resolve(strict=True)==p
  raw=read(p);sha=hashlib.sha256(raw).hexdigest();assert sha==reg['source']['sha256']and len(raw)==reg['source']['bytes']
  cells=item.get('cellsOverride',reg['cells'])if isinstance(item,dict)else reg['cells']
  selected=set(item.get('selectedCostumes',[]))if isinstance(item,dict)else set()
  for cell in cells:
   if selected and cell['outfit']not in selected:continue
   key=(reg['uid'],cell['outfit']);e=by.get(key)
   if e is None:raise ValueError('Registered outfit is absent from planned jobs: '+str(key))
   rect=cell['frameRect'];frame={'rect':[rect['x'],rect['y'],rect['width'],rect['height']]}
   if cell.get('footprint'):frame['pivot']=[(cell['footprint']['x']-rect['x'])/rect['width'],(cell['footprint']['y']-rect['y'])/rect['height']]
   review=reviews.get(key,{})
   if review.get('sourceSHA256')!=sha:review={}
   approved=review.get('status')=='approved'and review.get('sourceSHA256')==sha and bool(review.get('reviewer'))
   for field in ['rect','pivot','bodyBounds','footprint','clipPolygon','clipHoles']:
    if field in review:frame[field]=review[field]
   e.update(costume=cell.get('label')or e['costume'],source={'kind':'generated-atlas','src':reg['relativePath'],'sha256':sha,'verified':True,'width':reg['PNG']['width'],'height':reg['PNG']['height'],'columns':reg['columns'],'rows':reg['rows'],'slot':cell['slot']},frame=frame,facing=cell['facing'],status='drawn'if approved else'review',note=review.get('note',e.get('note',''))if approved else review.get('note','Nouvelle planche dessinée ; la pose et son appui attendent la revue.'),artReview=review or None)
 return entries
def main():
 a=argparse.ArgumentParser();group=a.add_mutually_exclusive_group(required=True);group.add_argument('--jobs');group.add_argument('--matrix');a.add_argument('--extra-entries');a.add_argument('--registration',action='append',default=[]);a.add_argument('--registration-dir');a.add_argument('--registration-index');a.add_argument('--review-index');a.add_argument('--output',default=str(CAT/'manifest.json'));args=a.parse_args()
 basepath=args.jobs or args.matrix;jobdata=load(basepath);excluded=[]
 if args.matrix:
  capturePath=ROOT/'artists/e/composites/ORIGINAL24_REFERENCE_INDEX_PRIVATE_V1.json';captures={r['uid']:r for r in load(capturePath)['references']}if capturePath.exists()else{}
  entries,aliases,excluded=build_matrix(jobdata,captures)
 else:entries,aliases=build_jobs(jobdata['jobs'])
 for existingName in ['EXISTING_NATIVE_OFFICIAL_STATIC_ENTRIES_PUBLIC_V1.json','EXISTING_DEDICATED_OFFICIAL_STATIC_ENTRIES_PUBLIC_V1.json']:
  existingOfficial=CAT/existingName
  if existingOfficial.exists():entries+=load(existingOfficial)['entries']
 if args.extra_entries:
  extra=load(args.extra_entries);entries+=extra if isinstance(extra,list)else extra['entries']
 regs=[pathlib.Path(p)for p in args.registration]
 if args.registration_dir:regs+=sorted(pathlib.Path(args.registration_dir).glob('*.registration.json'))
 if args.registration_index:regs+=load(args.registration_index)['registrations']
 officialMap=ROOT/'official/OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json'
 if officialMap.exists():
  current={(e['uid'],e['costumeId']):e for e in entries};identity={e['uid']:e for e in entries if e['family']=='original'}
  for record in load(officialMap)['rows']:
   uid=record['targetUID'];outfit=record.get('targetCostumeID')or record['reconciledOfficialID'];key=(uid,outfit)
   if key in current:
    current[key].setdefault('historicalOfficialIDs',[]).append(record['historicalID']);continue
   who=identity[uid];pending=record['resolutionState'];isMissing=pending=='REFERENCE_AND_STATIC_SOURCE_PENDING'
   e={'uid':uid,'character':who['character'],'era':who['era'],'incarnation':who['incarnation'],'costumeId':outfit,'costume':record['historicalCostumeName'],'family':'canonical','origin':'official','status':'missing'if isMissing else'review','facing':'right','references':[{'url':u}for u in record.get('referenceURLs',[])],'historicalOfficialIDs':[record['historicalID']],'note':'Référence complète et pose à établir pour cette tenue officielle.'if isMissing else record['resolutionReason']}
   entries.append(e);current[key]=e
 entries=generated_entries(entries,regs,load(args.review_index)if args.review_index else{})
 existingPrivate=CAT/'EXISTING_PRIVATE_POSE_OVERLAYS_PUBLIC_V1.json'
 if existingPrivate.exists():
  by={(e['uid'],e['costumeId']):e for e in entries}
  for overlay in load(existingPrivate)['entries']:
   key=(overlay['uid'],overlay['costumeId']);assert key in by;by[key].update(overlay)
 correctionPath=CAT/'FRAME_SELECTION_CORRECTIONS_PRIVATE_V1.json'
 if correctionPath.exists():
  by={(e['uid'],e['costumeId']):e for e in entries}
  for fix in load(correctionPath)['corrections']:
   e=by[(fix['uid'],fix['costumeId'])]
   if e.get('source',{}).get('sha256')!=fix['sourceSHA256']:continue
   for field in ['rect','pivot','bodyBounds','clipPolygon','clipHoles']:
    if field in fix:e['frame'][field]=fix[field]
   e['frameReview']={'reviewer':fix['reviewer'],'sourceSHA256':fix['sourceSHA256'],'reason':fix['reason'],'sourceFootDatum':fix.get('footprint'),'pixelsModified':False}
 for e in entries:
  if e.get('source')and e.get('frame',{}).get('rect'):
   e['baselineGenerationRequired']=e.get('generationRequired',False);e['generationRequired']=False
 guardPath=ROOT/'dispatch/HOLD_GUARDS_CURRENT_PUBLIC_V1.json'
 if guardPath.exists():
  guards={(g['uid'],g['family']):g for g in load(guardPath)['guards']}
  for e in entries:
   guard=guards.get((e['uid'],e['family']))
   if guard:
    e['baselineGenerationRequired']=e.get('generationRequired',False);e['generationRequired']=False;e['generationPermitted']=False;e['staticPoseUnresolved']=True
    e.update(status='review',generationGuard=guard,note='Génération ou correction refusée par l’outil ; cette variante reste en réserve. '+('Le concept déjà dessiné est conservé.'if e.get('source')else'Aucune nouvelle pose produite pour cette variante.'))
 keys=[e['uid']+':'+e['costumeId']for e in entries];assert len(keys)==len(set(keys))
 manifest={'schema':'cqc.static-pose-catalog/1','label':'Passe du 13 novembre — poses uniques','createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Static one-pose wardrobe evidence only. No animation/combat/deployment admission.','inventoryInput':str(pathlib.Path(basepath)),'baseSnapshot':jobdata.get('summary'),'aliasesCoveredByOriginal':aliases,'notApplicableExcluded':excluded,'entries':entries}
 out=pathlib.Path(args.output).absolute();assert out.is_relative_to(ROOT)and out.resolve(strict=False)==out;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
 counts={s:sum(e['status']==s for e in entries)for s in ['drawn','review','missing']};print(json.dumps({'output':str(out),'entries':len(entries),'counts':counts,'sameOriginalAliasesNotDoubleCounted':len(aliases),'newSpriteGenerationClaimed':False}))
if __name__=='__main__':main()
