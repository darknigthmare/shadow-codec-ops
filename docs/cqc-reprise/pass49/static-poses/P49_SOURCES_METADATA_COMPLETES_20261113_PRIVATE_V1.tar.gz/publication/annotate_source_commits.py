import pathlib,json,datetime
from git_blob_store import N
manifest=N/'catalog/manifest-all381.json';m=json.loads(manifest.read_text());bySHA={}
for p in sorted((N/'publication').glob('SOURCE_COMMIT_*_PRIVATE_V1.json')):
 d=json.loads(p.read_text())
 for r in d['rows']:bySHA.setdefault(r['sha256'],{'commit':d['commit'],'path':r['path'],'gitBlobOID':r['sha']})
count=0
for e in m['entries']:
 source=e.get('source')or{};r=bySHA.get(source.get('sha256'))
 if r:
  source.update(immutableURL='https://raw.githubusercontent.com/darknigthmare/shadow-codec-ops/'+r['commit']+'/'+r['path'],immutableSourceCommit=r['commit'],gitBlobOID=r['gitBlobOID']);count+=1
manifest.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'newPoseEntriesWithImmutableRawURLs':count,'rawHashesInLedger':len(bySHA)}))
