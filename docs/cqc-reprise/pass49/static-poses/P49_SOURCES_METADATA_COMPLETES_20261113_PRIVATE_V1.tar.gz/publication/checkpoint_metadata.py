"""Lossless, bounded metadata/code checkpoint; generated PNGs are separately in Git."""
import datetime,gzip,hashlib,io,json,os,pathlib,re,tarfile
N=pathlib.Path('/tmp/cqc-static-20261113');W=pathlib.Path('/workspace/cqc-static-20261113/checkpoints');W.mkdir(parents=True,exist_ok=True)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');selected=[];skipped=[];inherited=[];previous=None;previousHashes={}
latest=N/'publication/LATEST_METADATA_CHECKPOINT_PRIVATE_V1.json'
if latest.exists():
 previous=json.loads(latest.read_text())
 with tarfile.open(previous['archive'],'r:gz')as t:
  previousManifest=json.load(t.extractfile('CHECKPOINT_MANIFEST_PRIVATE_V1.json'))
 previousHashes={r['originalPath']:r['sha256']for r in previousManifest.get('inherited',[])+previousManifest['rows']}
for folder in ['inventory','dispatch','official','catalog','publication','artists','reuse-private','delivery']:
 for p in(N/folder).rglob('*'):
  if not p.is_file()or p.suffix.lower()not in['.json','.csv','.py','.mjs','.js','.html','.css','.md','.txt']:continue
  if any(x in p.parts for x in ['original-contracts381','__pycache__','node_modules'])or any('profile'in x.lower()for x in p.parts):continue
  if p.name.startswith('tmp')or p.stat().st_size>40*1024*1024:continue
  try:
   before=p.stat()
   with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:b=f.read()
   if before!=p.stat():raise ValueError('changed during snapshot')
   if p.suffix=='.json':json.loads(b)
   if re.search(rb'data:image/[a-z0-9.+-]+;base64,',b):raise ValueError('embedded raster excluded')
   digest=hashlib.sha256(b).hexdigest()
   if previousHashes.get(str(p))==digest:inherited.append({'originalPath':str(p),'sha256':digest,'bytes':len(b)})
   else:selected.append((p,b))
  except(Exception)as e:skipped.append({'path':str(p),'reason':str(e)[:150]})
rows=[{'originalPath':str(p),'member':p.relative_to(N).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}for p,b in selected]
head=json.loads((N/'publication/CURRENT_HEAD_PRIVATE_V1.json').read_text())
manifest={'schema':'cqc.static-pose.metadata-checkpoint/2','atUTC':stamp,'scope':'Static poses only; no animation/gameplay/deployment work. PNG source preservation is in Git commits on P49; this checkpoint preserves code, queues, references/provenance and framing. Each file captured losslessly, not an atomic filesystem snapshot. Restore prior checkpoint chain before this delta.','previousCheckpoint':previous,'currentGitHead':head,'branch':'codex/cqc-p49-static-costumes-20261113','rows':rows,'inherited':inherited,'skipped':skipped}
archive=W/('P49_STATIC_METADATA_'+stamp+'_PRIVATE_V1.tar.gz');controls=json.dumps(manifest,ensure_ascii=False,indent=2).encode();payload=[(r['member'],b)for r,(_,b)in zip(rows,selected)]+[('CHECKPOINT_MANIFEST_PRIVATE_V1.json',controls)]
with archive.open('xb')as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',compresslevel=9,mtime=0)as g:
  with tarfile.open(fileobj=g,mode='w|')as t:
   for name,b in payload:
    m=tarfile.TarInfo(name);m.size=len(b);m.mode=0o600;m.mtime=0;t.addfile(m,io.BytesIO(b))
expected=dict(payload)
with tarfile.open(archive,'r:gz')as t:
 assert len(t.getmembers())==len(expected)
 for m in t.getmembers():assert m.isfile()and t.extractfile(m).read()==expected[m.name]
digest=hashlib.sha256(archive.read_bytes()).hexdigest();receipt={'schema':'cqc.static-pose.metadata-checkpoint-receipt/2','archive':str(archive),'bytes':archive.stat().st_size,'sha256':digest,'filesExact':len(rows),'inheritedExact':len(inherited),'previousCheckpoint':previous,'skippedCount':len(skipped),'currentGitHead':head,'allStoredMembersReadbackExact':True,'sourcePixelsModified':False}
(W/(archive.name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');(N/'publication/LATEST_METADATA_CHECKPOINT_PRIVATE_V1.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
