import pathlib,json,concurrent.futures,datetime
from git_blob_store import pin_file,known_blobs,N,PUB
source=json.loads((PUB/'VIEWED_REFERENCE_IMAGE_SOURCE_INDEX_PRIVATE_V1.json').read_text());known=known_blobs()
def run(r):
 p=N/'delivery/reference-images'/r['file'];proof=pin_file(p,known);assert proof['sha256']==r['sha256']and proof['gitBlobOID']==r['gitBlobOID'];return dict(r,gitProof=proof,gitPath='docs/cqc-reprise/pass49/static-poses/reference-images/'+r['file'])
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:rows=list(pool.map(run,source['records']))
result={'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':rows,'allPinned':True,'referenceImagesNotNewSprites':True,'branchReferencesMoved':False};(PUB/'VIEWED_REFERENCE_BINARY_GIT_PIN_INDEX_PRIVATE_V1.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'referenceImagesPinned':len(rows),'uploadedNow':sum(r['gitProof']['uploadedNow']for r in rows),'branchReferencesMoved':False}))
