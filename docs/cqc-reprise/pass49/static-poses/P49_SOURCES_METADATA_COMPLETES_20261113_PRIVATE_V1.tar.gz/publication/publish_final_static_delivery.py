#!/usr/bin/env python3
"""Single final documentation/source commit; exact Git aliases, no gameplay edits."""
import pathlib,json,hashlib,datetime,sys,concurrent.futures
from git_blob_store import N,PUB,read,api,pin_file,known_blobs
PREFIX='docs/cqc-reprise/pass49/static-poses';BRANCH='codex/cqc-p49-static-costumes-20261113';OUT=N/'delivery';entries={};proofs=[]
def load(p):return json.loads(read(p))
def add(gitpath,oid):
 assert gitpath.startswith(PREFIX+'/') and '..'not in pathlib.PurePosixPath(gitpath).parts
 if gitpath in entries:assert entries[gitpath]['sha']==oid
 entries[gitpath]={'path':gitpath,'mode':'100644','type':'blob','sha':oid}
def from_index(path,key,paths):
 data=load(path)
 for r in data[key]:
  target,oid=paths(r);add(target,oid)
from_index(PUB/'PORTABLE_ALL_SOURCE_BLOB_PIN_INDEX_PRIVATE_V1.json','records',lambda r:(PREFIX+'/catalogue/'+r['portablePath'],r['gitBlobOID']))
from_index(PUB/'VIEWED_REFERENCE_BINARY_GIT_PIN_INDEX_PRIVATE_V1.json','rows',lambda r:(r['gitPath'],r['gitBlobOID']))
from_index(PUB/'EXISTING26_COMPOSITE_GIT_PIN_INDEX_PRIVATE_V1.json','rows',lambda r:(r['gitPath'],r['gitBlobOID']))
files=[]
for name in ['index.html','catalog.mjs','catalog.css','manifest-model.mjs','manifest.json','LIRE_MOI.txt']:files.append((OUT/'catalogue'/name,PREFIX+'/catalogue/'+name))
for name in ['REFERENCE_IMAGE_INDEX_PUBLIC_V1.json']:files.append((OUT/'reference-images'/name,PREFIX+'/reference-images/'+name))
for name in ['CQC_SUIVI_P49_POSES_UNIQUES_20261113_PUBLIC_V1.xlsx','P49_POSES_STATIQUES_PUBLIC_V1.csv','P49_OFFICIELS_PUBLIC_V1.csv','P49_MODE_EMPLOI_PUBLIC_V1.csv','P49_LIVRAISON_POSES_UNIQUES_PUBLIC_V1.json','P49_SOURCES_METADATA_COMPLETES_20261113_PRIVATE_V1.tar.gz','README.md','P49_FINAL_VERIFICATION_PUBLIC_V1.json']:files.append((OUT/name,PREFIX+'/'+name))
for folder,name in [('inventory','STATIC_ALL381_CATALOG_COMPACT_PUBLIC_V1.json'),('official','OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PUBLIC_V1.csv'),('official','OFFICIAL416_REFERENCE_DISPOSITIONS_PUBLIC_V1.csv')]:files.append((N/folder/name,PREFIX+'/inventaires/'+name))
for name in ['PORTABLE_CATALOG_BROWSER_ACTUAL_PRIVATE_V1.json','portable-officials-1440.png','portable-mobile-390.png','FRAME_CORRECTION_RENDER_01_PRIVATE_V1.png','FRAME_CORRECTION_RENDER_02_PRIVATE_V1.png']:
 p=N/'catalog/qa'/name
 if p.exists():files.append((p,PREFIX+'/verification/'+name))
known=known_blobs()
def prepare(item):
 p,target=item;r=pin_file(p,known);return r,target
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
 for r,target in pool.map(prepare,files):add(target,r['gitBlobOID']);proofs.append(dict(r,gitPath=target))
plan={'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prefix':PREFIX,'branch':BRANCH,'treeEntries':len(entries),'exactMetadataFiles':proofs,'gameFilesModified':0,'tree':list(entries.values())};(PUB/'FINAL_DELIVERY_TREE_PLAN_PRIVATE_V1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
if '--commit'not in sys.argv:print(json.dumps({'preparedTreeEntries':len(entries),'branchReferenceMoved':False}));sys.exit(0)
assert not(PUB/'PRESERVATION_SINGLE_WRITER.lock').exists(),'Source writer still active'
watch=load(PUB/'WATCH_STATUS_PRIVATE_V1.json');assert watch['stopping']and watch['pendingRawPages']==0
assert not(PUB/'WATCH_ERROR_PRIVATE_V1.json').exists()
head=load(PUB/'CURRENT_HEAD_PRIVATE_V1.json');remote=api('git/ref/heads/'+BRANCH);assert remote['object']['sha']==head['commit'],'Branch lease changed before publication'
for index in ['PORTABLE_ALL_SOURCE_BLOB_PIN_INDEX_PRIVATE_V1.json','VIEWED_REFERENCE_BINARY_GIT_PIN_INDEX_PRIVATE_V1.json']:
 d=load(PUB/index)
 assert d.get('allObjectsPinned',d.get('allPinned',False))
# Build immediate-child subtrees, avoiding a large deep-merge request.
current=api('git/trees/'+head['tree']+'?recursive=1');assert not current.get('truncated');dirs={r['path']:r['sha']for r in current['tree']if r['type']=='tree'};dirs['']=head['tree'];trie={}
for full,item in entries.items():
 relative=full[len(PREFIX)+1:];parts=relative.split('/');node=trie
 for part in parts[:-1]:node=node.setdefault(part,{})
 node[parts[-1]]=item['sha']
def create_directory(node,path):
 children=[]
 for name,value in sorted(node.items()):
  if isinstance(value,dict):children.append({'path':name,'mode':'040000','type':'tree','sha':create_directory(value,path+'/'+name)})
  else:children.append({'path':name,'mode':'100644','type':'blob','sha':value})
 base=dirs.get(path)
 for start in range(0,len(children),48):
  payload={'tree':children[start:start+48]}
  if base:payload['base_tree']=base
  made=api('git/trees',payload);base=made['sha']
  print('DIRECTORY_CHUNK',path,start+len(payload['tree']),len(children),base,flush=True)
 return base
child=create_directory(trie,PREFIX);parts=PREFIX.split('/')
for i in range(len(parts)-1,-1,-1):
 parent='/'.join(parts[:i]);name=parts[i];child=api('git/trees',{'base_tree':dirs[parent],'tree':[{'path':name,'mode':'040000','type':'tree','sha':child}]})['sha']
tree={'sha':child}

got=api('git/trees/'+tree['sha']+'?recursive=1');assert not got.get('truncated');actual={r['path']:r['sha']for r in got['tree']if r['type']=='blob'}
assert all(actual[p]==r['sha']for p,r in entries.items())
base=load(N/'reuse-private/BASE72807_GIT_TREE_PRIVATE_V1.json');basefiles={r['path']:r['sha']for r in base['tree']if r['type']=='blob'}
changed=[p for p,oid in actual.items()if basefiles.get(p)!=oid];removed=[p for p in basefiles if p not in actual]
assert all(p.startswith(PREFIX+'/')for p in changed)and not removed,'Unexpected change outside P49 source evidence'
commit=api('git/commits',{'message':'art(cqc): deliver single-pose costumes catalogue and preserved Excel [skip ci]\n\nOne static pose per costume, exact source PNGs, same-incarnation inventory, qualified official references and documented holds. Historical workbook sheets preserved. No game, animation, stage or deployment changes.','tree':tree['sha'],'parents':[head['commit']]})
assert api('git/ref/heads/'+BRANCH)['object']['sha']==head['commit'],'Branch lease changed after object preparation'
api('git/refs/heads/'+BRANCH,{'sha':commit['sha'],'force':False},method='PATCH')
report={'schema':'cqc.static-pose.final-git-delivery/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':commit['sha'],'tree':tree['sha'],'parent':head['commit'],'branch':BRANCH,'pullRequest':'https://github.com/darknigthmare/shadow-codec-ops/pull/11','deliveryEntriesVerified':len(entries),'changedPathsFromP48':len(changed),'allChangedPathsWithinStaticPoseEvidence':True,'removedExistingPaths':0,'gameFilesModified':0,'allPreparedGitTreeObjectsReadBackExact':True,'sourceWriterStopped':True,'metadataBinaryProofs':proofs}
(PUB/'FINAL_DELIVERY_GIT_COMMIT_PRIVATE_V1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');(PUB/'CURRENT_HEAD_PRIVATE_V1.json').write_text(json.dumps({'commit':commit['sha'],'tree':tree['sha']},indent=2)+'\n');(PUB/'FINAL_DELIVERY_FULL_GIT_TREE_PRIVATE_V1.json').write_text(json.dumps(got)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='metadataBinaryProofs'}))
