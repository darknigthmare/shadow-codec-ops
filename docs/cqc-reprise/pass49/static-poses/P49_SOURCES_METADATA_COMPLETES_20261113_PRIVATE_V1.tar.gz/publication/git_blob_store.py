"""Exact binary/text Git object preparation; branch mutation belongs to one publisher."""
import pathlib,json,os,subprocess,tempfile,hashlib,base64
N=pathlib.Path('/tmp/cqc-static-20261113');PUB=N/'publication';REPO='darknigthmare/shadow-codec-ops'
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:before=os.fstat(f.fileno());b=f.read();after=os.fstat(f.fileno())
 assert before==after and p.stat()==before;return b
def api(endpoint,payload=None,method=None):
 args=['gh','api','repos/'+REPO+'/'+endpoint];temp=None
 try:
  if payload is not None:
   with tempfile.NamedTemporaryFile(mode='w',dir=PUB,suffix='.json',delete=False)as f:json.dump(payload,f);temp=f.name
   args+=['--method',method or'POST','--input',temp]
  elif method:args+=['--method',method]
  p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
  if p.returncode:raise RuntimeError(p.stderr.decode()[:1000])
  return json.loads(p.stdout)
 finally:
  if temp:os.unlink(temp)
def known_blobs():
 d=json.loads(read(N/'reuse-private/BASE72807_GIT_TREE_PRIVATE_V1.json'));known={r['sha']for r in d['tree']if r['type']=='blob'}
 for suffix in ['*-RAW_BLOB_READBACK_PRIVATE_V1.json','*-PORTABLE_BLOB_READBACK_PRIVATE_V1.json','*-BINARY_SOURCE_BLOB_READBACK_PRIVATE_V1.json']:
  for p in PUB.glob(suffix):
   r=json.loads(read(p))
   if r.get('exactReadback'):known.add(r['gitBlobOID'])
 return known
def pin_file(path,known=None):
 p=pathlib.Path(path).absolute();assert p.resolve(strict=True)==p and(p.is_relative_to(N)or p.is_relative_to(pathlib.Path('/workspace/cqc-static-20261113/checkpoints')));b=read(p);assert len(b)<50*1024*1024;sha=hashlib.sha256(b).hexdigest();oid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();r={'source':str(p),'bytes':len(b),'sha256':sha,'gitBlobOID':oid,'branchReferenceMoved':False}
 if oid in(known if known is not None else known_blobs()):return dict(r,gitObjectVerified=True,proof='Exact local Git blob hash matches immutable tree or prior binary readback receipt.',uploadedNow=False)
 receipt=PUB/(sha+'-BINARY_SOURCE_BLOB_READBACK_PRIVATE_V1.json')
 if receipt.exists():
  old=json.loads(read(receipt));assert old['gitBlobOID']==oid and old['exactReadback'];return dict(r,gitObjectVerified=True,proof=str(receipt),uploadedNow=False)
 created=api('git/blobs',{'encoding':'base64','content':base64.b64encode(b).decode()});assert created['sha']==oid;got=api('git/blobs/'+oid);assert got['encoding']=='base64'and base64.b64decode(got['content'])==b;r.update(exactReadback=True);receipt.write_text(json.dumps(r,indent=2)+'\n');return dict(r,gitObjectVerified=True,proof=str(receipt),uploadedNow=True)
