#!/usr/bin/env python3
"""Pin local catalogue assets as exact Git blobs; never move a branch reference."""
import pathlib,json,hashlib,base64,os,subprocess,tempfile,concurrent.futures,datetime
N=pathlib.Path('/tmp/cqc-static-20261113');OUT=N/'publication';CAT=N/'delivery/catalogue';base=json.loads((N/'reuse-private/BASE72807_GIT_TREE_PRIVATE_V1.json').read_text());known={r['sha']for r in base['tree']if r['type']=='blob'}
for p in OUT.glob('*-RAW_BLOB_READBACK_PRIVATE_V1.json'):
 r=json.loads(p.read_text())
 if r.get('exactReadback'):known.add(r['gitBlobOID'])
records=json.loads((OUT/'PORTABLE_STATIC_CATALOG_SOURCE_INDEX_PRIVATE_V1.json').read_text())['records']
def api(endpoint,payload=None):
 args=['gh','api','repos/darknigthmare/shadow-codec-ops/'+endpoint];temp=None
 try:
  if payload is not None:
   with tempfile.NamedTemporaryFile(mode='w',dir=OUT,suffix='.json',delete=False)as f:json.dump(payload,f);temp=f.name
   args+=['--method','POST','--input',temp]
  r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
  if r.returncode:raise RuntimeError(r.stderr.decode()[:800])
  return json.loads(r.stdout)
 finally:
  if temp:os.unlink(temp)
def run(r):
 p=CAT/r['portablePath'];sha=r['sha256'];oid=r['gitBlobOID'];receipt=OUT/(sha+'-PORTABLE_BLOB_READBACK_PRIVATE_V1.json')
 if oid in known:return dict(r,gitObjectVerified=True,proof='Exact local Git blob SHA1 matches immutable baseline tree or full raw readback receipt.',uploadedByThisTool=False)
 if receipt.exists():
  d=json.loads(receipt.read_text());assert d['gitBlobOID']==oid and d['exactReadback'];return dict(r,gitObjectVerified=True,proof=str(receipt),uploadedByThisTool=True)
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:b=f.read()
 assert hashlib.sha256(b).hexdigest()==sha and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;made=api('git/blobs',{'encoding':'base64','content':base64.b64encode(b).decode()});assert made['sha']==oid;got=api('git/blobs/'+oid);assert base64.b64decode(got['content'])==b;d=dict(r,exactReadback=True,sourcePNGModified=False,branchRefMoved=False);receipt.write_text(json.dumps(d,indent=2)+'\n');return dict(r,gitObjectVerified=True,proof=str(receipt),uploadedByThisTool=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:results=list(pool.map(run,records))
report={'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':results,'allObjectsPinned':all(r['gitObjectVerified']for r in results),'branchReferenceMoved':False};(OUT/'PORTABLE_ALL_SOURCE_BLOB_PIN_INDEX_PRIVATE_V1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'pinned':len(results),'knownTreeOrReadback':sum(not r['uploadedByThisTool']for r in results),'newOrPriorPrepared':sum(r['uploadedByThisTool']for r in results),'branchReferenceMoved':False}))
