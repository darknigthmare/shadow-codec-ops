#!/usr/bin/env python3
"""Self-contained metadata/code snapshot for this static source pass."""
import pathlib,json,os,hashlib,datetime,tarfile,gzip,io,re
from git_blob_store import N,read
OUT=N/'delivery';OUT.mkdir(exist_ok=True);selected=[];skipped=[];allowed={'.json','.csv','.py','.mjs','.js','.html','.css','.md','.txt'}
for folder in ['inventory','dispatch','official','catalog','publication','artists','reuse-private','delivery']:
 for p in(N/folder).rglob('*'):
  if not p.is_file()or p.suffix.lower()not in allowed:continue
  if any('profile'in part.lower()for part in p.parts)or any(part in['node_modules','__pycache__']for part in p.parts)or p.name.startswith('tmp'):continue
  if p.stat().st_size>45*1024*1024:skipped.append({'file':str(p.relative_to(N)),'reason':'File exceeds bounded metadata size'});continue
  b=read(p)
  if re.search(rb'data:image/[a-z0-9.+-]+;base64,',b):skipped.append({'file':str(p.relative_to(N)),'reason':'Public search HTML with embedded raster; actual viewed image references preserved separately'});continue
  if p.suffix=='.json':json.loads(b)
  selected.append((p.relative_to(N).as_posix(),b))
manifest={'schema':'cqc.static-source.complete-metadata-bundle/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Metadata, framing, provenance, source contracts, inventory and code for one-pose costumes. PNG bytes are preserved in Git, addressed by their hashes; reference-image pool is separate. No browser profiles/secrets or new gameplay/animation files.','sourceRawHead':json.loads((N/'publication/CURRENT_HEAD_PRIVATE_V1.json').read_text()),'files':[{'file':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}for name,b in selected],'skipped':skipped}
selected.append(('COMPLETE_METADATA_MANIFEST_PRIVATE_V1.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode()));target=OUT/'P49_SOURCES_METADATA_COMPLETES_20261113_PRIVATE_V1.tar.gz'
with target.open('wb')as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',compresslevel=9,mtime=0)as g:
  with tarfile.open(fileobj=g,mode='w|')as tar:
   for name,b in selected:
    member=tarfile.TarInfo(name);member.size=len(b);member.mode=0o600;member.mtime=0;tar.addfile(member,io.BytesIO(b))
with tarfile.open(target,'r:gz')as tar:
 assert len(tar.getmembers())==len(selected)
 for member,(name,b)in zip(tar.getmembers(),selected):assert member.isfile()and member.name==name and tar.extractfile(member).read()==b
report={'file':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(read(target)).hexdigest(),'files':len(selected),'skipped':skipped,'allStoredFilesReadBackExact':True,'sourcePixelsModified':False};(N/'publication/FULL_METADATA_BUNDLE_READBACK_PRIVATE_V1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report))
