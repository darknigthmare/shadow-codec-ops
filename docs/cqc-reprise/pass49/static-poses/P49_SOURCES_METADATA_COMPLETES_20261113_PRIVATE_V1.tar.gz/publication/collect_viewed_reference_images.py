#!/usr/bin/env python3
"""Preserve already viewed public reference image bytes, with no image transform."""
import pathlib,json,os,hashlib,datetime,collections
N=pathlib.Path('/tmp/cqc-static-20261113');OUT=N/'delivery/reference-images';OUT.mkdir(parents=True,exist_ok=True);APP=pathlib.Path('/workspace/cqc-pass21-application/public/cqc');records={};skipped=[]
for meta in (N/'artists').rglob('*ARTIFACT_PROPOSAL*.json'):
 d=json.loads(meta.read_text())
 for ref in d.get('referenceSources',[]):
  if not ref.get('viewed'):continue
  name=ref.get('path')or ref.get('file')
  if not name:continue
  p=pathlib.Path(name).absolute()
  if not p.is_relative_to(N)and not p.is_relative_to(APP):skipped.append({'document':str(meta),'path':str(p),'reason':'Outside permitted image reference roots'});continue
  if not p.is_file()or p.resolve(strict=True)!=p:skipped.append({'document':str(meta),'path':str(p),'reason':'Reference local bytes absent'});continue
  with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:before=os.fstat(f.fileno());b=f.read();after=os.fstat(f.fileno())
  assert before==after and p.stat()==before
  ext='.png'if b.startswith(b'\x89PNG\r\n\x1a\n')else'.jpg'if b.startswith(b'\xff\xd8\xff')else'.gif'if b.startswith((b'GIF87a',b'GIF89a'))else'.webp'if b[:4]==b'RIFF'and b[8:12]==b'WEBP'else'.pdf'if b.startswith(b'%PDF-')else None
  if not ext:skipped.append({'document':str(meta),'path':str(p),'reason':'Not a supported image or original PDF reference container'});continue
  sha=hashlib.sha256(b).hexdigest();expected=ref.get('sha256');assert not expected or expected==sha
  r=records.setdefault(sha,{'sha256':sha,'bytes':len(b),'gitBlobOID':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'file':sha+ext,'references':[]});url=ref.get('URL')or ref.get('url');r['references'].append({'URL':url,'subject':ref.get('subject',''),'viewedBy':d.get('visualReview',{}).get('reviewer',ref.get('viewedBy','artist')),'proposalUID':d.get('uid'),'proposal':str(meta.relative_to(N))});target=OUT/r['file']
  if not target.exists():
   with open(target,'xb')as f:f.write(b)
  assert hashlib.sha256(target.read_bytes()).hexdigest()==sha
report={'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'uniqueImages':len(records),'bytes':sum(r['bytes']for r in records.values()),'records':list(records.values()),'skipped':skipped,'imageBytesModified':False};(N/'publication/VIEWED_REFERENCE_IMAGE_SOURCE_INDEX_PRIVATE_V1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');public={'qualification':'Reference images and original PDF documents already viewed for individual Source proposals. Original publisher/rehost URLs and exact image hashes retained. Reference images are not newly generated sprites.','records':[dict(r,references=[{k:v for k,v in q.items()if k!='proposal'}for q in r['references']])for r in records.values()]};(OUT/'REFERENCE_IMAGE_INDEX_PUBLIC_V1.json').write_text(json.dumps(public,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'uniqueImages':len(records),'bytes':report['bytes'],'skipped':len(skipped),'imageBytesModified':False}))
