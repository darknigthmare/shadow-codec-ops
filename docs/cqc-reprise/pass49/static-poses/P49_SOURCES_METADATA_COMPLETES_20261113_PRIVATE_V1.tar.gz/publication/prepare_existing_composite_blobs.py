import json,pathlib,datetime,concurrent.futures
from git_blob_store import N,PUB,pin_file,known_blobs
original=json.loads((N/'artists/e/composites/ORIGINAL24_REFERENCE_INDEX_PRIVATE_V1.json').read_text())['references'];retro=json.loads((N/'artists/e/existing-retro2/STATIC_EXISTING_RETRO2_COMPOSITES_PRIVATE_V1.json').read_text())['rows'];known=known_blobs()
def run(r):
 p=pathlib.Path(r['file']);proof=pin_file(p,known);assert proof['sha256']==r['sha256'];family=r.get('family','original');return {'uid':r['uid'],'family':family,'source':str(p),'sha256':r['sha256'],'gitBlobOID':proof['gitBlobOID'],'bytes':proof['bytes'],'gitPath':'docs/cqc-reprise/pass49/static-poses/existing-composites/'+p.name,'gitProof':proof,'newDrawing':False}
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:rows=list(pool.map(run,original+retro))
(PUB/'EXISTING26_COMPOSITE_GIT_PIN_INDEX_PRIVATE_V1.json').write_text(json.dumps({'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':rows,'allPinned':True,'newDrawings':0,'runtimeGuardsChanged':False},indent=2)+'\n');print(json.dumps({'existingCompositesPinned':len(rows),'allPinned':True,'uploadedNow':sum(r['gitProof']['uploadedNow']for r in rows)}))
