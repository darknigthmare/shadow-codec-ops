#!/usr/bin/env python3
"""Read-only final source/container/coverage/framing/pin consistency checks."""
import pathlib,json,hashlib,io,collections,datetime,sys
from PIL import Image
from git_blob_store import N,read
sys.path.insert(0,str(N/'catalog/tools'))
from register_source_page import png_structure
m=json.loads(read(N/'catalog/manifest-all381.json'));portable=json.loads(read(N/'delivery/catalogue/manifest.json'));sourceIndex=json.loads(read(N/'publication/PORTABLE_STATIC_CATALOG_SOURCE_INDEX_PRIVATE_V1.json'));by={(e['uid'],e['costumeId']):e for e in m['entries']};assert len(by)==len(m['entries'])
assert {(e['uid'],e['costumeId'])for e in portable['entries']}==set(by)
raws={}
for p in(N/'publication').glob('SOURCE_COMMIT_*_PRIVATE_V1.json'):
 d=json.loads(read(p))
 for r in d['rows']:
  b=read(pathlib.Path(r['localPath']));assert hashlib.sha256(b).hexdigest()==r['sha256'];raws[r['sha256']]=r
verified=[];sizes={}
for r in sourceIndex['records']:
 p=N/'delivery/catalogue'/r['portablePath'];b=read(p);assert hashlib.sha256(b).hexdigest()==r['sha256'];info=png_structure(b)
 with Image.open(io.BytesIO(b))as im:
  im.load();assert im.size==(info['width'],info['height'])
 verified.append(r['sha256']);sizes[r['sha256']]=(info['width'],info['height'])
assert len(set(verified))==len(sourceIndex['records'])
for e in m['entries']:
 s=e.get('source');f=e.get('frame')
 if not s:assert not f;continue
 assert f and s['sha256']in verified;assert(s['width'],s['height'])==sizes[s['sha256']]
 x,y,w,h=f['rect'];assert all(type(v)is int for v in[x,y,w,h])and x>=0 and y>=0 and w>0 and h>0 and x+w<=s['width']and y+h<=s['height']
 assert e['facing']=='right'
 if s['kind']=='generated-atlas':assert s['sha256']in raws and s.get('immutableURL')
 if e.get('generationRequired'):raise AssertionError('Present pose still requires generation')
planned=[e for e in m['entries']if e['family']!='canonical'];originals=[e for e in planned if e['family']=='original'];assert len(originals)==381 and all(e.get('source')and e.get('frame')for e in originals);assert not[e for e in planned if not e.get('source')and not e.get('generationGuard')]
assert len(planned)+len(m['aliasesCoveredByOriginal'])+len(m['notApplicableExcluded'])==3429
pins=json.loads(read(N/'catalog/HISTORICAL_METADATA_PIN_RESOLUTION_PRIVATE_V1.json'));assert not pins['unresolved'];assert pins['summary']['historicalPins']==len(list((N/'catalog/receipts/generation').glob('*.registration.json')))
for p in(N/'catalog/receipts/generation').glob('*.registration.json'):
 pin=json.loads(read(p))['metadataPin'];b=read(N/'catalog/import-metadata/history'/(pin['sha256']+'.json'));assert len(b)==pin['bytes']and hashlib.sha256(b).hexdigest()==pin['sha256']
active=json.loads(read(N/'catalog/ACTIVE_ARTIST_REGISTRATIONS_PRIVATE_V1.json'))
for item in active['registrations']:
 pin=item['activeMetadataPin'];b=read(pathlib.Path(pin['path']));assert hashlib.sha256(b).hexdigest()==pin['sha256']and len(b)==pin['bytes']and pin['sha256']in pathlib.Path(pin['path']).name
fixes=json.loads(read(N/'catalog/FRAME_SELECTION_CORRECTIONS_PRIVATE_V1.json'));applied=[];superseded=[]
for fix in fixes['corrections']:
 e=by[(fix['uid'],fix['costumeId'])]
 if e['source']['sha256']==fix['sourceSHA256']:
  assert e['frame']['rect']==fix['rect']and e['frame']['pivot']==fix['pivot']and e['frameReview']['reviewer']==fix['reviewer'];applied.append([fix['uid'],fix['costumeId']])
 else:superseded.append({'uid':fix['uid'],'costumeId':fix['costumeId'],'selectedNewSourceSHA256':e['source']['sha256']})
mapping=json.loads(read(N/'official/OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json'));assert len(mapping['rows'])==416
for r in mapping['rows']:
 e=by[(r['targetUID'],r.get('targetCostumeID')or r['reconciledOfficialID'])]
 if r['resolutionState']not in ['REFERENCE_AND_STATIC_SOURCE_PENDING','BODY_FORM_CHANGE_SCOPE_REVIEW_PENDING']:assert e.get('source')and e.get('frame')
 else:assert not e.get('source'),'Official mapping still stale for '+r['historicalID']
report={'schema':'cqc.static-pose.final-verification/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS','rosterIncarnations':len({e['uid']for e in m['entries']}),'plannedRowsReconciled':3429,'originalPosesPresent':len(originals),'allProduciblePlannedRowsHavePose':True,'selectedUniquePNGsSHA256CRCAndDecoded':len(verified),'rawGeneratedSourcesExactInGitLedger':len(raws),'historicalMetadataPinsExact':pins['summary']['historicalPins'],'activeImmutableMetadataPinsExact':len(active['registrations']),'reviewedFrames':len(fixes['corrections']),'reviewedFrameCorrectionsApplied':len(applied),'reviewedFrameCorrectionsSupersededBySinglePoseRedraw':superseded,'officialHistoricalRowsReconciled':416,'newAnimations':0,'gameFilesModified':0,'sourcePixelsEdited':False,'pixelPerfectFidelityCertified':False,'coverageCaveat':'Tool-refused variants remain guarded. Official outfits lacking a reliable complete same-incarnation visual source remain explicitly pending.'}
(N/'delivery/P49_FINAL_VERIFICATION_PUBLIC_V1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report))
