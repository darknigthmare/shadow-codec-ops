#!/usr/bin/env python3
import json,pathlib,hashlib,urllib.request,concurrent.futures,os,re,io,datetime
from PIL import Image
N=pathlib.Path('/tmp/cqc-static-20261113');D=N/'reuse-private';CAT=N/'catalog';d=json.loads((N/'inventory/STATIC_ALL381_CATALOG_COMPACT_PUBLIC_V1.json').read_text());tree=json.loads((D/'BASE72807_GIT_TREE_PRIVATE_V1.json').read_text());pathmap={x['path']:x for x in tree['tree']if x['type']=='blob'};shaPaths={}
for p in pathmap:
 m=re.search(r'/([a-f0-9]{64})\.png$',p)
 if m:shaPaths.setdefault(m[1],[]).append(p)
base='https://raw.githubusercontent.com/darknigthmare/shadow-codec-ops/72807eb3a89809557715ee088db8d66c675ce7f9/'
jobs=[];skipped=[]
for r in d['rows']:
 pose=r.get('sourcePose')or{};proof=pose.get('assetProof')or{};name=pose.get('file');expected=proof.get('expectedSHA256')or proof.get('sha256')or pose.get('expectedSHA256');url=proof.get('immutableSourceURL')or(name if isinstance(name,str)and name.startswith('https://raw.githubusercontent.com/darknigthmare/shadow-codec-ops/')else None)
 if not url and name and expected and not proof.get('localPresent'):
  matching=[x for x in [name,'rootassets/'+name,'public/cqc/'+name,'cqc/'+name]if x in pathmap]
  if not matching:matching=shaPaths.get(expected,[])
  if matching:url=base+matching[0]
 if not url or not pose.get('frameRect'):continue
 if not expected:
  m=re.search(r'/([a-f0-9]{64})\.png$',url)
  if m:expected=m[1]
 if not expected:skipped.append({'uid':r['uid'],'family':r['family'],'reason':'No independent expected SHA256'});continue
 jobs.append({'row':r,'url':url,'expected':expected})
cache=D/'remote-source-pages';cache.mkdir(exist_ok=True);published=CAT/'assets/reused-sources';published.mkdir(exist_ok=True)
def fetch(j):
 url=j['url'];sha=j['expected'];target=cache/(sha+'.png')
 try:
  if target.exists():raw=target.read_bytes()
  else:
   assert re.fullmatch(r'https://raw\.githubusercontent\.com/darknigthmare/shadow-codec-ops/[a-f0-9]{40}/[^\s]+\.png',url)
   with urllib.request.urlopen(url,timeout=40)as response:raw=response.read(32*1024*1024+1)
   assert len(raw)<=32*1024*1024 and hashlib.sha256(raw).hexdigest()==sha
   with open(target,'xb')as f:f.write(raw)
  assert hashlib.sha256(raw).hexdigest()==sha;im=Image.open(io.BytesIO(raw));assert im.format=='PNG'
  q=published/target.name
  if not q.exists():os.link(target,q)
  assert hashlib.sha256(q.read_bytes()).hexdigest()==sha;r=j['row'];p=r['sourcePose'];x,y,w,h=p['frameRect'];assert 0<=x and 0<=y and x+w<=im.width and y+h<=im.height
  frame={'rect':p['frameRect'],'pivot':p.get('pivot',[.5,1])}
  for k in ['clipPolygon','clipHoles','bodyBounds','footprint']:
   if k in p:frame[k]=p[k]
  e={'uid':r['uid'],'costumeId':r['id'],'status':'review','source':{'kind':'existing-archived-frame','src':q.relative_to(CAT).as_posix(),'sha256':sha,'width':im.width,'height':im.height,'verified':True,'immutableURL':url},'frame':frame,'facing':'right','note':'Dessin existant récupéré sans modification depuis son commit immuable ; cadrage statique historique conservé, aucune nouvelle admission animation.','generationRequired':False,'reusedExistingStaticPose':True}
  return {'ok':True,'entry':e,'source':str(target),'bytes':len(raw),'sha256':sha,'immutableURL':url}
 except Exception as exc:return {'ok':False,'uid':j['row']['uid'],'costumeId':j['row']['id'],'url':url,'error':str(exc)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:results=list(pool.map(fetch,jobs))
p=CAT/'EXISTING_PRIVATE_POSE_OVERLAYS_PUBLIC_V1.json';old=json.loads(p.read_text());by={(x['uid'],x['costumeId']):x for x in old['entries']}
for r in results:
 if r['ok']:by[(r['entry']['uid'],r['entry']['costumeId'])]=r['entry']
p.write_text(json.dumps({'entries':list(by.values())},ensure_ascii=False,indent=2)+'\n');report={'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'results':results,'skipped':skipped,'newDrawings':0,'originalPNGsModified':False};(D/'EXISTING_STATIC_SOURCE_RECOVERY_PRIVATE_V1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'jobs':len(jobs),'success':sum(r['ok']for r in results),'failures':[{k:v for k,v in r.items()if k!='entry'}for r in results if not r['ok']],'uniquePNGs':len({r['sha256']for r in results if r['ok']}),'skipped':skipped}))
