import pathlib,json,os,hashlib,urllib.request,io,concurrent.futures
from PIL import Image
N=pathlib.Path('/tmp/cqc-static-20261113');CAT=N/'catalog';APP=pathlib.Path('/workspace/cqc-pass21-application/public/cqc');allrows=json.loads((N/'inventory/CURRENT_NATIVE_OPTION_SOURCE_CANDIDATES_PRIVATE_V1.json').read_text())['rows'];matrix=json.loads((N/'inventory/STATIC_ALL381_CATALOG_COMPACT_PUBLIC_V1.json').read_text());ident={r['uid']:r for r in matrix['rows']if r['family']=='original'};root=CAT/'assets/reused-sources';root.mkdir(exist_ok=True)
def run(r):
 try:
  uid=r['uid'];p=r['preview'];name=p['file'];name='/'.join(name['nativePathParts'])if isinstance(name,dict)else name;sha=p.get('sha256')or next(a['sha256']for a in r['assets']if a['file']==p['file']);source=APP/name;url='https://raw.githubusercontent.com/darknigthmare/shadow-codec-ops/72807eb3a89809557715ee088db8d66c675ce7f9/rootassets/'+name;target=root/(sha+'.png')
  sourceAsset=next((a for a in r['assets']if a.get('sha256')==sha),{})
  if sourceAsset.get('url'):url=sourceAsset['url']
  elif not source.is_file():url='https://raw.githubusercontent.com/darknigthmare/shadow-codec-ops/72807eb3a89809557715ee088db8d66c675ce7f9/raw/'+sha+'.png'
  if target.exists():raw=target.read_bytes()
  elif source.is_file():
   with os.fdopen(os.open(source,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:raw=f.read()
  else:
   with urllib.request.urlopen(url,timeout=35)as response:raw=response.read(32*1024*1024)
  assert hashlib.sha256(raw).hexdigest()==sha
  if not target.exists():target.write_bytes(raw)
  im=Image.open(io.BytesIO(raw));who=ident[uid];prov=r.get('provenance')or{};assert prov.get('sourceUID',uid)==uid;refs=[{'url':x['url'],'scope':x.get('scope','')}for x in prov.get('sources',[])if x.get('url')];frame={k:p[k]for k in ['rect','pivot','clipPolygon','clipHoles','bodyBounds','footprint']if k in p};assert frame['rect']
  return {'ok':True,'entry':{'uid':uid,'character':who['name'],'era':who['incarnation'],'incarnation':who['incarnation'],'costumeId':r['id'],'costume':r['label'],'family':'canonical','origin':'official','status':'drawn','facing':'right','references':refs,'source':{'kind':'existing-archived-frame','src':target.relative_to(CAT).as_posix(),'sha256':sha,'width':im.width,'height':im.height,'verified':True,'immutableURL':url},'frame':frame,'reusedExistingStaticPose':True,'note':'Tenue officielle déjà dessinée et indexée. Une seule pose RIGHT réutilisée, PNG exact vérifié. Aucune nouvelle animation ni admission au combat.','artReview':r.get('artReview')},'source':str(target),'sourceIndex':r['index']}
 except Exception as exc:return {'ok':False,'uid':r['uid'],'id':r['id'],'error':str(exc)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:results=list(pool.map(run,[r for r in allrows if r['family']=='canonical']))
(CAT/'EXISTING_NATIVE_OFFICIAL_STATIC_ENTRIES_PUBLIC_V1.json').write_text(json.dumps({'entries':[r['entry']for r in results if r['ok']]},ensure_ascii=False,indent=2)+'\n');(N/'reuse-private/NATIVE_OFFICIAL65_RECOVERY_PRIVATE_V1.json').write_text(json.dumps({'results':results,'newDrawings':0},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'success':sum(r['ok']for r in results),'failures':[r for r in results if not r['ok']]}))
