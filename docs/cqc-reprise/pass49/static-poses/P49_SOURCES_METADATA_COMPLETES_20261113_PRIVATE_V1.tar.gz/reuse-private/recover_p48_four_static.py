import pathlib,csv,json,urllib.request,hashlib,concurrent.futures,os
N=pathlib.Path('/tmp/cqc-static-20261113');rows=list(csv.DictReader(open('/workspace/cqc-reprise-20261109/livraison-v9/P48_RAW36_SOURCE_PUBLIC_V9.csv',encoding='utf-8-sig')));wanted={('core__raven','cyborg'),('core__snake_pw','cyborg'),('core__raven','zombie'),('core__fatman','zombie')};chosen={}
for r in rows:
 key=r['UID'],r['Variante']
 if key not in wanted or r['Sens']!='RIGHT':continue
 if key not in chosen or int(r['Version'])>int(chosen[key]['Version']):chosen[key]=r
folder=N/'reuse-private/p48-static-four';folder.mkdir(exist_ok=True)
def run(item):
 key,r=item;u=r['URL PNG Source immuable'];sha=r['SHA256 PNG brut'];p=folder/(key[0]+'-'+key[1]+'-existing-right-v'+r['Version']+'.png')
 if not p.exists():
  with urllib.request.urlopen(u,timeout=30)as response:b=response.read()
  assert hashlib.sha256(b).hexdigest()==sha;p.write_bytes(b)
 return {'uid':key[0],'family':key[1],'file':str(p),'sha256':sha,'immutableURL':u,'version':int(r['Version'])}
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:report=list(pool.map(run,chosen.items()))
(folder/'P48_FOUR_EXISTING_SOURCES_PRIVATE_V1.json').write_text(json.dumps({'sources':report},indent=2)+'\n');print(json.dumps(report))
