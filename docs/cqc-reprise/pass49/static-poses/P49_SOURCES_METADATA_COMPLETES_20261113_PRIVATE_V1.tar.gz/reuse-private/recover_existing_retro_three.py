import pathlib,json,os,hashlib,urllib.request,io
from PIL import Image
N=pathlib.Path('/tmp/cqc-static-20261113');CAT=N/'catalog';p=pathlib.Path('/workspace/cqc-pass21-application/public/cqc/src/cqc-pass20-native-retro-costumes.js')
with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'r')as f:s=f.read()
data,_=json.JSONDecoder().raw_decode(s[s.index('const data=')+len('const data='):]);wanted={'core__solid','core__raiden_mgs4','core__venom'};overlay=CAT/'EXISTING_PRIVATE_POSE_OVERLAYS_PUBLIC_V1.json';d=json.loads(overlay.read_text());by={(e['uid'],e['costumeId']):e for e in d['entries']};report=[]
for r in data:
 if r['uid']not in wanted:continue
 sp=r['option']['sprite'];frames=sp.get('actions',{}).get('idle',{}).get('frames')or r.get('frames',{}).get('actions');frame=frames[0];sha=frame['sha256'];path=frame['file'];local=pathlib.Path('/workspace/cqc-pass21-application/public/cqc')/path;url='https://raw.githubusercontent.com/darknigthmare/shadow-codec-ops/72807eb3a89809557715ee088db8d66c675ce7f9/rootassets/'+path
 if local.is_file():
  with os.fdopen(os.open(local,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:raw=f.read()
 else:
  with urllib.request.urlopen(url,timeout=30)as response:raw=response.read()
 assert hashlib.sha256(raw).hexdigest()==sha;target=CAT/'assets/reused-sources'/(sha+'.png')
 if not target.exists():target.write_bytes(raw)
 im=Image.open(io.BytesIO(raw));e={'uid':r['uid'],'costumeId':'retro-msx','status':'review','source':{'kind':'existing-archived-frame','src':target.relative_to(CAT).as_posix(),'sha256':sha,'width':im.width,'height':im.height,'verified':True,'immutableURL':url},'frame':{k:frame[k]for k in ['rect','pivot','clipPolygon','clipHoles','bodyBounds','footprint']if k in frame},'facing':'right','reusedExistingStaticPose':True,'generationRequired':False,'note':'Pose rétro déjà dessinée, source et cadre RIGHT récupérés du registre natif pass20. Aucun nouveau dessin ni animation.'};by[(r['uid'],'retro-msx')]=e;report.append({'uid':r['uid'],'sourceSHA256':sha,'sourceURL':url,'frameRect':frame['rect'],'newDrawings':0})
assert len(report)==3;overlay.write_text(json.dumps({'entries':list(by.values())},ensure_ascii=False,indent=2)+'\n');(N/'reuse-private/EXISTING_RETRO_THREE_STATIC_RECOVERY_PRIVATE_V1.json').write_text(json.dumps({'recoveries':report,'nativeSourceBytesModified':False},indent=2)+'\n');print(json.dumps(report))
