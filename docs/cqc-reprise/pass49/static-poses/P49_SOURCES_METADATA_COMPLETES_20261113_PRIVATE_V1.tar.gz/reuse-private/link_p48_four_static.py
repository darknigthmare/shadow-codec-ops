import pathlib,json,hashlib,io,os
from PIL import Image
import numpy as np
N=pathlib.Path('/tmp/cqc-static-20261113');CAT=N/'catalog';report=json.loads((N/'reuse-private/p48-static-four/P48_FOUR_EXISTING_SOURCES_PRIVATE_V1.json').read_text());out=CAT/'EXISTING_PRIVATE_POSE_OVERLAYS_PUBLIC_V1.json';d=json.loads(out.read_text());by={(e['uid'],e['costumeId']):e for e in d['entries']};reviews=[]
for r in report['sources']:
 p=pathlib.Path(r['file']);raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256'];im=Image.open(io.BytesIO(raw)).convert('RGBA');a=np.asarray(im)[:,:,3];w,h=im.size;xmax=w//6;ymax=h//3;cell=a[:ymax,:xmax];ys,xs=np.where(cell>16);left,top,right,bottom=int(xs.min()),int(ys.min()),int(xs.max()),int(ys.max());rect=[max(0,left-2),max(0,top-2),min(xmax,right+3)-max(0,left-2),min(ymax,bottom+3)-max(0,top-2)];boots=np.where(cell[max(0,bottom-20):bottom+1]>64)[1];cx=(float(boots.min())+float(boots.max()))/2;
 if r['uid']=='core__fatman':
  # Current read-only flood analysis: idle component16 bbox20,6..208,335; neighbouring guard crosses tile edge255.
  rect=[18,4,193,334];cx=114.5;bottom=335
 frame={'rect':rect,'pivot':[(cx-rect[0])/rect[2],(bottom+1-rect[1])/rect[3]]};target=CAT/'assets/reused-sources'/(r['sha256']+'.png')
 if not target.exists():os.link(p,target)
 entry={'uid':r['uid'],'costumeId':r['family'],'status':'drawn','source':{'kind':'existing-archived-frame','src':target.relative_to(CAT).as_posix(),'sha256':r['sha256'],'width':w,'height':h,'verified':True,'immutableURL':r['immutableURL']},'frame':frame,'facing':'right','reusedExistingStaticPose':True,'generationRequired':False,'note':'Une seule pose neutre RIGHT sélectionnée dans la source P48 déjà dessinée, relue sur page originale. Aucun nouveau dessin ni animation.','artReview':{'sourceSHA256':r['sha256'],'status':'approved','reviewer':'Root current visual review of complete P48 source PNG','note':'Only the first neutral figure reused; other frames not admitted by this static pass.'}}
 by[(r['uid'],r['family'])]=entry;reviews.append({'uid':r['uid'],'costumeId':r['family'],'frameRect':rect,'pivot':frame['pivot'],'tileEdgesAlpha16':int((cell[:,0]>16).sum()+(cell[:,-1]>16).sum()+(cell[0]>16).sum()+(cell[-1]>16).sum()),'sourceSHA256':r['sha256'],'sourcePNGModified':False})
out.write_text(json.dumps({'entries':list(by.values())},ensure_ascii=False,indent=2)+'\n');(N/'reuse-private/P48_FOUR_SINGLE_POSE_SELECTION_REVIEW_PRIVATE_V1.json').write_text(json.dumps({'reviews':reviews,'newDrawings':0,'newAnimations':0},indent=2)+'\n');print(json.dumps(reviews))
