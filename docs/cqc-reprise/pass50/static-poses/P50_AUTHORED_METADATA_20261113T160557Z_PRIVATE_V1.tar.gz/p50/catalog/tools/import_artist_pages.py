#!/usr/bin/env python3
"""Import preferred static artist cells, selecting independently per UID/costume."""
import argparse,datetime,hashlib,json,pathlib,re
from types import SimpleNamespace
from register_source_page import register,read_exact_noatime,normalized_cells
ROOT=pathlib.Path('/tmp/cqc-static-20261113');CAT=ROOT/'p50/catalog'
LABELS={'retro':'Rétro','cyborg':'Châssis cybernétique','survive':'Dité','metalgear':'Metal Gear','tuxedo':'Tenue de soirée','zombie':'Zombie','furry':'Furry','nextgen':'Nouvelle génération'}
def load(p):return json.loads(read_exact_noatime(pathlib.Path(p))[0])
def version(p,d):
 if isinstance(d.get('version'),int):return d['version']
 m=re.search(r'_V(\d+)',pathlib.Path(p).name);return int(m.group(1))if m else 1
def cell(c):
 rect=c.get('frameRect')or(c.get('frame')or{}).get('rect')
 if isinstance(rect,dict):r=[rect[k]for k in ['x','y','width','height']]
 else:r=rect
 if not r or len(r)!=4:raise ValueError('Missing exact frame rectangle')
 x,y,w,h=r;pivot=c.get('pivot')or(c.get('frame')or{}).get('pivot');fp=c.get('footprint')
 if isinstance(fp,dict)and 'x'in fp and 'y'in fp:point=fp
 elif pivot:point={'x':x+pivot[0]*w,'y':y+pivot[1]*h}
 elif isinstance(fp,dict)and 'centerX'in fp and 'floorY'in fp:point={'x':x+fp['centerX'],'y':y+fp['floorY']}
 else:point=None
 outfit=c.get('outfit')or c.get('costumeId')or c.get('id')or c.get('family');facing=c.get('facing','right');assert facing in ['right',1]
 return {'slot':c.get('slot',c.get('index',0)),'outfit':outfit,'label':c.get('label',LABELS.get(outfit,outfit)),'facing':'right','frameRect':dict(zip(['x','y','width','height'],r)),'footprint':point}
def candidate(uid,source,sha,width,height,cols,rows,cells,ver,doc):
 cells=[c for c in cells if c.get('frameRect')or(c.get('frame')or{}).get('rect')]
 if not cells:return None
 p=pathlib.Path(source).absolute();assert p.is_relative_to(ROOT/'artists')and p.resolve(strict=True)==p
 raw,_=read_exact_noatime(p);assert hashlib.sha256(raw).hexdigest()==sha
 return {'uid':uid,'source':str(p),'sha256':sha,'width':width,'height':height,'columns':cols,'rows':rows,'cells':[cell(c)for c in cells],'version':ver,'metadataDocument':str(doc)}
def main():
 a=argparse.ArgumentParser();a.add_argument('--artists-root',default=str(ROOT/'artists'));a.add_argument('--output-index',default=str(CAT/'ACTIVE_ARTIST_REGISTRATIONS_PRIVATE_V1.json'));args=a.parse_args();artistroot=pathlib.Path(args.artists_root).absolute();assert artistroot.is_relative_to(ROOT/'artists')
 candidates={};documents=[];officialextras={};matrix=load(ROOT/'inventory/STATIC_ALL381_CATALOG_COMPACT_PUBLIC_V1.json');identities={r['uid']:r for r in matrix['rows']if r['family']=='original'}
 additionsPath=CAT/'P50_ADDITIONAL_DISTINCT_INCARNATIONS_PRIVATE_V1.json';additions=load(additionsPath)['entries']if additionsPath.exists()else[]
 for identity in additions:
  assert identity['uid']not in identities and identity.get('rootAuthorizedIdentitySplit')and identity['costumeID']=='original'
  identities[identity['uid']]=identity
 def add(c):
  if c is None:return
  key=(c['uid'],c['sha256']);old=candidates.get(key)
  if old:
   # The explicit source-slots/geometry file is more precise than its raw receipt.
   if 'STATIC'in pathlib.Path(c['metadataDocument']).name:candidates[key]=c
  else:candidates[key]=c
 for p in sorted(artistroot.rglob('*.json')):
  if not any(x in p.name for x in ['SOURCE_SLOTS','RAW_V','STATIC_GEOMETRY_PREFERRED','STATIC_SOLO_CORRECTION_GEOMETRY_PREFERRED','SOURCE_CATALOG_PUBLIC','RECEIPT','ARTIFACT_PROPOSAL']):continue
  d=load(p);documents.append(str(p));c=None
  if not isinstance(d,dict):continue  # Reference-copy receipts are lists, never source pages.
  if d.get('alphaExportIssue')or isinstance(d.get('visualReview'),dict)and d['visualReview'].get('alphaExportIssue'):continue  # Invalid intermediate kept in raw history only.
  if isinstance(d.get('image'),dict)and isinstance(d.get('slots'),list):
   i=d['image'];layout=d.get('layout',{});c=candidate(d['uid'],i['path'],i['sha256'],i['width'],i['height'],layout.get('columns',min(3,len(d['slots']))),layout.get('rows',1),d['slots'],version(p,d),p)
  elif d.get('sourceCanonicalPath')and isinstance(d.get('slots'),list):
   c=candidate(d['uid'],d['sourceCanonicalPath'],d['sourceSHA256'],d['width'],d['height'],d.get('cols',d.get('columns',3)),d['rows'],d['slots'],d.get('preferredRawVersion',1),p)
  elif isinstance(d.get('source'),dict)and d['source'].get('canonicalPath')and isinstance(d.get('slots'),list):
   i=d['source'];c=candidate(d['uid'],i['canonicalPath'],i['sha256'],i['width'],i['height'],i.get('cols',i.get('columns',1)),i['rows'],d['slots'],version(p,d),p)
  elif (d.get('source')or d.get('canonicalPath'))and d.get('sha256')and isinstance(d.get('slots',d.get('cells')),list):
   source=d.get('canonicalPath')or d.get('source');c=candidate(d['uid'],source,d['sha256'],d['width'],d['height'],d.get('cols',d.get('columns',3)),d['rows'],d.get('slots',d.get('cells')),version(p,d),p)
  elif d.get('rawPNG')and isinstance(d.get('slots'),list)and 'official'in d.get('schema',''):
   page=d['rawPNG'];layout=d.get('atlas',{});cells=[];uid=d['uid']
   for i,e in enumerate(d['slots']):
    outfit=e.get('costumeID',e.get('costumeId',e.get('id')));rect=e.get('sourceRect',e.get('rect'));assert outfit and rect
    x,y,w,h=rect;cells.append({'slot':i,'outfit':outfit,'label':e['label'],'facing':e.get('facing','right'),'frameRect':dict(zip(['x','y','width','height'],rect)),'footprint':{'x':e.get('bodyDatumX',x+w/2),'y':e.get('footDatumY',y+h)}})
    if e.get('classification','').startswith('official-'):
     identity=identities[uid];refs=[{'url':r.get('URL',r.get('url'))}for r in d.get('referenceSources',[])if r.get('viewed')and r.get('URL',r.get('url'))]
     officialextras[(uid,outfit)]={'uid':uid,'character':identity['name'],'era':identity['incarnation'],'incarnation':identity['incarnation'],'costumeId':outfit,'costume':e['label'],'family':'canonical','origin':'official','status':'review','facing':'right','references':refs,'note':'Tenue officielle dessinée ; revue statique finale en attente. '+str(d.get('visualReview',{}).get('limits',''))}
   c=candidate(uid,page['path'],page['sha256'],page['width'],page['height'],layout.get('columns',min(3,len(cells))),layout.get('rows',1),cells,version(p,d),p)
  elif d.get('pages')and d.get('entries')and 'official'in d.get('schema',''):
   for page in d['pages']:
    entries=[e for e in d['entries']if e['page']==page['id']]
    if not entries:continue  # Preserved superseded page: no active costume points here.
    uids={e['uid']for e in entries};assert len(uids)==1;uid=next(iter(uids));cells=[]
    for i,e in enumerate(entries):
     x,y,w,h=e['rect'];cells.append({'slot':i,'outfit':e['id'],'label':e['label'],'facing':e['facing'],'frameRect':dict(zip(['x','y','width','height'],e['rect'])),'footprint':{'x':e['bodyDatumX'],'y':e['footDatumY']}})
     if e['classification'].startswith('official-'):
      identity=identities[uid];officialextras[(uid,e['id'])]={'uid':uid,'character':identity['name'],'era':identity['incarnation'],'incarnation':identity['incarnation'],'costumeId':e['id'],'costume':e['label'],'family':'canonical','origin':'official','status':'review','facing':'right','references':[{'url':e['referenceURL']}]if e.get('referenceURL')else[],'note':'Tenue officielle dessinée ; revue statique finale en attente.'}
    add(candidate(uid,page.get('localPath')or p.parent/page['file'],page['sha256'],page['width'],page['height'],page['columns'],page['rows'],cells,1,p))
  if c:add(c)
 chosen={}
 for c in candidates.values():
  for s in c['cells']:
   key=(c['uid'],s['outfit']);rank=(c['version'],'STATIC'in pathlib.Path(c['metadataDocument']).name,c['metadataDocument'])
   if key not in chosen or rank>chosen[key][0]:chosen[key]=(rank,c,s)
 for identity in additions:
  key=(identity['uid'],'original');assert key in chosen,'Additional incarnation Source not ready: '+identity['uid']
  _,page,slot=chosen[key];assert page['sha256']==identity['requiredSourceSHA256']
  officialextras[key]={'uid':identity['uid'],'character':identity['name'],'era':identity['era'],'incarnation':identity['incarnation'],'costumeId':'original','costume':"Tenue d’origine — assaut de l’hôpital",'family':'original','origin':'original','status':'review','facing':'right','references':[{'url':r.get('URL',r.get('url'))}for r in load(pathlib.Path(page['metadataDocument'])).get('referenceSources',[])if r.get('viewed')and r.get('URL',r.get('url'))],'additionalDistinctIncarnation':True,'relatedHistoricalID':identity['relatedHistoricalID'],'note':"Incarnation distincte de1984. L’Original XOF de Ground Zeroes1975 reste séparé ; cette pose ne constitue pas un costume de1975 ni une clôture de son ancien libellé erroné."}
 groups={}
 for _,c,s in chosen.values():groups.setdefault((c['uid'],c['sha256']),{'candidate':c,'cells':[]})['cells'].append(s)
 index=[];pages=[];metadataRoot=CAT/'import-metadata';metadataRoot.mkdir(exist_ok=True)
 for (uid,sha),group in sorted(groups.items()):
  c=group['candidate'];cells=sorted(group['cells'],key=lambda x:x['slot']);meta={'columns':c['columns'],'rows':c['rows'],'cells':cells};normalized=normalized_cells(meta,c['width'],c['height'],uid);metaraw=(json.dumps(meta,ensure_ascii=False,indent=2)+'\n').encode();metasha=hashlib.sha256(metaraw).hexdigest();metapath=metadataRoot/f'{uid}-{sha[:12]}-{metasha}.json'
  if metapath.exists():assert read_exact_noatime(metapath)[0]==metaraw
  else:
   with metapath.open('xb')as handle:handle.write(metaraw)
  pageNo=c['version'];name=f'{uid}--planned--p{pageNo:03d}-{sha[:12]}';receipt=CAT/'receipts/generation'/(name+'.registration.json')
  if receipt.exists():
   reg=load(receipt);assert reg.get('stage')=='source_png_registered'and reg.get('exactCanonicalReadback')and reg['source']['sha256']==sha
  else:reg=register(SimpleNamespace(uid=uid,outfit='planned',page_no=pageNo,source=c['source'],catalog_root=str(CAT),metadata_json=str(metapath)))
  index.append({'receipt':str(receipt),'selectedCostumes':[s['outfit']for s in cells],'cellsOverride':normalized,'activeMetadataPin':{'path':str(metapath),'sha256':metasha,'bytes':len(metaraw),'immutableHashAddressed':True}})
  pages.append({'uid':uid,'sha256':sha,'source':c['source'],'version':c['version'],'activeCostumes':[s['outfit']for s in cells],'rawPreserved':True,'metadataDocument':c['metadataDocument']})
 result={'schema':'cqc.static.active-registration-index/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'preferenceRule':'Choose independently per(uid,costume): highest source version; geometry preferred only for the same sourceSHA. Single-MG V2 replaces only MG, full-atlas Amanda/Chris V2 replaces its matching outfits. No Root art approval inferred.','registrations':index,'pages':pages,'activePoseCandidates':len(chosen),'SourcePNGsModified':False,'sourceDocuments':documents}
 out=pathlib.Path(args.output_index).absolute();assert out.is_relative_to(ROOT);out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');extras=CAT/'OFFICIAL_EXTRA_ENTRIES_PUBLIC_V1.json';extras.write_text(json.dumps({'entries':list(officialextras.values())},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'index':str(out),'activePages':len(pages),'activePoseCandidates':len(chosen),'officialExtras':len(officialextras),'extras':str(extras)}))
if __name__=='__main__':main()
