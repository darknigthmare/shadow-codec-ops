from pathlib import Path
import json, datetime, collections
N = Path('/tmp/cqc-static-20261113'); P = N / 'p50'
m = json.loads((P/'catalog/manifest-all381.json').read_text())
old = json.loads((N/'catalog/manifest-all381.json').read_text())
omap = json.loads((P/'official/OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json').read_text())
oldby = {(e['uid'],e['costumeId']):e for e in old['entries']}
present = [e for e in m['entries'] if e.get('source') and e.get('frame',{}).get('rect')]
new = [e for e in present if e['source'].get('kind')=='generated-atlas' and
       e['source'].get('sha256') != oldby.get((e['uid'],e['costumeId']),{}).get('source',{}).get('sha256')]
guards = [e for e in m['entries'] if e.get('generationGuard')]
summary = {
 'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'P50: one static RIGHT pose per remaining official outfit; P49 original and invented costume work retained. No animation or runtime change.',
 'characters':len({e['uid'] for e in m['entries']}),'baselineCharacters':381,'additionalDistinctIncarnations':sum(bool(e.get('additionalDistinctIncarnation'))for e in m['entries']),
 'plannedMatrixRows':3429,
 'newUIDCostumePosesSinceP49':len(new),
 'newDistinctPhysicalPosesSinceP49':len({(e['source']['sha256'],tuple(e['frame']['rect'])) for e in new}),
 'newOfficialPoseEntriesSinceP49':sum(e['family']=='canonical' for e in new),
 'newOriginalCorrectionsSinceP49':sum(e['family']=='original' and (e['uid'],e['costumeId'])in oldby for e in new),
 'additionalOfficialPoseNotInHistorical416':sum(e['costumeId']=='official--virtuous-mission-medical' for e in new),
 'officialHistoricalP50Progress':omap['p50Summary'],
 'officialHistoricalCurrentCounts':omap['counts'],
 'allPoseEntriesPresent':len(present),
 'sameOriginalFamilyAliases':len(m.get('aliasesCoveredByOriginal',[])),
 'notApplicableRows':len(m.get('notApplicableExcluded',[])),
 'sourceKinds':dict(collections.Counter(e['source']['kind'] for e in present)),
 'guardedEntries':[{k:e.get(k) for k in ('uid','costumeId','family','generationGuard')} for e in guards],
 'officialRemainingWithoutSource':[{k:r.get(k) for k in ('historicalID','historicalCostumeName','historicalUID','resolutionReason')} for r in omap['rows'] if r['resolutionState']=='REFERENCE_AND_STATIC_SOURCE_PENDING'],
 'newAnimations':0,'runtimeFilesModified':0,'manualVercelDeployments':0,
 'fidelityCertifiedPixelPerfect':False
}
out=P/'delivery/P50_LIVRAISON_POSES_UNIQUES_PUBLIC_V1.json'
out.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('guardedEntries','officialRemainingWithoutSource','officialHistoricalCurrentCounts','officialHistoricalP50Progress')},ensure_ascii=False))
