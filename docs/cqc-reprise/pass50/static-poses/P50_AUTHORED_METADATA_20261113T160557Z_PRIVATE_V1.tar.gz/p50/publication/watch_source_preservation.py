"""Single-writer preservation of owned static PNG sources; never changes game code."""
import datetime,json,os,pathlib,subprocess,tempfile,time,traceback
N=pathlib.Path('/tmp/cqc-static-20261113');OUT=N/'p50/publication';REPO='darknigthmare/shadow-codec-ops';BRANCH='codex/cqc-p50-official-costumes-20261113'
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
def save(p,d):
 tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(d,indent=2)+'\n');os.replace(tmp,p)
def api(endpoint,payload=None,method='POST'):
 args=['gh','api','repos/'+REPO+'/'+endpoint];tmp=None
 try:
  if payload is not None:
   with tempfile.NamedTemporaryFile(mode='w',suffix='.json',dir=OUT,delete=False)as f:json.dump(payload,f);tmp=f.name
   args+=['--method',method,'--input',tmp]
  r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
  if r.returncode:raise RuntimeError(r.stderr.decode()[:1200])
  return json.loads(r.stdout)
 finally:
  if tmp:os.unlink(tmp)
def run(args):
 r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=600)
 if r.returncode:raise RuntimeError(r.stderr.decode()[-1500:])
 return r.stdout.decode()
lock=OUT/'PRESERVATION_SINGLE_WRITER.lock';fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);os.write(fd,str(os.getpid()).encode());os.close(fd)
lastCommit=time.time();rounds=0
try:
 while True:
  prior=sorted(OUT.glob('SOURCE_COMMIT_*_PRIVATE_V1.json'));known={x['localPath']for p in prior for x in json.loads(read(p))['rows']}
  pending=[p for p in sorted((N/'artists').rglob('*.png'))if '-raw-v'in p.name and 'p50'in p.parts and str(p)not in known and p.stat().st_size>10000 and time.time()-p.stat().st_mtime>8]
  stopping=(OUT/'STOP_PRESERVATION').exists()
  if pending and(len(pending)>=4 or time.time()-lastCommit>25 or stopping):
   chosen=pending[:12];print('P50_ARCHIVE_BATCH',len(chosen),flush=True);run(['python',str(OUT/'archive_static_raws.py'),*[str(p)for p in chosen]])
   d=json.loads(read(OUT/'RAW_CURRENT_TREE_INPUT_PRIVATE_V1.json'));assert len(d['rows'])==len(chosen)and d['allWholeBinaryReadbacksExact']
   head=json.loads(read(OUT/'CURRENT_HEAD_PRIVATE_V1.json'));remote=api('git/ref/heads/'+BRANCH);assert remote['object']['sha']==head['commit'],'Branch changed externally; stopping without overwrite'
   tree=api('git/trees',{'base_tree':head['tree'],'tree':[{k:r[k]for k in ['path','mode','type','sha']}for r in d['rows']]})
   commit=api('git/commits',{'message':'art(cqc): P50 preserve '+str(len(chosen))+' static costume source pages [skip ci]\n\nOne pose per intended costume. Exact source pixels and superseded outputs retained. Art review/framing remain separate; no gameplay or animation change.','tree':tree['sha'],'parents':[head['commit']]})
   again=api('git/ref/heads/'+BRANCH);assert again['object']['sha']==head['commit'],'Branch lease changed'
   api('git/refs/heads/'+BRANCH,{'sha':commit['sha'],'force':False},method='PATCH')
   number=len(prior)+1;p=OUT/('SOURCE_COMMIT_'+str(number).zfill(3)+'_PRIVATE_V1.json');r={'schema':'cqc.static-pose.source-git-commit/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':commit['sha'],'tree':tree['sha'],'parent':head['commit'],'branch':BRANCH,'rawPNGCount':len(chosen),'rows':d['rows'],'rawBytesVerified':True,'sourceReviewAndPoseAdmissionsSeparate':True,'gameplayChanged':False};save(p,r);save(OUT/'CURRENT_HEAD_PRIVATE_V1.json',{'commit':commit['sha'],'tree':tree['sha']});lastCommit=time.time();print('COMMITTED',number,commit['sha'],len(chosen),flush=True)
  for p in sorted(OUT.glob('SOURCE_COMMIT_*_PRIVATE_V1.json'))[-4:]:
   result=run(['python',str(OUT/'retire_committed_generator_duplicates.py'),str(p)]);summary=json.loads(result.strip());
   if summary.get('retiredOnlyCommittedDuplicateCount'):print('DUPLICATES_RETIRED',summary['retiredOnlyCommittedDuplicateCount'],flush=True)
  rounds+=1
  save(OUT/'WATCH_STATUS_PRIVATE_V1.json',{'round':rounds,'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pendingRawPages':len(pending),'committedRawPages':len(known),'currentHead':json.loads(read(OUT/'CURRENT_HEAD_PRIVATE_V1.json')),'stopping':stopping,'gameplayChanged':False})
  if stopping and not pending:break
  time.sleep(10)
except Exception as e:
 save(OUT/'WATCH_ERROR_PRIVATE_V1.json',{'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'error':str(e),'trace':traceback.format_exc()[-3000:],'noForceOrResetAttempted':True});print('PRESERVATION_STOPPED_ERROR',str(e),flush=True);raise
finally:
 lock.unlink(missing_ok=True)
