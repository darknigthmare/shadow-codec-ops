#!/usr/bin/env python3
"""Exact historical metadata-pin resolution; never changes receipts or catalog/history.
Adapted from P49 catalog/tools/resolve_historical_metadata_pins.py. New exact recovered
history files, if needed, live ONLY in p50/publication/metadata-pin-history/.
"""
import argparse,collections,os,re,stat
from pathlib import Path
from p50_verification_common import N,P,PUB,now,sha,exact,load,file_pin,publish,changed
import json
CELL_FIELDS=('slot','outfit','label','facing','frameRect','footprint')
def canonical_bytes(receipt):return (json.dumps({'columns':receipt['columns'],'rows':receipt['rows'],'cells':[{k:c[k]for k in CELL_FIELDS}for c in receipt['cells']]},ensure_ascii=False,indent=2)+'\n').encode()
def preserve_publication_history(raw,wanted):
 d=PUB/'metadata-pin-history';d.mkdir(exist_ok=True);p=d/(wanted+'.json')
 if p.exists():assert exact(p)==raw,'Immutable publication-history collision'
 else:
  with os.fdopen(os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o444),'wb')as f:f.write(raw)
 assert not stat.S_IMODE(os.stat(p).st_mode)&0o222;assert exact(p)==raw;return p

def run(mode='provisional'):
 start=now();activePath=P/'ACTIVE_ARTIST_REGISTRATIONS_PRIVATE_V1.json';activeRaw=exact(activePath);active=json.loads(activeRaw);activePin=dict(path=str(activePath),sha256=sha(activeRaw),bytes=len(activeRaw));activeReceipts={Path(r['receipt']).name for r in active['registrations']};receiptPaths=sorted((P/'receipts/generation').glob('*.registration.json'));pins=[];unresolved=[];created=0;activeResults=[];drifts=0;reconstructedCount=0
 for path in receiptPaths:
  raw=exact(path);r=json.loads(raw);pin=r.get('metadataPin',{});entry=dict(receiptPath=str(path),receiptSHA256=sha(raw),uid=r.get('uid'),pageId=r.get('pageId'),activeAtSnapshot=path.name in activeReceipts,historicalMetadataPin=pin)
  try:
   expected=pin['sha256'];assert re.fullmatch('[0-9a-f]{64}',expected);rec=canonical_bytes(r);assert sha(rec)==expected and len(rec)==pin['bytes'],'Exact six-field reconstruction mismatch';reconstructedCount+=1
   candidatePaths=[P/'import-metadata/history'/(expected+'.json'),N/'catalog/import-metadata/history'/(expected+'.json'),PUB/'metadata-pin-history'/(expected+'.json')]
   # A current mutable canonical path is an observation, never the historical authority.
   try:
    current=exact(Path(pin['path']));match=sha(current)==expected and len(current)==pin['bytes'];entry['currentPinnedPathReadback']=dict(path=pin['path'],sha256=sha(current),bytes=len(current),matchesHistoricalPin=match)
   except FileNotFoundError:match=False;entry['currentPinnedPathReadback']=dict(path=pin['path'],missing=True,matchesHistoricalPin=False)
   if not match:drifts+=1
   resolved=None
   for cp in candidatePaths:
    if cp.is_file():
     v=exact(cp)
     if sha(v)==expected and len(v)==pin['bytes']and not stat.S_IMODE(os.stat(cp).st_mode)&0o222:resolved=cp;break
   if resolved is None:resolved=preserve_publication_history(rec,expected);created+=1
   v=exact(resolved);assert v==rec;entry['resolvedMetadata']=dict(path=str(resolved),sha256=sha(v),bytes=len(v),modeOctal=oct(stat.S_IMODE(os.stat(resolved).st_mode)),exactHistoricalBytes=True);entry['resolutionMethod']='EXACT_RECEIPT_RECONSTRUCTION_AND_IMMUTABLE_PHYSICAL_READBACK';pins.append(entry)
  except Exception as e:unresolved.append(dict(entry,reason=type(e).__name__+': '+str(e)))
 for r in active['registrations']:
  pin=r.get('activeMetadataPin',{});item=dict(receipt=r['receipt'],activeMetadataPin=pin)
  try:
   b=exact(Path(pin['path']));assert sha(b)==pin['sha256']and len(b)==pin['bytes'];assert pin['sha256']in Path(pin['path']).name;item['exact']=True
  except Exception as e:item.update(exact=False,reason=type(e).__name__+': '+str(e))
  activeResults.append(item)
 receiptsUnchanged=all(sha(exact(Path(r['receiptPath'])))==r['receiptSHA256']for r in pins+unresolved);stable=receiptsUnchanged and not changed(activePin)and [p.name for p in sorted((P/'receipts/generation').glob('*.registration.json'))]==[p.name for p in receiptPaths]
 errors=len(unresolved)+sum(not r['exact']for r in activeResults)
 report=dict(schema='cqc.p50.historical-metadata-pin-resolution/1',mode=mode,startedAtUTC=start,finishedAtUTC=now(),status=('FAIL'if errors else('PASS_PROVISIONAL'if mode=='provisional'else'PASS_FINAL'))if stable else'LIVE_INPUTS_CHANGED_RERUN_REQUIRED',inputSnapshotStable=stable,activeRegistrationSnapshot=activePin,summary=dict(historicalReceipts=len(receiptPaths),historicalPinsExactlyReconstructed=reconstructedCount,historicalPinsExactlyResolved=len(pins),activeReceipts=len(activeResults),activeImmutablePinsExact=sum(r['exact']for r in activeResults),currentCanonicalPinPathsDriftedOrMissing=drifts,immutablePublicationHistoryCopiesCreated=created,unresolvedPins=len(unresolved),activePinErrors=sum(not r['exact']for r in activeResults),historicalReceiptsUnchanged=receiptsUnchanged),entries=pins,unresolved=unresolved,activePinChecks=activeResults,errorCount=errors,catalogReceiptsAndMetadataWritten=False,PNGReadOrModified=False,importerMapperBuildOrGitModified=False,historyResolutionOutputRoot=str(PUB/'metadata-pin-history'),limitations='Canonical paths may point to P49 or P50 and may drift; only receipt-expected SHA256+byte length and immutable reconstructed readback resolve historical pin. Provisional snapshot requires Root freeze rerun.')
 target=PUB/('P50_METADATA_PIN_RESOLUTION_'+mode.upper()+'_PRIVATE_V1.json');receipt=publish(target,report);print(json.dumps(dict(receipt,summary=report['summary'],status=report['status'])));return report
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=['provisional','final'],default='provisional');args=parser.parse_args();result=run(args.mode);raise SystemExit(bool(result['errorCount']))
