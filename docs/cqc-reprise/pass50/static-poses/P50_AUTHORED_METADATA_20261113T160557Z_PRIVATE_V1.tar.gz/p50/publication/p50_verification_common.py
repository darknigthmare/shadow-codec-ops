"""Read-only P50 verification primitives, adapted from P49; reports live in publication only."""
import os,stat,json,hashlib,datetime,struct,zlib
from pathlib import Path
N=Path('/tmp/cqc-static-20261113');P=N/'p50/catalog';PUB=N/'p50/publication';APP=Path('/workspace/cqc-pass21-application/public/cqc')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def exact(path):
 path=Path(path)
 with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:
  a=os.fstat(f.fileno());assert stat.S_ISREG(a.st_mode),str(path);b=f.read();z=os.fstat(f.fileno())
 q=os.lstat(path)
 fields=('st_dev','st_ino','st_size','st_mtime_ns','st_atime_ns')
 if any(getattr(a,k)!=getattr(z,k)or getattr(z,k)!=getattr(q,k)for k in fields)or len(b)!=a.st_size:raise RuntimeError('Input changed during exact no-atime read: '+str(path))
 return b
def load(path):return json.loads(exact(path))
def file_pin(path):
 b=exact(path);return dict(path=str(path),sha256=sha(b),bytes=len(b))
def publish(path,obj):
 path=Path(path);assert path.is_relative_to(PUB),path
 raw=(json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode();tmp=path.with_name('.'+path.name+'.tmp');tmp.write_bytes(raw);os.replace(tmp,path)
 assert exact(path)==raw;return dict(path=str(path),bytes=len(raw),sha256=sha(raw))
def changed(pin):
 try:return file_pin(Path(pin['path']))['sha256']!=pin['sha256']
 except (FileNotFoundError,RuntimeError):return True
def source_path(s):
 src=s['src']
 if src.startswith('/native/'):q=APP/src[len('/native/'):]
 elif src.startswith('/captures/'):q=N/'artists/e/composites'/src[len('/captures/'):]
 elif Path(src).is_absolute():q=Path(src)
 else:q=P/src
 if not(q.is_relative_to(N)or q.is_relative_to(APP)):raise ValueError('Source outside known roots: '+str(q))
 if q.resolve(strict=True)!=q:raise ValueError('Symlink source path: '+str(q))
 return q

# P49 png_structure verbatim, sourceSHA256 92293e43f37ba143c0a5efd4cb4cadda0f5205780798f01925ae1732b626b72c
def png_structure(raw: bytes) -> dict:
    if raw[:8] != b'\x89PNG\r\n\x1a\n':
        raise ValueError('Not a PNG signature')
    at, chunks, header, idats, ended, last_type = 8, [], None, 0, False, None
    palette = False
    while at < len(raw):
        if len(raw) - at < 12:
            raise ValueError('Truncated PNG chunk')
        length = int.from_bytes(raw[at:at + 4], 'big')
        kind = raw[at + 4:at + 8]
        end = at + 12 + length
        if not all(65 <= c <= 90 or 97 <= c <= 122 for c in kind) or end > len(raw):
            raise ValueError('Invalid PNG chunk boundary/type')
        payload = raw[at + 8:at + 8 + length]
        crc = int.from_bytes(raw[at + 8 + length:end], 'big')
        if zlib.crc32(kind + payload) & 0xffffffff != crc:
            raise ValueError('PNG chunk CRC mismatch')
        name = kind.decode('ascii')
        if kind in (b'acTL', b'fcTL', b'fdAT'):
            raise ValueError('Animated PNG chunks are outside this static-pose pass')
        if not chunks and kind != b'IHDR':
            raise ValueError('IHDR must be first')
        if kind == b'IHDR':
            if header is not None or length != 13:
                raise ValueError('Invalid or duplicate IHDR')
            width, height, depth, color, compression, filtering, interlace = struct.unpack('>IIBBBBB', payload)
            valid_depths = {0: {1, 2, 4, 8, 16}, 2: {8, 16}, 3: {1, 2, 4, 8}, 4: {8, 16}, 6: {8, 16}}
            if (not 1 <= width <= 16384 or not 1 <= height <= 16384 or width * height > 32 * 1024 * 1024
                    or depth not in valid_depths.get(color, set()) or compression != 0
                    or filtering != 0 or interlace not in (0, 1)):
                raise ValueError('Unsupported or invalid PNG header')
            header = {'width': width, 'height': height, 'bitDepth': depth, 'colorType': color,
                      'interlace': interlace, 'alphaChannelDeclared': color in (4, 6)}
        elif kind == b'PLTE':
            if palette or idats or not length or length % 3 or length > 768:
                raise ValueError('Invalid PNG palette')
            palette = True
        elif kind == b'IDAT':
            if idats and last_type != b'IDAT':
                raise ValueError('IDAT chunks must be contiguous')
            idats += 1
        elif kind == b'IEND':
            if length != 0 or not idats or end != len(raw):
                raise ValueError('Invalid IEND or trailing bytes')
            ended = True
        elif not kind[0] & 32:
            raise ValueError('Unknown critical PNG chunk')
        chunks.append({'type': name, 'bytes': length})
        if len(chunks) > 10000:
            raise ValueError('Too many PNG chunks')
        at, last_type = end, kind
        if ended:
            break
    if not ended or header is None or (header['colorType'] == 3 and not palette):
        raise ValueError('Incomplete PNG structure')
    return dict(header, chunks=chunks, chunkCRCsVerified=True, rasterDecoded=False,
                transparencyPixelsVerified=False, rasterModified=False)
