"""Pin Root-selected exact portable binaries only. Never creates commits or refs."""
import concurrent.futures
import datetime
import hashlib
import json
import pathlib
from git_blob_store import N, PUB, read, pin_file, known_blobs

P = N / 'p50'
PREFIX = 'docs/cqc-reprise/pass50/static-poses'

def load(path):
    return json.loads(read(path))

def prepare(kind, workers=4):
    assert kind in ('catalogue', 'references') and 1 <= workers <= 4
    if kind == 'catalogue':
        source_index = PUB / 'PORTABLE_STATIC_CATALOG_SOURCE_INDEX_PRIVATE_V1.json'
        root = P / 'delivery/catalogue'
        output = PUB / 'PORTABLE_ALL_SOURCE_BLOB_PIN_INDEX_PRIVATE_V1.json'
        key = 'records'
    else:
        source_index = PUB / 'VIEWED_REFERENCE_IMAGE_SOURCE_INDEX_PRIVATE_V1.json'
        root = P / 'delivery'
        output = PUB / 'VIEWED_REFERENCE_BINARY_GIT_PIN_INDEX_PRIVATE_V1.json'
        key = 'rows'
    index_bytes = read(source_index)
    data = json.loads(index_bytes)
    if kind == 'references':
        assert data.get('wholeBooksVideosPackagesExported') is False
        assert data.get('guardedScreeningsExported') is False
    records = data['records']
    assert len({r['portablePath'] for r in records}) == len(records)
    known = known_blobs()

    def one(record):
        rel = pathlib.PurePosixPath(record['portablePath'])
        assert not rel.is_absolute() and '..' not in rel.parts
        if kind == 'catalogue':
            assert rel.parts[0] == 'assets' and rel.suffix == '.png'
        else:
            assert rel.parts[0] == 'reference-images' and rel.suffix.lower() in ('.png', '.jpg', '.jpeg', '.webp')
        path = root / rel
        proof = pin_file(path, known)
        assert proof['sha256'] == record['sha256']
        assert proof['gitBlobOID'] == record['gitBlobOID']
        assert proof['bytes'] == record['bytes']
        target = PREFIX + ('/catalogue/' if kind == 'catalogue' else '/') + rel.as_posix()
        return dict(record, gitPath=target, gitObjectVerified=True,
                    uploadedNow=proof['uploadedNow'], proof=proof['proof'])

    rows = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        for row in pool.map(one, records):
            rows.append(row)
            if len(rows) % 100 == 0:
                print('PINNED', kind, len(rows), len(records), flush=True)
    assert read(source_index) == index_bytes, 'Selected source index changed; rerun preparation.'
    report = {
        'schema': 'cqc.p50.selected-exact-git-blobs/1',
        'atUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'kind': kind, 'sourceIndex': str(source_index),
        'sourceIndexSHA256': hashlib.sha256(index_bytes).hexdigest(),
        'allObjectsPinned': True, 'allPinned': True,
        'branchReferenceMoved': False, 'commitsCreated': 0,
        'objects': len(rows), 'bytes': sum(r['bytes'] for r in rows),
        'uploadedNow': sum(bool(r['uploadedNow']) for r in rows),
        'reusedImmutableObjects': sum(not r['uploadedNow'] for r in rows),
        'maxWorkers': workers, key: rows,
    }
    temporary = output.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(output)
    print(json.dumps({k:v for k,v in report.items() if k != key}), flush=True)
    return report
