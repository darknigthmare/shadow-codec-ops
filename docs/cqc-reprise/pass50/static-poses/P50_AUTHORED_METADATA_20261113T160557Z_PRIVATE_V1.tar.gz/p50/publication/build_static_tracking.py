#!/usr/bin/env python3
"""Append isolated static-source sheets, preserving all original sheet XML bytes."""
import pathlib,json,csv,io,hashlib,zipfile,os,datetime,collections,copy,xml.etree.ElementTree as ET
N=pathlib.Path('/tmp/cqc-static-20261113');OUT=N/'p50/delivery';OUT.mkdir(exist_ok=True)
BASE=N/'delivery/CQC_SUIVI_P49_POSES_UNIQUES_20261113_PUBLIC_V1.xlsx';MAN=N/'p50/catalog/manifest-all381.json';m=json.loads(MAN.read_text());official=json.loads((N/'official/OFFICIAL_COSTUMES_416_CURRENT_RECONCILIATION_PRIVATE_V1.json').read_text());by={(e['uid'],e['costumeId']):e for e in m['entries']}
HEAD=['UID','Personnage','Incarnation','Famille','ID tenue','Tenue','Origine','État revue statique','Pose présente','Source','SHA256 PNG','URL immuable','Cadre source','Appui normalisé','Nouvelle animation','Admission jeu par cette passe','Réserve']
def one(e):
 s=e.get('source')or{};f=e.get('frame')or{};present=bool(s and f.get('rect'));status={'drawn':'Dessin relu / source existante vérifiée','review':'Dessin à relire'if present else'Source ou référence à rapprocher','missing':'Pose à dessiner'}.get(e['status'],e['status']);art=e.get('artReview')or{}
 if art.get('status')=='held' or e.get('generationGuard'):status='Refus outil — dessin conservé'if present else'Refus outil — pose non produite'
 if(e.get('generationGuard')or{}).get('kind')=='content-guard-no-generation':status='Protection de contenu — aucune génération'
 return[e['uid'],e['character'],e['incarnation'],e['family'],e['costumeId'],e['costume'],e['origin'],status,'Oui'if present else'Non',s.get('kind',''),s.get('sha256',''),s.get('immutableURL',''),json.dumps(f.get('rect',[])),json.dumps(f.get('pivot',[])),'Non','Non',e.get('note','')]
rows=[HEAD]+[one(e)for e in m['entries']]
matrix=json.loads((N/'inventory/STATIC_ALL381_CATALOG_COMPACT_PUBLIC_V1.json').read_text());matrixBy={(r['uid'],r['family']):r for r in matrix['rows']}
for alias in m.get('aliasesCoveredByOriginal',[]):
 orig=by[(alias['uid'],'original')];r=matrixBy[(alias['uid'],alias['family'])];e=dict(orig,costumeId=r['id'],family=alias['family'],costume=r.get('label',alias['family']),note='Famille déjà couverte par le dessin Original de cette même incarnation : pas de doublon à générer.');line=one(e);line[7]='Couvert par l’Original';rows.append(line)
for r in m.get('notApplicableExcluded',[]):
 source=matrixBy[(r['uid'],r['family'])];rows.append([r['uid'],source['name'],source['incarnation'],r['family'],source['id'],source.get('label',r['family']),'invented','Non applicable au corps Original','Non','','','','','','Non','Non','Famille non applicable explicitement dans l’inventaire ; ne compte pas comme sprite manquant.'])
assert len(rows)-1==len(matrix['rows'])+sum(bool(e['family']=='canonical'or e.get('additionalDistinctIncarnation'))for e in m['entries'])
offhead=['UID','Personnage','Jeu','ID historique','Libellé historique','ID actuel','Rapprochement actuel','Pose présente','SHA256 PNG','Références','Réserve'];offrows=[offhead]
mapPath=N/'p50/official/OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json';mapping={r['historicalID']:r for r in json.loads(mapPath.read_text())['rows']}if mapPath.exists()else{}
for r in official['rows']:
 mp=mapping.get(r.get('historicalID'),{});targetId=mp.get('targetCostumeID')or r['id'];e=by.get((r['uid'],targetId));state=mp.get('resolutionState','REFERENCE_AND_STATIC_SOURCE_PENDING');reason=mp.get('resolutionReason','');source=e.get('source',{})if e else{};present=bool(source)
 labels={'REFERENCE_AND_STATIC_SOURCE_PENDING':'Référence complète / pose à établir','EXISTING_NATIVE_OFFICIAL_OPTION_REUSE':'Dessin officiel existant réutilisé','NEW_STATIC_SOURCE_POSE_DRAWN_ROOT_REVIEW_PENDING':'Nouveau dessin officiel — revue à consulter','POSSIBLE_ORIGINAL_EQUIVALENCE_VISUAL_REVIEW_PENDING':'Équivalence Original à vérifier','BODY_FORM_CHANGE_SCOPE_REVIEW_PENDING':'Forme distincte à cadrer'}
 labels.update({'P50_NEW_STATIC_SOURCE_POSE_DRAWN_REVIEW_PENDING':'Nouveau dessin P50 — revue à consulter','P50_CORRECTED_ORIGINAL_SOURCE_POSE_DRAWN':'Original corrigé P50 — forme officielle réutilisée','P50_EXISTING_SAME_UID_APPEARANCE_REUSED':'Équipement à apparence identique — dessin existant réutilisé','P50_STATIC_SOURCE_CORRECTION_PENDING':'Dessin conservé — correction ciblée en cours','P50_IMAGE_GENERATION_REFUSED':'Refus outil — aucun PNG produit','P50_CONTENT_GUARD_NO_GENERATION':'Protection de contenu — aucune génération'})
 if mp.get('p50RelatedDistinctIncarnation'):labels[state]='Erreur de période — incarnation 1984 distincte créée, aucune fusion avec 1975'
 offrows.append([r['uid'],r.get('name',''),r.get('game',''),r.get('historicalID',r['id']),r['costume'],targetId,labels.get(state,state),'Oui'if present else'Non',source.get('sha256',''),'\n'.join(list(dict.fromkeys(r.get('referenceURLs',[])+[q.get('URL',q.get('url'))for q in mp.get('p50Evidence',{}).get('referenceSources',[])if q.get('URL',q.get('url'))]))),reason+' '+r.get('historicalLimits','')])
summary=[['Champ','Valeur'],['Passe','P50 — suite des tenues officielles — une pose par costume'],['Incarnations',len({e['uid']for e in m['entries']})],['Nouvelles animations','Aucune'],['Admission dans le jeu','Aucune modification de cette passe'],['Qualification','Présence de dessin, revue visuelle, animation et admission jeu sont distinctes. Un dessin en revue est conservé sans certification 1:1.'],['Originals','381 Originals de base conservés, plus le XOF distinct de 1984 ; trois corrections ciblées P50 (Seth, Snake ACID et Teliko). Les autres sources sont réutilisées et leurs versions antérieures restent conservées.'],['Incarnations','Aucune fusion entre périodes. Costumes officiels et costumes inventés identifiés.'],['Libellés officiels historiques','Une ligne historique ne prouve pas à elle seule l’existence d’une tenue ; les libellés non attestés restent à documenter.'],['Feuilles historiques','58 feuilles précédentes conservées. Les trois feuilles P50 sont l’état courant ; les feuilles P49 restent des snapshots historiques, sans réécriture.'],['Date UTC',datetime.datetime.now(datetime.timezone.utc).isoformat()]]
for name,rs in [('P50_POSES_STATIQUES',rows),('P50_OFFICIELS',offrows),('P50_MODE_EMPLOI',summary)]:
 p=OUT/(name+'_PUBLIC_V1.csv')
 with open(p,'w',newline='',encoding='utf-8-sig')as f:csv.writer(f).writerows(rs)
S='http://schemas.openxmlformats.org/spreadsheetml/2006/main';R='http://schemas.openxmlformats.org/officeDocument/2006/relationships';P='http://schemas.openxmlformats.org/package/2006/relationships';C='http://schemas.openxmlformats.org/package/2006/content-types'
def col(n):
 out=''
 while n:n,k=divmod(n-1,26);out=chr(65+k)+out
 return out
def sheet(rs):
 root=ET.Element('{'+S+'}worksheet');ET.SubElement(root,'{'+S+'}dimension',{'ref':f'A1:{col(max(map(len,rs)))}{len(rs)}'});views=ET.SubElement(root,'{'+S+'}sheetViews');v=ET.SubElement(views,'{'+S+'}sheetView',{'workbookViewId':'0'});ET.SubElement(v,'{'+S+'}pane',{'ySplit':'1','topLeftCell':'A2','activePane':'bottomLeft','state':'frozen'});data=ET.SubElement(root,'{'+S+'}sheetData')
 for i,values in enumerate(rs,1):
  row=ET.SubElement(data,'{'+S+'}row',{'r':str(i)})
  for j,value in enumerate(values,1):
   c=ET.SubElement(row,'{'+S+'}c',{'r':f'{col(j)}{i}','t':'inlineStr'});iss=ET.SubElement(c,'{'+S+'}is');t=ET.SubElement(iss,'{'+S+'}t');t.text=str(value or'')[:32767]
 ET.SubElement(root,'{'+S+'}autoFilter',{'ref':f'A1:{col(max(map(len,rs)))}{len(rs)}'})
 return ET.tostring(root,encoding='utf-8',xml_declaration=True)
with os.fdopen(os.open(BASE,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:baseraw=f.read()
zin=zipfile.ZipFile(io.BytesIO(baseraw));book=ET.fromstring(zin.read('xl/workbook.xml'));rels=ET.fromstring(zin.read('xl/_rels/workbook.xml.rels'));types=ET.fromstring(zin.read('[Content_Types].xml'));sheets=book.find('{'+S+'}sheets');oldnames=[s.attrib['name']for s in sheets];assert len(oldnames)==58;maxid=max(int(s.attrib['sheetId'])for s in sheets);rids={r.attrib['Id']for r in rels};add={}
for i,(name,rs)in enumerate([('P50_poses_statiques',rows),('P50_officiels',offrows),('P50_mode_emploi',summary)],1):
 sheetid=maxid+i;rid=f'rId{sheetid}'
 while rid in rids:rid+='P49'
 rids.add(rid);xmlpath=f'xl/worksheets/sheet{sheetid}.xml';assert xmlpath not in zin.namelist();ET.SubElement(sheets,'{'+S+'}sheet',{'name':name,'sheetId':str(sheetid),'state':'visible','{'+R+'}id':rid});ET.SubElement(rels,'{'+P+'}Relationship',{'Type':R+'/worksheet','Target':'/'+xmlpath,'Id':rid});ET.SubElement(types,'{'+C+'}Override',{'PartName':'/'+xmlpath,'ContentType':'application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml'});add[xmlpath]=sheet(rs)
changes={'xl/workbook.xml':ET.tostring(book,encoding='utf-8',xml_declaration=True),'xl/_rels/workbook.xml.rels':ET.tostring(rels,encoding='utf-8',xml_declaration=True),'[Content_Types].xml':ET.tostring(types,encoding='utf-8',xml_declaration=True)}
target=OUT/'CQC_SUIVI_P50_POSES_UNIQUES_20261113_PUBLIC_V1.xlsx'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for info in zin.infolist():z.writestr(copy.copy(info),changes.get(info.filename,zin.read(info.filename)))
 for name,raw in add.items():z.writestr(name,raw)
with zipfile.ZipFile(target)as z:
 kept=[info.filename for info in zin.infolist()if info.filename not in changes];assert all(z.read(p)==zin.read(p)for p in kept);assert len(ET.fromstring(z.read('xl/workbook.xml')).find('{'+S+'}sheets'))==61
 import openpyxl
 wb=openpyxl.load_workbook(target,read_only=True,data_only=False);assert wb.sheetnames[:58]==oldnames and wb.worksheets[-3].max_row==len(rows);wb.close()
report={'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceWorkbook':str(BASE),'sourceWorkbookSHA256':hashlib.sha256(baseraw).hexdigest(),'output':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'bytes':target.stat().st_size,'oldSheets':58,'newSheets':3,'oldSheetsAndUnchangedZipMembersPreservedExact':True,'unchangedOriginalZipMembers':len(kept),'changedOriginalParts':list(changes),'staticRows':len(rows)-1,'officialHistoricalRows':len(offrows)-1,'newAnimations':0,'runtimeFilesModified':0}
(OUT/'P50_TRACKING_BUILD_READBACK_PRIVATE_V1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report))
