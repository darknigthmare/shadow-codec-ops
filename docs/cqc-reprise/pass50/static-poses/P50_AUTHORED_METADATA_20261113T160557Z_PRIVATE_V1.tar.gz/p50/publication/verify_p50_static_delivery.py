#!/usr/bin/env python3
"""P50 read-only selected-PNG/container/frame/preservation checks, adapted from P49.
No art, pixel edits, importer/mapper/build/catalog writes, network or Git operations.
Use --mode provisional during active artists, then --mode final after Root freeze.
"""
import argparse,collections,concurrent.futures,hashlib,io,json,math
from pathlib import Path
from PIL import Image
from p50_verification_common import N,P,PUB,APP,now,sha,exact,load,file_pin,publish,changed,source_path,png_structure
from resolve_p50_metadata_pins import run as resolve_pins

ALLOWED_ORIGINAL_CORRECTIONS={('archive__seth','original'),('core__snake_acid','original'),('core__teliko','original')}
OFFICIAL_GUARDS={('core__mistral','official--two-arm-configuration'),('archive__raiden_vr','official--x-raiden-substance'),('archive__paz','official--swimsuit'),('archive__paz','official--zeke-pilot')}
FAMILIES={'original','retro','nextgen','cyborg','metalgear','survive','zombie','furry','tuxedo'}

def run(mode='provisional',workers=4):
 start=now();errors=[];warnings=[];snapshotPins=[]
 def input_json(q):
  b=exact(q);snapshotPins.append(dict(path=str(q),sha256=sha(b),bytes=len(b)));return json.loads(b)
 m=input_json(P/'manifest-all381.json');base=input_json(N/'catalog/manifest-all381.json');active=input_json(P/'ACTIVE_ARTIST_REGISTRATIONS_PRIVATE_V1.json');mapping=input_json(N/'p50/official/OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json');newQA=input_json(P/'P50_NEW_SOURCE_FRAME_QA_PRIVATE_V1.json')
 entries=m['entries'];by={(e['uid'],e['costumeId']):e for e in entries};old={(e['uid'],e['costumeId']):e for e in base['entries']}
 def check(ok,reason,**details):
  if not ok:errors.append(dict(reason=reason,**details))
 check(len(by)==len(entries),'Duplicate UID/costume key');uids={e['uid']for e in entries};baseUIDs={e['uid']for e in base['entries']};check(len(baseUIDs)==381,'P49 baseline roster UID count',actual=len(baseUIDs))
 registryPath=P/'P50_ADDITIONAL_DISTINCT_INCARNATIONS_PRIVATE_V1.json';registry=input_json(registryPath)if registryPath.is_file()else{'entries':[]};registryRows=registry.get('entries',[]);extraUIDs={r['uid']for r in registryRows};check(len(extraUIDs)==len(registryRows),'Duplicate additional registry UID');check(not(baseUIDs&extraUIDs),'Additional registry reuses baseline UID');check(uids==baseUIDs|extraUIDs,'Roster UID set differs from baseline381 plus explicit additional registry',missing=sorted((baseUIDs|extraUIDs)-uids),unexpected=sorted(uids-(baseUIDs|extraUIDs)))
 if registryRows:
  check(registry.get('schema')=='cqc.p50.explicit-additional-distinct-incarnations/1'and registry.get('baselineRosterUIDs')==381 and registry.get('baselineMatrixRows')==3429,'Additional incarnation registry baseline/schema mismatch')
 additionalChecks=[]
 for row in registryRows:
  key=(row['uid'],row.get('costumeID'));entry=by.get(key);ownEntries=[e for e in entries if e['uid']==row['uid']];source=entry.get('source',{})if entry else{};ok=bool(entry and entry.get('family')=='original'and entry.get('frame')and entry.get('additionalDistinctIncarnation')is True and source.get('sha256')==row.get('requiredSourceSHA256')and row.get('rootAuthorizedIdentitySplit')is True and row.get('notHistoricalAlias')is True and row.get('newFamilyMatrixRowsClaimed')==0 and len(ownEntries)==1 and row.get('costumeID')=='original')
  check(ok,'Additional distinct incarnation not exactly registered as one authorized Original',key=key);additionalChecks.append(dict(uid=row['uid'],costumeID=row.get('costumeID'),expectedSourceSHA256=row.get('requiredSourceSHA256'),selectedSourceSHA256=source.get('sha256'),singleOriginalNoInventedFamilyMatrix=len(ownEntries)==1,consistent=ok))
  related=next((r for r in mapping['rows']if r['historicalID']==row.get('relatedHistoricalID')),None);check(related is not None and related.get('resolutionState')=='REFERENCE_AND_STATIC_SOURCE_PENDING','Additional1984 Original falsely closes related1975 hospital historical row',historicalID=row.get('relatedHistoricalID'))
 planned=[e for e in entries if e['family']!='canonical'and e['uid']in baseUIDs];plannedKeys={(e['uid'],e['family'])for e in planned};aliases={(e['uid'],e['family'])for e in m['aliasesCoveredByOriginal']};excluded={(e['uid'],e['family'])for e in m['notApplicableExcluded']};matrix=plannedKeys|aliases|excluded;expected={(uid,fam)for uid in baseUIDs for fam in FAMILIES}
 check(len(plannedKeys)==len(planned),'Duplicate planned UID/family');check(not(plannedKeys&aliases or plannedKeys&excluded or aliases&excluded),'Planned/alias/excluded matrix overlap');check(matrix==expected and len(matrix)==3429,'381×9 baseline matrix not fully preserved',actual=len(matrix),expected=3429,missing=list(expected-matrix)[:10],unexpected=list(matrix-expected)[:10]);check(m['aliasesCoveredByOriginal']==base['aliasesCoveredByOriginal'],'Baseline coveredByOriginal aliases changed');check(m['notApplicableExcluded']==base['notApplicableExcluded'],'Baseline non-applicable exclusions changed')
 originals=[e for e in planned if e['family']=='original'];check(len(originals)==381 and all(e.get('source')and e.get('frame')for e in originals),'Not all381 Originals have source+frame');uncoveredPlanned=[(e['uid'],e['costumeId'])for e in planned if not e.get('source')and not e.get('generationGuard')];check(not uncoveredPlanned,'Ungarded planned rows lack source',rows=uncoveredPlanned)
 missingOld=[];changedOld=[];allowed=[];oldKeysRemovedWithoutSource=[]
 for key,e in old.items():
  n=by.get(key)
  if not n:
   if e.get('source'):missingOld.append(key)
   else:oldKeysRemovedWithoutSource.append(key)
   continue
  if e.get('source')and(e['source']['sha256']!=(n.get('source')or{}).get('sha256')or e.get('frame')!=n.get('frame')):
   row=dict(key=key,oldSHA256=e['source']['sha256'],newSHA256=(n.get('source')or{}).get('sha256'),frameChanged=e.get('frame')!=n.get('frame'))
   (allowed if key in ALLOWED_ORIGINAL_CORRECTIONS else changedOld).append(row)
 check(not missingOld,'Previously sourced entry removed',keys=missingOld);check(not changedOld,'Unapproved previously sourced entry changed',rows=changedOld)
 aliasesByKey={(r['targetUID'],r['reconciledOfficialID']):r for r in mapping['rows']if r.get('resolutionState')=='P50_EXISTING_SAME_UID_APPEARANCE_REUSED'}
 correctedPlaceholderKeys={(r['targetUID'],r['reconciledOfficialID'])for r in mapping['rows']if r.get('resolutionState')=='P50_CORRECTED_ORIGINAL_SOURCE_POSE_DRAWN'and(r['targetUID'],r.get('targetCostumeID'))in ALLOWED_ORIGINAL_CORRECTIONS}
 check(all(k in aliasesByKey or k in correctedPlaceholderKeys for k in oldKeysRemovedWithoutSource),'Removed old placeholders are not documented exact aliases',keys=[k for k in oldKeysRemovedWithoutSource if k not in aliasesByKey and k not in correctedPlaceholderKeys])
 for key in OFFICIAL_GUARDS:
  e=by.get(key);check(e is not None and e.get('generationGuard')and not e.get('source')and not e.get('frame'),'Official guard gained Source or lost guard',key=key)
 inheritedGuardWithSource=[]
 for key,e in by.items():
  if e.get('generationGuard')and e.get('source'):
   oldE=old.get(key,{});same=oldE.get('generationGuard')and (oldE.get('source')or{}).get('sha256')==e['source']['sha256'];check(bool(same),'Guard gained a new Source',key=key);inheritedGuardWithSource.append(dict(key=key,sourceSHA256=e['source']['sha256'],unchangedFromP49=bool(same)))
 pathsBySHA={};sourceDims={};frameChecks=0;selectedGenerated=set();guardEntries=[]
 for e in entries:
  s=e.get('source');f=e.get('frame');key=(e['uid'],e['costumeId'])
  if not s:check(not f,'Frame without Source',key=key);continue
  check(f is not None,'Source without frame',key=key)
  try:
   q=source_path(s);pathsBySHA.setdefault(s['sha256'],set()).add(str(q));dims=(s['width'],s['height']);check(s['sha256']not in sourceDims or sourceDims[s['sha256']]==dims,'Same SHA has conflicting dimensions',key=key);sourceDims[s['sha256']]=dims
   if s.get('kind')=='generated-atlas':selectedGenerated.add(s['sha256'])
   x,y,w,h=f['rect'];check(all(type(v)is int for v in [x,y,w,h])and x>=0 and y>=0 and w>0 and h>0 and x+w<=s['width']and y+h<=s['height'],'Invalid/out-of-image source rect',key=key,rect=f.get('rect'),sourceDims=dims)
   pivot=f['pivot'];check(isinstance(pivot,list)and len(pivot)==2 and all(type(v)in(int,float)and math.isfinite(v)and 0<=v<=1 for v in pivot),'Invalid/nonfinite/outside normalized pivot',key=key,pivot=pivot)
   check(e.get('facing')=='right','Selected frame not declared RIGHT',key=key,facing=e.get('facing'));check(not e.get('generationRequired'),'Selected Source still marked requires generation',key=key);frameChecks+=1
  except Exception as exc:errors.append(dict(reason='Selected source/frame lookup failed',key=key,error=type(exc).__name__+': '+str(exc)))
 # Keep the three explicitly superseded Original PNGs physically readable as well.
 preservedOldOriginals=[]
 for key in ALLOWED_ORIGINAL_CORRECTIONS:
  s=old[key]['source'];q=source_path(s);pathsBySHA.setdefault(s['sha256'],set()).add(str(q));sourceDims[s['sha256']]=(s['width'],s['height']);preservedOldOriginals.append(dict(key=key,path=str(q),sha256=s['sha256']))
 selectedSHAs={e['source']['sha256']for e in entries if e.get('source')};records=[]
 def verify_group(item):
  wanted,paths=item
  try:
   first=None;physical=[]
   for path in sorted(paths):
    raw=exact(Path(path));assert sha(raw)==wanted,'SHA256 mismatch';physical.append(dict(path=path,bytes=len(raw),sha256=wanted));first=raw if first is None else first
   info=png_structure(first)
   with Image.open(io.BytesIO(first))as im:im.load();dims=im.size;modeIm=im.mode
   assert dims==(info['width'],info['height'])==sourceDims[wanted],'Decoded/IHDR/source dimensions mismatch'
   oid=hashlib.sha1(b'blob '+str(len(first)).encode()+b'\0'+first).hexdigest()
   return dict(sha256=wanted,bytes=len(first),width=dims[0],height=dims[1],mode=modeIm,chunkCount=len(info['chunks']),allChunkCRCsExact=True,fullRasterDecoded=True,animatedPNGRejected=True,gitBlobOID=oid,physicalPaths=physical,selectedCurrent=wanted in selectedSHAs)
  except Exception as exc:return dict(sha256=wanted,physicalPaths=sorted(paths),error=type(exc).__name__+': '+str(exc),selectedCurrent=wanted in selectedSHAs)
 with concurrent.futures.ThreadPoolExecutor(max_workers=workers)as pool:
  for i,r in enumerate(pool.map(verify_group,sorted(pathsBySHA.items())),1):
   records.append(r)
   if i%200==0:print(json.dumps(dict(progressUniquePNG=i,total=len(pathsBySHA))),flush=True)
 decodeErrors=[r for r in records if r.get('error')];errors.extend(dict(reason='PNG integrity/decode failed',**r)for r in decodeErrors);verified={r['sha256']:r for r in records if not r.get('error')};check(selectedSHAs<=set(verified),'Some selected PNGs not fully verified',missing=list(selectedSHAs-set(verified)))
 # Source ledgers are observations of local immutable publication receipts, not a new network/Git write.
 ledger={};ledgerFilePins=[]
 for folder in [N/'publication',PUB]:
  for q in sorted(folder.glob('SOURCE_COMMIT_*_PRIVATE_V1.json')):
   raw=exact(q);d=json.loads(raw);ledgerFilePins.append(dict(path=str(q),sha256=sha(raw),bytes=len(raw)))
   for r in d.get('rows',[]):ledger.setdefault(r['sha256'],[]).append(dict(r,commit=d.get('commit'),receiptPath=str(q)))
 generatedLedgerChecks=[]
 for wanted in sorted(selectedGenerated):
  refs=ledger.get(wanted,[]);r=verified.get(wanted);matches=[x for x in refs if r and x.get('sha')==r['gitBlobOID']and x.get('bytes')==r['bytes']];generatedLedgerChecks.append(dict(sha256=wanted,matchingLedgerRows=len(matches),ledgerReceipts=sorted({x['receiptPath']for x in matches})))
  check(bool(matches),'Selected generated Source not backed by matching local publication ledger/blob hash',sha256=wanted)
 missingImmutable=[]
 for e in entries:
  s=e.get('source',{})
  if s.get('kind')=='generated-atlas':
   if not s.get('immutableURL'):missingImmutable.append((e['uid'],e['costumeId']))
   if s.get('gitBlobOID')and s['sha256']in verified:check(s['gitBlobOID']==verified[s['sha256']]['gitBlobOID'],'Selected generated Source Git blob metadata mismatch',key=(e['uid'],e['costumeId']))
 check(not missingImmutable,'Selected generated Sources missing immutable URL',keys=missingImmutable)
 mapChecks=[]
 pendingStates={'REFERENCE_AND_STATIC_SOURCE_PENDING','BODY_FORM_CHANGE_SCOPE_REVIEW_PENDING','P50_IMAGE_GENERATION_REFUSED','P50_CONTENT_GUARD_NO_GENERATION'}
 check(len(mapping['rows'])==416,'Official historical mapping row count',actual=len(mapping['rows']))
 for row in mapping['rows']:
  key=(row['targetUID'],row.get('targetCostumeID')or row['reconciledOfficialID']);e=by.get(key);pending=row['resolutionState']in pendingStates
  ok=bool(e)and(bool(e.get('source')and e.get('frame'))if not pending else not e.get('source'))
  check(ok,'Official historical map/source state inconsistent',historicalID=row['historicalID'],key=key,resolutionState=row['resolutionState']);mapChecks.append(dict(historicalID=row['historicalID'],targetKey=key,state=row['resolutionState'],expectedSource=not pending,sourcePresent=bool(e and e.get('source')),consistent=ok))
 fixes=input_json(P/'FRAME_SELECTION_CORRECTIONS_PRIVATE_V1.json');fixApplied=[];fixSuperseded=[];oldQAFields=collections.Counter()
 for fix in fixes.get('corrections',[]):
  e=by.get((fix['uid'],fix['costumeId']))
  if not e or not e.get('source'):errors.append(dict(reason='Reviewed frame entry missing',key=(fix['uid'],fix['costumeId'])));continue
  if e['source']['sha256']==fix['sourceSHA256']:
   fields=[field for field in ['rect','pivot','bodyBounds','clipPolygon']if field in fix]
   for field in fields:oldQAFields[field]+=1
   ok=all(e['frame'].get(field)==fix[field]for field in fields)and e.get('frameReview',{}).get('reviewer')==fix['reviewer'];check(ok,'Published reviewed geometry not applied',key=(fix['uid'],fix['costumeId']),fields=fields);fixApplied.append((fix['uid'],fix['costumeId']))
  else:fixSuperseded.append(dict(uid=fix['uid'],costumeId=fix['costumeId'],newSourceSHA256=e['source']['sha256']))
 newQAChecks=[];newQAApplied=[];newQASuperseded=[];newQAFields=collections.Counter()
 for fix in newQA.get('corrections',[]):
  key=(fix['uid'],fix['costumeId']);e=by.get(key)
  result=dict(uid=fix['uid'],costumeId=fix['costumeId'],lockedSourceSHA256=fix['sourceSHA256'],fieldsChecked=[],mismatchedFields=[])
  if not e or not e.get('source'):
   check(False,'P50 reviewed geometry entry missing',key=key);result['state']='MISSING_ENTRY';newQAChecks.append(result);continue
  if e['source']['sha256']!=fix['sourceSHA256']:
   result.update(state='SUPERSEDED_BY_SELECTED_DIFFERENT_SOURCE',selectedSourceSHA256=e['source']['sha256']);newQASuperseded.append(result);newQAChecks.append(result);continue
  check(fix.get('requiresSourceSHAMatch')is True,'P50 geometry correction not explicitly SourceSHA-locked',key=key)
  for field in ['rect','pivot','bodyBounds','clipPolygon']:
   if field in fix:
    result['fieldsChecked'].append(field);newQAFields[field]+=1
    if e['frame'].get(field)!=fix[field]:result['mismatchedFields'].append(field)
  review=e.get('frameReview',{})
  if review.get('sourceSHA256')!=fix['sourceSHA256']:result['mismatchedFields'].append('frameReview.sourceSHA256')
  if review.get('reviewer')!=fix.get('reviewer'):result['mismatchedFields'].append('frameReview.reviewer')
  if 'footprint'in fix and review.get('sourceFootDatum')!=fix['footprint']:result['mismatchedFields'].append('frameReview.sourceFootDatum')
  check(not result['mismatchedFields'],'P50 active SourceSHA-locked geometry not applied',key=key,fields=result['mismatchedFields']);result['state']='APPLIED_EXACT'if not result['mismatchedFields']else'NOT_APPLIED';newQAChecks.append(result)
  if not result['mismatchedFields']:newQAApplied.append(key)
 pinReport=resolve_pins(mode)
 check(pinReport['errorCount']==0,'Historical/active metadata-pin resolution errors',count=pinReport['errorCount'])
 portableChecks=None
 portableRoot=N/'p50/delivery/catalogue';portableManifest=portableRoot/'manifest.json'
 if mode=='final':
  if not portableManifest.is_file():check(False,'Final portable catalogue manifest missing')
  else:
   portable=input_json(portableManifest);pb={(e['uid'],e['costumeId']):e for e in portable['entries']};portableErrors=[]
   if set(pb)!=set(by):portableErrors.append(dict(reason='Portable entry keys differ from canonical snapshot',missing=len(set(by)-set(pb)),extra=len(set(pb)-set(by))))
   portablePaths={}
   for key,e in by.items():
    pe=pb.get(key)
    if pe is None:continue
    if e.get('frame')!=pe.get('frame')or e.get('facing')!=pe.get('facing')or e.get('generationGuard')!=pe.get('generationGuard'):portableErrors.append(dict(reason='Portable frame/facing/guard differs',key=key))
    cs=e.get('source');ps=pe.get('source')
    if bool(cs)!=bool(ps):portableErrors.append(dict(reason='Portable Source presence differs',key=key));continue
    if cs:
     if any(cs.get(k)!=ps.get(k)for k in ['sha256','width','height','kind']):portableErrors.append(dict(reason='Portable Source metadata differs',key=key));continue
     q=portableRoot/ps['src']
     try:safePath=q.is_relative_to(portableRoot)and q.resolve(strict=True)==q
     except FileNotFoundError:safePath=False
     if not safePath:portableErrors.append(dict(reason='Missing/unsafe portable Source path',key=key));continue
     portablePaths.setdefault(ps['sha256'],set()).add(str(q))
   pverified=0
   for wanted,paths in portablePaths.items():
    try:
     for path in paths:
      raw=exact(Path(path));assert sha(raw)==wanted and wanted in verified,'Portable byte hash differs from already decoded canonical Source';assert len(raw)==verified[wanted]['bytes'],'Portable length differs'
     pverified+=1
    except Exception as exc:portableErrors.append(dict(reason='Portable Source exact readback failed',sha256=wanted,error=type(exc).__name__+': '+str(exc)))
   portableChecks=dict(portableManifestSHA256=file_pin(portableManifest)['sha256'],entryKeysCompared=len(pb),selectedUniquePNGsSHAComparedToDecodedCanonical=pverified,allSelectedFramesSourcesAndGuardsMatch=not portableErrors,errors=portableErrors)
   errors.extend(portableErrors)
 boundBrowserCheck=None;boundModelCheck=None
 if mode=='final':
  browserDoc=input_json(N/'p50/delivery/P50_BROWSER_VERIFICATION_PRIVATE_V1.json');expectedPortableSHA=portableChecks.get('portableManifestSHA256')if portableChecks else None
  browserOK=bool(expectedPortableSHA and browserDoc.get('manifestSHA256')==expectedPortableSHA and browserDoc.get('sourceLoadErrors')==0 and not browserDoc.get('uncaughtBrowserExceptions')and all(c.get('errors')==0 and not c.get('overflow')for c in browserDoc.get('cases',[])))
  check(browserOK,'Root browser evidence does not match final portable manifest or reports errors');boundBrowserCheck=dict(manifestSHA256=browserDoc.get('manifestSHA256'),portableManifestSHA256=expectedPortableSHA,caseCount=len(browserDoc.get('cases',[])),boundAndNoErrors=browserOK,atUTC=browserDoc.get('atUTC'))
  modelDoc=input_json(N/'p50/delivery/P50_MODEL_TESTS_PRIVATE_V1.json');modelOK=modelDoc.get('status')=='PASS'and modelDoc.get('checks')==13;check(modelOK,'Root meaningful model test evidence not PASS13');boundModelCheck=dict(status=modelDoc.get('status'),checks=modelDoc.get('checks'),atUTC=modelDoc.get('atUTC'),note='Root executed meaningful model tests; verifier only checks exact report and status.')
 changedInputs=[pin['path']for pin in snapshotPins if changed(pin)];stable=not changedInputs and pinReport['inputSnapshotStable'];status=('FAIL'if errors else('PASS_PROVISIONAL'if mode=='provisional'else'PASS_FINAL'))if stable else'LIVE_INPUTS_CHANGED_RERUN_REQUIRED'
 indexPath=PUB/'PORTABLE_STATIC_CATALOG_SOURCE_INDEX_PRIVATE_V1.json';portableObservation=None
 if indexPath.is_file():
  idx=load(indexPath);portableObservation=dict(path=str(indexPath),indexAtUTC=idx.get('atUTC'),indexedEntries=idx.get('entries'),currentSnapshotEntries=len(entries),indexEntriesMatchCurrent=idx.get('entries')==len(entries),note='Portable bundle not rebuilt or mutated by verifier; root performs packaging separately. Canonical selected Sources verified directly regardless of older portable snapshot.')
 report=dict(schema='cqc.p50.static-delivery-full-verification/1',mode=mode,startedAtUTC=start,finishedAtUTC=now(),status=status,inputSnapshotStable=stable,changedLiveInputs=changedInputs,inputPins=snapshotPins,metrics=dict(rosterUIDs=len(uids),catalogEntries=len(entries),plannedRows=len(planned),plannedMatrixRows=len(matrix),baselineAliasRows=len(aliases),baselineExcludedRows=len(excluded),originalPosesPresent=len(originals)+len(additionalChecks),baselineOriginalPosesPresent=len(originals),additionalOriginalPosesPresent=len(additionalChecks),baselineRosterUIDs=len(baseUIDs),additionalDistinctIncarnationUIDs=len(extraUIDs),selectedSourcedEntries=sum(bool(e.get('source'))for e in entries),selectedUniquePNGs=len(selectedSHAs),selectedUniquePNGsSHA256CRCAndDecoded=sum(r.get('selectedCurrent',False)and not r.get('error')for r in records),allVerifiedPNGsIncludingSupersededOriginals=len(verified),uniqueSelectedPNGBytes=sum(r['bytes']for r in records if r.get('selectedCurrent')and not r.get('error')),selectedRIGHTRectPivotChecks=frameChecks,generatedSelectedUniquePNGs=len(selectedGenerated),generatedSelectedUniquePNGsWithLedger=sum(bool(r['matchingLedgerRows'])for r in generatedLedgerChecks),activeCandidatePages=len(active.get('pages',[])),activePoseCandidates=active.get('activePoseCandidates'),baselineSelectedKeysRetained=sum(bool(e.get('source'))for e in base['entries'])-len(missingOld),approvedOriginalCorrections=len(allowed),removedUnbackedPlaceholdersAliased=sum(k in aliasesByKey for k in oldKeysRemovedWithoutSource),removedUnbackedPlaceholdersCoveredByExplicitOriginalCorrections=sum(k in correctedPlaceholderKeys for k in oldKeysRemovedWithoutSource),guardedOfficialRowsNoSource=sum(k in by and not by[k].get('source')for k in OFFICIAL_GUARDS),inheritedGuardWithPriorSource=len(inheritedGuardWithSource),generationGuardScopes=sum(bool(e.get('generationGuard'))for e in entries),newGuardSources=sum(bool(e.get('generationGuard')and e.get('source'))and not((old.get((e['uid'],e['costumeId']),{}).get('source')or{}).get('sha256')==e['source']['sha256'])for e in entries),officialHistoricalRowsReconciled=len(mapChecks),officialHistoricalStates=dict(collections.Counter(r['state']for r in mapChecks)),p50Summary={k:v for k,v in mapping.get('p50Summary',{}).items()if k!='proposalDocuments'},historicalMetadataPinsExact=pinReport['summary']['historicalPinsExactlyResolved'],activeMetadataPinsExact=pinReport['summary']['activeImmutablePinsExact'],reviewedFramesChecked=len(fixes.get('corrections',[])),reviewedFramesApplied=len(fixApplied),reviewedFramesSuperseded=len(fixSuperseded),p49ReviewedFieldsChecked=dict(oldQAFields),p50ReviewedCorrections=len(newQA.get('corrections',[])),p50ReviewedCorrectionsActiveSource=sum(r['state']not in ['MISSING_ENTRY','SUPERSEDED_BY_SELECTED_DIFFERENT_SOURCE']for r in newQAChecks),p50ReviewedCorrectionsApplied=len(newQAApplied),p50ReviewedCorrectionsSuperseded=len(newQASuperseded),p50ReviewedFieldsChecked=dict(newQAFields)),approvedOriginalChanges=allowed,additionalDistinctIncarnations=additionalChecks,priorOriginalSourcesPreserved=preservedOldOriginals,inheritedGuardedSourceObservations=inheritedGuardWithSource,selectedPNGVerification=records,generatedSourceLedgerChecks=generatedLedgerChecks,officialMappingChecks=mapChecks,reviewedFramesSuperseded=fixSuperseded,p50ReviewedGeometryChecks=newQAChecks,p50ReviewedGeometrySuperseded=newQASuperseded,metadataPinReport=str(PUB/('P50_METADATA_PIN_RESOLUTION_'+mode.upper()+'_PRIVATE_V1.json')),portableSnapshotObservation=portableObservation,finalPortableBundleVerification=portableChecks,finalBrowserEvidenceBinding=boundBrowserCheck,finalModelTestEvidence=boundModelCheck,errors=errors,warnings=warnings,errorCount=len(errors),newArtGenerated=False,SourcePixelsEdited=False,catalogMapperImporterBuildModified=False,GitRefsTouched=False,runtimeModified=False,newAnimations=0,pixelPerfectFidelityCertified=False,limitations=['Integrity, dimensions and declared RIGHT frame/pivot metadata are verified; visual anatomy/facing likeness and stage/runtime behaviour are not certified by this data audit.','Existing The End MetalGear Source under a correction guard is preserved exactly from P49; no new guarded Source allowed. Four new official guarded rows must remain without Source.','Provisional snapshot during live artists/catalog refreshes must be rerun only after Root freeze. No final publication/merge claim.','Original381 and matrix3429 describe the preserved baseline; explicit additional registry Originals are counted separately without synthesizing8family rows or closing cross-era historical costumes.'])
 target=PUB/('P50_FULL_VERIFICATION_'+mode.upper()+'_PRIVATE_V1.json');out=publish(target,report);aggregate=build_public_aggregate(report,out);print(json.dumps(dict(out,status=status,metrics=report['metrics'],errorCount=len(errors),changedInputs=changedInputs)),flush=True);return report
def build_public_aggregate(report,detailPin):
 manifestPin=next(p for p in report['inputPins']if p['path']==str(P/'manifest-all381.json'));metrics=report['metrics']
 browserPath=N/'p50/delivery/P50_BROWSER_VERIFICATION_PRIVATE_V1.json';browser=None
 if browserPath.is_file():
  b=load(browserPath);browser=dict(reportSHA256=file_pin(browserPath)['sha256'],checkedAtUTC=b.get('atUTC'),caseCount=len(b.get('cases',[])),sourceLoadErrors=b.get('sourceLoadErrors'),uncaughtExceptions=len(b.get('uncaughtBrowserExceptions',[])),desktopViewport=b.get('desktop'),mobileViewport=b.get('mobile'),filterPaginationAndRepeatedSourceLoads=b.get('filterPaginationAndRepeatedSourceLoads'),manifestSHA256=b.get('manifestSHA256'),finalPortableBinding=report.get('finalBrowserEvidenceBinding'),note='Existing Root browser evidence, not rerun by data verifier; final-mode SHA binding checked against portable manifest.')
 modelPath=N/'p50/delivery/P50_MODEL_TESTS_PRIVATE_V1.json';models=None
 if modelPath.is_file():
  model=load(modelPath);models=dict(reportSHA256=file_pin(modelPath)['sha256'],checkedAtUTC=model.get('atUTC'),checks=model.get('checks'),status=model.get('status'),note='Existing Root meaningful model tests; not rerun by data verifier.')
 publicMetrics=json.loads(json.dumps(metrics))
 extras=publicMetrics.get('p50Summary',{}).pop('unmappedAdditionalProposals',[])
 publicMetrics.get('p50Summary',{})['additionalDistinctOfficialAppearances']=len(extras)
 aggregate=dict(schema='cqc.p50.final-verification-aggregate/1',atUTC=report['finishedAtUTC'],status=report['status'],mode=report['mode'],finalFreezeClaimed=report['mode']=='final'and report['inputSnapshotStable'],manifestSHA256=manifestPin['sha256'],manifestBytes=manifestPin['bytes'],additionalRegistrySHA256=next((p['sha256']for p in report['inputPins']if p['path']==str(P/'P50_ADDITIONAL_DISTINCT_INCARNATIONS_PRIVATE_V1.json')),None),detailReportSHA256=detailPin['sha256'],inputSnapshotStable=report['inputSnapshotStable'],errorCount=report['errorCount'],metrics=publicMetrics,browserVerification=browser,modelTests=models,portableBundleVerification=report.get('finalPortableBundleVerification'),newArtByVerifier=False,sourcePixelsEdited=False,catalogOrRuntimeModifiedByVerifier=False,GitRefsTouched=False,pixelPerfectFidelityCertified=False,coverageCaveat='Four guarded official goals have no Source. Reference-pending historical looks remain explicit. This aggregate verifies data integrity and declared one-frame geometry; it does not certify visual1:1 or combat/animation admission.')
 path=N/'p50/delivery/P50_FINAL_VERIFICATION_PUBLIC_V1.json';raw=(json.dumps(aggregate,ensure_ascii=False,indent=2)+'\n').encode();temp=path.with_name('.'+path.name+'.tmp');temp.write_bytes(raw);__import__('os').replace(temp,path);assert exact(path)==raw;print(json.dumps(dict(publicAggregate=str(path),sha256=sha(raw),status=aggregate['status'],manifestSHA256=manifestPin['sha256'])),flush=True);return aggregate

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=['provisional','final'],default='provisional');parser.add_argument('--workers',type=int,default=4);args=parser.parse_args();r=run(args.mode,args.workers);raise SystemExit(bool(r['errorCount']))
