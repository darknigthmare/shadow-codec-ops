#!/usr/bin/env python3
"""Add P50 source evidence to frozen P49 rows, keyed by historical identity."""
import json,pathlib,hashlib,os,datetime,collections,csv,re,copy
N=pathlib.Path('/tmp/cqc-static-20261113');P=N/'p50';O=P/'official';O.mkdir(exist_ok=True)
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
def load(p):return json.loads(read(p))
def save(p,d):
 q=p.with_suffix(p.suffix+'.tmp');q.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');q.replace(p)
base=load(P/'base/OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json');out=copy.deepcopy(base);byHist={r['historicalID']:r for r in out['rows']};pending={r['historicalID']for r in base['rows']if r['resolutionState']=='REFERENCE_AND_STATIC_SOURCE_PENDING'};byKey={(r['targetUID'],r['reconciledOfficialID']):r for r in out['rows']};active=load(P/'catalog/ACTIVE_ARTIST_REGISTRATIONS_PRIVATE_V1.json');activeKeys={(p['uid'],c):p['sha256']for p in active['pages']for c in p['activeCostumes']};candidates={};documents=[];unmapped=[];sources={}
for p in sorted((N/'artists').rglob('*ARTIFACT_PROPOSAL*.json')):
 if'p50'not in p.parts:continue
 d=load(p)
 if not isinstance(d,dict)or not d.get('rawPNG')or not d.get('slots'):continue
 page=d['rawPNG'];raw=read(pathlib.Path(page['path']));assert len(raw)==page['bytes']and hashlib.sha256(raw).hexdigest()==page['sha256'];documents.append({'path':str(p),'sha256':hashlib.sha256(read(p)).hexdigest()});v=d.get('version');match=re.search(r'_V(\d+)',p.name);v=v if isinstance(v,int)else int(match.group(1))if match else 1
 for s in d['slots']:
  if not(s.get('classification','').startswith('official')or s.get('classification')=='corrected-original-pose'):continue
  uid=s.get('uid',d['uid']);cid=s.get('costumeID',s.get('costumeId'));hist=s.get('historicalID',s.get('historicalAlias'));r=byHist.get(hist)if hist else byKey.get((uid,cid))
  if r is None:unmapped.append({'uid':uid,'costumeID':cid,'proposal':str(p)});continue
  assert r['targetUID']==uid,'Cross-incarnation source assignment'
  if r['historicalID']not in pending:raise ValueError('P50 drew a row already covered by P49: '+r['historicalID'])
  if activeKeys.get((uid,cid))!=page['sha256']:continue
  source={'costumeID':cid,'sourceCatalogueKey':uid+':'+cid,'proposal':str(p),'proposalSHA256':hashlib.sha256(read(p)).hexdigest(),'PNG':page['path'],'sha256':page['sha256'],'bytes':page['bytes'],'width':page['width'],'height':page['height'],'rect':s['sourceRect'],'bodyDatumX':s['bodyDatumX'],'footDatumY':s['footDatumY'],'poseCount':1,'animationCount':0,'facing':s.get('facing','right')};assert source['facing']=='right'
  held=bool(s.get('held')or s.get('status')in['held','rejected','correction-pending']or d.get('alphaExportIssue')or d.get('visualReview',{}).get('alphaExportIssue'))
  if 'halo'in cid and d.get('visualReview',{}).get('haloTargetedCorrectionPending'):held=True
  rank=(v,d.get('atUTC',''),str(p));key=r['historicalID']
  if key not in candidates or rank>candidates[key][0]:candidates[key]=(rank,source,d,s,held)
for hist,(_,source,d,s,held)in candidates.items():
 r=byHist[hist];r['p49ResolutionState']=r['resolutionState'];r['p49ResolutionReason']=r['resolutionReason'];r.update(targetCostumeID=source['costumeID'],newSource=source,resolutionState='P50_STATIC_SOURCE_CORRECTION_PENDING'if held else'P50_CORRECTED_ORIGINAL_SOURCE_POSE_DRAWN'if s.get('classification')=='corrected-original-pose'else'P50_NEW_STATIC_SOURCE_POSE_DRAWN_REVIEW_PENDING',resolutionReason=('Exact Source retained but artist explicitly identified a targeted correction; not counted finished.'if held else'One P50 authored static RIGHT pose from actually inspected same-incarnation visual evidence; no new animation or gameplay admission. '+str(d.get('visualReview',{}).get('limits',''))));r['p50Evidence']={'proposal':source['proposal'],'referenceSources':d.get('referenceSources',[]),'visualReview':d.get('visualReview',{})};sources[hist]=source
aliasesPath=O/'P50_ACCEPTED_SAME_UID_ALIASES_PRIVATE_V1.json';aliases=load(aliasesPath)['entries']if aliasesPath.exists()else[];manifest=load(P/'base/manifest-all381.json');originals={(e['uid'],e['costumeId']):e for e in manifest['entries']};accepted=[]
for a in aliases:
 hist=a['historicalID'];assert hist in pending and hist not in sources;r=byHist[hist];assert a['uid']==r['targetUID']==a.get('targetUID',a['uid']);target=originals.get((a['uid'],a['targetCostumeID']));matching=[v for v in candidates.values()if v[1]['costumeID']==a['targetCostumeID']and v[2]['uid']==a['uid']and not v[4]]
 if matching:
  _,ts,td,tc,_=max(matching,key=lambda x:x[0]);x,y,w,h=ts['rect'];target={'source':{'kind':'generated-atlas','sha256':ts['sha256'],'width':ts['width'],'height':ts['height'],'src':ts['PNG']},'frame':{'rect':ts['rect'],'pivot':[(ts['bodyDatumX']-x)/w,(ts['footDatumY']-y)/h]}};r['newSource']=dict(ts,reusedPhysicalPose=True,newDrawingCount=0)
 assert target and target.get('source')and target.get('frame')and a.get('reviewer')and a.get('proofPaths');r['p49ResolutionState']=r['resolutionState'];r['p49ResolutionReason']=r['resolutionReason'];r.update(targetCostumeID=a['targetCostumeID'],resolutionState='P50_EXISTING_SAME_UID_APPEARANCE_REUSED',resolutionReason=a['reason']);r['p50AliasProof']=a;r['nativeOptions']=[{'uid':a['uid'],'costumeID':a['targetCostumeID'],'preview':{'sha256':target['source']['sha256'],'rect':target['frame']['rect'],'pivot':target['frame'].get('pivot')},'verifiedPhysicalSource':{'source':target['source'],'frame':target['frame'],'reusedExistingStaticPose':True}}];accepted.append(hist)
guardPath=O/'P50_EXACT_COSTUME_GENERATION_GUARDS_PRIVATE_V1.json';guards=load(guardPath)['entries']if guardPath.exists()else[]
for g in guards:
 hist=g['historicalID'];assert hist in pending and hist not in sources and hist not in accepted
 r=byHist[hist];assert r['targetUID']==g['uid'];r.update(targetCostumeID=g['costumeId'],resolutionState='P50_IMAGE_GENERATION_REFUSED'if g['kind']in['image-generation-output-refusal','image-generation-input-refusal']else'P50_CONTENT_GUARD_NO_GENERATION',resolutionReason=g['reason'],p50GenerationGuard=g)
additionPath=P/'catalog/P50_ADDITIONAL_DISTINCT_INCARNATIONS_PRIVATE_V1.json';additional=load(additionPath)['entries']if additionPath.exists()else[]
for identity in additional:
 hist=identity['relatedHistoricalID'];r=byHist[hist];assert r['resolutionState']=='REFERENCE_AND_STATIC_SOURCE_PENDING'and r['targetUID']!=identity['uid']
 r['p50RelatedDistinctIncarnation']={'uid':identity['uid'],'costumeID':'original','sourceSHA256':identity['requiredSourceSHA256'],'notHistoricalAlias':True};r['resolutionReason']='Historical period mismatch: this UID is explicitly1975 GroundZeroes, while hospital assault is1984 ThePhantomPain. A separate1984 incarnation '+identity['uid']+' has its own Original. It is not a1975 costume and does not silently close or reassign this erroneous historical row.'
out.update(schema='cqc.p50.official416.historical-id-map/1',atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),inputP49={'commit':'09e753326de16bbe8a1d327b503ed488b4b22fa9','mapSHA256':hashlib.sha256(read(P/'base/OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json')).hexdigest()},counts=dict(collections.Counter(r['resolutionState']for r in out['rows'])));out['p50Summary']={'startingPending':len(pending),'newSourceRows':sum(not x[4]for x in candidates.values()),'sourceRowsWithCorrectionPending':sum(bool(x[4])for x in candidates.values()),'exactSameUIDAliases':len(accepted),'guardedOfficialRows':len(guards),'remainingReferenceRows':sum(r['resolutionState']=='REFERENCE_AND_STATIC_SOURCE_PENDING'for r in out['rows']),'newAnimations':0,'gameplayAdmissions':0,'additionalDistinctIncarnations':len(additional),'proposalDocuments':documents,'unmappedAdditionalProposals':unmapped};assert len(out['rows'])==416;assert out['p50Summary']['startingPending']==out['p50Summary']['newSourceRows']+out['p50Summary']['sourceRowsWithCorrectionPending']+len(accepted)+len(guards)+out['p50Summary']['remainingReferenceRows']
out['p50Summary']['historicalEraSplitRowsWithSeparateOriginal']=sum(bool(r.get('p50RelatedDistinctIncarnation'))for r in out['rows']);out['p50Summary']['remainingUnproducedReferenceRows']=out['p50Summary']['remainingReferenceRows']-out['p50Summary']['historicalEraSplitRowsWithSeparateOriginal']
p=O/'OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json';save(p,out)
fields=['historicalID','historicalUID','historicalCostumeName','historicalEpisode','reconciledOfficialID','targetUID','targetCostumeID','resolutionState','resolutionReason','sourceSHA256','animationCount']
with(O/'OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PUBLIC_V1.csv').open('w',newline='',encoding='utf-8-sig')as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
 for r in out['rows']:
  q={k:r.get(k)for k in fields};q['sourceSHA256']=(r.get('newSource')or{}).get('sha256')or'|'.join(o.get('preview',{}).get('sha256','')for o in r.get('nativeOptions',[]));w.writerow(q)
print(json.dumps({k:v for k,v in out['p50Summary'].items()if k!='proposalDocuments'},ensure_ascii=False))
