"""Append current evidence without rewriting the frozen P49 research history."""
from pathlib import Path
import json, hashlib, datetime, collections

N = Path('/tmp/cqc-static-20261113')
P = N / 'p50'
base = json.loads((P / 'base/OFFICIAL416_REFERENCE_DISPOSITIONS_PRIVATE_V1.json').read_text())
mapping = json.loads((P / 'official/OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json').read_text())
by = {r['historicalID']: r for r in mapping['rows']}
reports = {}
for p in (N / 'artists').rglob('*.json'):
    if 'p50' not in p.parts or not any(k in p.name for k in ('DISPOSITION', 'HANDOFF')):
        continue
    try:
        raw = p.read_bytes()
        d = json.loads(raw)
    except (ValueError, OSError):
        continue
    if not isinstance(d, dict):
        continue
    for r in d.get('rows', []):
        if not isinstance(r, dict) or not r.get('historicalID'):
            continue
        reports.setdefault(r['historicalID'], []).append({
            'path': str(p), 'sha256': hashlib.sha256(raw).hexdigest(),
            'reportedStatus': r.get('status', r.get('resolutionState')),
            'reason': r.get('reason', r.get('resolutionReason')),
            'evidenceURLs': r.get('evidenceURLs', r.get('referenceURLs', []))
        })
rows = []
for old in base['rows']:
    r = dict(old)
    cur = by[r['historicalID']]
    r['p49DispositionPreserved'] = {k: old.get(k) for k in
        ('currentMappingState', 'referenceDisposition', 'reason')}
    r['currentMappingState'] = cur['resolutionState']
    if cur['resolutionState'].startswith('P50_'):
        r['reason'] = cur['resolutionReason']
        r['referenceDisposition'] = (
            'P50_GUARDED_WITHOUT_GENERATION' if 'GUARD' in cur['resolutionState'] else
            'P50_IMAGE_GENERATION_REFUSED_NO_PNG' if 'REFUSED' in cur['resolutionState'] else
            'RESOLVED_STATIC_SOURCE_OR_VERIFIED_REUSE')
        r['p50Evidence'] = cur.get('p50Evidence', {})
        r['p50NewSource'] = cur.get('newSource')
        r['p50Guard'] = cur.get('p50GenerationGuard')
    if cur.get('p50RelatedDistinctIncarnation'):
        r['p50RelatedDistinctIncarnation'] = cur['p50RelatedDistinctIncarnation']
        r['reason'] = cur['resolutionReason']
        r['referenceDisposition'] = 'HISTORICAL_PERIOD_ERROR_DISTINCT_ORIGINAL_AVAILABLE'
    r['p50ResearchReports'] = reports.get(r['historicalID'], [])
    rows.append(r)
assert len(rows) == 416 and len(by) == 416
result = {
    'schema': 'cqc.p50.official-reference-dispositions/1',
    'atUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'inputMap': str(P / 'official/OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json'),
    'counts': dict(collections.Counter(r['currentMappingState'] for r in rows)),
    'qualification': 'Frozen P49 research retained; current source/frame map is authoritative. One static pose only, no animation or runtime admission. Report snapshots may retain superseded research states; p50Evidence records the selected current result.',
    'rows': rows
}
out = P / 'official/OFFICIAL416_REFERENCE_DISPOSITIONS_PRIVATE_V1.json'
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'rows': len(rows), 'counts': result['counts'], 'reports': sum(map(len, reports.values()))}))
