from pathlib import Path
from PIL import Image
import json,hashlib,datetime,numpy as np
ROOT=Path('/tmp/cqc-static-20261113/artists/c/p50')
assignment=json.loads(Path('/tmp/cqc-static-20261113/p50/assignments/c_mgs3_survive.json').read_text())
fetch=[]
for p in ROOT.glob('FETCH_P50_*.json.receipts.json'):fetch+=json.loads(p.read_text())
fetch+=json.loads((ROOT/'FIRST_FETCH_PRIVATE_V1.json').read_text())
pins=json.loads((ROOT/'ORIGINAL_PINS_PRIVATE_V1.json').read_text())
def proof(name,observation,viewed=True):
 p=ROOT/'references'/name;b=p.read_bytes();r=next((d for d in fetch if d.get('path')==str(p)),{});return {'localPath':str(p),'URL':r.get('URL'),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'physicallyViewed':viewed,'observation':observation}
proposals={};sources=[]
for p in sorted(ROOT.glob('*/ARTIFACT_PROPOSAL_PRIVATE_*.json')):
 d=json.loads(p.read_text());raw=d['rawPNG'];b=Path(raw['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==raw['sha256'];im=Image.open(raw['path']);a=np.asarray(im)[:,:,3];assert (a==0).any();assert d['alphaAnalysis']['edgeForegroundAbove16']==0
 sources.append({'proposalPath':str(p),'proposalSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'rawPNG':raw,'rawSHA256Verified':True,'alphaZeroPixels':int((a==0).sum()),'edgeForegroundAbove16':0,'allSlotKeys':[s['uid']+':'+s['costumeID']for s in d['slots']],'preferredForKey':d.get('preferredForKey'),'correction':d.get('correction',False)})
 for s in d['slots']:
  if s.get('sourceStatus')=='SUPERSEDED_BY_SOLO_V2':continue
  proposals[s['historicalID']]={'proposalPath':str(p),'proposalSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'sourcePNG':raw,'sourceRect':s['sourceRect'],'footDatumY':s['footDatumY'],'bodyDatumX':s['bodyDatumX'],'targetCostumeID':s['costumeID'],'classification':s['classification'],'referenceProofs':d['referenceSources'],'limits':d['visualReview']['limits']}
assert len(sources)==9 and len(proposals)==11
csv=proof('ps2-texture-slot-map.csv','Text rows link exact final dumped bodytextures to camoufla-snow and camoufla-scientist; read text, not an image.',False)
gaps={
'roster51__volgin_delta__alt__shirtless_battle':{
 'reason':'The requested bare-torso configuration is still not visually attested. Fresh finalDelta firstfight AND later Shagohod direct-retail captures show the same red chest suit with bare arms; bare arms do not prove a shirtless costume. No fabricated torso and no alias to red-combat-suit.',
 'proofs':[proof('mgs-volgin-featured.jpg','Actual finalDelta firstfight frontal RED covered chest and barearms.'),proof('mgs-shagohod-volgin-aim.jpg','Actual later Shagohod battle still RED chest and bulletbandolier, no nakedtorso.'),proof('mgs-shagohod-volgin.jpg','Actual Shagohod scene entiremachine/Volgin in red suit.')],
 'missingEvidence':'A real finalDelta unobstructed baretorso view with same-period lowerbody, rather than the historical label or a mod.'},
'core__snake__alt__prisoner_bandaged':{
 'reason':'Classic prison context is attested, but the specifically requested bandaged variant is not. New classic-model Steam capture shows shirtless harness and gloves, without a documented wrap arrangement. Do not infer an official fixed bandage costume from generic cure mechanics or alias to pre-injury Original/ordinary Naked.',
 'proofs':[proof('ps2-prison-steam-0.jpg','Actual classicMGS3 prison scene with guard, shirtless Snakeharness/gloves; crop does not prove a fixed bandaged fullbody.')],
 'missingEvidence':'Actual PS2/classic prisoner fullbody plus visible bandage locations and post-injury eye/head configuration. Existing YouTube URLs blocked403.'},
'archive__naked_delta__alt__prisoner_bandaged':{
 'reason':'New actual Delta prison/torture captures establish injured shirtless Snake with harness, camotrousers and natural injured RIGHTeye, but none of the viewed captures establishes the requested specific bandages. No unverified white wrapping, eyepatch or bag-overhead is invented as an outfit.',
 'proofs':[proof('pcgamer-prison-delta.jpg','Actual finalDelta prisoner front, barebloodytorso/harness/camotrousers; no bodybandages.'),proof('delta-torture-steam-0.jpg','Actual Delta torture cutscene body/harness with bagcovering head, not a complete bandaged prisonconfiguration.'),proof('delta-torture-steam-3.jpg','Actual Delta injured right-eye closeup without bandage; two naturaleyes/preinjury Original not equivalent.')],
 'missingEvidence':'Actual sameDelta bandagedprison fullbody or genuine wrapping placement proof. Bandages/prisoner Steam searches zeroresults; torture sources reviewed individually.'},
'archive__naked_delta__alt__one_eyed_crocodile_cap':{
 'reason':'DLC existence is documented in guides, but exact One-Eyed cap geometry/patch placement is not visually identified. Eight fresh Delta Steam crocodile results were physically viewed: ordinarycap, fullCrocodileSuit, realanimal or rank screen. HumanSnakes right eyepatch in one picture is not proof of a patch on the cap. Do not alias the ordinaryCrocCap or invent an eyepatch.',
 'proofs':[proof('delta-crocodile-steam-0.jpg','Ordinary Delta cap closeup with visible naturalreptileeye, not identifiedOneEyedDLC.'),proof('delta-crocodile-steam-4.jpg','FullCrocodileSuit and humanSnakes rightpatch; does not identify a distinct OneEyed cap eye-side configuration.'),proof('delta-crocodile-steam-7.jpg','Ordinary cap gameplay inwater; no distinctDLCname/equipmentproof.')],
 'extraEvidenceURLs':['https://gamingbolt.com/metal-gear-solid-delta-snake-eater-guide-how-to-find-all-items-and-their-locations'],
 'missingEvidence':'Official DLC pack closeup or retail equipment selector explicitly naming One-Eyed Crocodile Cap and showing cap/anatomicaleye detail. Name alone is insufficient.'},
'archive__virgil_at9__alt__deployed':{
 'reason':'The preserved known Original is a black cylindrical AIpod; the old official candidate is only a tight upper redoptic/vent closeup. New Steam Virgil search gives a distant ending scene, not a whole open pod. Authored native open-hatch parts are not independent retailproof of a distinct deployed configuration. No invented legs, doors, panels or exact alias.',
 'proofs':[proof('virgil-Original-parts.png','Known sameUID approved Original parts atlas, copiedNoAtime SHA72ae…; authored source silhouette only, not external officialproof.'),proof('virgil-old-candidate.png','Preserved actual2018 public upperpod crop showing redoptic/vents and struts, too cropped to establish full openbody.'),proof('survive-virgil-steam-0.jpg','Fresh retail2018 ending scene with distantpod/creature context; no unambiguous full deployedopenconfig.')],
 'missingEvidence':'Actual whole Virgil open/deployed pod showing lid/doors/internals and ground/support arrangement, so configuration can be distinguished from Original.'}
}
rows=[]
for row in assignment['rows']:
 h=row['historicalID'];out={k:row[k]for k in ['historicalID','historicalUID','historicalCostumeName','historicalEpisode','reconciledOfficialID','targetUID','historicalStatusPreserved']}
 if h in proposals:
  d=proposals[h];correct=d['classification']=='corrected-original-pose';out.update({'status':'CORRECTED_ORIGINAL_STATIC_SOURCE_READY_ROOT_REVIEW'if correct else'STATIC_SOURCE_READY_ROOT_REVIEW','reason':'New single RIGHT static pose generated from physically viewed same-incarnation official/retail/textureproof; exact PNG preserved. Root final admission pending.'if not correct else'Root requested new corrected Original human Seth from actual LEFTsubject retail fullbody. Old Original clothes were materially incorrect. This fills historicalHuman without adding another costume; all oldsources/animations preserved.','targetCostumeID':d['targetCostumeID'],'proposalPath':d['proposalPath'],'proposalSHA256':d['proposalSHA256'],'sourcePNG':d['sourcePNG'],'sourceRect':d['sourceRect'],'footDatumY':d['footDatumY'],'bodyDatumX':d['bodyDatumX'],'classification':d['classification'],'evidenceURLs':[v['URL']for v in d['referenceProofs']if v.get('URL')],'localProofs':d['referenceProofs'],'limits':d['limits'],'poseCount':1,'animationCount':0})
  if h in ['core__snake__alt__snow','core__snake__alt__scientist_disguise']:out['supportingTextProofs']=[csv]
  if h=='core__snake__alt__halo_equipment':out['supersedesOnlyV1HaloSlot']=True
  if correct:out.update({'notANewCostume':True,'oldOriginalPreserved':True,'oldAnimationsPreserved':True})
 else:
  d=gaps[h];out.update({'status':'REFERENCE_GAP_NO_NEW_SOURCE','reason':d['reason'],'targetCostumeID':None,'proposalPath':None,'evidenceURLs':list(dict.fromkeys([v['URL']for v in d['proofs']if v.get('URL')]+d.get('extraEvidenceURLs',[]))),'localProofs':d['proofs'],'missingEvidence':d['missingEvidence'],'poseCount':0,'animationCount':0})
 rows.append(out)
assert len(rows)==16 and len(set(x['historicalID']for x in rows))==16
report={'schema':'cqc.p50.official-assignment-dispositions/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'batch':'c_mgs3_survive','assignmentPath':'/tmp/cqc-static-20261113/p50/assignments/c_mgs3_survive.json','sourceCommit':assignment['sourceCommit'],'assignedHistoricalRows':16,'rowsDispositioned':16,'rowsWithNewSourceProposals':11,'newOfficialCostumePoses':10,'correctedOriginalHumanPoses':1,'referenceGapRows':5,'newRawPNGPagesIncludingSuperseded':9,'generatedPoseCountIncludingSupersededHalo':12,'preferredLogicalPoseCount':11,'rows':rows,'sourcePages':sources,'OriginalSourceCopyPins':pins,'serviceModerationRefusals':[],'guards':{'EVAcyborgAttempted':False,'FearcyborgAttempted':False,'EndMetalGearAttempted':False,'noHeldFamilyAttempted':True},'changes':{'animationsGenerated':False,'SourcePixelsEditedByCPU':False,'runtimeMenuStagesVercelGitChanged':False,'globalIndexOrMapOrBuildChanged':False,'oldSourcesDeletedOrOverwritten':False},'RootAdmission':'PENDING','limitations':'Documented reference-grounded static recreations, not exact mesh/UV pixel1:1 extraction. Five precise gaps remain visible; no falseofficial aliases or label-only inventions.'}
p=ROOT/'P50_C_MGS3_SURVIVE_DISPOSITIONS_PRIVATE_V1.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'rows':16,'sourceRows':11,'gaps':5,'rawPNGs':9,'sourceBytes':sum(s['rawPNG']['bytes']for s in sources)}))
