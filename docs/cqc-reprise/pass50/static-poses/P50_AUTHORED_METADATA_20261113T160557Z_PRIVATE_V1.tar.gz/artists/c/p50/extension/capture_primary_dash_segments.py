"""Decode uncropped whole frames from published primary DASH segments. No image editing."""
from pathlib import Path
import concurrent.futures,urllib.request,subprocess,hashlib,json,xml.etree.ElementTree as ET,os
from PIL import Image
P=Path(__file__).parent;ns={'m':'urn:mpeg:dash:schema:mpd:2011'}
raw=json.load(open(P/'references/survive-appdetails.json'))['543900']['data']['movies'][0];manifestURL=raw['dash_h264'];base=manifestURL.rsplit('/',1)[0]+'/'
mpd=ET.parse(P/'references/survive-primary-movie0-manifest.mpd');rep=mpd.find('.//m:Representation[@id="0"]',ns);template=rep.find('m:SegmentTemplate',ns);scale=int(template.attrib['timescale']);duration=int(template.attrib['duration'])/scale
initURL=base+template.attrib['initialization'].replace('$RepresentationID$','0');init=urllib.request.urlopen(initURL,timeout=25).read();initPath=P/'references/survive-primary-init-stream0.m4s';initPath.write_bytes(init)
def run(n):
 u=base+template.attrib['media'].replace('$RepresentationID$','0').replace('$Number%05d$',f'{n:05d}');part=P/f'references/survive-primary-native-segment-{n:05d}.m4s';combined=P/f'references/survive-primary-native-segment-{n:05d}.mp4';out=P/f'references/survive-primary-native-frame-{(n-1)*duration:g}.jpg'
 try:
  b=urllib.request.urlopen(u,timeout=25).read();part.write_bytes(b);combined.write_bytes(init+b)
  result=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-i',str(combined),'-frames:v','1','-an','-sn','-q:v','2',str(out)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20)
  if result.returncode:raise RuntimeError(result.stderr.decode()[:200])
  frame=out.read_bytes()
  with Image.open(out)as im:size=list(im.size)
  return dict(URL=manifestURL,segmentURL=u,initializationURL=initURL,segmentPath=str(part),segmentSHA256=hashlib.sha256(b).hexdigest(),path=str(out),bytes=len(frame),sha256=hashlib.sha256(frame).hexdigest(),dimensions=size,timestampSeconds=(n-1)*duration,viewed=False,operation='First whole native1920x1080 frame decoded from explicit published DASH segment+init; no crop/resize/retouch')
 except Exception as e:return dict(URL=manifestURL,segmentURL=u,error=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as ex:r=list(ex.map(run,[31,35,41,51,61,71,81,91,101,111]))
receipt=dict(init=dict(URL=initURL,path=str(initPath),bytes=len(init),sha256=hashlib.sha256(init).hexdigest()),frames=r)
json.dump(receipt,open(P/'SURVIVE_PRIMARY_NATIVE_SEGMENTS_PRIVATE_V1.json','x'),indent=2);print(json.dumps(r))
