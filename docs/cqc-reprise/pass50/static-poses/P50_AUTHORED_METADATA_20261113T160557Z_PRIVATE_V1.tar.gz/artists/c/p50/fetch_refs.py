import urllib.request,json,hashlib,concurrent.futures
from pathlib import Path
p=Path('/tmp/cqc-static-20261113/artists/c/p50/references');p.mkdir(parents=True,exist_ok=True)
def fetch(pair):
 name,url=pair
 try:
  response=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=35);data=response.read();dst=p/name;dst.write_bytes(data); return {'path':str(dst),'URL':url,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'status':response.status}
 except Exception as exc:return {'URL':url,'error':str(exc)}
if __name__=='__main__':
 import sys
 pairs=json.loads(Path(sys.argv[1]).read_text());rows=list(concurrent.futures.ThreadPoolExecutor(5).map(fetch,pairs));Path(sys.argv[1]+'.receipts.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
