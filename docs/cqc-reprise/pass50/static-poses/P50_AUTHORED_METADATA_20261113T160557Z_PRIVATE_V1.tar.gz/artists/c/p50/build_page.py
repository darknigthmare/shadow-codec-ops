from pathlib import Path
import json,hashlib
ROOT=Path('/tmp/cqc-static-20261113/artists/c/p50')
def build(name,uid,ids,files,prompt,limits,columns=1,period=''):
 out=ROOT/name;out.mkdir(exist_ok=True)
 db=[]
 for p in ROOT.glob('FETCH_P50_*.json.receipts.json'):db+=json.loads(p.read_text())
 db+=json.loads((ROOT/'FIRST_FETCH_PRIVATE_V1.json').read_text())
 refs=[]
 for n in files:
  p=ROOT/'references'/n;r=next((r for r in db if r.get('path')==str(p)),{});refs.append({'path':str(p),'URL':r.get('URL'),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'viewed':True})
 slots=[{'uid':uid,'costumeID':cost,'historicalID':hist,'historicalAlias':hist,'label':lab,'classification':'official-same-period-costume'} for cost,hist,lab in ids]
 spec={'uid':uid,'period':period,'columns':columns,'rows':1,'rawFilename':uid+'-'+name+'-raw-v1.png','proposalFilename':'ARTIFACT_PROPOSAL_PRIVATE_V1.json','slots':slots,'referenceSources':refs,'visualReview':{'reviewer':'static_artist_c','newSpriteViewed':False,'allInputReferencesPhysicallyViewed':True,'limits':limits}}
 (out/'REGISTRATION_SPEC_PRIVATE_V1.json').write_text(json.dumps(spec,indent=2)+'\n');(out/'PROMPT_V1.txt').write_text(prompt+'\n');(out/'INPUT_REFERENCES_PRIVATE_V1.json').write_text(json.dumps([r['path'] for r in refs[:5]],indent=2)+'\n');return out
if __name__=='__main__': pass
