from pathlib import Path
import json,hashlib,datetime,re
P=Path(__file__).parent;R=P/'references'
seen={
'delta-longplay-21600.png':'EVA/Ocelot motorcycle escape; no target costume.',
'delta-longplay-23400.png':'Forest codec after Volgin finale; not target costume.',
'delta-longplay-25200.png':'The Boss death scene; not target costume.',
'ps2-longplay-18000.png':'Actual PS2 torture, Volgin still green coat; naked Snake.',
'ps2-range2-18300.png':'PS2 torture cutscene closeup Ocelot; not useful body.',
'ps2-range2-18600.png':'Actual PS2 front Survival Viewer prisoner: white wraps both upper arms + lower torso, naked/harness/TigerStripe.',
'ps2-range3-18590.png':'Actual PS2 Cure Viewer side: torso/biceps wraps.',
'ps2-range3-18615.png':'Actual PS2 rear prison: white wraps both upper arms and waist with black X harness.',
'delta-range2-14400.png':'Delta underground ladder gameplay, clothed.',
'delta-range2-16200.png':'Delta Volgin in green coat, Raikov disguise capture scene.',
'delta-range2-18000.png':'Delta Sorrow fight, naked prisoner escaping; no white body wraps seen.',
'delta-range2-19800.png':'Delta Survival Viewer menu maintenance clothing label, no relevant body.',
'delta-range3-16800.png':'Delta seated in cell: naked torso/harness, wounds, no white wraps.',
'delta-range3-17400.png':'Delta outdoor escape gameplay, naked back/harness no visible body wraps.',
'delta-range3-20400.png':'Microfilm cutscene; not target costume.',
'delta-range3-21000.png':'Delta Volgin battle intro: red cap-sleeved top + bare scarred arms, not naked torso.',
'delta-range4-16900.png':'Delta prison rear, naked wounds + harness; no wraps.',
'delta-range4-17000.png':'Delta prison rear, naked wounds + harness; no wraps.',
'delta-range4-17200.png':'Delta guard cutscene with full prisoner side; dark boots/TigerStripe, no wraps.',
'delta-range4-18200.png':'Dark Sorrow/death cutscene; not sufficient wrap evidence.',
'delta-range4-22200.png':'EVA crashed motorcycle before Shagohod arena.',
'delta-finale-22400.png':'Shagohod battle gameplay; Volgin too small to attest bare chest.',
'delta-finale-22600.png':'EVA during finale, no relevant torso.',
'delta-finale-22800.png':'EVA closeup; Volgin behind under dark lighting, insufficient torso detail.',
'delta-finale-23000.png':'Forest escape gameplay after Volgin death.',
'delta-native4k-volgin-22530.jpg':'Whole native4K retail frame: Volgin on Shagohod still wears complete red top.',
'delta-native4k-volgin-22760.jpg':'Whole native4K retail frame: Volgin struck/burning; overexposure prevents separate bare-torso configuration proof.',
'delta-native4k-volgin-22810.jpg':'Whole native4K retail frame: EVA closeup, not Volgin torso.',
'delta-altlongplay-12600.png':'Independent Delta playthrough before Raikov disguise; no target.',
'delta-altlongplay-14400.png':'Independent Delta scientist disguise combat.',
'delta-altlongplay-16200.png':'Independent Delta capture Sokolov scene, Volgin green coat.',
'delta-altprison-16950.png':'Independent Delta pursuit dogs/sewer cutscene.',
'delta-altprison-17250.png':'Independent Delta Sorrow gameplay: no visible white wraps.',
'delta-altprison-17450.png':'Independent Delta Sorrow gameplay and item menu.',
'delta-altprison-18000.png':'EVA/ Snake behind waterfall, naked harness and injuries, no white torso wraps.',
'delta-altcure-16530.png':'Independent Delta prisoner codec; upper body bruised/unwrapped.',
'delta-altcure-16600.png':'Independent Delta prisoner crawling; TigerStripe and boots, no wraps.',
'delta-altcure-16700.png':'Independent Delta naked prisoner crawling outdoors.',
'delta-altcure-16800.png':'Independent Delta prisoner descending stairs, no wraps.',
'survive-quicklook-600.png':'Retail Survive base gate/pursuit, no clear Virgil.',
'survive-quicklook-1800.png':'Retail Survive wasteland gameplay, no Virgil.',
'survive-range2-60.png':'Retail title1.02, no Virgil.',
'survive-range2-3000.png':'Retail wasteland gameplay, no Virgil.',
'survive-range3-120.png':'Retail avatar selection, no Virgil.',
'survive-range3-240.png':'Retail loading screen, no Virgil.',
'survive-range3-360.png':'Retail wasteland gameplay, no Virgil.',
'survive-range4-300.png':'Retail whole Virgil pod very close at left: black closed cylinder, upper3 red vent bars, side vertical rods; lid not visibly deployed.',
'survive-range4-480.png':'Retail inventory screen, no Virgil.',
'survive-virgil-270.png':'Retail whole Virgil pod front: optic + upper3 red vents, closed lid and complete lower cylinder.',
'survive-virgil-280.png':'Retail base ground, no close pod.',
'survive-virgil-290.png':'Retail camp characters/base, distant pod.',
'survive-virgil-3540.png':'Retail loading screen.',
'survive-primarypromo-30.png':'Konami campaign commentary intro, developer seated.',
'survive-primarypromo-90.png':'Konami action preview, no useful pod.',
'survive-primarypromo-180.png':'Konami dusty wasteland gameplay, no useful pod.',
'survive-primarypromo-300.png':'Konami transition blackscreen.',
'delta-reddit-bandaged-gallery-first.png':'Actual Delta prisoner photo; no body bandages. Poster/background not used for art.',
'delta-primary-playstation-bandaged-tree.jpg':'Primary PlayStation screenshot16: injured Snake after Virtuous Mission with two natural eyes, no bandana, left arm sling/splint, wraps both upper arms+chest+abdomen. Not post-torture prisoner proof.'}
for i in range(13):seen[f'delta-primary-screen-{i}.jpg']='Primary Steam Delta screenshot actually viewed; no separate bandaged prisoner/shirtless Volgin/OneEyed cap selector proof. Screen4 normal croc cap, screen6 red-top Volgin.'
for i in range(9):seen[f'dlc-primary-screen-{i}.jpg']='Primary Steam Sneaking DLC screenshot actually viewed; screen2 Crocodile Suit/ordinary cap, no One-Eyed cap visual distinction attested.'
for i in range(6):seen[f'survive-primary-screen-{i}.jpg']='Primary Steam Survive screenshot actually viewed; no deployed/open Virgil geometry proof.'
for i in range(20):
 name='delta-reddit-bandaged-gallery-first.png'if i==0 else f'delta-reddit-gallery-{i}.png'
 seen[name]='Actual native community Delta retail screenshot from documented Reddit gallery; bodies naked/injured with harness and no white wraps (0-16), tank-only frames17-19. Comment claiming some wraps not visually corroborated; not proof of bandaged prisoner.'
for i in range(2):
 for t in [20,40,60,80]:seen[f'survive-primary-steam-movie{i}-{t}.jpg']='Primary Steam/CDN whole trailer frame actually viewed; no open Virgil geometry established.'
for t in [90,100,110]:seen[f'survive-steam-virgil-target-{t}.jpg']='Primary Steam Launch Trailer whole frame actually viewed; no open Virgil configuration established.'
for t in [90,102,120,150,180,210,240,270,300,330]:seen[f'survive-primary-native-frame-{t}.jpg']='Primary Steam SinglePlayer direct DASH whole native frame actually viewed; no distinct open Virgil positively identified. Frame210 distant airborne cylinder unidentified; frame330 red open machine unidentified and not accepted as Virgil.'
# Build provenance lookup from downloaded receipts without claiming their initial viewed:false changed.
lookup={}
def walk(v):
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and any(k in v for k in ['URL','url']):lookup[Path(v['path']).name]=v
  for x in v.values():walk(x)
 elif isinstance(v,list):
  for x in v:walk(x)
for q in P.glob('*.json'):
 try:walk(json.load(open(q)))
 except Exception:pass
rows=[]
for f in sorted(R.iterdir()):
 if f.suffix.lower()not in ['.png','.jpg','.jpeg','.avif','.webp']:continue
 b=f.read_bytes();r=lookup.get(f.name,{})
 rows.append(dict(path=str(f),URL=r.get('URL',r.get('url')),timestampSeconds=r.get('timestampSeconds'),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),viewed=f.name in seen,observation=seen.get(f.name,'Downloaded scout/unviewable large PNG; not used as actually seen art proof.')))
report=dict(schema='cqc.p50.visual-reference-observations/1',atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),reviewer='static_artist_c',referenceImages=rows,actuallyViewed=sum(x['viewed']for x in rows),downloadedNotViewed=sum(not x['viewed']for x in rows),notes=['Video frames decoded whole, native dimensions, no crops/resizes/retouches. Native JPEG frames are separate fresh ffmpeg decodes from actual media; original4K PNG scouts remain unchanged and not claimed viewed after tool output-size failure.','No Reddit comment or web search image caption treated as sufficient appearance proof.','Archived footage and Steam/CDN primary sources all have exact URLs/timestamps/bytes/SHA in receipts. Original reference contracts remain separate.'])
q=P/'P50_C_EXTENSION_REFERENCE_OBSERVATIONS_PRIVATE_V1.json';q.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(path=str(q),sha256=hashlib.sha256(q.read_bytes()).hexdigest(),viewed=report['actuallyViewed'],unviewed=report['downloadedNotViewed'])))
