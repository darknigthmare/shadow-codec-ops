import os,json,subprocess,hashlib,sys,concurrent.futures
from pathlib import Path
out=Path('/tmp/cqc-static-20261113/artists/f/p50/extension/references')
name=sys.argv[1]; pairs=[tuple(map(int,p.split(':'))) for p in sys.argv[2:]]
env=dict(os.environ)
if env.get('HTTPS_PROXY'):env['http_proxy']=env['HTTPS_PROXY']
def frame(pair):
 part,t=pair;u=f'https://archive.org/download/PS4_Longplay_051_Metal_Gear_Solid_V_The_Phantom_Pain/PS4_Longplay_051_Metal_Gear_Solid_V_The_Phantom_Pain_Part_{part}.mp4';p=out/f'lp{part}-{name}-{t}.png'
 r={'part':part,'atSeconds':t,'URL':u,'path':str(p)}
 if not p.exists():
  try:
   z=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-rw_timeout','15000000','-ss',str(t),'-i',u,'-frames:v','1',str(p)],env=env,capture_output=True,text=True,timeout=35);r.update(exitCode=z.returncode,stderr=z.stderr)
  except Exception as e:r['error']=str(e)
 if p.exists():b=p.read_bytes();r.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(frame,pairs))
path=out/(name.upper()+'_REFERENCE_EXTRACT_PRIVATE_V1.json');path.write_text(json.dumps(rows,indent=2));print(json.dumps({'receipt':str(path),'success':sum('sha256'in x for x in rows),'rows':len(rows)}))
