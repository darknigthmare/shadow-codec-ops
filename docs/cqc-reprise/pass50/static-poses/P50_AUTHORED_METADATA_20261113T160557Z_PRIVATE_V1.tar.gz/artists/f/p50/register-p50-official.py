import os,sys,json,pathlib,hashlib,datetime
from PIL import Image
import numpy as np
from scipy import ndimage
reqpath=pathlib.Path(sys.argv[1]);gen=sys.argv[2];version=int(sys.argv[3]) if len(sys.argv)>3 else 1
job=json.loads(reqpath.read_text());base=reqpath.parent
with os.fdopen(os.open(gen,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:raw=f.read()
dest=base/(job['key']+'-raw-v'+str(version)+'.png')
assert not dest.exists()or dest.read_bytes()==raw
if not dest.exists():dest.write_bytes(raw)
im=Image.open(dest).convert('RGBA');w,h=im.size;a=np.asarray(im)[:,:,3];lab,n=ndimage.label(a>16);comps=[]
for k,sl in enumerate(ndimage.find_objects(lab),1):
 if sl is None:continue
 m=lab[sl]==k;count=int(m.sum())
 if count<500:continue
 yy,xx=np.nonzero(m);comps.append({'component':k,'pixels':count,'rect':[sl[1].start,sl[0].start,sl[1].stop-sl[1].start,sl[0].stop-sl[0].start],'centroid':[float(xx.mean()+sl[1].start),float(yy.mean()+sl[0].start)]})
cols=job['atlas']['columns'];rows=job['atlas']['rows'];slots=[]
for i,s in enumerate(job['slots']):
 c=i%cols;r=i//cols;owns=[z for z in comps if min(cols-1,int(z['centroid'][0]/w*cols))==c and min(rows-1,int(z['centroid'][1]/h*rows))==r]
 if not owns:slots.append(dict(s,status='NO_COMPONENT_REVIEW_HOLD'));continue
 x=min(z['rect'][0]for z in owns);y=min(z['rect'][1]for z in owns);x1=max(z['rect'][0]+z['rect'][2]for z in owns);y1=max(z['rect'][1]+z['rect'][3]for z in owns)
 slots.append(dict(s,sourceRect=[x,y,x1-x,y1-y],footDatumY=y1-1,bodyDatumX=(x+x1)/2,datumQualification='Bounding proposal only; direct artist anatomical-body/real-support review must update this before handoff. No runtime normalization.',poseCount=1,animationCount=0,facing='right',originalSourceRetained=True))
edges={k:int((v>16).sum())for k,v in {'top':a[0,:],'bottom':a[-1,:],'left':a[:,0],'right':a[:,-1]}.items()}
out={'schema':'cqc.static.official-generated-page-proposal/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'uid':job.get('uid'),'period':job['period'],'request':str(reqpath),'rawPNG':{'path':str(dest),'generatorPath':gen,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'width':w,'height':h,'rawPNGTransformed':False},'atlas':job['atlas'],'slots':slots,'referenceSources':job['referenceSources'],'visualReview':{'reviewer':'/root/static_artist_a/p50_msf_research — output review pending','newSpriteViewed':False,'referencesViewed':True,'sameIdentityAndPeriod':None,'sourceOnly':True,'limits':job['limits']},'alphaAnalysis':{'min':int(a.min()),'max':int(a.max()),'alphaZero':int((a==0).sum()),'alphaAbove16':int((a>16).sum()),'mainComponentsAbove16':len(comps),'edgeForegroundAbove16':sum(edges.values()),'edgeForegroundAbove16BySide':edges,'components':comps,'weakAlphaResidue1to16Present':bool(((a>0)&(a<=16)).any()),'qualification':'Analysis only; no CPU raster edit.'},'SourcePixelsEditedByCPU':False,'ASWrites':False,'GitWrites':False,'runtimeAdmitted':False,'RootAdmission':'PENDING','newAnimations':0}
p=base/(job['key'].upper().replace('-','_')+'_ARTIFACT_PROPOSAL_PRIVATE_V'+str(version)+'.json');p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'proposal':str(p),'rawPNG':out['rawPNG'],'poses':len(slots),'mainComponents':len(comps),'edgeAbove16':sum(edges.values())}))
