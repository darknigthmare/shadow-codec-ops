from pathlib import Path
import json

base=Path('/tmp/cqc-static-20261113/artists/a/p50')
assignment=json.loads(Path('/tmp/cqc-static-20261113/p50/assignments/a_pw.json').read_text())
rows={r['reconciledOfficialID']:r for r in assignment['rows'] if r['targetUID']=='core__snake_pw'}
textures=base/'research-snake/camo-textures'
provenance=json.loads((textures/'COPY_PROVENANCE_PRIVATE_V1.json').read_text())
body_proofs=json.loads((base/'references/ORIGINAL_JF_COPY_PROVENANCE_PRIVATE_V1.json').read_text())
for record in provenance+body_proofs:
 record.update(viewed=True,viewedBy='/root/static_artist_a')
(textures/'COPY_PROVENANCE_PRIVATE_V1.json').write_text(json.dumps(provenance,indent=2)+'\n')
(base/'references/ORIGINAL_JF_COPY_PROVENANCE_PRIVATE_V1.json').write_text(json.dumps(body_proofs,indent=2)+'\n')
patterns=[
 ('leaf','Leaf','Deep olive and forest green with muted khaki broad irregular leaf-like camouflage patches.'),
 ('tiger-stripe','Tiger-Stripe','Very dark muted brown/olive ground with near-black irregular mainly horizontal tiger stripes. No bright orange.'),
 ('choco-chip','Choco-Cam','Pale sandy beige/tan desert cloth with small dark chocolate-chip speckles/streaks and lighter islands.'),
 ('squares','Squares','Distinct dark RUSSET/BURGUNDY/BLACK broad rectangular checked/square block camouflage. Not green or gray.'),
 ('splitter','Splitter','Pale gray, slate and black sharply angular splinter polygons over gray cloth. Cool monochrome geometric camo.'),
 ('snake-camo','Snake','Blue-gray/steel/dark charcoal reptilian small-scale mottled pattern, fine scalelike marks. This stays cloth, not real skin/armor.'),
 ('neo-moss','Neo-Moss','Almost black dark forest-green cloth with bright yellow-green tiny clustered moss flecks and irregular green shadow patches.'),
 ('stench','Stench','Dark olive/black and rusty brown weathered smeared irregular patches and amber-brown streaks. Different from plain Leaf.'),
 ('tigrex','Tigrex','Rich burnt ORANGE/copper fabric with broad dark charcoal/black and muted green angular stripes/irregular patches. Cloth only.'),
 ('rathalos','Rathalos','Muted dusty ROSE/salmon PINK ground with large black/dark charcoal jagged angular patches/streaks. No orange/green substitution.'),
 ('gear-rex','Gear-Rex','Monochrome medium gray/black broad SQUARE BLOCKS/checked bands with lighter gray bands. Grid/checker motif, not splinter polygons.')
]
common='''Create a NEW STATIC official alternate-costume sprite page of adult BIG BOSS/NAKED SNAKE, original 2010 PSP METAL GEAR SOLID PEACE WALKER (1974). Exactly ONE quiet neutral standing RIGHT/front-three-quarter fullbody pose per DIFFERENT outfit, no animation or extra repeated figure. High-detail crisp hand-painted 2D/2.5D fighting-game art, actual transparent alpha0 background, solid opaque sprites, no floor, shadow, haze, glow, text, labels, UI or grid.
FIRST attached PRIMARY Konami fullbody render establishes the same mature brown-bearded/brown-haired PW face/body, dark charcoal forehead bandana/tails and black eyepatch on anatomical RIGHT eye. Two natural arms and legs. No MGS3/Delta/MGSV face, horn/prosthetic arm or Miller head.
Same original PW JUNGLE FATIGUES construction on ALL slots: short-sleeve collared military shirt/chest pockets, black upper-arm bands, black forearm protectors, black fingerless gloves, olive-green webbing Y harness/chest crossstrap, olive belt/hip pouches and RIGHT thigh holster/straps, matching cloth cargo trousers, black military lace-up boots, ONE elongated black kneepad only on anatomical RIGHT knee/shin like PRIMARY render. No Battle Dress armor plates or second kneepad. Rifle is same original PW M16A1 fixed stock/carry handle/triangular handguard, both hands low-ready barrel RIGHT; RIGHT pistol grip/LEFT fore-end. One attached rifle, not firing. No cropped hair, headband tails, fingers, rifle or boots.
The following textures are newly examined actual original PSP game assets. Reproduce EACH actual visible pattern, not a generic camouflage inferred from its name. Keep olive webgear/black guards separate from the patterned shirt and pants. Paint each costume anew, no recolor/filter/copy. Same character, era and physical scale on all figures.'''
for number,group in enumerate([patterns[:4],patterns[4:8],patterns[8:]],1):
 slug=f'snake-jf-camos-{number:02d}'
 directory=base/slug; directory.mkdir(exist_ok=True)
 count=len(group); columns=2 if count==4 else 3; row_count=2 if count==4 else 1
 references=[dict(body_proofs[1],scope='PRIMARY original Konami JF fullbody: identity, garment construction, boots and equipment; default green is not proof of other patterns.'),dict(body_proofs[0],scope='Own sameUID native Original identity/build only; its Battle Dress armor must not transfer.')]
 paths=[body_proofs[1]['path']]; slots=[]; descriptions=[]
 for index,(suffix,folder,description) in enumerate(group):
  row=rows['official--jungle-fatigues-'+suffix]
  slots.append({'uid':'core__snake_pw','costumeID':row['reconciledOfficialID'],'historicalID':row['historicalID'],'label':row['historicalCostumeName'],'classification':'official-same-period-costume','textureFolder':folder,'textureObservation':description})
  paths.append(str(textures/(folder+'-shirtfrontpockets.png')))
  for record in provenance:
   if Path(record['path']).name in [folder+'-shirtfrontpockets.png',folder+'-legs.png']:
    references.append(dict(record,appliesToCostumeIDs=[row['reconciledOfficialID']],scope='New P50 named original PSP uniform texture from extracted MSF Male Fatigues. Shared same-era cloth pattern on canonical Snake JF body; no MSF head/UID transfer. Exact UV placement is interpreted.'))
  descriptions.append(f'SLOT {index}, row-major order, {row["historicalCostumeName"]}: {description} Attached image {index+2} is its exact shirt texture. Apply COLOR/PATTERN to shirt and trousers, not the raw UV layout, pocket/shadow triangles or surrounding empty areas.')
 layout=f'OUTPUT exactly {count} figures, {columns} columns x {row_count} rows, row-major order, landscape 1536x1024 RGBA. Full bodies about 430px high in 2-row pages or 850px high in 1-row pages. Invisible cells, at least 24px clear outer margins and 32px clear gutters. Feet share a baseline in each row; same anatomical stature/scale. Each rifle, boot and bandana tail stays entirely in its own cell. '
 request={'schema':'cqc.p50.static-official-request/1','uid':'core__snake_pw','slug':slug,'period':'Original 2010 PSP Peace Walker, 1974 Naked Snake. Same-period official JF patterns; original Snake identity and body retained.','atlas':{'columns':columns,'rows':row_count,'onePosePerCostume':True,'animations':False},'slots':slots,'referenceSources':references,'generationReferencePaths':paths,'prompt':common+'\n'+layout+'\n'+'\n'.join(descriptions),'limits':'Named game-ripped original PSP textures from MSF Male Fatigues asset331661 define shared official cloth patterns on PRIMARY Konami original Snake JF body. No MSF head/UID transfer. Painted repeat/UV distribution and microscopic details are interpreted, not certified exact original Snake mesh/UV/shader equivalence. Existing sprites and invented outfits remain unchanged.','newAnimations':0}
 path=directory/'REQUEST_PRIVATE_V1.json'; path.write_text(json.dumps(request,ensure_ascii=False,indent=2)+'\n'); print(path)
