exec(open('/tmp/cqc-static-20261113/artists/a/p50/extension17/read_public_japan_dlc_zip.py').read().split('stream=RangeFile()')[0])
stream=RangeFile();dest=base/'dlc-jp-extracted';dest.mkdir(exist_ok=True);out=[]
with zipfile.ZipFile(stream)as archive:
 for z in archive.infolist():
  if 'NPJH50045DLCTEX/' not in z.filename:continue
  n=Path(z.filename).name
  if not (n in ['DATA0000.SYS','TDLSFILE.SYS'] or n.startswith('CMD000')and n.endswith('.PDT')and int(n[3:8])<24):continue
  b=archive.read(z);f=dest/n;f.write_bytes(b);out.append(dict(path=str(f),archiveMember=z.filename,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),crc32=f'{z.CRC:08x}',magic=b[:32].hex()))
(base/'PUBLIC_JP_RAW_CAMO_EXTRACTION_PRIVATE_V1.json').write_text(json.dumps(dict(url=url,archiveBytes=size,rangeOnly=True,noWholeArchive=True,members=out,rangeReads=stream.requests),indent=2))
print(json.dumps(dict(files=len(out),totalBytes=sum(x['bytes']for x in out),firstHeaders=out[:3]),indent=2))
