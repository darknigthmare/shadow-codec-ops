import io,json,urllib.request,urllib.parse,zipfile,hashlib
from pathlib import Path
base=Path('/tmp/cqc-static-20261113/artists/a/p50/extension17')
filename='MGS PW JAPAN DLC.zip'
url='https://archive.org/download/mgs-pw-japan-dlc/'+urllib.parse.quote(filename)
size=359565791
class RangeFile(io.RawIOBase):
 def __init__(self):self.position=0;self.requests=[]
 def readable(self):return True
 def seekable(self):return True
 def tell(self):return self.position
 def seek(self,offset,whence=0):
  self.position=offset if whence==0 else self.position+offset if whence==1 else size+offset
  return self.position
 def read(self,n=-1):
  n=size-self.position if n<0 else min(n,size-self.position)
  if n<=0:return b''
  if n>2*1024*1024:raise ValueError('Refusing full archive read; select small reference members only.')
  start=self.position;end=start+n-1
  request=urllib.request.Request(url,headers={'Range':f'bytes={start}-{end}'})
  with urllib.request.urlopen(request,timeout=25)as response:
   if response.status!=206:raise ValueError('Server did not honor public HTTPRange.')
   data=response.read(n);self.requests.append({'start':start,'end':end,'status':response.status,'bytes':len(data)})
  self.position+=len(data);return data
stream=RangeFile()
with zipfile.ZipFile(stream)as archive:
 entries=[{'name':z.filename,'size':z.file_size,'compressedSize':z.compress_size,'crc32':f'{z.CRC:08x}'}for z in archive.infolist()]
 (base/'PUBLIC_JP_PW_DLC_ZIP_MEMBER_LIST_PRIVATE_V1.json').write_text(json.dumps({'url':url,'archiveBytes':size,'archiveSHA1FromIA':'e8ab87970e7e994355b0000335c62faf2c9795d0','members':entries,'rangeReads':stream.requests},indent=2)+'\n')
 print(json.dumps({'count':len(entries),'members':entries[:70]}))
