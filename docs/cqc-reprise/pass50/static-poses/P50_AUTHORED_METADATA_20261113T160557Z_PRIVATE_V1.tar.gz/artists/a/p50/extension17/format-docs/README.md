# Peace Walker Localization Tool

**Work in progress.** A tool for localizing **METAL GEAR SOLID: Peace Walker — Master Collection Version** into your language.

Made in Ukraine 🇺🇦 by **Dmytro Bidlov** — [Little Bit Team](https://t.me/LittleBitUA)

> *(Українською — [нижче](#peace-walker-localization-tool-ua).)*

---

## Running it

Download the release, run `PeaceWalkerLocalizationTool.exe`. Nothing to
install, no Python needed. The game is found automatically in your Steam
libraries; if it sits somewhere unusual, point the **Game folder** field at
`…/MGS_PW/mgspw`.

From source:

```
pip install numpy pillow lz4
python src/pw_studio.py
```

Python 3.10+. Build the executable with `python build.py`.

---

## What it does

### Text

**Unpack text** reads every `.olang` language table, decrypts it, and writes one
editable file:

```
### 1  — OLANG/MLG/0005ee2f/0001/en · AI Weapon Voices
AI Weapon Voices
```

Translate the line **below** each `###` header and leave the header alone — it
carries the write-back address (`OLANG/<folder>/<file>/<pool index>/<languages>`).

**Pack** applies it back and re-encrypts. Blocks you did not touch are skipped,
so a partial translation is fine, and untouched entries stay byte-identical.
**Nothing is written into the game folder** — installing is a separate step you
take yourself.

The game ships six languages: English, French, German, Italian, Japanese,
Spanish. The **English entries only** checkbox is on by default; the filter is
exact, not guesswork, because every string reference stores its language
explicitly (see [docs/FORMATS.md §5](docs/FORMATS.md)).

### Story text

The shipped `.olang` files are only the peripheral text — options screens,
lobby, online errors. **The story itself is somewhere else entirely.**

It lives in `SLOT.DAT` (`MLG/disc0_rel/002aba34.DAT` plus its `.KEY`), as
**4 458 `.olang` files inside 2 137 compressed blocks — 145 groups, 52 396
distinct strings, about 10 000 English lines**, subtitles included.

Extract it to one editable `.txt`, translate, and put it back. Only blocks
whose text actually changed are rewritten, and the `.KEY` is copied byte for
byte so every block identity stays stock.

### Fonts

The fonts are textures, and there is not one of them — there are **hundreds**,
spread across four different containers:

| where | sheets |
|---|---|
| `Text/*.txp`, `loading/*.txp` | ~159 glyph sheets over 8 packages |
| `FONT/*.xpr` | 2 XPR2 faces — the subtitles |
| `002aba34.DAT` (SLOT) | 215 more sheets inside `.slot` elements |
| `009645fa.PDT` (STAGEDAT) | `db_font.txp`, `fontprint.txp` |

**Scan every font** writes a catalogue and a readable PNG per sheet. **Type
Cyrillic into the fonts** renders an alphabet and writes it into every sheet
it can reach, in every package at once.

You pick a **separate typeface for the menu face and for the subtitle face**,
because they are genuinely different designs.

Two things make this less simple than it sounds, and the tool handles both:

- The caps UI face is **duplicated byte-for-byte across several packages** —
  ten copies of one sheet alone. Patching one and launching the game is the
  classic way to see no change at all, because the game loads whichever
  package the current language selects.
- Of the 160 sheets on that grid, only **35 have their spare band actually
  free**. The rest already store their own glyphs there, and their free cells
  do not line up with each other, so one shared byte mapping cannot reach
  them. Those are reported and skipped rather than overwritten.

---

### Textures

Unpacks the `.txp` texture packages, the `FONT/*.xpr` glyph sheets and the
`STAGEDAT.PDT` container.

`STAGEDAT.PDT` is followed all the way down. An entity is not a texture — the
pictures sit three levels in (`.PDT` entity → QAR sub-archive → `.txp` member →
DDS), so unpacking it yields **142 sub-archives and 9 743 textures**, not 557
opaque blobs.

Textures are written as **`.dds`, byte-for-byte as they sit in the game** —
verified identical on all 84 textures of `008299c5.txp`. Alongside each sheet
that looks like a font you also get a `__INK.png`: that is **not** game data,
it is a preview this tool renders so you can actually see the glyphs, because
the originals are white on transparent and look like a blank page in any
viewer. Each folder gets a `contents.tsv` index.

---

## Project layout

```
build.py              builds the one-file executable with PyInstaller
docs/FORMATS.md       the full write-up of every format, in English and Ukrainian
src/
    pw_studio.py      the GUI — the only entry point
    pwpaths.py        finds the game in your Steam libraries; picks the output folder
    pwcrypt.py        the Master Collection cipher, both directions
    olang.py          the .olang text tables: read, write, export, apply a translation
    pdt.py            the .PDT container: header, tables, per-entity decryption
    pdt_unpack.py     unpacks a whole .PDT (STAGEDAT and the rest)
    qar.py            the QAR sub-archives found inside .PDT entries
    txp_unpack.py     the .txp texture packages
    pwfont.py         the FONT/*.xpr glyph sheets: atlas, character map, glyph records
    pwfont_unpack.py  dumps a font to atlas, glyph PNGs, charmap and coverage
    pwtex.py          DDS mip arithmetic, BC1/BC3 decoding, glyph-grid detection
    txp_pack.py       puts edited .dds back into a .txp package
    pdt_pack.py       rebuilds a .PDT — byte-exact when nothing changed
    slotdat.py        the SLOT container: KEY records, blocks, splice
    slotitem.py       the .slot element directory inside a block
    slottext.py       story text out of SLOT.DAT and back in
    pwbc.py           BC1/BC3 encoding, and per-block patching
    pwfontatlas.py    the UI font grid: cells, TTF rendering, installation
    pwfonts.py        finds every font in the game; installs per role
    pwxpr.py          writing glyphs into an XPR2 subtitle face
```

Every module also runs standalone from the command line — `python src/olang.py
export`, `python src/qar.py list <file>`, and so on.

---

## How the formats work

The full technical write-up, with function addresses and structure layouts, is
in **[docs/FORMATS.md](docs/FORMATS.md)**. The short version:

**The cipher.** Every asset is wrapped in one symmetric stream cipher keyed by
the *file name* — MT19937 seeded the 1998 way, twisted immediately, first five
words skipped, each dword XORed with the keystream and `0xB9D3018F`. Two things
bite here: a naively vectorised MT twist silently corrupts 169 of every 624
words in one contiguous run, and the keystream **restarts on every read**, which
is what hides the `.PDT` payloads.

**Names.** Almost nothing is stored by name; a 24-bit rotate-and-add hash is
used instead. It resolves every archive on disk — `STAGEDAT.PDT` → `009645fa.PDT`,
`BGM.PDT` → `0001112d.PDT`, and so on, eight for eight.

**`.PDT`.** Three layers. Magic `0x007A7E9C` proves a good decrypt. The second
layer is one of two ciphers chosen by `HashKey2` — a plain byte XOR, or an LCG
— and the third is per-entity zlib. `STAGEDAT.PDT` unpacks 557 of 557 entries,
each inflating to exactly its declared size.

**`.olang`.** A six-language string pool addressed by those 24-bit hashes.
Round trip is byte-exact on all 17 shipped files.

**`SLOT.DAT`.** Three layers again. The outer cipher **restarts at every
block**, exactly as it restarts per entity in a `.PDT`; layer two is an affine
word stream seeded from the `.KEY` header; layer three is zlib behind a
16-byte block header. The `.KEY` record is 20 bytes, and the field that
misleads is `pageCount` — the block's real footprint is `endPage - startPage`.
By that measure the container tiles the whole file with zero holes, so the
~55 MB that looks like free space is padding *inside* other blocks. The record
hash is a block **identity**, not a checksum: recomputing it loses models.

**Fonts.** The game has **three** separate font systems: `FONT/*.xpr` for
subtitles (Xbox 360 XPR2 bundles with a Unicode-indexed character map),
`db_font`/`fontprint` inside `STAGEDAT.PDT`, and DDS atlases in the `.txp`
packages.

The UI atlas turned out to be a plain byte grid after all — `cell = byte -
0x20`, 28×48 cells — with one twist that hides it: **the first cell of each
row sits alone at the right-hand edge of the sheet**, and the other fifteen
run from the left. That is why the sheet appears to start at `Q` while `P`
floats far to the right. The reading was then confirmed against strings the
game itself ships: this face has no lowercase, so accented letters are stored
in the lowercase byte range, and `hQUIPE`, `CONFIGURACIpN` and `DRvCKEN` all
land exactly where the formula puts them.

The `.xpr` subtitle faces are different in a useful way: their character map is
indexed by **real Unicode**, with tens of thousands of empty slots. Their atlas
is plain linear 8-bit alpha, so it can be written directly.

---

## Status

**Work in progress. None of this has been tested in the running game yet** —
the formats are analysed and the round trips are proven on disk, but nothing
here has been put in front of the renderer. Treat every output as a candidate,
keep backups, and expect to iterate.

What is proven, on the real game files:

| | |
|---|---|
| the cipher, both directions | byte-exact on every shipped asset |
| `.olang` round trip | 17 / 17 shipped files byte-identical |
| `SLOT.DAT` | 2 137 / 2 137 blocks decode; `.slot` rebuild byte-identical 2 137 / 2 137; 4 458 / 4 458 `.olang` inside them rebuild byte-identical |
| `.PDT` rebuild | an untouched repack of the 511 MB `STAGEDAT` is **byte-identical** to the original |
| `.txp` round trip | opening and saving a package unchanged is byte-identical |
| BC3 encoding | re-encoding a real block reproduces it exactly |
| font installation | rows outside the target band stay bit-identical; 0.076% of the package changes |

Known limits:

- **Not tested in game.** Nothing above says the engine likes the result.
- The text still has to be stored with the byte values the atlas cells answer
  to. The tool can render the alphabet and knows the mapping, but wiring that
  substitution into the text-packing path is not finished.
- 125 of the 160 sheets on the UI grid cannot take the shared mapping (see
  **Fonts** above); they are skipped, not overwritten.
- Two `SLOT.DAT` blocks overflow their footprint when recompressed after a
  font edit, and are reported and skipped.
- The glyph rectangle table for `db_font` / `fontprint` inside `STAGEDAT.PDT`
  is still not mapped, so those sheets are dump-only.

---

## Credits and licence

Made in Ukraine by **Dmytro Bidlov** ([Little Bit Team](https://t.me/LittleBitUA)).
MIT licence — see [LICENSE](LICENSE).

This project ships **no game data**. Metal Gear Solid and Peace Walker are
trademarks of Konami; this tool is independent and not endorsed by Konami.

---
---

<a name="peace-walker-localization-tool-ua"></a>

# Peace Walker Localization Tool (українською)

**У розробці.** Програма для локалізації **METAL GEAR SOLID: Peace Walker — Master Collection Version** вашою мовою.

Зроблено в Україні 🇺🇦 **Дмитром Бидловим** — [Little Bit Team](https://t.me/LittleBitUA)

---

## Як запустити

Завантаж реліз і запусти `PeaceWalkerLocalizationTool.exe`. Встановлювати
нічого не треба, Python не потрібен. Гра знаходиться автоматично у твоїх
бібліотеках Steam; якщо вона лежить десь незвично, вкажи в полі **Тека гри**
шлях до `…/MGS_PW/mgspw`.

З вихідного коду:

```
pip install numpy pillow lz4
python src/pw_studio.py
```

Потрібен Python 3.10 або новіший. Зібрати exe: `python build.py`.

---

## Що вміє

### Текст

**Розпакувати текст** читає всі мовні таблиці `.olang`, розшифровує їх і
складає один файл для редагування:

```
### 1  — OLANG/MLG/0005ee2f/0001/en · AI Weapon Voices
AI Weapon Voices
```

Перекладай рядок **під** кожним заголовком `###`, а сам заголовок не чіпай — у
ньому адреса для зворотного запису (`OLANG/<тека>/<файл>/<індекс у пулі>/<мови>`).

**Запакувати** застосовує переклад назад і зашифровує. Блоки, яких ти не
торкався, пропускаються, тож частковий переклад цілком нормальний, а незаймані
рядки лишаються байт у байт. **У теку гри нічого не записується** —
встановлення це окремий крок, який ти робиш сам.

У грі шість мов: англійська, французька, німецька, італійська, японська,
іспанська. Галочка **«Лише англійські записи»** увімкнена за замовчуванням, і
фільтр цей точний, а не на око: кожне посилання на рядок зберігає свою мову
явно (див. [docs/FORMATS.md §5](docs/FORMATS.md)).

### Сюжетний текст

Комплектні `.olang` — це лише периферійний текст: екрани опцій, лобі, помилки
мережі. **Сам сюжет лежить зовсім в іншому місці.**

Він у `SLOT.DAT` (`MLG/disc0_rel/002aba34.DAT` разом із `.KEY`): **4 458
файлів `.olang` усередині 2 137 стиснених блоків — 145 груп, 52 396 унікальних
рядків, близько 10 000 англійських**, разом із субтитрами.

Витягується в один `.txt`, перекладається і повертається назад. Перезаписуються
лише ті блоки, де текст справді змінився, а `.KEY` копіюється байт у байт, тож
ідентифікатори блоків лишаються стоковими.

### Шрифти

Шрифти — це текстури, і їх не один, а **сотні**, у чотирьох різних контейнерах:

| де | аркушів |
|---|---|
| `Text/*.txp`, `loading/*.txp` | ~159 у 8 пакетах |
| `FONT/*.xpr` | 2 гарнітури XPR2 — субтитри |
| `002aba34.DAT` (SLOT) | ще 215 усередині елементів `.slot` |
| `009645fa.PDT` (STAGEDAT) | `db_font.txp`, `fontprint.txp` |

**Знайти всі шрифти** складає каталог і PNG на кожен аркуш. **Втайпити
кирилицю** малює абетку й вписує її в усі аркуші, до яких може дотягнутися,
одразу в усіх пакетах.

Гарнітура обирається **окремо для меню й окремо для субтитрів**, бо це справді
різні шрифти.

Дві речі роблять це складнішим, ніж звучить, і програма враховує обидві:

- Капсовий шрифт інтерфейсу **побайтово продубльований у кількох пакетах** —
  лише одного аркуша є десять копій. Пропатчити один і запустити гру — це
  класичний спосіб не побачити змін, бо гра підвантажує пакет під поточну мову.
- Зі 160 аркушів на цій сітці лише **35 мають справді вільну смугу**. Решта вже
  зберігає там власні гліфи, і вільні комірки в них не збігаються між собою,
  тож єдина спільна байтова мапа до них не дотягується. Такі аркуші програма
  показує у звіті й пропускає, а не перезаписує.

---

### Текстури

Розпаковує пакети `.txp`, шрифтові аркуші `FONT/*.xpr` і контейнер
`STAGEDAT.PDT`.

`STAGEDAT.PDT` розбирається до самого дна. Запис — це ще не текстура: картинки
лежать на три рівні глибше (запис `.PDT` → підархів QAR → член `.txp` → DDS),
тож на виході **142 підархіви і 9 743 текстури**, а не 557 незрозумілих блобів.

Текстури зберігаються як **`.dds`, байт у байт такими, як вони лежать у грі** —
перевірено на всіх 84 текстурах `008299c5.txp`. Поруч із кожним аркушем, схожим
на шрифт, з'являється ще `__INK.png`: це **не** ігровий файл, а прев'ю, яке
малює сама програма, щоб гліфи було видно — бо оригінали білі на прозорому і в
будь-якому переглядачі виглядають як порожня сторінка. У кожній теці є опис
вмісту `contents.tsv`.

---

## Структура проєкту

```
build.py              збирає однофайловий exe через PyInstaller
docs/FORMATS.md       повний розбір усіх форматів, англійською та українською
src/
    pw_studio.py      графічний інтерфейс — єдина точка входу
    pwpaths.py        шукає гру в бібліотеках Steam; обирає теку результату
    pwcrypt.py        шифр Master Collection в обидва боки
    olang.py          текстові таблиці .olang: читання, запис, експорт, застосування перекладу
    pdt.py            контейнер .PDT: заголовок, таблиці, розшифрування записів
    pdt_unpack.py     розпаковує весь .PDT (STAGEDAT та інші)
    qar.py            підархіви QAR усередині записів .PDT
    txp_unpack.py     пакети текстур .txp
    pwfont.py         шрифтові аркуші FONT/*.xpr: атлас, таблиця символів, записи гліфів
    pwfont_unpack.py  вивантажує шрифт в атлас, PNG гліфів, таблицю символів і покриття
    pwtex.py          арифметика мипів DDS, декодування BC1/BC3, пошук сітки гліфів
    txp_pack.py       повертає змінені .dds у пакет .txp
    pdt_pack.py       перезбирає .PDT — побайтово точно, якщо нічого не змінювалось
    slotdat.py        контейнер SLOT: записи KEY, блоки, сплайс
    slotitem.py       каталог елементів .slot усередині блока
    slottext.py       сюжетний текст із SLOT.DAT і назад
    pwbc.py           кодування BC1/BC3 і поблокове патчення
    pwfontatlas.py    сітка шрифту інтерфейсу: комірки, рендер із TTF, встановлення
    pwfonts.py        знаходить усі шрифти гри; встановлює за ролями
    pwxpr.py          запис гліфів у гарнітуру субтитрів XPR2
```

Кожен модуль працює і окремо з командного рядка — `python src/olang.py export`,
`python src/qar.py list <файл>` тощо.

---

## Як влаштовані формати

Повний технічний розбір, з адресами функцій і розкладками структур, — у
**[docs/FORMATS.md](docs/FORMATS.md)**. Коротко:

**Шифр.** Кожен ассет загорнутий в один симетричний потоковий шифр, ключем
якого є *ім'я файлу*: MT19937 із засівом за схемою 1998 року, одразу скручений,
перші п'ять слів пропущено, кожне слово XOR-иться з потоком і `0xB9D3018F`. Тут
дві пастки: наївно векторизований скрут MT тихо псує 169 слів із кожних 624
суцільним блоком, а сам потік **перезапускається на кожному читанні** — саме це
й ховає вміст `.PDT`.

**Імена.** Майже ніщо не зберігається під іменем — замість цього 24-бітний хеш
із зсувом і додаванням. Він розкриває всі архіви на диску: `STAGEDAT.PDT` →
`009645fa.PDT`, `BGM.PDT` → `0001112d.PDT` і так далі, вісім із восьми.

**`.PDT`.** Три шари. Магія `0x007A7E9C` підтверджує вдале розшифрування.
Другий шар — один із двох шифрів, який обирається за `HashKey2`: простий
побайтовий XOR або LCG. Третій — zlib на кожен запис. `STAGEDAT.PDT`
розпаковується повністю: 557 із 557 записів, кожен рівно в оголошений розмір.

**`.olang`.** Пул рядків на шість мов, адресований тими самими 24-бітними
хешами. Перезбирання побайтово точне на всіх 17 файлах.

**`SLOT.DAT`.** Знову три шари. Зовнішній шифр **перезапускається на кожному
блоці**, так само як на кожному записі в `.PDT`; другий шар — афінний
пословний потік із засівом із заголовка `.KEY`; третій — zlib за 16-байтовим
заголовком блока. Запис `.KEY` має 20 байтів, і поле, яке вводить в оману, —
`pageCount`: справжній футпринт блока це `endPage - startPage`. За цією мірою
контейнер вкриває весь файл без жодної дірки, тож ті ~55 МБ, що виглядають як
вільне місце, — це доповнення *всередині* інших блоків. Хеш у записі — це
**ідентифікатор** блока, а не контрольна сума: перерахувати його означає
втратити моделі.

**Шрифти.** У грі **три** окремі шрифтові системи: `FONT/*.xpr` для субтитрів
(пакунки Xbox 360 XPR2 з таблицею символів за Unicode), `db_font`/`fontprint`
усередині `STAGEDAT.PDT` і DDS-атласи в пакетах `.txp`.

Атлас інтерфейсу виявився звичайною байтовою сіткою — `комірка = байт - 0x20`,
комірки 28×48 — з однією особливістю, яка це ховає: **перша комірка кожного
рядка стоїть окремо біля правого краю аркуша**, а решта п'ятнадцять ідуть
зліва. Саме тому здається, що рядок починається з `Q`, тоді як `P` висить
далеко справа. Прочитання підтверджено рядками, які возить сама гра: ця
гарнітура не має малих літер, тож акцентовані символи зберігаються в діапазоні
малих, і `hQUIPE`, `CONFIGURACIpN` та `DRvCKEN` лягають рівно туди, куди веде
формула.

Гарнітури субтитрів `.xpr` відрізняються корисним чином: їхня таблиця символів
індексується **справжнім Unicode** і має десятки тисяч порожніх місць, а атлас
є простим лінійним 8-бітним альфа-масивом, тож у нього можна писати напряму.

---

## Стан робіт

**Робота триває. Нічого з цього ще не перевірено в запущеній грі** — формати
розібрано, зворотні перетворення доведено на диску, але жоден результат ще не
показували рушієві. Ставтеся до кожного файлу як до кандидата, робіть резервні
копії й будьте готові до ітерацій.

Що доведено на справжніх файлах гри:

| | |
|---|---|
| шифр в обидва боки | побайтово на кожному ресурсі гри |
| `.olang` туди-назад | 17 із 17 файлів побайтово тотожні |
| `SLOT.DAT` | 2 137 із 2 137 блоків читаються; перезбірка `.slot` побайтова 2 137/2 137; 4 458 із 4 458 `.olang` усередині — теж побайтово |
| перезбірка `.PDT` | перепаковка 511 МБ `STAGEDAT` без змін **побайтово тотожна** оригіналу |
| `.txp` туди-назад | відкрити й зберегти пакет без змін — побайтово тотожно |
| кодування BC3 | перекодування реального блока відтворює його точно |
| встановлення шрифту | рядки поза цільовою смугою лишаються біт-у-біт; змінюється 0,076% пакета |

Відомі обмеження:

- **Не перевірено в грі.** Жоден із пунктів вище не каже, що рушій прийме результат.
- Текст усе ще треба зберігати тими байтами, на які відгукуються комірки атласа.
  Програма вміє намалювати абетку й знає мапу, але під'єднання цієї підміни до
  шляху пакування тексту ще не завершене.
- 125 зі 160 аркушів сітки інтерфейсу не приймають спільну мапу (див. **Шрифти**);
  вони пропускаються, а не перезаписуються.
- Два блоки `SLOT.DAT` не влазять у свій футпринт після перестискання зі змінами
  шрифту — вони показуються у звіті й пропускаються.
- Таблиця прямокутників гліфів для `db_font` / `fontprint` усередині
  `STAGEDAT.PDT` досі не розібрана, тож ті аркуші лише вивантажуються.

---

## Автор і ліцензія

Зроблено в Україні **Дмитром Бидловим** ([Little Bit Team](https://t.me/LittleBitUA)).
Ліцензія MIT — див. [LICENSE](LICENSE).

Проєкт **не містить жодних ігрових даних**. Metal Gear Solid і Peace Walker —
торговельні марки Konami. Проєкт незалежний і не схвалений Konami.
