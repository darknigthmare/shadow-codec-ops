const results=await Promise.allSettled(requestPaths.map(async requestPath=>{
 const fetched=await tools.exec_command({cmd:'cat '+requestPath,max_output_tokens:18000});
 const job=JSON.parse(fetched.output);
 try{
  const generated=await tools.image_gen__imagegen({prompt:job.prompt,referenced_image_paths:job.generationReferencePaths,transparent_background:true});
  const path=generated.output_hint?.match(/\/workspace\/generated_images\/exec-[a-f0-9-]+\.png/)?.[0];
  if(!path)throw Error('Successful output lacks exact W path; no regeneration.');
  const receipt=await tools.exec_command({cmd:'python /tmp/cqc-static-20261113/artists/a/p50/register_p50_official.py '+requestPath+' '+path+' 1',max_output_tokens:1800});
  text(receipt.output);generatedImage(generated);return {slug:job.slug,status:'EXACT_PNG_PRESERVED'};
 }catch(error){
  const message=String(error),blocked=message.includes('moderation_blocked');
  const record={slug:job.slug,uid:job.uid,costumeIDs:job.slots.map(s=>s.costumeID),status:blocked?'MODERATION_BLOCKED_NO_OUTPUT_NO_RETRY':'TECHNICAL_ERROR_NO_AUTOMATIC_RETRY',error:message,requestID:message.match(/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/)?.[0],noRetry:true};
  await tools.apply_patch('*** Begin Patch\n*** Add File: '+requestPath.replace('REQUEST_PRIVATE_V1.json','IMAGEGEN_FAILURE_NO_RETRY_PRIVATE_V1.json')+'\n+'+JSON.stringify(record,null,2).split('\n').join('\n+')+'\n*** End Patch');text(record);return record;
 }
}));text(results.map(r=>r.status==='fulfilled'?r.value:{error:String(r.reason)}));
