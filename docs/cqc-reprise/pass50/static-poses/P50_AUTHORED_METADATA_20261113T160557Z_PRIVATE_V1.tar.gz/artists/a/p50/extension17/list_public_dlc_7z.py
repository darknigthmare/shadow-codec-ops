import sys,io,urllib.request,json,pathlib,hashlib,os
sys.path.insert(0,'/tmp/cqc-p50-a-reference-7z-tools')
import py7zr
P=pathlib.Path('/tmp/cqc-static-20261113/artists/a/p50/extension17')
class PublicRange(io.RawIOBase):
 def __init__(self):self.pos=0;self.size=494313707;self.receipts=[];self.readTotal=0;self.cache={}
 def seekable(self):return True
 def readable(self):return True
 def tell(self):return self.pos
 def seek(self,off,whence=0):
  self.pos=off if whence==0 else self.pos+off if whence==1 else self.size+off
  if self.pos<0:raise ValueError('negative seek')
  return self.pos
 def read(self,n=-1):
  if n<0:n=self.size-self.pos
  n=min(n,self.size-self.pos)
  if not n:return b''
  if n>4*1024*1024 or self.readTotal+n>16*1024*1024:raise ValueError('Reference range budget; no whole unrelated bundle download')
  key=(self.pos,n)
  if key in self.cache:b=self.cache[key]
  else:
   u='https://archive.org/download/psp-dlc-usa.-7z/PSP%20DLC%20%28USA%29.7z';req=urllib.request.Request(u,headers={'Range':f'bytes={self.pos}-{self.pos+n-1}'})
   with urllib.request.urlopen(req,timeout=25) as r:
    if r.status!=206:raise ValueError('Expected public206')
    b=r.read(n)
   self.readTotal+=len(b);self.cache[key]=b;self.receipts.append(dict(offset=self.pos,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
  self.pos+=len(b);return b
f=PublicRange()
with py7zr.SevenZipFile(f,'r')as z:
 files=[]
 for x in z.files:
  d=dict(name=x.filename,uncompressed=x.uncompressed,compressed=x.compressed,isDirectory=x.is_directory)
  files.append(d)
 info=None
 stream=z.header.main_streams
 streamInfo=dict(packSizes=stream.packinfo.packsizes,folders=len(stream.unpackinfo.folders),numUnpackStreams=stream.substreamsinfo.num_unpackstreams_folders)
 out=dict(files=files,archiveInfo=streamInfo,httpRanges=f.receipts,bytesRead=f.readTotal)
 (P/'public-usa-dlc-7z-listing.json').write_text(json.dumps(out,indent=2))
 print(json.dumps(dict(archive=out['archiveInfo'],fileCount=len(files),pw=[x for x in files if any(t in x['name'].lower() for t in ['peace','10509'])],bytesRead=f.readTotal),indent=2))
