import pathlib,os,sys,json,hashlib,datetime
from PIL import Image
import numpy as np
from scipy import ndimage

job_path=pathlib.Path(sys.argv[1]); generator=sys.argv[2]
version=int(sys.argv[3]) if len(sys.argv)>3 else 1
job=json.loads(job_path.read_text()); directory=job_path.parent
with os.fdopen(os.open(generator,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb') as stream: raw=stream.read()
dest=directory/(job['slug']+'-raw-v'+str(version)+'.png')
assert not dest.exists() or dest.read_bytes()==raw
if not dest.exists(): dest.write_bytes(raw)
im=Image.open(dest).convert('RGBA'); width,height=im.size; alpha=np.asarray(im)[:,:,3]
labels,total=ndimage.label(alpha>16); components=[]
for identifier,region in enumerate(ndimage.find_objects(labels),1):
 if region is None:continue
 mask=labels[region]==identifier; pixels=int(mask.sum())
 if pixels<800:continue
 yy,xx=np.nonzero(mask)
 components.append({'component':identifier,'pixels':pixels,'rect':[region[1].start,region[0].start,region[1].stop-region[1].start,region[0].stop-region[0].start],'centroid':[float(xx.mean()+region[1].start),float(yy.mean()+region[0].start)]})
columns=job['atlas']['columns']; rows=job['atlas']['rows']; slots=[]
for index,slot in enumerate(job['slots']):
 col=index%columns; row=index//columns
 owns=[c for c in components if min(columns-1,int(c['centroid'][0]/width*columns))==col and min(rows-1,int(c['centroid'][1]/height*rows))==row]
 item=dict(slot,poseCount=1,animationCount=0,facing='right',originalSourceRetained=True)
 if owns:
  x=min(c['rect'][0]for c in owns); y=min(c['rect'][1]for c in owns); x1=max(c['rect'][0]+c['rect'][2]for c in owns); y1=max(c['rect'][1]+c['rect'][3]for c in owns)
  trunk=alpha[y+round((y1-y)*.5):y+round((y1-y)*.7),x:x1]>16; cy,cx=np.nonzero(trunk)
  item.update(sourceRect=[x,y,x1-x,y1-y],bodyDatumX=float(cx.mean()+x)if len(cx)else x+(x1-x)/2,footDatumY=y1-1,datumQualification='Measured silhouette proposal; direct artist anatomical pelvis and actual foot/support review pending. Rifle/tail must not set runtime body scale.',mainComponentIDs=[c['component']for c in owns])
 else:item.update(status='NO_MAIN_COMPONENT_REVIEW_HOLD')
 slots.append(item)
edges={name:int((values>16).sum())for name,values in {'top':alpha[0,:],'bottom':alpha[-1,:],'left':alpha[:,0],'right':alpha[:,-1]}.items()}
proposal={'schema':'cqc.static.official-generated-page-proposal/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'uid':job['uid'],'period':job['period'],'rawPNG':{'path':str(dest),'generatorPath':generator,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'width':width,'height':height,'rawPNGTransformed':False},'atlas':job['atlas'],'slots':slots,'referenceSources':job['referenceSources'],'visualReview':{'reviewer':'/root/static_artist_a — output review pending','newSpriteViewed':False,'referencesViewed':True,'sameIdentityAndPeriod':None,'sourceOnly':True,'limits':job['limits']},'alphaAnalysis':{'min':int(alpha.min()),'max':int(alpha.max()),'alphaZero':int((alpha==0).sum()),'alphaAbove16':int((alpha>16).sum()),'mainComponentsAbove16':len(components),'edgeForegroundAbove16':sum(edges.values()),'edgeForegroundAbove16BySide':edges,'components':components,'weakAlphaResidue1to16Present':bool(((alpha>0)&(alpha<=16)).any()),'qualification':'Analysis only; exact raw PNG preserved without CPU raster editing.'},'SourcePixelsEditedByCPU':False,'ASWrites':False,'GitWrites':False,'runtimeAdmitted':False,'RootAdmission':'PENDING','newAnimations':0,'p50Assignment':'a_pw'}
path=directory/(job['slug'].upper().replace('-','_')+'_ARTIFACT_PROPOSAL_PRIVATE_V'+str(version)+'.json')
path.write_text(json.dumps(proposal,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'uid':job['uid'],'rawPNG':proposal['rawPNG'],'proposal':str(path),'poses':len(slots),'mainComponents':len(components),'edgeForegroundAbove16':sum(edges.values())}))
