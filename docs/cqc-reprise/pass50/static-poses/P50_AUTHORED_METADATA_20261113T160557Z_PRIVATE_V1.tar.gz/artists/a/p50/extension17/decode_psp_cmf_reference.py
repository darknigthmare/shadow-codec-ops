from pathlib import Path
import struct,json,hashlib
import numpy as np
from PIL import Image
P=Path('/tmp/cqc-static-20261113/artists/a/p50/extension17');out=[]
for f in sorted((P/'dlc-jp-extracted').glob('CMD*.PDT')):
 if int(f.stem[3:])>12:continue
 raw=f.read_bytes();d=raw[:12]+bytes(x^raw[0]for x in raw[12:]);count=struct.unpack_from('<H',d,0x18)[0];ents=[struct.unpack_from('<3I',d,0x20+i*12)for i in range(count)];manifest=d[ents[0][2]:ents[0][2]+ents[0][0]];name=manifest[0x49:].split(b'\0')[0].decode('utf8');cmf=next(d[pos:pos+sz]for sz,ha,pos in ents if d[pos:pos+3]==b'CMF');txpStart=struct.unpack_from('<I',cmf,12)[0];t=cmf[txpStart:];flag,sc,nimage,ninfo,ncol,imageoff,infooff,clutoff=struct.unpack_from('<8I',t,0);dest=P/'dlc-jp-reference-textures'/f.stem;dest.mkdir(parents=True,exist_ok=True);textures=[]
 for i in range(ninfo):
  vals=struct.unpack_from('<4I4f4h',t,infooff+40*i);flag,sc,imgo,cluto=vals[:4];w,h,xo,yo=vals[8:];bits,mw,mh,pad,pad0,po,zo=struct.unpack_from('<4H3I',t,imgo);mw&=0xfff;mh&=0xfff;bpp=bits&15
  if not po or bpp not in [4,5]or bits&0xf0:continue
  src=np.frombuffer(t[po:po+mw*mh*(1 if bpp==5 else .5).__int__()],dtype=np.uint8) if False else t[po:]
  pixels=np.zeros((mh,mw),dtype=np.uint8)
  for yy in range(mh):
   for xx in range(mw if bpp==5 else mw//2):
    pos=xx-(xx//16*16)+(xx//16*128)+yy*16+(yy//8)*(mw*(8 if bpp==5 else 4)-128)
    if bpp==5:pixels[yy,xx]=src[pos]
    else:pixels[yy,xx*2]=src[pos]&15;pixels[yy,xx*2+1]=src[pos]>>4
  pal=np.frombuffer(t[cluto:cluto+4*(256 if bpp==5 else 16)],dtype=np.uint8).reshape(-1,4);rgba=pal[pixels[yo:yo+h,xo:xo+w]];assert rgba.shape==(h,w,4)
  path=dest/f'texture-{i:02d}-{sc:08x}-{w}x{h}.png';Image.fromarray(rgba,'RGBA').save(path);b=path.read_bytes();textures.append(dict(path=str(path),index=i,hash=f'{sc:08x}',width=w,height=h,pixelFormat=bpp,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),viewed=False))
 out.append(dict(sourcePDT=str(f),sourceSHA256=hashlib.sha256(raw).hexdigest(),nameJP=name,embeddedNameExact=True,CMFBytes=len(cmf),TXPStart=txpStart,textureCount=len(textures),textures=textures,operation='Decode unmodified original PSP indexed/swizzled texture pixels using documented Jayveer TXP format; no filtering, painting, recolor, resize or generated sprite edits.'))
(P/'JP_DLC_DECODED_REFERENCE_TEXTURES_PRIVATE_V1.json').write_text(json.dumps(dict(decoderSourceURL='https://github.com/Jayveer/MGS-MDP-Noesis/blob/master/mgs/txp/txp.cpp',rows=out),indent=2,ensure_ascii=False));print(json.dumps([(r['nameJP'],r['sourcePDT'],r['textureCount'])for r in out],ensure_ascii=False))
