from pathlib import Path
import json
base=Path('/tmp/cqc-static-20261113/artists/a/p50')
assignment=json.loads(Path('/tmp/cqc-static-20261113/p50/assignments/a_pw.json').read_text())
rows={(r['targetUID'],r['reconciledOfficialID']):r for r in assignment['rows']}
models=json.loads((base/'references/MODEL_PREVIEW_AND_MSF_ORIGINAL_COPY_PROVENANCE_PRIVATE_V1.json').read_text())
for p in models:p.update(viewed=True,viewedBy='/root/static_artist_a')
(base/'references/MODEL_PREVIEW_AND_MSF_ORIGINAL_COPY_PROVENANCE_PRIVATE_V1.json').write_text(json.dumps(models,indent=2)+'\n')
model={Path(p['path']).stem.replace('model-',''):p for p in models if Path(p['path']).name.startswith('model-')}
msf_original=next(p for p in models if Path(p['path']).name.startswith('completion44'))
body=json.loads((base/'references/ORIGINAL_JF_COPY_PROVENANCE_PRIVATE_V1.json').read_text())
states=json.loads((base/'references/KONAMI_UNIFORM_STATE_COPY_PROVENANCE_PRIVATE_V1.json').read_text());states.update(viewed=True,viewedBy='/root/static_artist_a')
naked=json.loads((base/'references/MSF_NAKED_LEAF_TEXTURE_COPY_PROVENANCE_PRIVATE_V1.json').read_text())
for p in naked:p.update(viewed=True,viewedBy='/root/static_artist_a')
(base/'references/MSF_NAKED_LEAF_TEXTURE_COPY_PROVENANCE_PRIVATE_V1.json').write_text(json.dumps(naked,indent=2)+'\n')
leaf_leg=next(p for p in json.loads((base/'research-snake/camo-textures/COPY_PROVENANCE_PRIVATE_V1.json').read_text()) if Path(p['path']).name=='Leaf-legs.png')
research=json.loads((base/'research-msf/MSF16_NEW_REFERENCE_DISPOSITIONS_PRIVATE_V1.json').read_text())
research_rows={r['costumeID']:r for r in research['rows']}

def write_request(slug,uid,descriptions,paths,refs,limits):
 directory=base/slug;directory.mkdir(exist_ok=True)
 count=len(descriptions);cols=2;nr=2 if count>2 else 1
 slots=[]
 for cid,description in descriptions:
  row=rows[(uid,'official--'+cid)]
  slots.append({'uid':uid,'costumeID':row['reconciledOfficialID'],'historicalID':row['historicalID'],'label':row['historicalCostumeName'],'classification':'official-same-period-costume','observedCostume':description})
 common=f'''Create exactly {count} NEW separate fullbody STATIC costume sprites, ONE quiet neutral standing RIGHT/front-three-quarter pose per different official outfit. Layout {cols}columns x{nr}rows, row-major order on landscape1536x1024 transparentRGBA. Figures same physical adult human height, feet on equal invisible baseline perrow. Large clear gutters and outer margins, full hair/headgear/hands/feet included, no neighboring overlap. Highly detailed crisp hand-painted2D/2.5D fighting-game art, not a photograph or raw3D render. No text/UI/grid/floor/shadows/glow/haze, no repeated action or animation frames, no extra figures. Source previews are TPOSE only as factual outfit references: NEW output must have arms down/relaxed guard, not TPOSE. No weapons held; hands empty, no firing or threatening gesture. Retain only the holsters/gear actually visible on that specific outfit. Do not add tactical gear to formal/swim/prison outfits. Body clothing and headgear are to follow actual referred game model, no futuristic, cyborg, MGSV/Delta or other-era borrowing. Exact slot descriptions follow.'''
 if uid=='core__snake_pw':
  common+=' ALL slots remain original2010PSP PeaceWalker1974 adult BigBoss/NakedSnake: rugged mature brown hair/mullet and beard, charcoal bandana/tails, anatomicalRIGHT black eyepatch, same muscular adult build, both arms natural. FIRST primaryKonami JF render establishes Snake head/body. Clothes-only model references of generic MSF male must NEVER transfer their short brown donor head, sunglasses or face to Snake. Preserve Snake identity including his bandana/eyepatch on every outfit. No Miller blondhead/watch, no prosthetic/horn. '
 else:
  common+=' Selected UID is original2010PSP MALE MSF SOLDIER, not Snake/Miller/a namedperson or femaleMSF. FIRST reference ownnativeOriginal sets adult body scale and native blackbalaclava where the given costume keeps it. Game model previews establish exact official costume headgear/state, colors/gear/boots. Never import Snake bandana, eyepatch or beard. Formal/swim and specified enemyuniforms may reveal the actual generic male costume-model head where the previewdoes: this is a same-era unnamed soldier costume state, not a named character swap. Do not add an unsupported balaclava under a costume whose actual preview clearly removes it. '
 prompt=common+'\n'+'\n'.join(f'SLOT {i} ({"top-left"if i==0 and nr==2 else "top-right"if i==1 and nr==2 else "bottom-left"if i==2 else "bottom-right"if i==3 else "left"if i==0 else "right"}), '+cid+': '+description for i,(cid,description) in enumerate(descriptions))+'\nExactly one neutral complete figure for each slot, all facing RIGHT. No animation. Actual alpha0 empty background and opaque sprites.'
 req={'schema':'cqc.p50.static-official-request/1','uid':uid,'slug':slug,'period':'Original2010PSP MetalGearSolid PeaceWalker,1974; same-era official costume states only.','atlas':{'columns':cols,'rows':nr,'onePosePerCostume':True,'animations':False},'slots':slots,'referenceSources':refs,'generationReferencePaths':paths,'prompt':prompt,'limits':limits,'newAnimations':0}
 p=directory/'REQUEST_PRIVATE_V1.json';p.write_text(json.dumps(req,ensure_ascii=False,indent=2)+'\n');print(p)

snake_desc=[
 ('tuxedo','Black official tuxedo jacket/trousers, black satin lapels, white vertically pleated formal shirt, black bowtie, white pocket square, bare natural hands, black dress shoes. Copy clothes from generic TUXEDO MALE attached second reference but keep Snake own mature head/bandana/eyepatch; no donor sunglasses, no tacticalbelt/holster/rifle.'),
 ('swim-trunks','Ordinary nonsexual adult military swim outfit. Exact SWIMSUIT MALE third reference: CHARCOAL/BLACK fitted swim BRIEFS with fine YELLOW trim along waist, NOT long shorts. Natural bare hands and bare feet, no gear/boots. Same matureadult Snake identity and bandana/RIGHTeyepatch, normal relaxed standing guard, no flexing/glamour/sexual pose or body emphasis.'),
 ('naked','Official NAKED JungleFatigues state on bottomLEFT of last primaryKonami sheet: adult Snake bare upper torso, olive military harness/utilitybelt/pouches and diagonal brass-ammunition bandolier; black forearm guards/fingerless gloves. Plain OLIVE JF cargo trousers/rightthighholster/straps/ONE elongated anatomicalRIGHT black kneepad/black laceboots from FIRST fullbody JF render. No white/patterned pants, no blacktanktop (tanktop isMSFsoldier state, notSnake). Normal functional military ready pose, no flexing/glamour, no rifle held.'),
 ('sneaking-suit','Official original PW sneaking suit. Last primaryKonami topRIGHT image controls SNAKE upperbody: dark blue-black formfitting utility suit with horizontal molded cooling/ribbed chest/abdomen panels, olive shoulder/webbelt/rightthighholster; no MSFmask overSnakeface. Fourth attached ripped SNEAKING model supplies complete lowerbody: black/darkbluegray legs, gray bands on knees/shins, dark boots, gold upperarm/thigh accents. Keep Snake head/bandana/RIGHTeyepatch instead of balaclava. No heavy BattleDressplates. Empty gloved hands.')]
write_request('snake-specials-01','core__snake_pw',snake_desc,[body[1]['path'],model['331650']['path'],model['331640']['path'],model['331667']['path'],states['path']],[body[0],body[1],model['331650'],model['331640'],model['331667'],states], 'NewP50 actual game-ripped male costume previews define tux/swim construction; sameera primary Konami Snake states define Naked/Sneaking torso, fullbody Konami JF defines unchanged adult body and Naked lowergear. Clothes transferred, no donor head/UID. Community rip provenance, no signed retailmesh/UV or exactpixels certification. Sneaking lowerbody materially corroborated from sameuniform MSFmodel; unseen tiny Snake-specific details remain interpreted. All old sprites/animations retained.')

g1=[
 ('naked-leaf','Actual MSF NAKED(LEAF), NOT shirtlessSnake. Black sleeveless TANKTOP from attached raw Leaf/shirt texture; bare adult upper/lowerarms with black fingerlessgloves, black balaclava retained. Olivewebbelt/pouches/rightthighholster/straps, green/darkleafcamouflage cargo trousers from attached Leaf/legs texture, both long black knee/shin protectors and black boots from same original MSFMaleFatigues model. No collared militaryshirt or bare chest. Exact named MSFMaleNaked.obj exists. Same adult genericMSFbody, emptyhands.'),
 ('sneaking-suit','Attached actual MSFMALE SNEAKING preview: blackbalaclava with eyeopening, dark navy/blueblack ribbed/molded torso/abdomen suit, olive shoulder/chest harness/belt/rightthighholster, thin gold upperarm/thigh accents, gray knee/shin bands, darkboots/gloves. No Snakeface/eyepatch or heavyBattleDressarmor.'),
 ('battle-dress','Actual MSFMALE COMBAT armor body from attached helmet-preview, but NORMAL unhelmeted model state (archive MSFMaleCombat.obj, separate from HelmetOBJ): retain own original blackBALACLAVA/eyeopening and no opaquehelmet. Black padded rectangular fronttorso utilityplate/pouches, segmented darksilver shoulders/forearms/thigh/knee/shin armor, orangebrown exposed elbow joint fabric, olive straps/gear, black gloves and armoredboots. MSF chest is this model blackfrontplate, not Snake alternatebody.'),
 ('battle-dress-helmet','Exact attached MSFMALE COMBAT HELMET preview: same black paddedfronttorso plate and darksilver segmentedlimb armor with orangebrown elbow fabric/olive straps, but integral blackhelmet with large OPAQUE smokedtan/gray fullfacevisor. No eyes/face visible throughvisor. Complete armoredboots, hands empty.')]
g1refs=[msf_original]+naked+[leaf_leg,model['331667'],model['331666'],model['331661']]
write_request('msf-official-01','completion44__msf_soldier_44',g1,[msf_original['path'],naked[0]['path'],leaf_leg['path'],model['331667']['path'],model['331666']['path']],g1refs,'NewP50 actual extracted MSFmale model body/states and named Leaftextures viewed. Normal and helmet BattleDress are separate OBJstates in331666 archive; ordinary head stays ownblackbalaclava. Naked is blacktanktop, not shirtlessSnake. Sameera named model, community-extraction provenance and interpreted painted seam/UV detail; no retailpixel certificate.')

groups=[
 [('tuxedo','331650'),('swim-trunks','331640'),('plain-tshirt','331670'),('russian-commando','331649')],
 [('russian-soldier','331648'),('commando-versus','331628'),('pow-versus','331636'),('patrolman-versus','331627')],
 [('mechanic-versus','331634'),('escort-versus','331635')]
]
extra={
 'tuxedo':'Generic adult male shortbrownhair and black sunglasses as real outfitmodel, no Snakeidentity. Black formal tuxedo/satinlapels, white pleatedshirt/blackbowtie, white pocket square, black dressshoes, barehands, no tacticalgear.',
 'swim-trunks':'Ordinary nonsexual adult male swimoutfit. Genericshortbrownhair/blacksunglasses likeactualmodel, darkcharcoal swimBRIEFS with thin YELLOW waistbandtrim, barehands/barefeet, no gear or weapon. Normal calm guard, no flexing/glamour/bodyemphasis.',
 'plain-tshirt':'Actual MSFMALE TSHIRT: own blackbalaclava, plain WHITE crewneck short sleeveTshirt with no graphic/text, barearms, blackfingerlessgloves, olivewebbelt/pouches/rightthighholster and plainolivetrousers, two longblack kneecovers, blacklaceboots. Do not import a UTcommercialprintedshirt or Snakehead.',
 'russian-commando':'Exact actual RUSSIAN COMMANDO: olivebrown rounded tallhelmet with forehead goggles, blackbalaclava/eyesvisible, slateblue heavyapron/bodyarmor with centralbrownmetalbuckle andbluepouches, darkgray baggy longsleeved suit with thinred upperarm accents, blackgloves, brown calfboots. No RussianSoldier redtie/visor or inventedhead.',
 'russian-soldier':'Exact actual RUSSIAN SOLDIER: tall darkblackhelmet with opaque bluegray fullface visor, beige long sleeve shirt, RED TIE and red anatomicalLEFT upperarm band, darkgreen/black tacticalvest with pouches, brown trousers, blackgloves and calfboots. No bluecommandoapron, no visiblehumanface.',
 'commando-versus':'Exact actual COMMANDO regular variant, notNightVision/heavy: blackbalaclava, olivegreencommunicationsheadset, darkgray zipped coverall with subtle gold piping andsmallchestpatch, olive shoulder straps/webbelt/pouches/rightthighholster, blackfingerlessgloves andblacklaceboots. No nightvisiongoggles or shoulderarmor.',
 'pow-versus':'Exact actual MALE POW outfit: genericadultmale with shaggybrownhair obscuringeyes and brownbeard, dirtyyellow-olive buttonjacket andmatching croppedloosepants, barehands/wrists/ankles and oliveSLIP-ONshoes. No tacticalgear, cuffs/restraints, extra injury or weapon. Keep ordinary neutralstanding pose.',
 'patrolman-versus':'Exact actual CIAPATROLMAN: olivefieldcap, genericadultmale brownhairface, rich orange zipped highcollarjacket, olive suspenders and broadutilitybelt with two large pairedfrontpouches, olivecargo pants, blackgloves/blacklaceboots. No soldierhelmet/armor.',
 'mechanic-versus':'Exact actual UNDERGROUNDBASEENGINEER: adultgenericmaleface under orange workcap, orange utilitycoverall with rolledelbowsleeves, whiteundershirt, gray shoulderstraps, yellow workgloves, blackworkboots. No goggles/helmet/gun or futuristicgear.',
 'escort-versus':'Exact actual PEACESENTINELESCORT/CAPTAIN outfit: paleivoryhelmet, yellowtintedgoggles, blackfullgasmask withfrontfilter and headset/mic, blackpaddedsuit/shoulderarmor/knee/shinguards, olive chest/hipwebpouches andbelt/rightthighholster, blackgloves/boots. No exposedface, no humanskinhead.'
}
for number,group in enumerate(groups,2):
 descriptions=[]; refs=[msf_original];paths=[msf_original['path']]
 for cid,identifier in group:
  # Two historical costume IDs have versus suffixes while model names do not.
  descriptions.append((cid,extra[cid]));refs.append(dict(model[identifier],scope='NewP50 actual game-extracted named male costume preview; exact full outfit and associated official headgear/state. Not a named playable character.'))
  paths.append(model[identifier]['path'])
  key='official--'+cid
  if key in research_rows:
   for archive in research_rows[key].get('archiveProofs',[]):refs.append({k:v for k,v in archive.items()if k!='files'})
 write_request(f'msf-official-{number:02d}','completion44__msf_soldier_44',descriptions,paths,refs,'NewP50 actual originalPSP named maleuniform model previews/archives physically viewed. Exact official costume body/headgear state is followed. Unmasked generic male face shown by outfitmodel is not a separately attested identity beneath nativeOriginal hood; no Snake/Miller/named-character identity transferred. Community rip provenance, painted seams/microtextures interpreted; no retailpixel/meshUV certificate. Runtime/animations untouched.')
