"""Decode uncropped actual public video frames for reference inspection only."""
import argparse, concurrent.futures, hashlib, json, os, subprocess
from pathlib import Path
from PIL import Image

def capture(job):
    target=Path(job['path']);target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():raise FileExistsError(str(target))
    env=os.environ.copy()
    if env.get('HTTPS_PROXY'):
        env['http_proxy']=env['HTTPS_PROXY'];env['https_proxy']=env['HTTPS_PROXY']
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-rw_timeout','20000000',
         '-ss',str(job['timestampSeconds']),'-i',job['url'],'-frames:v','1','-an','-sn',str(target)]
    try:
        result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=55)
        if result.returncode:return dict(job,error=result.stderr.decode(errors='replace')[:300])
        raw=target.read_bytes()
        with Image.open(target)as im:size=list(im.size)
        return dict(job,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),dimensions=size,
                    operation='Actual whole retail video frame decoding; no crop/resize/retouch',viewed=False)
    except subprocess.TimeoutExpired:return dict(job,error='Video range/decoder timeout55s')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('jobs');parser.add_argument('receipt');a=parser.parse_args()
    with open(a.jobs)as f:jobs=json.load(f)
    with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:results=list(pool.map(capture,jobs))
    with open(a.receipt,'x')as f:json.dump(results,f,indent=2)
    print(json.dumps(results))
