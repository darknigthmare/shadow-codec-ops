import json,pathlib
from PIL import Image
import numpy as np
P=pathlib.Path('/tmp/cqc-static-20261113/artists/a/p50/extension')
for slug,v in [('snake-dlc-patterns-02',1),('snake-dlc-patterns-03',2)]:
 f=P/slug/(slug.upper().replace('-','_')+f'_ARTIFACT_PROPOSAL_PRIVATE_V{v}.json');j=json.load(open(f));a=np.asarray(Image.open(j['rawPNG']['path']))[:,:,3]
 for s in j['slots']:
  x,y,w,h=s['sourceRect'];y0=y+int(h*.88);y1=y+h;active=np.any(a[y0:y1,x:x+w]>16,axis=0);runs=[];st=None
  for i,b in enumerate(list(active)+[False]):
   if b and st is None:st=i
   if not b and st is not None:
    if i-st>5:runs.append([x+st,x+i-1])
    st=None
  sup=[]
  for xa,xb in runs:
   yy,xx=np.nonzero(a[y0:y1,xa:xb+1]>16);bot=int(yy.max()+y0);lastxs=np.where(a[bot,xa:xb+1]>16)[0];sup.append(dict(type='physical-foot-sole',x=float(xa+lastxs.mean()),y=bot,lowerFootRect=[xa,y0,xb-xa+1,y1-y0],method='Alpha16 independent boot component in lowest12percent, visually confirmed two actual boots; no raster edit.'))
  assert len(sup)==2,(slug,s['costumeID'],sup)
  s['supportDatums']=sup;s['footDatumY']=max(v['y']for v in sup);s['bodyDatumX']=round(x+w*.40,2);s['datumQualification']='Two physical boot soles measured and artist reviewed; anatomical pelvis estimate excludes rifle and bandana from alignment.'
 j['visualReview'].update(newSpriteViewed=True,reviewer='/root/static_artist_a',sameIdentityAndPeriod=True,onePosePerCostume=True,facingRight=True,bothBootsWhole=True,anatomyAndConnectedGear=True,patternsComparedToActualNamedPSPTextures=True,notes='Four independent static RIGHT/front3quarter fullbody poses physically seen. Correct exact official named PSP palette/pattern; samePW face/build/construction. No opposite-era faces/armor transfers; kneepad anatomicalRIGHT only; no clipping.')
 if v==2:j['priorOpaqueSourcePreserved']=str(P/slug/(slug+'-raw-v1.png'));j['visualReview']['alphaExportIssueCorrectedViaImagegenOnly']=True;j['supersedesProposalForSameFourCostumes']=str(P/slug/(slug.upper().replace('-','_')+'_ARTIFACT_PROPOSAL_PRIVATE_V1.json'))
 f.write_text(json.dumps(j,indent=2,ensure_ascii=False));print(slug,[(s['costumeID'],s['supportDatums'])for s in j['slots']])
