import json,hashlib,datetime,os,io,csv
from pathlib import Path
from PIL import Image
BASE=Path('/tmp/cqc-static-20261113/artists/d/p50')
ASSIGN=Path('/tmp/cqc-static-20261113/p50/assignments/d_legacy.json')
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
assignment=json.loads(read(ASSIGN));originals={r['uid']:r for r in json.loads(read(BASE/'ORIGINAL6_COPY_RECEIPTS_PRIVATE_V1.json'))}
refs={}
for p in (BASE/'references').glob('*.json'):
 r=json.loads(read(p))
 if isinstance(r,dict)and'url'in r:refs[r['url']]=r
def source(url,viewed=False,role=None):
 r=refs.get(url,{'url':url,'status':'not-locally-downloaded'})
 return {**r,'physicallyViewed':viewed,'role':role,'reviewer':'static_catalog artist D'if viewed else None}
MG1='https://metalgear.konami.net/manual/mc1/mg1_msx/pc/en/page11.html'
MG2='https://metalgear.konami.net/manual/mc1/mg2/pc/en/page12.html'
NES='https://metalgear.konami.net/manual/mc1/mg1_nes/pc/en/page10.html'
SR='https://metalgear.konami.net/manual/mc1/snakes_revenge/pc/en/page11.html'
SHEETS={
 'core__snake_mg1':('https://www.spriters-resource.com/media/assets/21/22527.png?updated=1755472545','https://www.spriters-resource.com/media/assets/254/257259.png?updated=1755493974',MG1),
 'core__snake_mg2':('https://www.spriters-resource.com/media/assets/21/22530.png?updated=1755472545','https://www.spriters-resource.com/media/assets/258/261346.png?updated=1755494275',MG2),
 'archive__snake_nes':('https://www.spriters-resource.com/media/assets/76/79356.png?updated=1755474360','https://www.spriters-resource.com/media/assets/251/254129.png?updated=1755493688',NES),
 'core__snake_sr':('https://www.spriters-resource.com/media/assets/9/9767.png?updated=1755472453','https://www.spriters-resource.com/media/assets/253/256494.png?updated=1755493938',SR)}
def lp(part,name):return f'https://lparchive.org/Metal-Gear-1-2/Update%20{part:02d}/{name}'
mg1default=lp(8,'14-Metal_Gear_0336.png')
aliases={
 'core__snake_mg1__alt__gas_mask':([lp(8,'15-Metal_Gear_0337.png'),mg1default], 'Retail gas-maze capture has the GasMask icon selected in the HUD, yet the same ordinary teal fatigues/head silhouette as the card-selected capture and NORM retail sheet. The inventory mask is real but is not drawn as a separate worn mask on Snake.'),
 'core__snake_mg1__alt__infrared_goggles':([lp(5,'25-Metal_Gear_0212.png'),lp(5,'26-Metal_Gear_0213.png')], 'Direct before/after pair in the same laser room: Card3 selected then infrared-goggles icon selected. The room palette and visible laser beams change; Snake keeps the same head/body sprite without drawn goggles.'),
 'core__snake_mg1__alt__body_armor':([lp(11,'31-Metal_Gear_0487.png'),mg1default], 'BodyArmor icon selected in lower HUD of the elevator capture; the full human sprite remains ordinary teal fatigues, without new vest geometry. Compare the default card-selected capture and NORM retail sheet; an actual body-armor inventory item is not a separate alternate body sprite.'),
 'core__snake_mg1__alt__enemy_uniform':([lp(7,'30-Metal_Gear_0316.png'),mg1default], 'EnemyUniform selected and the entrance guards grant passage, while Snake remains the ordinary teal body rather than the brown guard sprite. Both equipped gameplay and default capture were viewed; the LP also explicitly discusses the unchanged player sprite. No invented enemy-uniform wearer drawing.'),
 'core__snake_mg1__alt__bomb_blast_suit':([lp(6,'5-Metal_Gear_0251.png'),lp(6,'6-Metal_Gear_0252.png'),mg1default], 'BlastSuit icon is selected during the rooftop wind crossing. Whole Snake remains the ordinary teal fatigues sprite, matching the default card-selected capture/NORM sheet; only wind resistance changes, no full bomb-disposal costume appears.'),
 'core__snake_mg1__alt__oxygen_tanks':([lp(11,'33-Metal_Gear_0491.png'),lp(11,'39-Metal_Gear_0497.png'),mg1default], 'OxygenTank icon selected in active swimming and, crucially, the subsequent full standing body on the electric-floor screen. Standing Snake is the unchanged ordinary teal sprite with no externally drawn cylinders; the swimming bubble is a movement/state graphic, not a new standing costume.'),
 'core__snake_mg2__alt__riot_face_mask':([lp(21,'30-Metal_Gear_2_0099.png'),lp(21,'34-Metal_Gear_2_0104.png')], 'The gas-room capture displays the selected gas-mask glyph and O2 gauge; Snake uses the standard body silhouette. Red alert/damage tint affects the whole scene, consistent with the retail damaged frames, and does not add mask geometry. The ordinary green default body and complete player sheet were also viewed.'),
 'core__snake_mg2__alt__night_viewer':([lp(27,'43-Metal_Gear_2_0596.png'),lp(27,'44-Metal_Gear_2_0597.png')], 'NightViewer selected in the dark/blue room and card selected in the following normal-lit room. Whole-scene night-vision color treatment changes, while the body/head outlines remain the standard retail Snake. This is equipment/lighting state, not a new drawn goggles costume.'),
 'core__snake_sr__alt__power_armor':([lp(16,'3-Snake_s_Revenge_215.png'),lp(16,'4-Snake_s_Revenge_216.png')], 'PowerArmor mechanical-arm inventory glyph is selected as Snake pushes the boulder. Actual player arms remain the ordinary human retail arm pixels; no replacement mechanical limb or distinct armored body appears. Historical suffix bras mecanique describes the item icon, not an attested wearable cybernetic arm.'),
 'core__snake_sr__alt__infrared_goggles':([lp(17,'5-Snake_s_Revenge_275.png'),lp(17,'6-Snake_s_Revenge_276.png')], 'Equipment menu identifies NightSite/infrared goggles, followed by the gondola gameplay capture with its selected HUD glyph. The player has the same ordinary head/body outline as the native default sheet, no separately rendered goggles; flashing health palettes are ordinary damage frames, not costumes.'),
 'core__snake_sr__alt__body_armor':([lp(18,'29-Snake_s_Revenge_364.png'),lp(18,'56-Snake_s_Revenge_408.png')], 'After the vest acquisition sequence, later whole-body corridor gameplay shows the BodyArmor vest HUD glyph selected, recognizable against the official equipment icon. Snake retains normal human body geometry and clothing silhouette, with no added vest sprite; default and damage-state retail sheets were viewed.'),
 'core__snake_sr__alt__backpack':([lp(18,'54-Snake_s_Revenge_404.png'),lp(18,'55-Snake_s_Revenge_405.png'),lp(18,'56-Snake_s_Revenge_408.png')], 'Actual before/pickup/after captures show the loose backpack object, I GOT A BACKPACK event, then the unchanged player body. It is a passive increased-capacity inventory configuration, without an additional worn-backpack graphic. Color flashing is health/damage, not a costume change.')}
primaryIcons={
 'core__snake_mg1__alt__gas_mask':MG1.replace('page11.html','img/11_icon05.png'),
 'core__snake_mg1__alt__enemy_uniform':MG1.replace('page11.html','img/11_icon07.png'),
 'core__snake_mg1__alt__bomb_blast_suit':MG1.replace('page11.html','img/11_icon08.png'),
 'core__snake_mg1__alt__infrared_goggles':MG1.replace('page11.html','img/11_icon09.png'),
 'core__snake_mg1__alt__body_armor':MG1.replace('page11.html','img/11_icon16.png'),
 'core__snake_mg1__alt__oxygen_tanks':MG1.replace('page11.html','img/11_icon17.png'),
 'core__snake_mg2__alt__riot_face_mask':MG2.replace('page12.html','img/12_icon05.png'),
 'core__snake_sr__alt__power_armor':SR.replace('page11.html','img/11_icon14.png'),
 'core__snake_sr__alt__body_armor':SR.replace('page11.html','img/11_icon07.png'),
 'core__snake_sr__alt__backpack':SR.replace('page11.html','img/11_icon12.png')}
pendingReasons={
 'core__snake_mg2__alt__sps_body_armor':'Official manual attests the Silent Partner Special vest and native item sheet contains its icon. Acquired-item screenshots still have card equipment selected; no physically verified equipped/default body pair establishes a separate worn appearance or an exact Original alias yet. No new wearer costume invented from the icon.',
 'core__snake_mg2__alt__oxygen_cylinder':'Official manual and native inventory icon attest an OxygenTank equipment effect on the underwater gauge. Current captures show acquisition while card remains selected, not an equipped full-body comparison. No cylinder-strapped body or exact Original alias admitted from inventory art alone.',
 'core__snake_sr__alt__oxygen_tanks':'Official manual attests consumable OxygenTanks used automatically underwater. Viewed tunnel gameplay shows the stock oxygen counter but is dry, so it does not prove active underwater wearer appearance. No scuba suit or tank-strapped human invented; no exact Original alias proposed without that visual pair.'}
rows=[]
for old in assignment['rows']:
 h=old['historicalID'];uid=old['targetUID'];proposal=BASE/'pages'/uid/(uid.upper()+'_P50_ARTIFACT_PROPOSAL_PRIVATE_V1.json')
 r={**old,'historicalLabelPreserved':True,'newDrawingCount':0,'animationCount':0,'runtimeAdmitted':False,'noCPUImageEditing':True,'globalMappingMutated':False,'reviewer':'static_catalog artist D','RootReviewPending':True,'targetUID':uid,'targetCostumeID':None,'proposalPath':None}
 if proposal.exists():
  page=json.loads(read(proposal));slot=next((s for s in page['slots']if s['historicalID']==h),None)
 else:slot=None
 if slot:
  raw=read(page['rawPNG']['path']);assert hashlib.sha256(raw).hexdigest()==page['rawPNG']['sha256'];im=Image.open(io.BytesIO(raw));assert im.size==(page['rawPNG']['width'],page['rawPNG']['height']);a=im.getchannel('A');b=a.point(lambda q:255 if q>16 else 0).getbbox();assert b and b[0]>0 and b[1]>0 and b[2]<im.width and b[3]<im.height
  r.update(status='NEW_RETRO_STATIC_SOURCE_PROPOSAL',reason=slot['sourceLimits']+' Actual native wearer/gameplay physically viewed. A new single-pose retro redraw was generated and its original PNG bytes preserved; Root approval pending.',targetCostumeID=slot['costumeID'],proposalPath=str(proposal),newDrawingCount=1,newSource=page['rawPNG'],evidenceURLs=[x['url']for x in page['referenceSources']],proofPaths=[x['path']for x in page['referenceSources']]+[str(proposal),page['rawPNG']['path']],newSourceAlpha16BBox=list(b),referenceSources=page['referenceSources'])
 elif h in aliases:
  captures,reason=aliases[h];player,item,manual=SHEETS[uid];sources=[source(u,True,'Physically viewed equipped/default gameplay comparison')for u in captures]+[source(player,True,'Complete native default/player sprite sheet physically viewed'),source(item,True,'Native inventory icons physically viewed'),source(manual,False,'Primary KONAMI manual text reviewed; confirms actual equipment function')]
  if h in primaryIcons:sources.append(source(primaryIcons[h],True,'Named official item icon physically compared to selected HUD glyph'))
  r.update(status='OFFICIAL_EQUIPMENT_CONFIGURATION_ALIAS_PROPOSAL',reason=reason+' This resolves a visible-costume label as an equipment configuration, never a new delivered drawing. The existing authored Original is reused only for this same UID; no claim that its pixels equal the retail sprite.',targetCostumeID='original',officialEquipmentConfigurationAlias={'uid':uid,'id':'original','equipmentID':old['reconciledOfficialID'],'equipmentName':old['historicalCostumeName'],'newDrawing':False,'appearanceChange':'not-rendered-on-body','equipmentEffectPreservedInMetadataOnly':True,'proofScope':'Observed player silhouette unchanged; gameplay mechanics not modified'},nativeOriginalSource=originals[uid],evidenceURLs=[x['url']for x in sources],proofPaths=[x['path']for x in sources if x.get('path')]+[originals[uid]['copy']],referenceSources=sources)
 else:
  player,item,manual=SHEETS[uid];sources=[source(player,True,'Complete native player sheet physically viewed; no separate labeled wearable form'),source(item,True,'Native object/item sheet physically viewed; inventory art is not a wearer'),source(manual,False,'Primary KONAMI manual text reviewed; confirms equipment item/function')]
  reason=pendingReasons.get(h,'The NES item is real and corroborated by the official manual plus native inventory sheet. The complete native player sheet shows ordinary body/box/damage groups, but an actual equipped/default full-body capture pair for this specific item was not obtained. Inventory-object art alone does not attest a distinct worn costume; no contemporary face, mask, vest, tanks or glove body invented. Existing drawing is not silently aliased without that visual proof.')
  r.update(status='EQUIPMENT_OBJECT_ATTESTED_WEARER_COMPARISON_PENDING',reason=reason,nativeOriginalSource=originals[uid],evidenceURLs=[x['url']for x in sources]+old['referenceURLs'],proofPaths=[x['path']for x in sources if x.get('path')]+[originals[uid]['copy']],referenceSources=sources)
 rows.append(r)
assert len(rows)==25 and len({r['historicalID']for r in rows})==25
counts={s:sum(r['status']==s for r in rows)for s in sorted({r['status']for r in rows})};assert sum(r['newDrawingCount']for r in rows)==3
out=BASE/'P50_D_LEGACY_DISPOSITIONS_PRIVATE_V1.json';rec={'schema':'cqc.p50.official-pending-dispositions/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'batch':'d_legacy','sourceCommit':assignment['sourceCommit'],'assignment':str(ASSIGN),'sourceRows':25,'allRowsDispositioned':True,'newStaticDrawings':3,'newPNGPages':3,'counts':counts,'animations':0,'runtimeMutations':0,'GitMutations':0,'globalMapIndexBuildMutations':0,'notes':['All historical labels/UIDs/IDs preserved, including former generated_reviewed status as historical evidence only.','A real inventory icon or manual equipment description never counted as a new worn body.','Configuration aliases are sameUID Original proposals with physically viewed equipped/default or pickup/after comparisons; zero new drawings.','Ten object-attested rows still lack adequate wearer comparison; not declared nonexistent and not counted as delivered sprites.','LP screenshots are actual classic game visual captures hosted secondarily and may use a fan translation/emulator; no claim of unmodified-ROM or translation-authority certification. Native ripping-sheet publisher provenance and primary KONAMI equipment labels are recorded.','All new PNG pixels from image_gen preserved byte-exact; no CPU image drawing/crop/recolor; all P49 sources and OCs preserved.','No global map/index/build, runtime, Git or deployment change by artist D.'],'rows':rows};out.write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n')
with (BASE/'P50_D_LEGACY_DISPOSITIONS_PUBLIC_V1.csv').open('w',newline='')as f:
 w=csv.DictWriter(f,fieldnames=['historicalID','targetUID','historicalCostumeName','status','targetCostumeID','newDrawingCount','proposalPath','reason']);w.writeheader();w.writerows({k:r[k]for k in w.fieldnames}for r in rows)
print(json.dumps({'path':str(out),'sha256':hashlib.sha256(read(out)).hexdigest(),'counts':counts,'newDrawings':3},ensure_ascii=False,indent=2))
