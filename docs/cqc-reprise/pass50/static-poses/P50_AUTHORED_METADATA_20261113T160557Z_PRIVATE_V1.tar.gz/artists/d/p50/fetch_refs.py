import sys,json,hashlib,os,datetime,concurrent.futures
from pathlib import Path
import urllib.request,urllib.error
BASE=Path('/tmp/cqc-static-20261113/artists/d/p50/references');BASE.mkdir(exist_ok=True)
def fetch(url):
 key=hashlib.sha256(url.encode()).hexdigest();meta=BASE/(key+'.json')
 if meta.exists():return json.loads(meta.read_text())
 try:
  try:r=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 source-reference-review/1.0'}),timeout=40)
  except urllib.error.HTTPError as e:r=e
  raw=r.read()
  ext='.png' if raw.startswith(b'\x89PNG') else '.jpg' if raw.startswith(b'\xff\xd8') else '.gif' if raw.startswith(b'GIF8') else '.pdf' if raw.startswith(b'%PDF') else '.zip' if raw.startswith(b'PK\x03\x04') else '.html' if b'<html' in raw[:2000].lower() or b'<!doctype' in raw[:2000].lower() else '.ref'
  path=BASE/(key+ext)
  with path.open('xb') as f:f.write(raw)
  rec={'url':url,'finalURL':r.url,'status':r.status,'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'contentType':r.headers.get('Content-Type'),'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rawSourcePreserved':True}
 except Exception as e:rec={'url':url,'error':str(e)}
 with meta.open('x') as f:json.dump(rec,f,ensure_ascii=False,indent=2)
 return rec
if __name__=='__main__':
 urls=json.loads(Path(sys.argv[1]).read_text())
 with concurrent.futures.ThreadPoolExecutor(max_workers=6)as ex:rows=list(ex.map(fetch,urls))
 Path(sys.argv[2]).write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
 for r in rows:print(json.dumps(r,ensure_ascii=False))
