import os,json,hashlib,io,datetime,sys
from pathlib import Path
from PIL import Image
BASE=Path('/tmp/cqc-static-20261113/artists/d/p50/pages')
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
def run(uid,generator):
 d=BASE/uid;j=json.loads(read(d/'JOB_PRIVATE_V1.json'));p=Path(generator);before=p.stat();raw=read(p);assert p.stat()==before;assert raw.startswith(b'\x89PNG\r\n\x1a\n');target=d/(uid+'-p50-static-raw-v1.png')
 if target.exists():assert read(target)==raw
 else:
  with target.open('xb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
 im=Image.open(io.BytesIO(raw));assert im.mode=='RGBA';a=im.getchannel('A');n=len(j['slots']);cols=min(3,n);rows=(n+cols-1)//cols;slots=[]
 for i,s in enumerate(j['slots']):
  x0=im.width*(i%cols)//cols;y0=im.height*(i//cols)//rows;x1=im.width*((i%cols)+1)//cols;y1=im.height*((i//cols)+1)//rows
  mask=a.crop((x0,y0,x1,y1)).point(lambda v:255 if v>16 else 0);b=mask.getbbox();assert b;bot=mask.crop((0,max(0,b[3]-20),mask.width,b[3])).getbbox();cx=(bot[0]+bot[2])/2 if bot else (b[0]+b[2])/2
  slots.append({**s,'uid':uid,'classification':s.get('classification','official-same-period-costume'),'sourceRect':[x0,y0,x1-x0,y1-y0],'footDatumY':y0+b[3],'bodyDatumX':x0+cx,'poseCount':1,'animationCount':0,'facing':'right','datumQualification':'Alpha-derived static proposal; no runtime geometry or world-size admission'})
 edge=a.crop((0,0,im.width,1)).histogram()+a.crop((0,im.height-1,im.width,im.height)).histogram()+a.crop((0,0,1,im.height)).histogram()+a.crop((im.width-1,0,im.width,im.height)).histogram()
 rec={'schema':'cqc.static.official-generated-page-proposal/1','batch':'P50','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'uid':uid,'period':j['incarnation'],'rawPNG':{'path':str(target),'generatorPath':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'width':im.width,'height':im.height,'rawPNGTransformed':False},'atlas':{'columns':cols,'rows':rows,'onePosePerCostume':True,'animations':False},'slots':slots,'referenceSources':j['referenceSources'],'nativeOriginalSource':j['nativeOriginalSource'],'visualReview':{'reviewer':'static_catalog artist D direct inspection of P49 Original, retail references and new P50 static sprite','newSpriteViewed':True,'sameIdentityAndPeriod':True,'limits':j['limits']+' Root display and exact framing review pending; no absolute indexed-palette byte or hidden-pixel certification.'},'alphaAnalysis':{'min':a.getextrema()[0],'max':a.getextrema()[1],'alphaZero':a.histogram()[0]},'SourcePixelsEditedByCPU':False,'runtimeAdmitted':False,'newAnimations':0}
 out=d/(uid.upper()+'_P50_ARTIFACT_PROPOSAL_PRIVATE_V1.json');out.write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n');return {'uid':uid,'poses':n,'proposal':str(out),'rawPNG':rec['rawPNG'],'alpha':rec['alphaAnalysis']}
if __name__=='__main__':print(json.dumps(run(*sys.argv[1:]),ensure_ascii=False))
