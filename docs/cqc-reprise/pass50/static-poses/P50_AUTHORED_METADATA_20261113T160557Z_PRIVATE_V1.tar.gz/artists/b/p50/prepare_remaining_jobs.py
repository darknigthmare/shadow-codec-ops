from pathlib import Path
import json,hashlib
R=Path('/tmp/cqc-static-20261113/artists/b/p50')
MGR='https://archive.org/download/PS3_Longplay_079_Metal_Gear_Rising_Revengeance/PS3_Longplay_079_Metal_Gear_Rising_Revengeance.mkv'
MGS4='https://archive.org/download/PS3_Longplay_081_Metal_Gear_Solid_4_Guns_of_the_Patriots_a_V2/PS3_Longplay_081_Metal_Gear_Solid_4_Guns_of_the_Patriots_part_5_of_5.mkv'
def job(name,uid,costume,historical,label,refs,prompt,limits):
 proofs=[]
 for rel,url,scope in refs:
  p=R/rel;b=p.read_bytes();proofs.append(dict(path=str(p),URL=url,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),scope=scope,viewed=True,viewedBy='/root/static_artist_b'))
 d=dict(name=name,uid=uid,period='Official retail same-incarnation documented state',references=[x['path'] for x in proofs],referenceSources=proofs,slots=[dict(uid=uid,costumeID=costume,historicalID=historical,label=label,classification='official-same-period-costume',observations=limits)],atlas=dict(columns=1,rows=1,onePosePerCostume=True,animations=False),limits=limits,prompt=prompt)
 p=R/'jobs'/f'{name}-JOB_PRIVATE_V1.json';p.write_text(json.dumps(d,ensure_ascii=False,indent=2));print(p)
if __name__=='__main__':
 job('raiden-mgr-epilogue-suit','core__raiden','official--epilogue-suit','core__raiden__alt__epilogue_suit','Épilogue — costume noir et cravate grise',[
 ('originals/core__raiden-original-right.png',None,'Own SAME UID MGR Raiden adult proportions and silverhair identity only. This armored Original is NOT the clothes/face configuration of the epilogue.'),
 ('research/video-captures/mgrHD-18945s.png',MGR,'Actual retail postcredits18945s: black businessjacket, black suitpants, white shirtcuffs, black gloves. No exposed armored body.'),
 ('research/video-captures/mgrHD-18950s.png',MGR,'Actual retail18950s head/chest: humanlike natural jaw/skin with subtle angular facial seams, silverhair, white shirt and patterned GRAY tie, black notched jacketlapels. No combat visor.'),
 ('research/video-captures/mgrHD-18957s.png',MGR,'Actual retail18957s fullbody: same silverhair Raiden in fitted black suit, normal black formal shoes, black gloves, slim proportions.')],
 'ONE SINGLE FULLBODY STATIC SPRITE, calm neutral standing pose front threequarter facing RIGHT. True alpha0 transparent background. Whole head, fingers, both shoes fully in frame with generous64px margin. Highquality detailed painted2D/2.5D fightinggame native asset, no text, labels, grids, scene, glow or ground. Depict adult RAIDEN from the ACTUAL MGR POSTCREDITS EPILOGUE clothing in references2-4, SAME UID as first Original but use actual epilogue humanlike face and FORMAL SUIT. Slim adult athletic build, tousled SILVERHAIR swept over forehead, pale natural-looking face, natural humanlike lower jaw with subtle angular cheek seam from retail closeup3, no cybernetic combat visor or armored chin. Fitted BLACK singlebreasted businessjacket with notched lapels, WHITE collared shirt, subdued patterned GRAY necktie, narrow BLACK formal suittrousers, BLACK fullfinger gloves with small white shirtcuffs, plain BLACK polished formal shoes. No exposed combatarmor, no tuxedo bowtie, no eyepatch added, no coat tails. Keep adult proportions coherent with Original. Arms relaxed down; no sword action, no other people, no background. ONE pose only, no animation or repeated frames.',
 'Actual retail fullbody18957 plus clothing18945 and closeup18950 establish sameUID epilogue suit. Original used only for identity/proportion; actual epilogue natural-looking jaw/face overrides armored Original. Fine tie weave and unseen back tailoring are not pixel-exact certified. No sword/attack posed; no animation.')
