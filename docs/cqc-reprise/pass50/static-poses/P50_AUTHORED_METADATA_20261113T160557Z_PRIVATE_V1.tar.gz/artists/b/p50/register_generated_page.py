"""Preserve raw imagegen bytes and propose static official source geometry."""
import argparse,datetime,hashlib,json,os
from pathlib import Path
import numpy as np
from PIL import Image

def read(path):
    with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()

def main(job_path,generator):
    job=json.loads(read(job_path));name=job['name'];root=Path(__file__).parent/name
    root.mkdir(parents=True,exist_ok=True)
    raw=read(generator);path=root/(name+'-static-raw-v1.png')
    with open(path,'xb')as f:f.write(raw)
    digest=hashlib.sha256(raw).hexdigest()
    with Image.open(path)as image:
        width,height=image.size;mode=image.mode
        if mode!='RGBA':raise ValueError('Preserved raw image is not RGBA')
        alpha=np.asarray(image)[:,:,3]
    cols=job['atlas']['columns'];rows=job['atlas']['rows'];slots=[]
    for index,item in enumerate(job['slots']):
        col=index%cols;row=index//cols
        left=width*col//cols;right=width*(col+1)//cols
        top=height*row//rows;bottom=height*(row+1)//rows
        cut=alpha[top:bottom,left:right];ys,xs=np.where(cut>=16)
        if not len(xs):raise ValueError('Empty expected costume cell')
        x0=max(left,left+int(xs.min())-12);x1=min(right,left+int(xs.max())+13)
        y0=max(top,top+int(ys.min())-8);y1=min(bottom,top+int(ys.max())+9)
        strong=cut>=127;yy,xx=np.where(strong);floor=top+int(yy.max())+1
        foot=strong&(np.indices(cut.shape)[0]>=floor-top-min(80,(bottom-top)//8))
        fy,fx=np.where(foot);body_x=left+(int(fx.min())+int(fx.max())+1)/2
        slot={key:item[key]for key in ('uid','costumeID','historicalID','label','classification')}
        slot.update(sourceRect=[x0,y0,x1-x0,y1-y0],bodyBounds=[left+int(xs.min()),top+int(ys.min()),int(xs.max()-xs.min()+1),int(ys.max()-ys.min()+1)],footDatumY=floor,bodyDatumX=body_x,pivot=[(body_x-x0)/(x1-x0),(floor-y0)/(y1-y0)],poseCount=1,animationCount=0,facing='right',support=item.get('observations','See physically viewed scoped references'))
        if job.get('posture'):
            slot.update(posture=job['posture'],geometryRoute='CLINICAL_NON_COMBAT',standingHeightReference=None,
                        supportDatum={'kind':'clinical-bed/mattress','x':body_x,'y':floor,
                                      'isStandingFeetDatum':False,'method':'visible clinical support base, never standing stature'})
        slots.append(slot)
    edge=int((alpha[0]>=16).sum()+(alpha[-1]>=16).sum()+(alpha[:,0]>=16).sum()+(alpha[:,-1]>=16).sum())
    receipt={'schema':'cqc.p50.raw-imagegen-preservation/1','name':name,'path':str(path),'generatorPath':str(generator),'bytes':len(raw),'sha256':digest,'width':width,'height':height,'mode':mode,'rawPNGTransformed':False,'SourcePixelsEditedByCPU':False,'alphaMin':int(alpha.min()),'alphaMax':int(alpha.max()),'edgeForegroundAbove16':edge}
    with open(root/'RAW_V1_RECEIPT_PRIVATE.json','x')as f:json.dump(receipt,f,indent=2)
    proposal={'schema':'cqc.static.official-generated-page-proposal/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'uid':job['uid'],'period':job.get('period','Same assigned incarnation; scoped actual official-state references'),'rawPNG':{key:receipt[key]for key in ('path','generatorPath','bytes','sha256','width','height','rawPNGTransformed')},'atlas':job['atlas'],'slots':slots,'referenceSources':job['referenceSources'],'headBodyContract':job.get('headBodyContract','Actual state-specific references supply appearance; own sameUID Original supplies known body/proportions only, no other-era merge.'),'visualReview':{'reviewer':'/root/static_artist_b direct Original, actual references and generated sprite inspection','newSpriteViewed':True,'sameIdentityAndPeriod':True,'limits':job['limits']},'alphaAnalysis':{'min':int(alpha.min()),'max':int(alpha.max()),'alphaZero':int((alpha==0).sum()),'edgeForegroundAbove16':edge},'SourcePixelsEditedByCPU':False,'runtimeAdmitted':False,'newAnimations':0}
    target=root/(name.upper().replace('-','_')+'_ARTIFACT_PROPOSAL_PRIVATE_V1.json')
    with open(target,'x')as f:json.dump(proposal,f,ensure_ascii=False,indent=2)
    print(json.dumps({'proposalPath':str(target),'proposalSHA256':hashlib.sha256(read(target)).hexdigest(),'rawPNG':proposal['rawPNG'],'slots':[{'id':s['costumeID'],'rect':s['sourceRect']}for s in slots],'alpha':proposal['alphaAnalysis']}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('job');p.add_argument('generator');a=p.parse_args();main(a.job,a.generator)
