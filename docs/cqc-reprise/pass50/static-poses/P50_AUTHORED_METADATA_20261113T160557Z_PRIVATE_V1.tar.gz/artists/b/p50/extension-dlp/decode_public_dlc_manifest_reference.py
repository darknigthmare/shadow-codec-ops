"""Read-only reproduction of a documented public DLC manifest decode.

No DLP texture decoding, executable launch, image manipulation, game or catalog edits.
Algorithm: Zoft123/LA2_Studio commit f0558ce560a8fc304214b38b7330ed99fdf20969,
js/formats/mgo2crypt.js (MIT), checksumOk/decrypt with the actual folder key `dlc`.
"""
import argparse
import csv
import hashlib
import io
import json
import os
import re
import struct
import zipfile
import zlib
from pathlib import Path

PUBLIC_FILES_KEY = bytes.fromhex(
    '5db9c260dcde6397dde2487e08ed5e93b7052bb190a9f6749f5eae699c168697'
    'd0c85a21c732dfa1bb5cedc93ed4b7971b99dc1c45300afc415c591ca150de52')
ALGORITHM_URL = ('https://github.com/Zoft123/LA2_Studio/blob/'
                 'f0558ce560a8fc304214b38b7330ed99fdf20969/js/formats/mgo2crypt.js')

def read_noatime(path):
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOATIME | os.O_NOFOLLOW), 'rb') as f:
        return f.read()

def derive(folder):
    salt = hashlib.md5(folder.encode()).digest()
    key = bytes(v ^ salt[i % 16] for i, v in enumerate(PUBLIC_FILES_KEY))
    return key, bytes(v ^ 0x36 for v in key), bytes(v ^ 0x5c for v in key)

def checksum_ok(data, folder):
    if len(data) < 24:
        return False
    _, salt_a, salt_b = derive(folder)
    return hashlib.md5(salt_b + hashlib.md5(salt_a + data[:-16]).digest()).digest() == data[-16:]

def decode_verified_manifest(data):
    assert checksum_ok(data, 'dlc'), 'Native manifest ptsys checksum mismatch'
    key, _, _ = derive('dlc')
    words = struct.unpack('<8Q', key)
    previous = words[0]
    out = bytearray()
    for i in range((len(data) - 16) // 8):
        cipher = struct.unpack_from('<Q', data, 8 * i)[0]
        out += struct.pack('<Q', cipher ^ previous ^ words[i % 7 + 1])
        previous = cipher
    return bytes(out[:len(data) - 24])

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--zip', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    package = read_noatime(args.zip)
    with zipfile.ZipFile(io.BytesIO(package)) as archive:
        encrypted = archive.read('dlc/dlc.bak')
        manifest = decode_verified_manifest(encrypted)
        text = manifest.decode('utf-8')
        assert '<!-- "MGS4LIST"' in text
        rows = []
        for match in re.finditer(r'(?ms)^Data=(.*?)(?=^Data=|^\s*-->)', text):
            row = next(csv.reader(io.StringIO(match.group(1)), skipinitialspace=True))
            if len(row) < 4 or row[1] != 'OCT' or row[2] not in {'DIGITALRED', 'LAUGH', 'POWER', 'SPIRIT'}:
                continue
            assert len(row) == 10
            name = row[2] + '.dlp'
            data = archive.read('dlc/dl_oct/' + name)
            crc = zlib.crc32(data) & 0xffffffff
            assert len(data) == int(row[4]) and crc == int(row[8], 16)
            rows.append(dict(nativeFile=name, officialMenuName=row[3], bytes=len(data),
                             sha256=hashlib.sha256(data).hexdigest(), CRC32=f'{crc:08x}',
                             manifestCRC32Match=True, manifestRowByteOffset=len(text[:match.start()].encode()),
                             locator='https://savemgo.com/mgs4/files/' + name,
                             pixelTextureDecoded=False))
    assert len(rows) == 4
    args.out.mkdir(parents=True, exist_ok=True)
    with (args.out / 'manifest-decoded-reference.html').open('xb') as f:
        f.write(manifest)
    report = dict(schema='cqc.p50.public-dlc-manifest-verified-reference/1', algorithmURL=ALGORITHM_URL,
                  inputZIP=str(args.zip), inputZIP_SHA256=hashlib.sha256(package).hexdigest(),
                  inputManifest_SHA256=hashlib.sha256(encrypted).hexdigest(),
                  decodedManifest_SHA256=hashlib.sha256(manifest).hexdigest(),
                  ptsysIntegrityVerified=True, rows=rows, DLPTexturesDecoded=0, newPNGCount=0)
    with (args.out / 'MANIFEST_NAME_CRC_PROOF_PRIVATE_V1.json').open('x') as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(json.dumps(dict(rows=len(rows), integrityVerified=True, DLPTexturesDecoded=0, newPNGCount=0)))

if __name__ == '__main__':
    main()
