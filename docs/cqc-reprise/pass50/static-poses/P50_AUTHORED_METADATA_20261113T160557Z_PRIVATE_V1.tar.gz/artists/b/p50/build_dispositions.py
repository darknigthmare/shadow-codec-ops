"""Consolidate B29 static-only proposals; never change external catalogs or runtime."""
from pathlib import Path
import os,json,hashlib,datetime,collections,io
import numpy as np
from PIL import Image
R=Path(__file__).parent

def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
def js(p):return json.loads(read(p))
def sha(p):return hashlib.sha256(read(p)).hexdigest()
assignment=Path('/tmp/cqc-static-20261113/p50/assignments/b_mgs4_mgr.json');a=js(assignment);by={};proposals=[];checks=[]
for p in sorted(R.glob('*/*_ARTIFACT_PROPOSAL_PRIVATE_V1.json')):
 d=js(p);raw=d['rawPNG'];b=read(raw['path']);assert len(b)==raw['bytes'] and hashlib.sha256(b).hexdigest()==raw['sha256']
 im=np.asarray(Image.open(io.BytesIO(b)));alpha=im[:,:,3];edge127=int((alpha[0]>=127).sum()+(alpha[-1]>=127).sum()+(alpha[:,0]>=127).sum()+(alpha[:,-1]>=127).sum());assert alpha.min()==0;assert edge127==0
 for ref in d['referenceSources']:
  assert ref['viewed'] and ref['viewedBy']=='/root/static_artist_b';assert sha(ref['path'])==ref['sha256']
 for s in d['slots']:
  assert s['historicalID'] not in by;assert s['animationCount']==0 and s['poseCount']==1 and s['facing']=='right';by[s['historicalID']]=(p,d,s)
 proposals.append(dict(proposalPath=str(p),sha256=sha(p),rawPNG=raw,poseCount=len(d['slots']),historicalIDs=[s['historicalID']for s in d['slots']]))
 checks.append(dict(rawPNG=raw['path'],rawPNG_SHA256=raw['sha256'],alphaZero=int((alpha==0).sum()),alphaMin=int(alpha.min()),edgeForegroundAbove127=edge127,edgeForegroundAbove16=d['alphaAnalysis']['edgeForegroundAbove16'],referencePinsMatch=True))
aliasp=R/'OTACON_MGS4_WEDDING_ORIGINAL_EQUIVALENCE_PRIVATE_V1.json';alias=js(aliasp)
refusalp=R/'MISTRAL_TWO_ARM_SERVICE_REFUSAL_PRIVATE_V1.json';refusal=js(refusalp)
lacunap=R/'OCTOCAMO_THREE_EXACT_TEXTURE_LACUNAE_PRIVATE_V1.json';lacuna=js(lacunap);lacunaBy={x['historicalID']:x for x in lacuna['items']};rows=[]
for source in a['rows']:
 h=source['historicalID'];r={k:source[k]for k in ['historicalID','historicalCostumeName','historicalEpisode','reconciledOfficialID','historicalStatusPreserved']};r.update(uid=source['targetUID'],reviewer='/root/static_artist_b',animationCount=0,newAnimationCount=0,targetCostumeID=None)
 if h in by:
  p,d,s=by[h];r.update(status='GENERATED_STATIC_SOURCE_PROPOSED',reason=s['support'],proposalPath=str(p),targetCostumeID=s['costumeID'],newPoseCount=1,rawPNG=d['rawPNG'],evidenceURLs=list(dict.fromkeys(x['URL']for x in d['referenceSources']if x.get('URL'))),proofPaths=[x['path']for x in d['referenceSources']],referenceLimit=d['visualReview']['limits'])
 elif h==alias['historicalID']:
  r.update(status='ORIGINAL_VISUAL_EQUIPMENT_ALIAS_PROPOSED',reason=alias['reason'],proposalPath=str(aliasp),targetCostumeID=alias['targetCostumeID'],newPoseCount=0,evidenceURLs=list(dict.fromkeys(x['URL']for x in alias['referenceSources']if x.get('URL'))),proofPaths=[x['path']for x in alias['referenceSources']]+[alias['existingSource']['path']],referenceLimit=alias['limits'])
 elif h==refusal['historicalID']:
  job=js(refusal['jobPath']);r.update(status='SERVICE_MODERATION_BLOCKED',reason=refusal['reason'],requestID=refusal['requestID'],costumeID=refusal['costumeID'],rawPNGCount=0,newPoseCount=0,noRetry=True,moderationStage=refusal['moderationStage'],categories=refusal['categories'],evidenceQualified=True,evidenceURLs=list(dict.fromkeys(x['URL']for x in job['referenceSources']if x.get('URL'))),proofPaths=[str(refusalp),refusal['jobPath']]+[x['path']for x in job['referenceSources']],preciseMissingEvidence='No evidencegap; actualretail state qualified. Image service output refused, 0PNG. No retry/rephrase/other-agent substitute.')
 elif h in lacunaBy:
  x=lacunaBy[h];r.update(status='DEFERRED_REFERENCE_EVIDENCE_INSUFFICIENT',reason=x['reason'],newPoseCount=0,rawPNGCount=0,evidenceURLs=x['evidenceURLs'],proofPaths=[str(lacunap)]+x['proofPaths'],preciseMissingEvidence=x['reason'],searchesAttempted=lacuna['searchesAttempted'])
 else:raise RuntimeError('Unresolved assignment row '+h)
 rows.append(r)
assert len(rows)==29 and len({x['historicalID']for x in rows})==29 and len(by)==24
assert sum(x['newPoseCount']for x in rows)==24 and len(proposals)==14
out=dict(schema='cqc.p50.official-disjoint-final-dispositions/1',atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),assignment=str(assignment),author='/root/static_artist_b',reviewer='/root/static_artist_b',counts=dict(assignedRows=29,newStaticPoses=24,rawPNGs=14,sameUIDOriginalAliases=1,serviceRefusals=1,referenceDeferred=3,newAnimations=0,statusCounts=dict(collections.Counter(x['status']for x in rows))),rows=rows,sourceProposals=proposals,verification=checks,constraints=dict(ONE_RIGHT_static_pose_per_costume=True,maximum9DifferentCostumesPerPNG=True,imageGenerationOnly=True,CPUartEdits=False,allOldSourcesPreserved=True,gameMenuStageRuntimeChanges=False,GitVercelChanges=False,existingGuardsUntouched=True,newMistralRefusalNoRetry=True),researchReceipts=[str(R/'ORIGINAL_PROOFS_PRIVATE_V1.json'),str(R/'research/GUIDE_PDF_DOWNLOAD_RECEIPT_PRIVATE_V1.json'),str(R/'research/MGS4_DLC_ARCHIVE_RECEIPT_PRIVATE_V1.json'),str(R/'research/MGS4_DLC_REFERENCE_EXTRACTION_RECEIPT_PRIVATE_V1.json')],largeLocalResearchInputsExcludedFromPublication=['research/mgs4-public-dlc.7z','research/savemgo-public-dlc.zip','research/vendor/'],qualification='Actual retail/video or officialguide appearance + physicallyknown SAMEUID/incarnationOriginal bridge. These are new static2D/2.5D adaptations, not pixel-extracted retailsprites. Exact tinyUV/hiddengeometry limitations retained ineach proposal. No undocumented pattern invented asofficial.')
p=R/'P50_B_MGS4_MGR_DISPOSITIONS_PRIVATE_V1.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps({'report':str(p),'sha256':sha(p),'counts':out['counts']},ensure_ascii=False))
