import os,json,sys,hashlib,datetime,io,math
from pathlib import Path
from PIL import Image
import numpy as np
ROOT=Path('/tmp/cqc-static-20261113/artists/e/p50/extension')
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
job=Path(sys.argv[1]);source=Path(sys.argv[2]);q=json.loads(read(job));version=int(sys.argv[3])if len(sys.argv)>3 else 1
slug=q.get('outputSlug',job.name.split('-PREPARED')[0]);dest=ROOT/(slug+'-raw-v'+str(version)+'.png');raw=read(source)
with open(dest,'xb')as f:f.write(raw)
assert read(dest)==raw
im=Image.open(io.BytesIO(raw)).convert('RGBA');ar=np.asarray(im);alpha=ar[:,:,3];n=len(q['slots']);cols=q.get('columns',min(3,n));rows=q.get('rows',math.ceil(n/cols));slots=[]
for i,s in enumerate(q['slots']):
 rect=s.get('sourceRect',[im.width*(i%cols)//cols,im.height*(i//cols)//rows,im.width*((i%cols)+1)//cols-im.width*(i%cols)//cols,im.height*((i//cols)+1)//rows-im.height*(i//cols)//rows]);x,y,w,h=rect;a=alpha[y:y+h,x:x+w];yy,xx=np.where(a>=16);assert len(xx)
 body=[x+int(xx.min()),y+int(yy.min()),int(xx.max()+1-xx.min()),int(yy.max()+1-yy.min())]
 m=a>=127;yy,xx=np.where(m);floor=y+int(yy.max())+1;fy,fx=np.where(m&(np.indices(m.shape)[0]>=int(yy.max())-79));cx=x+(int(fx.min())+int(fx.max())+1)/2
 bodyX=s.get('bodyDatumX',cx);footY=s.get('footDatumY',floor)
 tight=[max(x,body[0]-16),max(y,body[1]-12),0,0];tight[2]=min(x+w,body[0]+body[2]+16)-tight[0];tight[3]=min(y+h,body[1]+body[3]+12)-tight[1]
 slots.append({**s,'sourceRect':tight,'bodyBounds':body,'bodyDatumX':bodyX,'footDatumY':footY,'pivot':[(bodyX-tight[0])/tight[2],(footY-tight[1])/tight[3]],'poseCount':1,'animationCount':0,'facing':'right'})
refs=[]
for i,p in enumerate(q['references']):
 r=read(p);refs.append({'path':p,'URL':q.get('referenceURLs',[None]*len(q['references']))[i],'sha256':hashlib.sha256(r).hexdigest(),'bytes':len(r),'viewed':True,'viewedBy':'/root/static_artist_b/p50_mgr_reference','scope':q.get('referenceScopes',['Reference physically viewed']*len(q['references']))[i]})
out={'schema':'cqc.static.official-generated-page-proposal/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'uid':q['uid'],'period':q.get('period','Exact selected original-game UID/incarnation'),'rawPNG':{'path':str(dest),'generatorPath':str(source),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'width':im.width,'height':im.height,'rawPNGTransformed':False},'atlas':{'columns':cols,'rows':rows,'onePosePerCostume':True,'animations':False},'slots':slots,'referenceSources':refs,'visualReview':{'reviewer':'/root/static_artist_b/p50_mgr_reference','newSpriteViewed':True,'sameIdentityAndPeriod':True,'limits':q['limits']},'alphaAnalysis':{'min':int(alpha.min()),'max':int(alpha.max()),'alphaZero':int((alpha==0).sum()),'edgeForegroundAbove16':int((alpha[0]>=16).sum()+(alpha[-1]>=16).sum()+(alpha[:,0]>=16).sum()+(alpha[:,-1]>=16).sum())},'SourcePixelsEditedByCPU':False,'runtimeAdmitted':False,'newAnimations':0,'preparedJob':str(job)}
path=ROOT/(slug+'-ARTIFACT_PROPOSAL_PRIVATE_V'+str(version)+'.json')
with open(path,'x')as f:json.dump(out,f,ensure_ascii=False,indent=2)
print(json.dumps({'proposal':str(path),'proposalSHA256':hashlib.sha256(read(path)).hexdigest(),'rawPNG':out['rawPNG'],'slots':slots,'alpha':out['alphaAnalysis']},ensure_ascii=False))
