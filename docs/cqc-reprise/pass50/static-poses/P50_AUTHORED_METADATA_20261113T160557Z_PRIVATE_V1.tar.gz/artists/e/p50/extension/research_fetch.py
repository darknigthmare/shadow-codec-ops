import urllib.request, urllib.parse, urllib.error, os, json, hashlib, concurrent.futures, sys, datetime
from pathlib import Path
ROOT=Path('/tmp/cqc-static-20261113/artists/e/p50/extension')
DEST=ROOT/'references';DEST.mkdir(parents=True,exist_ok=True)
def fetch(url):
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
  with urllib.request.urlopen(req,timeout=25)as response:
   raw=response.read(40*1024*1024);ct=response.headers.get('Content-Type','');status=response.status;final=response.url
  name=urllib.parse.urlparse(url).path.rsplit('/',1)[-1] or 'index';name=''.join(c if c.isalnum()or c in '._-'else'_'for c in name)[:100]
  path=DEST/(hashlib.sha256(url.encode()).hexdigest()[:14]+'-'+name)
  if path.exists():
   with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:old=f.read()
   if old!=raw:path=DEST/(hashlib.sha256(url.encode()).hexdigest()[:14]+'-'+hashlib.sha256(raw).hexdigest()[:12]+'-'+name)
  if not path.exists():
   with open(path,'xb')as f:f.write(raw)
  return {'url':url,'status':status,'finalURL':final,'contentType':ct,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'path':str(path),'viewed':False}
 except urllib.error.HTTPError as e:return {'url':url,'status':e.code,'error':str(e)}
 except Exception as e:return {'url':url,'error':str(e)}
if __name__=='__main__':
 batch=sys.argv[1];urls=sys.argv[2:]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4)as executor:results=list(executor.map(fetch,urls))
 out=ROOT/(batch+'.json')
 with open(out,'x')as f:json.dump({'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'results':results},f,ensure_ascii=False,indent=2)
 print(json.dumps(results,ensure_ascii=False))
