from pathlib import Path
import urllib.request,urllib.parse,hashlib,json,re,datetime,concurrent.futures,os
R=Path('/tmp/cqc-static-20261113/artists/e/p50/extension')
pages=['https://www.creativeuncut.com/gallery-11/mga2-snake.html','https://www.creativeuncut.com/gallery-11/mga2-snake-portrait.html','https://www.creativeuncut.com/gallery-11/mga2-venus.html','https://www.creativeuncut.com/gallery-11/mga2-venus-portrait.html','https://www.creativeuncut.com/gallery-06/mgs2-raiden3.html']
def fetch(page):
 o={'pageURL':page,'method':'ordinary public image load with actual page Referer, no auth/cookie workaround'}
 try:
  with urllib.request.urlopen(urllib.request.Request(page,headers={'User-Agent':'Mozilla/5.0'}),timeout=20)as q:t=q.read().decode()
  matches=re.findall(r'<img[^>]+src="(art/[^"]+)"',t)
  if not matches:raise Exception('No real art image found in HTML')
  url=urllib.parse.urljoin(page,matches[0]);o['URL']=url
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0','Referer':page,'Accept':'image/*'}),timeout=20)as q:b=q.read(15000000);o['status']=q.status
  p=R/'references'/('PAGE_REFERRED_'+url.rsplit('/',1)[-1]);p.write_bytes(b);o.update(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),viewed=False)
 except Exception as e:o['error']=str(e)
 return o
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as ex:r=list(ex.map(fetch,pages))
p=R/'FETCH_LAST_CU_ACTUAL_REFERENCE_IMAGES_PRIVATE_V1.json';p.write_text(json.dumps({'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'results':r},indent=2));print(json.dumps(r))
