import pathlib,json,hashlib,datetime,struct,os
B=pathlib.Path('/tmp/cqc-static-20261113/artists/f/p52'); R=B/'references'; N=pathlib.Path('/tmp/cqc-static-20261113')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def info(p):
 raw=p.read_bytes(); d={'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 if raw[:8]==b'\x89PNG\r\n\x1a\n':d.update(zip(['width','height'],struct.unpack('>II',raw[16:24])))
 return d
copy_receipts=[]
for uid in ['core__quiet','completion44__diamond_dogs_scout_44']:
 src=N/'recovered-originals'/(uid+'-original-right.png'); dest=R/src.name
 fd=os.open(src,os.O_RDONLY|os.O_NOATIME)
 with os.fdopen(fd,'rb') as f:data=f.read()
 dest.write_bytes(data); rec=info(dest); rec.update({'from':str(src),'readWithNoAtime':True,'transformed':False});copy_receipts.append(rec)
write(R/'P52_TWO_NATIVE_REFERENCE_BYTE_COPIES_PRIVATE_V1.json',{'atUTC':now,'rows':copy_receipts})
viewed={
'core__quiet-original-right.png':('existing-native-atlas','Same adult Quiet standard clothing, first neutral RIGHT pose viewed in original atlas.'),
'completion44__diamond_dogs_scout_44-original-right.png':('existing-native-atlas','Generic adult male DD tan/olive fatigues and black patches with belt/rifle; no chest vest visible in first neutral RIGHT pose.'),
'pcgamer-quiet-arrival-2014.jpg':('prerelease-official-screenshot-secondary-host','Mother Base arrival scene, back three-quarter: bare shoulders/back, olive harness and belt pouches, black bikini/torn tights; no draped coat in this frame.'),
'mgi-quiet-arrival-2014.jpg':('prerelease-official-screenshot-secondary-host','Mother Base arrival scene, front three-quarter: black tie-front bikini, olive harness and belt, one long black left glove, torn tights; no shoulder coat in this frame.'),
'gamepressure-quiet-367618540.jpg':('retail-guide-screenshot','Named Quiet defeated after Mission11: black tie-front bikini and olive straps on bare shoulders; upper-body corroboration, no garment change shown.'),
'gamepressure-quiet-367618555.jpg':('retail-guide-screenshot','Mission11 extraction: Quiet carried toward helicopter, back visible between olive straps and dark torn tights. No coat worn on the shown back. Distance limits fine detail.'),
'gamepressure-quiet-526243055.jpg':('retail-guide-screenshot','Quiet in post-Mission11 helicopter cutscene with handcuffs: black tie-front bikini, olive shoulder harness, left long black glove, bare upper arms/shoulders. No shoulder cloak in shown area. Guide connects this route to return at Mother Base.'),
'gamepressure-quiet-526243071.jpg':('retail-guide-screenshot','Quiet combat scope silhouette; inspected but too distant to establish fine clothing or a cape.'),
'gamepressure-quiet-526243102.jpg':('retail-guide-context-screenshot','Mother Base medical stairs context only; not costume proof.'),
'gamepressure-quiet-526243117.jpg':('retail-guide-context-screenshot','Visit Quiet map context only; not costume proof.')
}
for i in range(1,7):viewed[f'konami-mgo-scout-{i:02}.jpg']=('primary-publisher-MGO-class-screenshot','Official MGO Scout class image. Scoped to MGO class; does not prove TPP generic DD same-body vest. Short cape/shoulder overlay and MGO gear are not silently imported into TPP DD.')
ledger=[]
for name,(kind,observed) in viewed.items():
 p=R/name; rec=info(p);rec.update({'viewed':True,'kind':kind,'observed':observed});ledger.append(rec)
write(R/'P52_F_PHYSICALLY_VIEWED_REFERENCE_LEDGER_PRIVATE_V1.json',{'atUTC':now,'reviewer':'/root/p52_mgsv','rows':ledger,'viewsAreOriginalBytes':True,'CPURasterTransforms':False})
qsrc=next(x for x in copy_receipts if x['path'].endswith('core__quiet-original-right.png'))
qsrc={k:v for k,v in qsrc.items() if k in ['path','bytes','sha256','width','height']}
qsrc.update({'viewed':True,'kind':'existing-native-atlas','originalPath':'/workspace/cqc-pass21-application/public/cqc/assets/combat-sprites/core__quiet/a-right-v1.png','slot':0})
qrefs=[]
for name,url,page,kind in [
('gamepressure-quiet-526243055.jpg','https://www.gamepressure.com/mgs5thephantompain/gfx/word/526243055.jpg','https://www.gamepressure.com/mgs5thephantompain/quiet-the-female-sniper/z17cf1','retail-guide-screenshot'),
('gamepressure-quiet-367618555.jpg','https://www.gamepressure.com/mgs5thephantompain/gfx/word/367618555.jpg','https://www.gamepressure.com/mgs5thephantompain/deciding-quiets-fate/ze7cc1','retail-guide-screenshot'),
('pcgamer-quiet-arrival-2014.jpg','https://cdn.mos.cms.futurecdn.net/677718101f5e2878e3cc726d71e43d51.jpg','https://www.pcgamer.com/metal-gear-solid-v-tgs-gallery/','prerelease-official-screenshot-secondary-host'),
('mgi-quiet-arrival-2014.jpg','https://www.metalgearinformer.com/wp-content/uploads/2014/10/MGSV-The-Phantom-Pain-Screen-Quiet-at-Mother-Base-1024x576.jpg','https://www.metalgearinformer.com/watch-quiet-attack-mother-base-in-this-snippet-of-mgsv-tpp-tgs-footage/','prerelease-official-screenshot-secondary-host')]:
 rec=info(R/name); rec.update({'URL':url,'pageURL':page,'kind':kind,'viewed':True});qrefs.append(rec)
limits=[
'This explicitly corrects the historical cloak label for the observed arrival scene. No physical arrival cloak is verified, no cloak Source is declared, and no newly distinct official costume is counted. Root must approve the semantic correction; otherwise the historical cloak row remains a gap.',
'The retail Gamepressure post-Mission11 helicopter image establishes the actual normal upper-body garment and glove/harness configuration. The guide names the recruit and connects this sequence with the Mother Base return. It does not independently prove every lower-body seam, boot sole or stocking hole.',
'The two full front/back Mother Base images are 2014 TGS promotional captures, explicitly pre-release rather than a new claim of retail exactness. They corroborate visible arrival gear and no coat in those frames, not absence of a cape from every game asset.',
'Native first RIGHT pose supplies dark combat boots, torn stockings and lower belt gear; exact retail boot construction and every stocking hole stay the existing illustration interpretation. Body/anatomy/palette are not claimed to be UV-accurate.',
'Use one existing neutral RIGHT frame only. Handcuffs, rifle, arrival leap and invisibility effects are not separately drawn or counted. No Original or animation frame is overwritten.'
]
proposal={
'schema':'cqc.static.official-existing-pose-alias-proposal/1','atUTC':now,'uid':'core__quiet','costumeID':'official--arrival-cloak','historicalID':'core__quiet__alt__arrival_cloak',
'label':'Arrivée à Mother Base — tenue Naked d’origine attestée','classification':'historical-scene-label-correction-to-existing-original',
'proposedTargetCostumeID':'original','historicalLabel':'Arrivée à Mother Base — manteau drapé','explicitLabelCorrectionRequired':True,'unverifiedPhysicalCloakRetainedAsFact':False,
'reuseFrom':{'uid':'core__quiet','costumeID':'original','source':qsrc,'frame':{'rect':[86,3,165,396],'bodyDatumX':154.39803320973724,'footDatumY':394,'groundY':394,'pivot':[0.41453353460446807,0.9873737373737373]}},
'newDrawings':0,'newPNG':False,'samePhysicalPose':True,'noSeparateCostumeBodyClaimed':True,'logicalUIDsAndHistoricalIDsPreserved':True,
'proof':{'reviewer':'/root/p52_mgsv','existingSourceActuallyViewed':True,'primaryReferenceActuallyViewed':False,'retailScreenshotActuallyViewed':True,'reference':qrefs[0],'additionalReferences':qrefs[1:],'observed':'New retail post-Mission11 helicopter screenshot shows Quiet wearing the normal black tie-front bikini and olive harness with bare shoulders and upper arms, one long black left glove, and handcuffs. Guide and extraction capture identify the sequence returning her to Mother Base. Existing first neutral RIGHT Quiet frame has the same normal upper-body garments, hair and gear. Full 2014 arrival promotional front/back captures show normal Naked outfit rather than a draped coat. This supports explicitly correcting the scene label to the existing Naked/Original garment, subject to Root review; it does not support drawing an arrival cloak.','limits':limits},
'SourcePixelsEditedByCPU':False,'ASWrites':False,'GitWrites':False,'runtimeAdmitted':False,'RootAdmission':'PENDING','newAnimations':0}
pp=B/'CORE__QUIET_ARRIVAL_NORMAL_CLOTHING_EXISTING_NATIVE_ALIAS_PROPOSAL_PRIVATE_V1.json';write(pp,proposal)
rows=[{
'uid':'completion44__diamond_dogs_scout_44','historicalID':'completion44__diamond_dogs_scout_44__alt__tactical_vest','costumeID':'official--tactical-vest','status':'REFERENCE_DETAIL_PENDING_AFTER_NEW_P52_PRIMARY_AND_ACCESSORY_SEARCH','newSource':None,'newDrawings':0,'newPNG':False,
'reason':'New publisher MGO Scout class screenshots, FV2 attachment documentation and DD uniform inventory routes do not establish the requested TPP generic DD vest-and-helmet configuration. Official MGO images are a different game-mode class with a shoulder cape/armor; the new technical example attaches a DD beret and is not a vest. General secondary DD equipment lists name LBV but do not establish this exact variant geometry or compatible helmet. Previously known woodland/black-vest/padded-helmet illustration remains concept art; it is not newly verified retail clothing. Existing Sneaking Suit/Battle Dress already cover the proven helmet bodies and are not duplicated.',
'evidenceURLs':['https://www.konami.com/mg/mgs5/tpp/jp/online/class.php','https://unknown321.github.io/mgsv_research/fv2.html','https://metalgear.fandom.com/wiki/Diamond_Dogs','https://metalgear.fandom.com/wiki/Roughneck_Raven'],
'proofPaths':[str(R/'P52_F_PHYSICALLY_VIEWED_REFERENCE_LEDGER_PRIVATE_V1.json'),str(R/'konami-mgo-scout-primary-page.html'),str(R/'mgsv-fv2-primary-technical-research.html'),str(R/'completion44__diamond_dogs_scout_44-original-right.png')],
'missingProof':'Actual same-incarnation TPP retail/model/texture view of the vest plus compatible headgear, or a precise unmodified accessory/body join. No artificial full-body-per-costume requirement is imposed; the accessory remains unproved.','noMGOClassSubstitution':True,'noConceptAsRetailClaim':True},
{'uid':'core__quiet','historicalID':'core__quiet__alt__arrival_cloak','costumeID':'official--arrival-cloak','status':'NEW_RETAIL_SCENE_JOIN_SUPPORTS_EXPLICIT_LABEL_CORRECTION_AND_QUALIFIED_EXISTING_ORIGINAL_REUSE_PROPOSED','newSource':None,'newDrawings':0,'newPNG':False,'proposalPath':str(pp),'proposedTargetCostumeID':'original','reason':proposal['proof']['observed'],'missingPhysicalCloakProof':True,'notCompletedAsDistinctCloak':True,'samePhysicalPose':True,'RootAdmission':'PENDING','limits':limits}]
write(B/'P52_F_TWO_MGSV_DISPOSITIONS_PRIVATE_V1.json',{'schema':'cqc.private.p52-two-row-new-reference-dispositions/1','atUTC':now,'agent':'/root/p52_mgsv','rows':rows,'counts':{'assignedHistoricalRows':2,'newPhysicalStaticPoses':0,'newPhysicalPNGs':0,'qualifiedExistingPhysicalPoseReuseProposed':1,'remainingPreciseGarmentGaps':1,'unverifiedPhysicalCloakLabelsExplicitlyCorrectedByProposal':1,'newAnimations':0,'runtimeWrites':0,'GitWrites':0,'guardRetries':0},'interpretation':'Quiet closure is conditional on explicit historical-label correction admitted by Root. It is not a found arrival cloak. Without that correction both requested garment labels remain unverified.','scope':'Only assigned two MGSV rows. 12 guard scopes frozen. No new generation attempted; no pixels edited; no shared index/catalog/runtime/Git writes.'})
write(B/'P52_F_FINAL_HANDOFF_PRIVATE_V1.json',{'schema':'cqc.private.artist-final-handoff/1','atUTC':now,'root':'/tmp/cqc-static-20261113/artists/f/p52','dispositions':str(B/'P52_F_TWO_MGSV_DISPOSITIONS_PRIVATE_V1.json'),'proposals':[str(pp)],'newDrawings':0,'newPNGs':0,'existingPhysicalPoseReuseProposed':1,'remainingGarmentGap':'DD tactical vest and helmet; Quiet physical cloak remains unverified but explicit scene-label correction proposed.','sourcePNGsNewlyGenerated':[],'newReferencesViewed':16,'physicalReferenceLedger':str(R/'P52_F_PHYSICALLY_VIEWED_REFERENCE_LEDGER_PRIVATE_V1.json'),'noRuntimeWrites':True,'noGitWrites':True,'guardRetries':0,'RootAdmission':'PENDING'})
print(json.dumps({'proposal':str(pp),'source':qsrc,'referenceCount':len(ledger),'dispositions':str(B/'P52_F_TWO_MGSV_DISPOSITIONS_PRIVATE_V1.json')},indent=2))
