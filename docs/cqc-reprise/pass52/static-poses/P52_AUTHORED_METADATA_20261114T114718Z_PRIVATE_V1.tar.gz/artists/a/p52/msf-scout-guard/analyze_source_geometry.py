from pathlib import Path
from PIL import Image
from collections import deque,Counter
import json,hashlib,statistics
p=Path('/tmp/cqc-static-20261113/artists/a/p52/msf-scout-guard/msf-scout-guard-raw-v1.png');im=Image.open(p);a=im.getchannel('A');w,h=im.size;data=list(a.get_flattened_data());seen=bytearray(w*h);comps=[]
for i,v in enumerate(data):
 if v<=16 or seen[i]:continue
 q=deque([i]);seen[i]=1;pts=[]
 while q:
  j=q.popleft();x=j%w;y=j//w;pts.append((x,y))
  for k in ([j-1]if x else [])+([j+1]if x+1<w else [])+([j-w]if y else [])+([j+w]if y+1<h else []):
   if not seen[k] and data[k]>16:seen[k]=1;q.append(k)
 if len(pts)>1000:
  x0=min(x for x,y in pts);y0=min(y for x,y in pts);x1=max(x for x,y in pts);y1=max(y for x,y in pts)
  torso=[]
  for y in range(int(y0+(y1-y0)*.30),int(y0+(y1-y0)*.58)):
   xs=[x for x in range(x0,x1+1)if data[y*w+x]>16]
   if xs:torso.append((min(xs)+max(xs))/2)
  feet=[];remaining=set((x,y)for x,y in pts if y>=int(y0+(y1-y0)*.87))
  while remaining:
   start=remaining.pop();q=deque([start]);fpts=[start]
   while q:
    x,y=q.popleft()
    for k in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
     if k in remaining:remaining.remove(k);q.append(k);fpts.append(k)
   if len(fpts)>50:
    fx0=min(x for x,y in fpts);fy0=min(y for x,y in fpts);fx1=max(x for x,y in fpts);fy1=max(y for x,y in fpts);footxs=[x for x,y in fpts if y>=fy1-1]
    feet.append(dict(type='physical-foot-sole',x=statistics.median(footxs),y=fy1,lowerFootRect=[fx0,fy0,fx1-fx0+1,fy1-fy0+1],method='Alpha16 connected silhouette within lowest13percent; sole row median of last2rows, directly checked against raw visible boots.'))
  comps.append(dict(pixels=len(pts),rect=[x0,y0,x1-x0+1,y1-y0+1],bodyDatumX=statistics.median(torso),footDatumY=y1,supportDatums=sorted(feet,key=lambda f:f['x'])))
comps.sort(key=lambda c:c['rect'][0]);hist=Counter(data);edge=[data[x]for x in range(w)]+[data[(h-1)*w+x]for x in range(w)]+[data[y*w]for y in range(h)]+[data[y*w+w-1]for y in range(h)]
d=dict(width=w,height=h,alphaMin=min(data),alphaMax=max(data),alphaZero=hist[0],alpha1to16=sum(v for k,v in hist.items()if 0<k<=16),alphaAbove16=sum(v for k,v in hist.items()if k>16),edgeAlphaMax=max(edge),edgeForegroundAbove16=sum(x>16 for x in edge),mainComponentsAbove16=len(comps),components=comps,rawSHA256=hashlib.sha256(p.read_bytes()).hexdigest(),rawBytes=p.stat().st_size,sourceOnly=True,CPUImageEdits=False)
(p.parent/'SOURCE_GEOMETRY_PRIVATE_V1.json').write_text(json.dumps(d,indent=2));print(json.dumps(d,indent=2))
