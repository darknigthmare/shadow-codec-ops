import io,json,urllib.request,urllib.parse,zipfile,hashlib
from pathlib import Path
base=Path('/tmp/cqc-static-20261113/artists/a/p52')
i='mgs-pw-official-strategy-guide-the-complete-edition-jp'
d=json.loads((base/'research'/(i+'-metadata.json')).read_text())
f=next(x for x in d['files']if x['name'].endswith('_jp2.zip'));size=int(f['size']);url='https://archive.org/download/'+i+'/'+urllib.parse.quote(f['name'])
class RangeFile(io.RawIOBase):
 def __init__(self):self.position=0;self.requests=[]
 def readable(self):return True
 def seekable(self):return True
 def tell(self):return self.position
 def seek(self,o,w=0):
  self.position=o if w==0 else self.position+o if w==1 else size+o;return self.position
 def read(self,n=-1):
  n=size-self.position if n<0 else min(n,size-self.position)
  if n<=0:return b''
  if n>4*1024*1024:raise ValueError('Only small source page members allowed')
  start=self.position;end=start+n-1
  req=urllib.request.Request(url,headers={'Range':f'bytes={start}-{end}'})
  with urllib.request.urlopen(req,timeout=40)as r:
   if r.status!=206:raise ValueError('Server did not honor public Range')
   data=r.read(n);self.requests.append(dict(start=start,end=end,status=r.status,bytes=len(data)))
  self.position+=len(data);return data
stream=RangeFile();receipts=[]
with zipfile.ZipFile(stream)as z:
 entries=[dict(name=x.filename,size=x.file_size,compressedSize=x.compress_size,crc32=f'{x.CRC:08x}')for x in z.infolist()]
 (base/'research/NEW_OFFICIAL_GUIDE_JP2_MEMBER_LIST_PRIVATE_V1.json').write_text(json.dumps(dict(URL=url,archiveBytes=size,archiveSHA1=f.get('sha1'),members=entries),indent=2))
 for n in [459,455,512]:
  matches=[x for x in z.namelist()if x.endswith(f'_{n:04d}.jp2')]
  if not matches:print('no leaf',n);continue
  member=matches[0];data=z.read(member);out=base/'references'/f'official-complete-guide-leaf{n:04d}.jp2';out.write_bytes(data)
  receipts.append(dict(URL=url,member=member,path=str(out),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),unmodified=True));print(str(out),len(data))
(base/'research/NEW_OFFICIAL_GUIDE_SOURCE_PAGE_FETCH_PRIVATE_V1.json').write_text(json.dumps(dict(receipts=receipts,rangeReads=stream.requests),indent=2))
