import io,json,urllib.request,urllib.parse,zipfile,hashlib,concurrent.futures
from pathlib import Path
base=Path('/tmp/cqc-static-20261113/artists/a/p52');i='metal-gear-solid-peace-walker-official-artwork';d=json.loads((base/'research'/(i+'-metadata.json')).read_text());f=next(x for x in d['files']if x['name'].endswith('_jp2.zip'));size=int(f['size']);url='https://archive.org/download/'+i+'/'+urllib.parse.quote(f['name'])
class RF(io.RawIOBase):
 def __init__(self):self.pos=0
 def readable(self):return True
 def seekable(self):return True
 def tell(self):return self.pos
 def seek(self,o,w=0):self.pos=o if w==0 else self.pos+o if w==1 else size+o;return self.pos
 def read(self,n=-1):
  n=min(n,size-self.pos)
  if n<=0:return b''
  if n>4*1024*1024:raise ValueError('Small source members only')
  req=urllib.request.Request(url,headers={'Range':f'bytes={self.pos}-{self.pos+n-1}'})
  with urllib.request.urlopen(req,timeout=40)as r:
   if r.status!=206:raise ValueError('No range')
   b=r.read(n)
  self.pos+=len(b);return b
with zipfile.ZipFile(RF())as z:
 names=z.namelist();(base/'research/NEW_OFFICIAL_ARTBOOK_JP2_MEMBER_LIST_PRIVATE_V1.json').write_text(json.dumps(dict(URL=url,members=names),indent=2))
 jobs=[(n,next(x for x in names if x.endswith(f'_{n:04d}.jp2')))for n in [45,46,47,48]]
def fetch(job):
 n,m=job;args={'zip':d['dir']+'/'+f['name'],'file':m,'id':i,'scale':'1','rotate':'0'};u='https://'+d['d1']+'/BookReader/BookReaderImages.php?'+urllib.parse.urlencode(args);data=urllib.request.urlopen(u,timeout=40).read();out=base/'references'/f'official-artbook-leaf{n:04d}-server.jpg';out.write_bytes(data);return dict(URL=u,path=str(out),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),leaf=n,unmodified=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as ex:receipts=list(ex.map(fetch,jobs))
(base/'research/NEW_OFFICIAL_ARTBOOK_AMANDA_PAGES_FETCH_PRIVATE_V1.json').write_text(json.dumps(receipts,indent=2));print(receipts)
