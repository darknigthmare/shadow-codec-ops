import json,hashlib,os,io,datetime
from pathlib import Path
import numpy as np
from PIL import Image
from scipy import ndimage
ROOT=Path('/tmp/cqc-static-20261113');Q=ROOT/'artists/d/p52/qa'
ps=[ROOT/'artists/e/p52/core__snake_acid2-link-battle-color-b-ARTIFACT_PROPOSAL_PRIVATE_V1.json',ROOT/'artists/e/p52/core__venus-link-battle-color-b-ARTIFACT_PROPOSAL_PRIVATE_V1.json',ROOT/'artists/a/p52/msf-scout-guard/MSF_SCOUT_GUARD_ARTIFACT_PROPOSAL_PRIVATE_V1.json']
manifest=json.loads((ROOT/'p52/catalog/manifest-all381.json').read_text());rows=[]
for pp in ps:
 prop=json.loads(pp.read_text());p=Path(prop['rawPNG']['path'])
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:b=f.read()
 s=hashlib.sha256(b).hexdigest();assert s==prop['rawPNG']['sha256']
 im=Image.open(io.BytesIO(b)).convert('RGBA');a=np.asarray(im)[:,:,3];mask=a>64;labels,n=ndimage.label(mask,np.ones((3,3)));counts=np.bincount(labels.ravel());objects=ndimage.find_objects(labels);components=[]
 for i,sl in enumerate(objects,1):
  if sl is None or counts[i]<100:continue
  yy,xx=sl;components.append({'id':i,'pixels':int(counts[i]),'bbox':[xx.start,yy.start,xx.stop,yy.stop]})
 page={'sourcePath':str(p),'proposalPath':str(pp),'sha256':s,'bytes':len(b),'dimensions':[im.width,im.height],'alphaMinMax':[int(a.min()),int(a.max())],'alphaZero':int((a==0).sum()),'edgeCounts':{str(t):{'top':int((a[0]>t).sum()),'bottom':int((a[-1]>t).sum()),'left':int((a[:,0]>t).sum()),'right':int((a[:,-1]>t).sum())}for t in [0,7,16,64,127,192,240]},'componentsAlpha64':components,'slots':[]}
 for slot in prop['slots']:
  e=next(e for e in manifest['entries']if e['uid']==slot['uid']and e['costumeId']==slot['costumeID']and e.get('source',{}).get('sha256')==s)
  x,y,w,h=e['frame']['rect'];region=labels[y:y+h,x:x+w];ct=np.bincount(region.ravel(),minlength=n+1);rank=sorted([dict(c,pixelsInFrame=int(ct[c['id']]))for c in components if ct[c['id']]],key=lambda c:c['pixelsInFrame'],reverse=True);main=rank[0];bb=main['bbox'];bottom=bb[3];top=int(bottom-(bottom-bb[1])*.13);low=labels[top:bottom,bb[0]:bb[2]]==main['id'];ll,nn=ndimage.label(low,np.ones((3,3)));cnt=np.bincount(ll.ravel());obs=ndimage.find_objects(ll);feet=[]
  for k,sl in enumerate(obs,1):
   if sl is None or cnt[k]<100:continue
   yy,xx=sl;fb=[bb[0]+xx.start,top+yy.start,bb[0]+xx.stop,top+yy.stop];floor=fb[3];soleBandHeight=50;st=max(fb[1],floor-soleBandHeight);sub=(labels[st:floor,fb[0]:fb[2]]==main['id']);ys,xs=np.nonzero(sub)
   if len(xs):feet.append({'lowerFootBBox':fb,'footPixelsInLower13Percent':int(cnt[k]),'soleContactRect':[int(fb[0]+xs.min()),int(st+ys.min()),int(xs.max()-xs.min()+1),int(ys.max()-ys.min()+1)],'soleCenterX':float((fb[0]+xs.min()+fb[0]+xs.max()+1)/2),'soleBottomY':int(st+ys.max()+1),'soleMethod':'Full projected opaque sole silhouette envelope in final50source-pixel band of each separately connected physically viewed boot; lastrow-only toe bias avoided.'})
  d={'uid':e['uid'],'costumeId':e['costumeId'],'sourceSHA256':s,'source':e['source'],'frame':e['frame'],'proposalSlot':slot,'mainComponent':main,'mainPixelsOutsideFrame':int(main['pixels']-main['pixelsInFrame']),'otherLargeComponentsInFrame':rank[1:],'supports':feet}
  page['slots'].append(d)
 rows.append(page)
(Q/'QUANTITATIVE_FRAME_AUDIT_PRIVATE_V1.json').write_text(json.dumps({'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pixelsWritten':False,'pages':rows},indent=2))
print(json.dumps([{'sha':r['sha256'],'dimensions':r['dimensions'],'edgeAlpha16':r['edgeCounts']['16'],'slots':[{'uid':s['uid'],'id':s['costumeId'],'bbox':s['mainComponent']['bbox'],'outside':s['mainPixelsOutsideFrame'],'neighbors':s['otherLargeComponentsInFrame'],'supports':s['supports']}for s in r['slots']]}for r in rows],indent=2))
