"""Extract unchanged full video frames as reference evidence, never sprite edits."""
import os,json,sys,subprocess,concurrent.futures,hashlib,datetime
from pathlib import Path
ROOT=Path('/tmp/cqc-static-20261113/artists/d/p52');DEST=ROOT/'reference-frames';DEST.mkdir(exist_ok=True)
def capture(job):
 label,url,seconds=job;path=DEST/(label+'_'+str(seconds)+'.png')
 if path.exists():raise FileExistsError(path)
 args=['ffmpeg','-hide_banner','-loglevel','error','-rw_timeout','20000000','-ss',str(seconds)]
 proxy=os.environ.get('https_proxy')or os.environ.get('HTTPS_PROXY')
 if proxy:args+=['-http_proxy',proxy]
 args+=['-i',url,'-frames:v','1','-an','-n',str(path)]
 try:
  r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=55)
  out={'url':url+'#t='+str(seconds),'videoURL':url,'timestampSeconds':seconds,'path':str(path),'exitCode':r.returncode,'stderr':r.stderr.decode(errors='replace')[:1200],'unchangedFullSourceFrame':True,'spriteRasterEdited':False,'viewed':False}
  if path.exists():
   with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:raw=f.read()
   out.update({'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
  return out
 except Exception as e:return {'videoURL':url,'timestampSeconds':seconds,'error':str(e)}
if __name__=='__main__':
 batch,label,url=sys.argv[1:4];jobs=[(label,url,int(s))for s in sys.argv[4:]]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3)as ex:out=list(ex.map(capture,jobs))
 with open(ROOT/(batch+'.json'),'x')as f:json.dump({'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'results':out},f,indent=2)
 print(json.dumps(out))
