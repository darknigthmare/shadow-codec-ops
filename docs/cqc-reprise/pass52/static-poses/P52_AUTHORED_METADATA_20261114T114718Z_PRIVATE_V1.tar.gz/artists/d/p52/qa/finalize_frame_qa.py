from pathlib import Path
import json,os,hashlib,datetime
R=Path('/tmp/cqc-static-20261113');Q=R/'artists/d/p52/qa';OUT=R/'p52/catalog/P52_NEW_SOURCE_FRAME_QA_PRIVATE_V1.json'
def sha(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:b=f.read()
 return hashlib.sha256(b).hexdigest()
oldnames=['FRAME_SELECTION_CORRECTIONS_PRIVATE_V1.json','P50_NEW_SOURCE_FRAME_QA_PRIVATE_V1.json','P51_NEW_SOURCE_FRAME_QA_PRIVATE_V1.json']
frozen=[]
for name in oldnames:
 a=R/'p51/catalog'/name;b=R/'p52/catalog'/name
 ha,hb=sha(a),sha(b);assert ha==hb
 frozen.append({'name':name,'P51SHA256':ha,'P52SHA256':hb,'byteIdentical':True,'modifiedByThisReviewer':False})
draft=json.loads((Q/'P52_SOURCE_FRAME_QA_DRAFT_PRIVATE_V1.json').read_text());audit=json.loads((Q/'QUANTITATIVE_FRAME_AUDIT_PRIVATE_V1.json').read_text());base=json.loads((Q/'BASELINE_BROWSER_PLACEMENT_ACTUAL_PRIVATE_V1.json').read_text());corrected=json.loads((Q/'CORRECTED_BROWSER_PLACEMENT_ACTUAL_PRIVATE_V1.json').read_text());proof=[]
for page in audit['pages']:
 assert sha(page['sourcePath'])==page['sha256']
 for slot in page['slots']:
  assert slot['mainPixelsOutsideFrame']==0 and not slot['otherLargeComponentsInFrame']
  assert not any(page['edgeCounts']['16'].values())
  p=next(x for x in corrected['rendered']if x['uid']==slot['uid']and x['costumeId']==slot['costumeId']and x['sourceSHA256']==page['sha256'])
  supports=p['renderedSupports'];mean=sum(f['displayCenterX']for f in supports)/2;floor=max(f['displayBottomY']for f in supports)
  assert abs(mean-160)<1e-9 and abs(floor-340)<1e-9
  c=next(x for x in draft['corrections']if x['uid']==slot['uid']and x['costumeId']==slot['costumeId']and x['sourceSHA256']==page['sha256'])
  c['actualCorrectedPlacement']=p['placement'];c['actualRenderedSupportDatums']=supports;c['sourcePhysicallyViewed']=True;c['baselineAndCorrectedBrowserPhysicallyViewed']=True
  c['geometryValidation']={'fullStrongSilhouetteRetained':True,'opaqueMainPixelsOutsideRect':0,'otherLargeComponentsInFrame':0,'alphaAbove16PageEdgeCounts':page['edgeCounts']['16'],'noVisibleCanvasClipping':True,'neighborBleed':False,'sourceRectUnchanged':c['rect']==c['previousFrame']['rect'],'sourceSHA256ReverifiedAfterBrowser':sha(page['sourcePath']),'displayFootSupportMeanX':mean,'displayLowestOpaqueFloorY':floor,'higherFarFootPreserved':True,'noPixelPerfectCertification':True}
  proof.append({'uid':slot['uid'],'costumeId':slot['costumeId'],'sourceSHA256':page['sha256'],'sourcePath':page['sourcePath'],'pageDimensions':page['dimensions'],'pagePhysicallyViewed':True,'posePhysicallyViewed':True,'rawAndCatalogSHA256Unchanged':True,'mainComponentAlpha64':slot['mainComponent'],'bodySourceCenterX':c['bodyDatumX'],'groundSourceY':c['footDatumY']})
out={**draft,'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/p52_legacy','scope':'Only the four newly active P52 poses in three exact rawPNG SHAs. Static source geometry/display review using actualp52/catalog/manifest-model.mjs placement() at320x360. No importer,manifest,index,build,sourcepixels,Git or game runtime changes.', 'counts':{'pages':3,'posesActuallyViewed':4,'corrections':4,'rectsChanged':0,'pivotCorrections':4,'bodyBoundsRestoredFromArtistProposal':2,'newDrawingsByReviewer':0,'newAnimations':0},'sourceReviews':proof,'browserQA':{'actualPlacementModulePath':str(R/'p52/catalog/manifest-model.mjs'),'actualPlacementModuleSHA256':sha(R/'p52/catalog/manifest-model.mjs'),'canvas':[320,360],'groundY':340,'centerX':160,'baselineActualPlacementReceipt':str(Q/'BASELINE_BROWSER_PLACEMENT_ACTUAL_PRIVATE_V1.json'),'correctedActualPlacementReceipt':str(Q/'CORRECTED_BROWSER_PLACEMENT_ACTUAL_PRIVATE_V1.json'),'baselineCapture':str(Q/'baseline-render.png'),'baselineCaptureSHA256':sha(Q/'baseline-render.png'),'correctedCapture':str(Q/'corrected-render.png'),'correctedCaptureSHA256':sha(Q/'corrected-render.png'),'allFourBaselineAndCorrectedCardsPhysicallyViewed':True,'allFourSourceFiguresPhysicallyViewed':True,'sourcePixelsWritten':False},'frozenPriorQALayers':frozen,'pixelPolicy':'Read-only rawRGBA analysis and browser screenshot captures only. No crop, resize, recolor, retouch, alpha edit or CPU raster output was made to any source image. Metadata only; each correction requires exact sourceSHA256 match.','limits':['Static frame,alpha,source-rectangle,body-center and projected-foot support review only; no retail pixel/mesh or pixel-perfect certification.','The two sourcePNG atlas cells remain independent outfits for the same UID; neither fullpage nor another figure is substituted.','Weak generated alpha fringe and hiddenRGB are retained exactly. Strong silhouette completeness uses alpha>64 and source-edge safety also checks alpha>16.','Different perspective heights of the two boot soles are preserved. Centering uses each whole projected sole envelope, not a one-row toe-only contact mean.','The corrected browser capture is a static metadata preview. Root must apply through the existing authorized catalogue refresh; this reviewer has not changed the importer,manifest,index or build.'],'sourcePixelsModified':False,'all12GuardsFrozen':True,'guardsChanged':0,'priorP51QALayersModified':False,'runtimeAdmitted':False,'GitModified':False}
OUT.write_text(json.dumps(out,indent=2)+'\n')
for x in frozen:assert sha(R/'p52/catalog'/x['name'])==x['P52SHA256']
(Q/'FINAL_SOURCE_AND_PRIOR_QA_VERIFICATION_PRIVATE_V1.json').write_text(json.dumps({'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'outPath':str(OUT),'outSHA256':sha(OUT),'sources':proof,'frozenPriorQALayers':frozen,'rawSourceSHAsReverified':True,'allSourcePixelsUnchanged':True},indent=2))
print(json.dumps({'written':str(OUT),'sha256':sha(OUT),'poses':4,'corrections':4,'rectsChanged':0,'sourcePixelsChanged':0,'frozenPriorLayersByteIdentical':True},indent=2))
