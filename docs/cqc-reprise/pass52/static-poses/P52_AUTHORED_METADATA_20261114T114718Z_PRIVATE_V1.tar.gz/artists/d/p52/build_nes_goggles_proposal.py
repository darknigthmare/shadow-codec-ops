from pathlib import Path
import json,hashlib,datetime,os
from PIL import Image
ROOT=Path('/tmp/cqc-static-20261113/artists/d/p52')
NOW=datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:b=f.read()
 return hashlib.sha256(b).hexdigest()
receipts={}
for p in ROOT.glob('CAPTURE*.json'):
 try:x=json.loads(p.read_text())
 except:continue
 for r in x.get('results',[]):receipts[r['path']]=(r,str(p))
roles={
'NES_JAGOFTROY_CHAIN_2217.png':('DEFAULT_COMPLETE_DRY_PLAYER','CARD4 selected, complete ordinary green player in preceding corridor; bare normal retail head.'),
'NES_JAGOFTROY_CHAIN_2219.png':('WORLD_EFFECT_BEFORE_ONLY','Same laser room before selection: CARD4 HUD, laser beams invisible. Player is not visible in this transition frame; excluded from full-body proof.'),
'NES_JAGOFTROY_CHAIN_2224.png':('GOGGLES_SELECTED_COMPLETE_DRY_PLAYER_AND_LASERS','GOGGLES explicitly selected in HUD; visible red laser beams; complete green player on lower dry entry.'),
'NES_JAGOFTROY_CHAIN_2226.png':('GOGGLES_SELECTED_COMPLETE_DRY_PLAYER_AND_LASERS','GOGGLES explicitly selected in HUD; visible red laser beams; complete green player between emitters, ordinary head/body.'),
'NES_JAGOFTROY_2227.png':('GOGGLES_SELECTED_COMPLETE_DRY_PLAYER_AND_LASERS','Complete green player between emitters; GOGGLES HUD and visible red laser beams.'),
'NES_JAGOFTROY_2229.png':('GOGGLES_SELECTED_COMPLETE_DRY_PLAYER_AND_LASERS','Complete green player in laser room; GOGGLES HUD and red laser beams; ordinary retail head/body.'),
'NES_JAGOFTROY_2233.png':('GOGGLES_SELECTED_COMPLETE_DRY_PLAYER','Complete ordinary green player in open dry corridor; GOGGLES explicitly selected in HUD.'),
'NES_JAGOFTROY_2237.png':('GOGGLES_SELECTED_COMPLETE_DRY_PLAYER','Complete ordinary green player on upper dry entry to water-trench room; GOGGLES explicitly selected.'),
'NES_JAGOFTROY_2243.png':('GOGGLES_SELECTED_COMPLETE_DRY_PLAYER','Complete ordinary green player on lower dry walkway in water-trench room; GOGGLES explicitly selected.'),
'NES_JAGOFTROY_2244.png':('GOGGLES_SELECTED_COMPLETE_DRY_PLAYER','Complete ordinary green player on lower dry walkway; GOGGLES explicitly selected, ordinary unmodified retail head/body outline.'),
'NES_JAGOFTROY_2245.png':('GOGGLES_SELECTED_COMPLETE_DRY_PLAYER','Complete ordinary green player on left dry walkway; GOGGLES explicitly selected.'),
'NES_JAGOFTROY_2281.png':('DEFAULT_COMPLETE_DRY_PLAYER_AFTER','CARD2 selected after target sequence, complete ordinary green player on left walkway of the same water-trench room.'),
'NES_JAGOFTROY_1830.png':('INVENTORY_OWNERSHIP_SUPPORT_ONLY','GOGGLES text and object icon in equipment inventory; CARD1 cursor selected. Ownership alone excluded from wearer proof.'),
'NES_JAGOFTROY_2241.png':('TARGET_SELECTION_LOCATOR_ONLY','GOGGLES HUD physically identified here first; body appears submerged/curled and is excluded from dry full-body comparison.')
}
frames=[]
for name,(role,obs) in roles.items():
 p=ROOT/'reference-frames'/name
 r,receipt=receipts[str(p)]
 assert sha(p)==r['sha256']
 with Image.open(p) as im:size=list(im.size)
 frames.append(dict(r,extractionReceipt=receipt,physicallyViewed=True,viewedBy='/root/p52_legacy',viewedWholeUnchangedFrame=True,role=role,observation=obs,frameDimensions=size,cropOrResizeOrRetouch=False,newDrawing=False))
index={'schema':'cqc.static.reference-inspection-index/1','atUTC':NOW,'reviewer':'/root/p52_legacy','frames':frames,'captureReceiptViewedFlagNote':'The extraction-time viewed:false fields are retained verbatim; physicallyViewed:true records subsequent actual viewing.','limits':'Known JagOfTroy NES255 source already used P50; these precise GOGGLES-selected seconds are new inspected evidence, never claimed as a newly independent video. Full retail ROM provenance was not certified. No ROM download, emulator, rebuild, video download, crop, resize, recolor, retouch, or new art.'}
idx=ROOT/'P52_D_NES_GOGGLES_RETAIL_VIEWING_INDEX_PRIVATE_V1.json';idx.write_text(json.dumps(index,indent=2))
refs=json.loads((ROOT/'FETCH_NES_RETAIL_AND_ORIGINAL_REFERENCE_BYTES_V1.json').read_text())
for r in refs:
 p=Path(r['path']);assert sha(p)==r['sha256'];r.update(physicallyViewed=True,viewedBy='/root/p52_legacy',viewedWholeSource=True)
 with Image.open(p) as im:r['dimensions']=list(im.size)
refs[0]['role']='Whole native NES player sheet: NORMAL/DAMAGED, UNARMED/ARMED, IDLE/WALK/PUNCH, BOX, DEATH. Target observed green body corresponds to normal retail groups; sheet alone was insufficient and is now paired with actual selected HUD/world captures.'
refs[1]['role']='Whole native NES object/effect sheet, support for goggles item and laser graphics only; no wearer inference from inventory icon.'
(ROOT/'P52_D_NES_GOGGLES_REFERENCE_VIEWING_INDEX_PRIVATE_V1.json').write_text(json.dumps({'atUTC':NOW,'references':refs},indent=2))
proposal={
'schema':'cqc.static.p52-nes-goggles-visual-alias-proposal/1','atUTC':NOW,'reviewer':'/root/p52_legacy',
'historicalID':'archive__snake_nes__alt__infrared_goggles','uid':'archive__snake_nes','equipmentID':'official--infrared-goggles','historicalLabel':'Lunettes infrarouges NES',
'status':'ROOT_REVIEW_PENDING_EQUIPMENT_CONFIGURATION_ALIAS_PROPOSAL','targetCostumeID':'original','newDrawingCount':0,'newSpritePNGCount':0,'newAliasAppliedCount':0,'proposalCount':1,
'finding':'Actual NES GOGGLES-selected world frames now qualify the missing visual comparison. At2224/2226/2227/2229s the HUD explicitly says GOGGLES and red lasers are visible while the complete dry player retains the ordinary green retail head/body. At2233/2237/2243/2244/2245s GOGGLES remains selected with complete ordinary dry player views. Default CARD4 at2217s and CARD2 at2281s show the same ordinary retail player family. No separately rendered goggles or new worn body appearance is seen in these observed states.',
'proposedDisposition':'Reuse existing Original only within archive__snake_nes as an equipment configuration. Preserve goggles selection and infrared-laser visibility as effect metadata, with no newly delivered drawing and no independent goggles wearer costume.',
'visualChain':[
 {'seconds':2217,'selectedHUD':'CARD4','proof':'Complete dry standard player in preceding corridor.'},
 {'seconds':2219,'selectedHUD':'CARD4','proof':'Laser-room beams invisible; body absent during room transition, so world-effect evidence only.'},
 {'seconds':2224,'selectedHUD':'GOGGLES','proof':'Beams visible and complete dry standard player in the same laser room.'},
 {'seconds':2226,'selectedHUD':'GOGGLES','proof':'Beams visible, complete dry standard player between emitters.'},
 {'seconds':2233,'selectedHUD':'GOGGLES','proof':'Complete dry standard player in open corridor, ordinary head/body.'},
 {'seconds':2244,'selectedHUD':'GOGGLES','proof':'Complete dry standard player on water-room lower walkway.'},
 {'seconds':2281,'selectedHUD':'CARD2','proof':'Complete dry standard player on same water-room left walkway after goggles is deselected.'}
],
'existingOriginal':dict(refs[2],nativeFirstFrameRectFromPriorAcceptedMetadata=[54,32,183,343],nativePivotFromPriorAcceptedMetadata=[0.472678,0.994169],geometryTransferredFromRetail=False,artSourceReusedOnlyWithinSameUID=True),
'evidenceURLs':['https://archive.org/details/NesLongplay255MetalGear','https://archive.org/download/NesLongplay255MetalGear/NES_Metal_Gear.mp4#t=2226','https://archive.org/download/NesLongplay255MetalGear/NES_Metal_Gear.mp4#t=2233','https://archive.org/download/NesLongplay255MetalGear/NES_Metal_Gear.mp4#t=2244','https://archive.org/download/NesLongplay255MetalGear/NES_Metal_Gear.mp4#t=2281',refs[0]['url'],refs[1]['url'],'https://metalgear.konami.net/manual/mc1/mg1_nes/pc/en/page10.html'],
'proofPaths':[str(idx),str(ROOT/'P52_D_NES_GOGGLES_REFERENCE_VIEWING_INDEX_PRIVATE_V1.json'),str(ROOT/'IA_METADATA_NesLongplay255MetalGear_V1.json')],
'proofSHA256':{str(idx):sha(idx)},
'lineage':{'videoTitle':'NES Longplay [255] Metal Gear','creator':'JagOfTroy','archiveUploader':'longplays@longplays.org','archiveCollection':'worldoflongplays','publishedSourceAlreadyKnownP50':True,'newPreciselyInspectedTargetSeconds':True,'notAnIndependentNewVideoClaim':True,'publicRetailCaptureNotROMLocalReplay':True,'retailROMByteIdentityCertified':False,'noMSXInference':True},
'limits':['Evidence is actual selected-item public NES gameplay, not a NES disassembly or a ROM-rebuild certificate. No correct NES item-to-PPU public code chain was recovered.','No pixel equality is claimed between existing authored Original and native retail sprites. This proposal addresses whether the equipment creates another visible costume, and only reuses the same UID Original.','No absolute claim across every animation/state or another game/item. The depicted target states show ordinary green head/body; damage flashes, submerged shapes, and invisible room-transition frames are excluded from wearer comparisons.','CARD4 before and CARD2 after are in different moments/directions; this is whole-body visual corroboration with a complete native player sheet, not an exact identical-coordinate pixel-difference test.','The new dr-Sunny gallery and secondary guide pages are research leads, not needed or promoted as wearer proof.','Root acceptance required; this agent has not applied an alias or modified any shared mapping.'],
'rootAcceptance':None,'RootReviewRequired':True,'selfClosed':False,'guardsChanged':0,'all12GuardsFrozen':True,'priorP50P51FilesContentModified':False,'sharedMapIndexBuildModified':False,'GitModified':False,'runtimeAdmittedByThisAgent':False,'newAnimations':0,'noCPUImageEditing':True
}
p=ROOT/'P52_D_NES_GOGGLES_VISUAL_ALIAS_PROPOSAL_PRIVATE_V1.json';p.write_text(json.dumps(proposal,indent=2))
print(json.dumps({'proposal':str(p),'sha256':sha(p),'viewedEvidenceFrames':len(frames),'retailAndOriginalReferences':len(refs),'newDrawings':0,'appliedAliases':0},indent=2))
