#!/usr/bin/env python3
"""Render French P52 delivery notes from current P51-baseline metrics."""
from pathlib import Path
import argparse
import json

P = Path('/tmp/cqc-static-20261113/p52')
D = P / 'delivery'


def render(report):
    r = report
    s = r['officialHistoricalP52Progress']
    w = r.get('workbook', {})
    portable = r.get('portableCatalogue', {})
    sheets = (
        f"Le classeur contient **{w['totalSheets']} feuilles**, dont les **{w['oldSheets']} feuilles antérieures conservées exactement** et {w['newSheets']} nouvelles feuilles P52."
        if w.get('oldSheetsAndUnchangedZipMembersPreservedExact') else
        "Le classeur P52 ajoute ses feuilles de suivi au classeur publié P51. La preuve de conservation exacte des feuilles antérieures reste à vérifier.")
    size = (
        f" Le lecteur contient {portable['uniquePNGs']} PNG distincts, soit {portable['bytesUniquePNGs']/1024**3:.2f} Gio de sources sélectionnées."
        if portable.get('bytesUniquePNGs') is not None else '')
    pending_correction = (
        f" **{s['sourceRowsWithCorrectionPending']} ligne(s) avec une source attendent encore une correction ciblée.**"
        if s['sourceRowsWithCorrectionPending'] else '')
    roster = (
        f"Les **{r['baselineCharacters']} incarnations déjà présentes dans P51** restent la base de cette passe. Le XOF de l’hôpital de 1984 en faisait déjà partie depuis P50 ; il n’est pas compté comme un nouveau personnage P52. La matrice historique de {r['originalMatrixRosterUIDs']} incarnations et de ses {r['plannedMatrixRows']} lignes reste distincte de cette incarnation ajoutée antérieurement.")
    extra = (
        f" Le catalogue courant compte {r['characters']} incarnations ; {r['newAdditionalDistinctIncarnationsSinceP51']} ajout(s) par rapport à P51 sont signalés dans le bilan."
        if r['newAdditionalDistinctIncarnationsSinceP51'] else '')
    notice = (
        "\nLes fichiers de suivi reflètent encore un état de préparation : " + ' '.join(r['snapshotWarnings']) + "\n"
        if r.get('snapshotWarnings') else '')
    prior_reuses = (
        f"Les **{r['existingBaselineSameUIDAliases']} réemplois P50/P51 déjà établis** ({r['existingP50SameUIDAliases']} P50 et {r['existingP51SameUIDAliases']} P51) ne sont pas comptés comme des résolutions nouvelles de P52.")
    corrections = []
    for c in r.get('explicitHistoricalLabelCorrections', []):
        corrections.append(
            f"Le libellé historique « {c['previousLabel']} » est corrigé en « {c['correctedLabel']} ». {c['reason']}")
    correction_text = '\n\n' + '\n\n'.join(corrections) if corrections else ''
    source_kinds = ', '.join(f"{name} : {count}" for name, count in sorted(r.get('sourceKinds', {}).items()))
    new_names = '; '.join(f"{e['character']} — {e['costume']}" for e in r.get('newSelectedPoseEntriesSinceP51', []))
    new_names_text = f"\n\nNouvelles poses sélectionnées : {new_names}." if new_names else ''
    reuse_names = '; '.join(e.get('label') or e['historicalID'] for e in r.get('newP52SameUIDReuseRows', []))
    reuse_names_text = f" Réemplois qualifiés P52 : {reuse_names}." if reuse_names else ''
    preservation = (
        "Les sources et cadrages sélectionnés avant P52 restent identiques à la base P51."
        if r.get('baselineManifestSourceFramesPreservedExact') else
        "La conservation des sources et cadrages sélectionnés avant P52 reste à vérifier dans le bilan.")
    return f'''# CQC — poses uniques restantes — P52

Cette livraison poursuit les tenues officielles encore ouvertes après P51 : **une pose statique vers la droite par tenue qualifiée**, avant les animations. {roster}{extra} Les costumes créés, les sources brutes et toutes leurs versions précédentes restent conservés.

Le catalogue sélectionne **{r['newDistinctPhysicalPosesSinceP51']} nouvelles poses physiques depuis P51**, correspondant à {r['newUIDCostumePosesSinceP51']} entrées personnage/tenue et {r['newDistinctPhysicalPNGsSinceP51']} PNG distincts. Parmi ces entrées, {r['newOfficialPoseEntriesSinceP51']} concernent des tenues officielles et {r['newOriginalCorrectionsSinceP51']} des Originals corrigés. Un PNG peut contenir plusieurs tenues statiques ; les versions remplacées ne multiplient pas le total des dessins. {preservation}{new_names_text}

Sur les **{s['startingPending']} lignes réellement manquantes au départ de P52**, **{s['newSourceRows']} ont une nouvelle source**, **{s['exactSameUIDAliases']} réutilisent une apparence vérifiée de la même incarnation**, **{s['guardedOfficialRows']} ont un refus ou une garde sans nouvelle production**, et **{s['remainingReferenceRows']} nécessitent encore une preuve visuelle précise**.{pending_correction} La ligne historique qui mélangeait XOF 1975 et hôpital 1984 reste signalée séparément ; son Original de 1984 existait déjà dans P50. {prior_reuses}{reuse_names_text}{correction_text}
{notice}
## Consulter

- [Excel complet](CQC_SUIVI_P52_POSES_UNIQUES_20261114_PUBLIC_V1.xlsx). {sheets} Les onglets P50 et P51 restent des snapshots historiques.
- [Catalogue autonome](catalogue/) et [mode d’emploi](catalogue/LIRE_MOI.txt).{size}
- [Bilan chiffré](P52_LIVRAISON_POSES_UNIQUES_PUBLIC_V1.json), [contrôles finaux](P52_FINAL_VERIFICATION_PUBLIC_V1.json) et CSV correspondants.
- Dans `inventaires/`, les 416 rapprochements officiels et leurs références conservent les recherches P49/P50/P51 et ajoutent les preuves P52. Les anciennes recherches n’ont pas été réécrites.

Le catalogue compte {r['allPoseEntriesPresent']} entrées pourvues d’une pose sélectionnée. Types de sources : {source_kinds}. Ces totaux cumulent les sources anciennes et nouvelles ; ils ne sont pas le nombre de dessins produits pendant P52.

Les PNG exacts produits pendant cette passe sont conservés dans `artists/`. Le lecteur utilise les fichiers sélectionnés sous `catalogue/assets/`. Les PNG bruts antérieurs restent conservés dans les livraisons précédentes ; une correction de pose ou de cadrage ne supprime pas sa source précédente.

Pour récupérer uniquement le lecteur :

```sh
git clone --filter=blob:none --sparse --branch codex/cqc-p52-remaining-costumes-20261114 https://github.com/darknigthmare/shadow-codec-ops.git cqc-poses
cd cqc-poses
git sparse-checkout set docs/cqc-reprise/pass52/static-poses/catalogue
cd docs/cqc-reprise/pass52/static-poses/catalogue
python -m http.server 8160 --bind 127.0.0.1
```

Ouvrir ensuite http://127.0.0.1:8160/ .

## Fidélité et limites

Les dessins reposent sur les captures, modèles, textures et accessoires effectivement inspectés. Une référence précise d’accessoire peut compléter le corps connu de la même incarnation ; un simple nom de tenue ne suffit pas. Les époques, remakes et formes distinctes gardent leurs identités.

Le bilan conserve **{r['cumulativeGenerationGuardScopes']} périmètres de garde cumulés**, dont {r['newGenerationGuardScopesSinceP51']} nouveau(x) depuis P51 et {r['canonicalOfficialGuardRows']} lignes officielles dans le registre courant. Les refus effectifs du service sont distingués des gardes sans tentative. Une source ancienne déjà conservée sous garde reste une archive ; elle n’autorise aucune nouvelle tentative, substitution ou relance par un autre agent.

Les détails reconstruits, preuves techniques et références seulement conceptuelles gardent leurs limites. Aucun dessin n’est certifié identique pixel pour pixel au jeu d’origine. Les réemplois techniques, les dessins et l’admission dans les combats sont des états distincts. Un état « À vérifier » ne vaut pas admission au jeu.

Les cadrages et points d’appui sélectionnent une pose sans modifier les pixels des PNG. Les empreintes et locateurs des références sont conservés ; les livres complets, vidéos, paquets tiers et images exclues des preuves publiables ne font pas partie de cette livraison.

Cette passe ne crée aucune animation et ne modifie aucun combat, stage, menu du jeu ou déploiement Vercel. Son dossier est isolé sous `docs/cqc-reprise/pass52/static-poses/`.
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    report = json.loads((D / 'P52_LIVRAISON_POSES_UNIQUES_PUBLIC_V1.json').read_text())
    text = render(report)
    if args.dry_run:
        print(text)
    else:
        target = D / 'README.md'
        temp = target.with_suffix('.md.tmp')
        temp.write_text(text, encoding='utf-8')
        temp.replace(target)
        print(target)


if __name__ == '__main__':
    main()
