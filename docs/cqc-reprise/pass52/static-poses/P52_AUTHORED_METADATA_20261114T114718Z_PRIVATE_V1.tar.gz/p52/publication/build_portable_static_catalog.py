#!/usr/bin/env python3
"""Package selected exact PNGs and one-frame metadata; no raster transforms."""
import pathlib,json,hashlib,os,datetime,copy
N=pathlib.Path('/tmp/cqc-static-20261113');CAT=N/'p52/catalog';OUT=N/'p52/delivery/catalogue';OUT.mkdir(parents=True,exist_ok=True);APP=pathlib.Path('/workspace/cqc-pass21-application/public/cqc');m=json.loads((CAT/'manifest-all381.json').read_text());records={}
def exact(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:before=os.fstat(f.fileno());raw=f.read();after=os.fstat(f.fileno())
 assert before==after and p.stat()==before;return raw
for e in m['entries']:
 s=e.get('source')
 if not s:continue
 src=s['src']
 if src.startswith('/native/'):p=APP/src[len('/native/'):];folder='native-sources'
 elif src.startswith('/captures/'):p=N/'artists/e/composites'/src[len('/captures/'):];folder='composite-sources'
 else:p=CAT/src;folder='source-pages'if s['kind']=='generated-atlas'else'reused-sources'
 assert p.resolve(strict=True)==p and(p.is_relative_to(N)or p.is_relative_to(APP));sha=s['sha256'];target=OUT/'assets'/folder/(sha+'.png');target.parent.mkdir(parents=True,exist_ok=True)
 if sha not in records:
  raw=exact(p);assert hashlib.sha256(raw).hexdigest()==sha and raw[:8]==b'\x89PNG\r\n\x1a\n';oid=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
  if not target.exists():
   if p.is_relative_to(N):os.link(p,target)
   else:
    oldIndex=N/'p51/publication/PORTABLE_STATIC_CATALOG_SOURCE_INDEX_PRIVATE_V1.json'
    if '_p49Reusable'not in globals():_p49Reusable={r['sha256']:N/'p51/delivery/catalogue'/r['portablePath']for r in json.loads(oldIndex.read_text())['records']}
    oldCopy=_p49Reusable.get(sha)
    if oldCopy and oldCopy.is_file():
     assert hashlib.sha256(exact(oldCopy)).hexdigest()==sha;os.link(oldCopy,target)
    else:
     with open(target,'xb')as f:f.write(raw)
  assert hashlib.sha256(exact(target)).hexdigest()==sha
  records[sha]={'source':str(p),'portablePath':target.relative_to(OUT).as_posix(),'bytes':len(raw),'sha256':sha,'gitBlobOID':oid,'sourceKind':s['kind']}
 else:target=OUT/records[sha]['portablePath']
 s['src']=target.relative_to(OUT).as_posix();s.pop('localPath',None)
m['inventoryInput']='ALL381_STATIC_BASELINE_MATRIX_PUBLIC_V1.json';m['portableCatalog']=True;m['sourceVersionPolicy']='PNG bytes exact, one frame per costume selected. Full raw versions preserved separately in Git. No new animation or runtime admission.'
(OUT/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
for name in ['index.html','catalog.mjs','catalog.css','manifest-model.mjs']:(OUT/name).write_bytes(exact(CAT/name))
(OUT/'LIRE_MOI.txt').write_text('CQC — poses uniques, passe P52 du14novembre2026\n\nDepuis ce dossier, lancer :\npython -m http.server 8160 --bind 127.0.0.1\nPuis ouvrir http://127.0.0.1:8160/\n\nChaque costume possède une seule pose sélectionnée via son cadre source. Plusieurs costumes partagent un même PNG brut ; ce ne sont pas des animations. Les PNG sont copiés sans modification de pixels. Les états de revue ne valent pas admission au combat. Le jeu et les animations existants restent hors de cette passe. Les différences d’époque gardent leurs UID. Les costumes officiels et inventés ont des filtres séparés.\n\nLes sources antérieures ou supersédées sont préservées dans le dossier Git artists/ des PR11/P49 et PR12/P52. Une pose avec réserve reste visible «À vérifier». Le suivi Excel distingue les familles couvertes par un Original, les non-applicables, les dessins, les références encore à établir et les refus de génération documentés.\n',encoding='utf-8')
report={'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(OUT),'entries':len(m['entries']),'uniquePNGs':len(records),'bytesUniquePNGs':sum(r['bytes']for r in records.values()),'SourcePNGsModified':False,'sourceReadsNoAtime':True,'records':list(records.values()),'newAnimations':0,'runtimeFilesModified':0};(N/'p52/publication/PORTABLE_STATIC_CATALOG_SOURCE_INDEX_PRIVATE_V1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='records'}))
