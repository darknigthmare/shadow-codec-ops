"""Retire only new generator duplicates after exact source and immutable Git proof."""
import hashlib,json,os,pathlib,re,stat,subprocess,sys,datetime,shutil
N=pathlib.Path('/tmp/cqc-static-20261113');OUT=N/'p52/publication';W=pathlib.Path('/workspace/cqc-static-20261113')
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/darknigthmare/shadow-codec-ops/'+path]))
receipt=pathlib.Path(sys.argv[1]);d=json.loads(read(receipt));commit=d['commit'];assert re.fullmatch('[0-9a-f]{40}',commit)
proofPath=OUT/('REFERENCES_VERIFIED_'+commit+'_PRIVATE_V1.json')
if proofPath.exists():
 proof=json.loads(read(proofPath));assert proof['commit']==commit and proof['tree']==d['tree']and proof['rows']==d['rows']and proof['verified']
else:
 c=api('git/commits/'+commit);assert c['tree']['sha']==d['tree']
 delta=api('compare/'+d['parent']+'...'+commit);by={x['filename']:x for x in delta['files']}
 for r in d['rows']:assert by[r['path']]['sha']==r['sha']
 proofPath.write_text(json.dumps({'commit':commit,'tree':d['tree'],'rows':d['rows'],'verified':True},indent=2)+'\n')
approved={r['sha256']:r for r in d['rows']}
known=set()
def walk(x):
 if isinstance(x,str):
  if re.fullmatch('/workspace/generated_images/exec-[0-9a-f-]+\\.png',x):known.add(x)
 elif isinstance(x,list):
  for y in x:walk(y)
 elif isinstance(x,dict):
  for y in x.values():walk(y)
for p in (N/'artists').rglob('*.json'):
 if p.stat().st_size<1500000:
  try:walk(json.loads(read(p)))
  except (ValueError,FileNotFoundError):pass
selected=[]
for name in sorted(known):
 p=pathlib.Path(name)
 if not p.exists():continue
 s=p.stat(follow_symlinks=False)
 if p.resolve(strict=True)!=p or not stat.S_ISREG(s.st_mode)or s.st_nlink!=1:continue
 b=read(p);digest=hashlib.sha256(b).hexdigest()
 if digest not in approved:continue
 r=approved[digest];src=pathlib.Path(r['localPath']);assert src.is_relative_to(N/'artists')and src.resolve(strict=True)==src
 assert read(src)==b and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==r['sha']
 selected.append({'generatorPath':name,'canonicalSourcePath':str(src),'bytes':len(b),'sha256':digest,'gitBlobOID':r['sha'],'gitPath':r['path'],'gitCommit':commit,'device':s.st_dev,'inode':s.st_ino,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns,'nlink':1,'allocatedBytes':s.st_blocks*512})
if not selected:
 print(json.dumps({'retiredOnlyCommittedDuplicateCount':0,'canonicalSourcesPreserved':True}));sys.exit(0)
plan={'schema':'cqc.static-pose.committed-generator-copy-retirement/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':commit,'canonicalSourcesAndGitExact':True,'onlyOwnedNewGeneratorDuplicates':True,'rows':selected,'pixelsChanged':False,'OriginalFilesTouched':False}
W.mkdir(exist_ok=True);attempt=1
while (W/('GENERATOR_RETIREMENT_'+commit[:12]+'_'+str(attempt)+'_PRIVATE_V1.json')).exists():attempt+=1
name='GENERATOR_RETIREMENT_'+commit[:12]+'_'+str(attempt)+'_PRIVATE_V1.json';planPath=W/name;planPath.write_text(json.dumps(plan,indent=2)+'\n')
before=shutil.disk_usage('/workspace').free
for r in selected:
 p=pathlib.Path(r['generatorPath']);s=p.stat(follow_symlinks=False);assert(s.st_dev,s.st_ino,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink)==(r['device'],r['inode'],r['mtimeNs'],r['ctimeNs'],1)
 assert hashlib.sha256(read(p)).hexdigest()==r['sha256']and hashlib.sha256(read(pathlib.Path(r['canonicalSourcePath']))).hexdigest()==r['sha256'];p.unlink()
plan.update(actualRetiredCount=len(selected),freeBefore=before,freeAfter=shutil.disk_usage('/workspace').free,GitReferencesVerified=True,allCanonicalSourcesStillExact=True)
for r in selected:assert hashlib.sha256(read(pathlib.Path(r['canonicalSourcePath']))).hexdigest()==r['sha256']
(OUT/name).write_text(json.dumps(plan,indent=2)+'\n');planPath.write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'retiredOnlyCommittedDuplicateCount':len(selected),'freedObserved':plan['freeAfter']-before,'canonicalSourcesPreserved':True,'durableReceipt':str(planPath)}))
