#!/usr/bin/env python3
"""Offline JSON-controlled fixtures; no current catalogue or delivery output writes."""
import copy
import json
import unittest

import build_p52_dispositions as dispositions
import write_delivery_metrics as metrics
import write_delivery_readme as readme


def fixture():
    uids = ['core__quiet', 'archive__snake_nes', 'archive__xof_hospital_1984'] + [f'uid-{i}' for i in range(379)]
    def entry(uid, cid='original', sha=None, rect=None, family='original'):
        return {'uid': uid, 'costumeId': cid, 'family': family,
                'source': {'sha256': sha or 'old-' + uid, 'kind': 'generated-atlas' if sha else 'native-frame'},
                'frame': {'rect': rect or [1, 2, 30, 40], 'pivot': [.5, 1]}}
    baseline = {'entries': [entry(u) for u in uids], 'baselineRosterUIDs': 381, 'baselineMatrixRows': 3429,
                'additionalDistinctIncarnations': [{'uid': 'archive__xof_hospital_1984'}]}
    pending = [f'pending-{i}' for i in range(14)]
    pending[4] = 'archive__snake_nes__alt__infrared_goggles'
    pending[5] = 'core__quiet__alt__arrival_cloak'
    old_rows = [{'historicalID': hid, 'resolutionState': 'REFERENCE_AND_STATIC_SOURCE_PENDING',
                 'resolutionReason': 'Old missing state', 'historicalCostumeName': 'Old label', 'historicalUID': uids[i]}
                for i, hid in enumerate(pending)]
    old_rows[5]['historicalCostumeName'] = 'Arrivée à Mother Base — manteau drapé'
    old_rows.append({'historicalID': 'old-xof-period-error', 'resolutionState': 'REFERENCE_AND_STATIC_SOURCE_PENDING',
                     'p50RelatedDistinctIncarnation': {'uid': 'archive__xof_hospital_1984'}, 'resolutionReason': 'Old era correction'})
    old_rows += [{'historicalID': f'old-alias-{i}',
                  'resolutionState': f"P{50 if i < 24 else 51}_EXISTING_SAME_UID_APPEARANCE_REUSED", 'resolutionReason': 'Old reuse'}
                 for i in range(26)]
    guards = []
    for i in range(12):
        g = {'uid': uids[i], 'costumeId': 'original', 'historicalID': f'old-guard-{i}', 'kind': 'content-guard-no-generation'}
        baseline['entries'][i]['generationGuard'] = copy.deepcopy(g)
        guards.append(g)
        old_rows.append({'historicalID': g['historicalID'], 'resolutionState': 'P51_CONTENT_GUARD_NO_GENERATION', 'resolutionReason': 'Old guard'})
    while len(old_rows) < 416:
        old_rows.append({'historicalID': f'old-covered-{len(old_rows)}', 'resolutionState': 'EXISTING_NATIVE_OFFICIAL_OPTION_REUSE', 'resolutionReason': 'Old source'})
    baseline_map = {'rows': old_rows, 'p50Summary': {'old': 50}, 'p51Summary': {'old': 51}}
    current_map = copy.deepcopy(baseline_map)
    current = copy.deepcopy(baseline)
    for i, png in enumerate(['new-pair', 'new-pair', 'new-snake', 'new-venus']):
        current['entries'].append(entry(uids[i + 20], f'official-new-{i}', png, [i * 100, 0, 50, 90], 'canonical'))
        current_map['rows'][i].update(resolutionState='P52_NEW_STATIC_SOURCE_POSE_DRAWN_REVIEW_PENDING',
                                     resolutionReason='New exact source', newSource={'sha256': png}, p52Evidence={'actuallyViewed': True})
    for i, uid in [(4, 'archive__snake_nes'), (5, 'core__quiet')]:
        current_map['rows'][i].update(resolutionState='P52_EXISTING_SAME_UID_APPEARANCE_REUSED', resolutionReason='New exact reuse',
                                     p52AliasProof={'historicalID': pending[i], 'uid': uid, 'targetCostumeID': 'original'})
        target = next(e for e in baseline['entries'] if e['uid'] == uid)
        e = copy.deepcopy(target)
        e.update(costumeId=f'official-reuse-{i}', family='canonical')
        e.pop('generationGuard', None)
        current['entries'].append(e)
    quiet = current_map['rows'][5]
    quiet.update(historicalCostumeNameBeforeP52=quiet['historicalCostumeName'],
                 historicalCostumeName='Arrivée à Mother Base — tenue Naked d’origine attestée',
                 p52LabelCorrection='Aucun manteau drapé attesté ; correction du libellé historique, aucune cape inventée.')
    quiet['p52AliasProof']['correctedHistoricalLabel'] = quiet['historicalCostumeName']
    old_dispositions = {'rows': [dict(historicalID=r['historicalID'], currentMappingState=r['resolutionState'],
                                   referenceDisposition='Old report state', reason=r['resolutionReason'],
                                   costume=r.get('historicalCostumeName', 'Old costume'),
                                   p50ResearchReports=[{'preserved': 'P50'}], p51ResearchReports=[{'preserved': 'P51'}]) for r in old_rows],
                        'p50SummaryPreserved': {'preserved': 50}, 'p51Summary': {'preserved': 51}}
    # Serialize through JSON so fixtures exercise the same types as actual inputs.
    return json.loads(json.dumps([current, baseline, current_map, baseline_map, {'entries': guards[:5]},
                                  {'startingActualMissing': 14}, old_dispositions]))


class ReportingChecks(unittest.TestCase):
    def test_p51_baseline_accounting_and_existing_history(self):
        current, base, mapping, oldmap, guards, resume, _ = fixture()
        result = metrics.compute(current, base, mapping, oldmap, guards, resume)
        self.assertEqual((result['characters'], result['baselineCharacters']), (382, 382))
        self.assertEqual((result['originalMatrixRosterUIDs'], result['plannedMatrixRows']), (381, 3429))
        self.assertEqual(result['newDistinctPhysicalPosesSinceP51'], 4)
        self.assertEqual(result['newDistinctPhysicalPNGsSinceP51'], 3)
        self.assertEqual(result['newOriginalCorrectionsSinceP51'], 0)
        self.assertEqual(result['reusedBaselineSourceMappingsSinceP51'], 2)
        self.assertEqual((result['existingP50SameUIDAliases'], result['existingP51SameUIDAliases'], result['existingBaselineSameUIDAliases']), (24, 2, 26))
        self.assertEqual(result['existingBaselineSameUIDAliasesRetained'], 26)
        self.assertEqual(result['newP52SameUIDAliases'], 2)
        self.assertEqual((result['cumulativeGenerationGuardScopes'], result['newGenerationGuardScopesSinceP51']), (12, 0))
        self.assertTrue(result['baselineManifestSourceFramesPreservedExact'])
        self.assertTrue(result['existingHospitalXOF1984Retained'])
        self.assertEqual(result['officialHistoricalP52Progress']['startingPending'], 14)
        self.assertEqual(result['officialHistoricalP52Progress']['remainingReferenceRows'], 8)
        self.assertEqual(result['snapshotWarnings'], [])

    def test_source_counts_are_dynamic_and_physical_pose_deduplicates(self):
        current, base, mapping, oldmap, guards, resume, _ = fixture()
        current['entries'][-6]['frame']['rect'] = list(current['entries'][-5]['frame']['rect'])
        result = metrics.compute(current, base, mapping, oldmap, guards, resume)
        self.assertEqual(result['newUIDCostumePosesSinceP51'], 4)
        self.assertEqual(result['newDistinctPhysicalPosesSinceP51'], 3)
        current['entries'].append({'uid': 'uid-50', 'costumeId': 'fifth', 'family': 'canonical',
                                   'source': {'sha256': 'fifth-png', 'kind': 'generated-atlas'}, 'frame': {'rect': [0, 0, 50, 90]}})
        mapping['rows'][6].update(resolutionState='P52_NEW_STATIC_SOURCE_POSE_DRAWN_REVIEW_PENDING', newSource={'sha256': 'fifth-png'})
        result = metrics.compute(current, base, mapping, oldmap, guards, resume)
        self.assertEqual(result['newUIDCostumePosesSinceP51'], 5)
        self.assertEqual(result['newDistinctPhysicalPNGsSinceP51'], 4)
        self.assertEqual(result['officialHistoricalP52Progress']['remainingReferenceRows'], 7)

    def test_prior_frame_mutation_is_visible(self):
        current, base, mapping, oldmap, guards, resume, _ = fixture()
        current['entries'][30]['frame']['rect'][0] += 1
        result = metrics.compute(current, base, mapping, oldmap, guards, resume)
        self.assertFalse(result['baselineManifestSourceFramesPreservedExact'])
        self.assertEqual(len(result['changedPriorSourceFramesSinceP51']), 1)
        self.assertTrue(result['snapshotWarnings'])

    def test_dispositions_preserve_p50_p51_and_correct_quiet_label(self):
        _, _, mapping, _, _, _, old = fixture()
        frozen = copy.deepcopy(old)
        result = dispositions.build(old, mapping, {})
        self.assertEqual(old, frozen)
        quiet = result['rows'][5]
        self.assertEqual(quiet['costumeBeforeP52'], 'Arrivée à Mother Base — manteau drapé')
        self.assertEqual(quiet['costume'], 'Arrivée à Mother Base — tenue Naked d’origine attestée')
        self.assertEqual(quiet['p51DispositionPreserved']['currentMappingState'], 'REFERENCE_AND_STATIC_SOURCE_PENDING')
        for r in result['rows']:
            self.assertEqual(r['p50ResearchReports'], [{'preserved': 'P50'}])
            self.assertEqual(r['p51ResearchReports'], [{'preserved': 'P51'}])
        self.assertEqual(result['rows'][0]['p52Evidence'], {'actuallyViewed': True})
        mapping['rows'][5]['p52AliasProof'].pop('correctedHistoricalLabel')
        with self.assertRaises(AssertionError):
            dispositions.build(old, mapping, {})

    def test_readme_dynamic_counts_dates_and_explicit_correction(self):
        current, base, mapping, oldmap, guards, resume, _ = fixture()
        r = metrics.compute(current, base, mapping, oldmap, guards, resume)
        r['workbook'] = {'oldSheets': 64, 'newSheets': 3, 'totalSheets': 67, 'oldSheetsAndUnchangedZipMembersPreservedExact': True}
        text = readme.render(r)
        for wanted in ['67 feuilles', '64 feuilles antérieures', '20261114', 'depuis P51', '26 réemplois P50/P51',
                       '24 P50 et 2 P51', '8 nécessitent', 'tenue Naked d’origine attestée', 'Aucun manteau drapé attesté',
                       '12 périmètres', 'Aucun dessin n’est certifié identique pixel pour pixel']:
            self.assertIn(wanted, text.replace('**', ''))
        self.assertNotIn('nouveau personnage P51', text)
        r['newDistinctPhysicalPosesSinceP51'] = 9
        self.assertIn('9 nouvelles poses physiques depuis P51', readme.render(r).replace('**', ''))


if __name__ == '__main__':
    unittest.main(verbosity=2)
