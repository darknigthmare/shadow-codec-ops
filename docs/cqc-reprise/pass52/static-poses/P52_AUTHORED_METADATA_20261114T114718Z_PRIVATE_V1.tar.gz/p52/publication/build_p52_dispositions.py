#!/usr/bin/env python3
"""Append P52 evidence to frozen published P51 dispositions; run after Root refresh."""
from pathlib import Path
import argparse
import collections
import copy
import datetime
import hashlib
import json
import os

N = Path('/tmp/cqc-static-20261113')
P = N / 'p52'
CURRENT_VIEWS = {'currentMappingState', 'referenceDisposition', 'reason'}


def exact(path):
    path = Path(path)
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOATIME | os.O_NOFOLLOW), 'rb') as stream:
        before = os.fstat(stream.fileno())
        raw = stream.read()
        after = os.fstat(stream.fileno())
    assert before == after and path.stat() == before
    return raw


def build(base, mapping, reports):
    previous = {r['historicalID']: r for r in base['rows']}
    current = {r['historicalID']: r for r in mapping['rows']}
    assert len(previous) == len(current) == 416 and set(previous) == set(current)
    rows = []
    for historical_id, old in previous.items():
        row = copy.deepcopy(old)
        now = current[historical_id]
        row['p51DispositionPreserved'] = {k: copy.deepcopy(old.get(k)) for k in CURRENT_VIEWS}
        row['currentMappingState'] = now['resolutionState']
        state = now['resolutionState']
        if state.startswith('P52_'):
            row['reason'] = now['resolutionReason']
            row['referenceDisposition'] = (
                'P52_IMAGE_GENERATION_REFUSED_NO_PNG' if 'REFUSED' in state else
                'P52_GUARDED_WITHOUT_GENERATION' if 'GUARD' in state else
                'P52_STATIC_SOURCE_CORRECTION_PENDING' if 'CORRECTION_PENDING' in state else
                'P52_EXACT_SAME_UID_APPEARANCE_REUSED' if 'REUSED' in state else
                'P52_QUALIFIED_STATIC_SOURCE_DRAWN_REVIEW_PENDING')
            row['p52Evidence'] = copy.deepcopy(now.get('p52Evidence', {}))
            for source_key, target_key in (
                ('newSource', 'p52NewSource'), ('p52AliasProof', 'p52AliasProof'),
                ('p52GenerationGuard', 'p52Guard')):
                if now.get(source_key):
                    row[target_key] = copy.deepcopy(now[source_key])
        overwritten = set(CURRENT_VIEWS)
        correction = now.get('p52AliasProof', {}).get('correctedHistoricalLabel')
        if historical_id == 'core__quiet__alt__arrival_cloak' and state == 'P52_EXISTING_SAME_UID_APPEARANCE_REUSED':
            assert correction and now.get('p52LabelCorrection'), 'Quiet arrival reuse requires its explicit historical-label correction'
        if correction:
            # A corrected scene label is an explicit correction, not evidence for a cloak.
            assert state == 'P52_EXISTING_SAME_UID_APPEARANCE_REUSED'
            assert now.get('p52LabelCorrection')
            assert now.get('historicalCostumeName') == correction
            row['costumeBeforeP52'] = copy.deepcopy(old.get('costume'))
            row['costume'] = correction
            row['historicalCostumeName'] = correction
            row['historicalCostumeNameBeforeP52'] = copy.deepcopy(now['historicalCostumeNameBeforeP52'])
            row['p52LabelCorrection'] = copy.deepcopy(now['p52LabelCorrection'])
            overwritten.add('costume')
            if 'historicalCostumeName' in old:
                overwritten.add('historicalCostumeName')
        if now.get('p50RelatedDistinctIncarnation'):
            row['p50RelatedDistinctIncarnation'] = copy.deepcopy(now['p50RelatedDistinctIncarnation'])
            if state == 'REFERENCE_AND_STATIC_SOURCE_PENDING':
                row['reason'] = now['resolutionReason']
                row['referenceDisposition'] = 'HISTORICAL_PERIOD_ERROR_DISTINCT_ORIGINAL_ALREADY_AVAILABLE_IN_P50'
        row['p52ResearchReports'] = copy.deepcopy(reports.get(historical_id, []))
        assert all(row[key] == value for key, value in old.items() if key not in overwritten), historical_id
        rows.append(row)
    return {
        'schema': 'cqc.p52.official-reference-dispositions/1',
        'atUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'inputMap': str(P / 'official/OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json'),
        'counts': dict(collections.Counter(r['currentMappingState'] for r in rows)),
        'p50SummaryPreserved': copy.deepcopy(base.get('p50SummaryPreserved', mapping.get('p50Summary', {}))),
        'p51SummaryPreserved': copy.deepcopy(base.get('p51Summary', mapping.get('p51Summary', {}))),
        'p52Summary': copy.deepcopy(mapping.get('p52Summary', {})),
        'qualification': 'Published P51 is the frozen baseline. All P49/P50/P51 authored evidence and research fields remain preserved. Current P52 map and Root-accepted reuse proofs are authoritative; artist reports are evidence snapshots, not automatic admission. Quiet arrival has an explicit historical-label correction to the attested ordinary outfit, with no cloak delivered. Existing hospital XOF1984 belongs to the baseline. One static RIGHT pose only; no animation/runtime admission.',
        'rows': rows,
    }


def collect_reports(artist_root):
    reports = {}
    pins = []
    for path in sorted(Path(artist_root).rglob('*.json')):
        if 'p52' not in path.parts or not any(k in path.name for k in ('DISPOSITION', 'HANDOFF', 'ALIAS_PROPOSAL')):
            continue
        try:
            raw = exact(path)
            data = json.loads(raw)
        except (OSError, ValueError):
            continue
        if not isinstance(data, dict):
            continue
        rows = data.get('rows', [])
        if data.get('historicalID'):
            rows = [data, *rows]
        used = False
        for row in rows:
            if not isinstance(row, dict) or not row.get('historicalID'):
                continue
            used = True
            reports.setdefault(row['historicalID'], []).append({
                'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(),
                'reportedStatus': row.get('status', row.get('resolutionState')),
                'reason': row.get('reason', row.get('resolutionReason')),
                'evidenceURLs': row.get('evidenceURLs', row.get('referenceURLs', [])),
                'proposalPath': row.get('proposalPath'), 'targetCostumeID': row.get('targetCostumeID'),
            })
        if used:
            pins.append({'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest()})
    return reports, pins


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    base_path = P / 'base/OFFICIAL416_REFERENCE_DISPOSITIONS_PRIVATE_V1.json'
    map_path = P / 'official/OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json'
    base_raw, map_raw = exact(base_path), exact(map_path)
    reports, pins = collect_reports(N / 'artists')
    result = build(json.loads(base_raw), json.loads(map_raw), reports)
    result['inputPins'] = [
        {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest()}
        for path, raw in ((base_path, base_raw), (map_path, map_raw))
    ] + pins
    assert all(hashlib.sha256(exact(pin['path'])).hexdigest() == pin['sha256'] for pin in result['inputPins']), 'Inputs changed during reporting; rerun.'
    if not args.dry_run:
        target = P / 'official/OFFICIAL416_REFERENCE_DISPOSITIONS_PRIVATE_V1.json'
        temp = target.with_suffix('.json.tmp')
        temp.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
        temp.replace(target)
    print(json.dumps({'dryRun': args.dry_run, 'rows': len(result['rows']), 'counts': result['counts'],
                      'p52ResearchReports': sum(map(len, reports.values())),
                      'explicitLabelCorrections': sum(bool(r.get('p52LabelCorrection')) for r in result['rows'])}, ensure_ascii=False))


if __name__ == '__main__':
    main()
