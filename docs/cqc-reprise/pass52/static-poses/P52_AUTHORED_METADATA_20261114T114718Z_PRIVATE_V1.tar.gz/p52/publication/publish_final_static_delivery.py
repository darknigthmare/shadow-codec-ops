#!/usr/bin/env python3
"""Prepare P52 delivery objects; only Root may execute --commit after watcher stops.

Default invocation never creates a commit or changes a ref. Trees are built one
directory at a time, at most 48 immediate children per API request. Existing
P49/P52 source files are retained from CURRENT_HEAD, never reconstructed.
"""
import argparse
import concurrent.futures
import datetime
import hashlib
import json
import pathlib
import tarfile
from git_blob_store import N, PUB, read, api, pin_file, known_blobs

P = N / 'p52'
OUT = P / 'delivery'
PREFIX = 'docs/cqc-reprise/pass52/static-poses'
BRANCH = 'codex/cqc-p52-remaining-costumes-20261114'
CHUNK_SIZE = 48

def load(path):
    return json.loads(read(path))

def digest(path):
    return hashlib.sha256(read(path)).hexdigest()

def json_write(path, value):
    temp = path.with_suffix('.json.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temp.replace(path)

def safe_target(path):
    rel = pathlib.PurePosixPath(path)
    assert not rel.is_absolute() and '..' not in rel.parts
    assert path.startswith(PREFIX + '/')
    assert not path.startswith(PREFIX + '/artists/'), 'Raw sources belong to watcher only.'
    return path

def build_trie(entries):
    trie = {}
    for full, item in sorted(entries.items()):
        parts = full[len(PREFIX)+1:].split('/')
        node = trie
        for part in parts[:-1]:
            node = node.setdefault(part, {})
            assert isinstance(node, dict), 'File/directory collision.'
        assert parts[-1] not in node, 'Duplicate file/directory target.'
        node[parts[-1]] = item['sha']
    return trie

def create_tree(entries, existing, call=api, log=print):
    directories = {r['path']:r['sha'] for r in existing['tree'] if r['type'] == 'tree'}
    directories[''] = existing['sha']
    chunks = []

    def create_directory(node, path):
        children = []
        for name, value in sorted(node.items()):
            assert '/' not in name and name not in ('', '.', '..')
            if isinstance(value, dict):
                children.append({'path':name, 'mode':'040000', 'type':'tree',
                                 'sha':create_directory(value, path + '/' + name)})
            else:
                children.append({'path':name, 'mode':'100644', 'type':'blob', 'sha':value})
        base = directories.get(path)
        assert children, 'Empty selected directory.'
        for start in range(0, len(children), CHUNK_SIZE):
            payload = {'tree':children[start:start+CHUNK_SIZE]}
            if base:
                payload['base_tree'] = base
            base = call('git/trees', payload)['sha']
            chunks.append({'directory':path, 'children':len(payload['tree']), 'sha':base})
            log('DIRECTORY_CHUNK', path, start+len(payload['tree']), len(children), flush=True)
        return base

    child = create_directory(build_trie(entries), PREFIX)
    parts = PREFIX.split('/')
    for i in range(len(parts)-1, -1, -1):
        parent = '/'.join(parts[:i])
        payload = {'tree':[{'path':parts[i], 'mode':'040000', 'type':'tree', 'sha':child}]}
        if directories.get(parent):
            payload['base_tree'] = directories[parent]
        child = call('git/trees', payload)['sha']
        chunks.append({'directory':parent, 'children':1, 'sha':child})
    assert all(0 < r['children'] <= CHUNK_SIZE for r in chunks)
    return child, chunks

def validate_preservation(before, after, entries):
    assert not before.get('truncated') and not after.get('truncated')
    old = {r['path']:r['sha'] for r in before['tree'] if r['type'] == 'blob'}
    new = {r['path']:r['sha'] for r in after['tree'] if r['type'] == 'blob'}
    assert all(new.get(path) == item['sha'] for path,item in entries.items()), 'Selected delivery mismatch.'
    removed = sorted(set(old)-set(new))
    changed = sorted(path for path,oid in new.items() if old.get(path) != oid)
    assert not removed, 'Existing source or metadata file removed.'
    assert all(path.startswith(PREFIX+'/') for path in changed), 'Change outside P52 delivery.'
    protected = [path for path in old if path.startswith('docs/cqc-reprise/pass49/')
                 or '/artists/' in path and path.lower().endswith('.png')]
    assert all(new[path] == old[path] for path in protected), 'P49 or raw artist PNG changed.'
    return changed, protected

def verify_raw_and_p49_baseline(tree):
    """All prior P49 files and every committed/local P52 raw must still exist."""
    actual = {r['path']:r['sha'] for r in tree['tree'] if r['type'] == 'blob'}
    p49 = load(N/'p51/publication/FINAL_DELIVERY_FULL_GIT_TREE_PRIVATE_V1.json')
    assert not p49.get('truncated')
    prior = [r for r in p49['tree'] if r['type'] == 'blob']
    assert all(actual.get(r['path']) == r['sha'] for r in prior), 'P49 baseline changed or missing.'
    raw = {}
    for receipt in sorted(PUB.glob('SOURCE_COMMIT_*_PRIVATE_V1.json')):
        record = load(receipt)
        assert record['rawBytesVerified']
        for row in record['rows']:
            if row['localPath'] in raw:
                assert raw[row['localPath']]['sha'] == row['sha']
            raw[row['localPath']] = row
    local = sorted(path for path in (N/'artists').rglob('*.png')
                   if '-raw-v' in path.name and 'p52' in path.parts)
    assert {str(path) for path in local} == set(raw), 'Local P52 source missing from watcher receipts, or source deleted.'
    for path in local:
        row = raw[str(path)]
        assert actual.get(row['path']) == row['sha'], 'Committed P52 raw missing from Git tree.'
        data = read(path)
        assert hashlib.sha256(data).hexdigest() == row['sha256']
        assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest() == row['sha']
    return {'p49BaselineBlobPaths':len(prior),'p52RawPNGPaths':len(local)}

def validate_snapshot(path, receipt):
    assert path.parent == OUT and path.name.startswith('P52_AUTHORED_METADATA_')
    assert digest(path) == receipt['sha256'] and path.stat().st_size == receipt['bytes']
    allowed = {'.json','.csv','.py','.mjs','.js','.css','.html','.md','.txt'}
    with tarfile.open(path, 'r:gz') as archive:
        members = archive.getmembers()
        for member in members:
            rel = pathlib.PurePosixPath(member.name)
            assert member.isfile() and not rel.is_absolute() and '..' not in rel.parts
            assert rel.suffix.lower() in allowed, 'Non-authored binary/package in metadata snapshot.'
        assert len(members) == receipt['filesReadBackExact']

def prepare(args):
    entries, proofs, inputs, missing = {}, [], {}, []

    def add(target, oid):
        safe_target(target)
        if target in entries:
            assert entries[target]['sha'] == oid, 'Conflicting Git target.'
        entries[target] = {'path':target,'mode':'100644','type':'blob','sha':oid}

    for name, source, key in [
        ('PORTABLE_ALL_SOURCE_BLOB_PIN_INDEX_PRIVATE_V1.json', 'PORTABLE_STATIC_CATALOG_SOURCE_INDEX_PRIVATE_V1.json', 'records'),
        ('VIEWED_REFERENCE_BINARY_GIT_PIN_INDEX_PRIVATE_V1.json', 'VIEWED_REFERENCE_IMAGE_SOURCE_INDEX_PRIVATE_V1.json', 'rows')]:
        index = PUB / name
        pinned = load(index)
        assert pinned.get('allObjectsPinned') and not pinned.get('branchReferenceMoved')
        assert pinned['sourceIndexSHA256'] == digest(PUB/source), 'Stale selected PNG index; rerun pinner.'
        inputs[str(index)] = digest(index)
        inputs[str(PUB/source)] = digest(PUB/source)
        for row in pinned[key]:
            assert row['gitObjectVerified']
            add(row['gitPath'], row['gitBlobOID'])

    files = []
    def select(path, target, required=True):
        if path.is_file():
            files.append((path, safe_target(PREFIX+'/'+target)))
        elif required:
            missing.append(str(path))

    for name in ('index.html','catalog.mjs','catalog.css','manifest-model.mjs','manifest.json','LIRE_MOI.txt'):
        select(OUT/'catalogue'/name, 'catalogue/'+name)
    for name in (
        'CQC_SUIVI_P52_POSES_UNIQUES_20261114_PUBLIC_V1.xlsx',
        'P52_POSES_STATIQUES_PUBLIC_V1.csv', 'P52_OFFICIELS_PUBLIC_V1.csv',
        'P52_MODE_EMPLOI_PUBLIC_V1.csv', 'P52_LIVRAISON_POSES_UNIQUES_PUBLIC_V1.json',
        'P52_TRACKING_BUILD_READBACK_PRIVATE_V1.json', 'README.md',
        'P52_FINAL_VERIFICATION_PUBLIC_V1.json'):
        select(OUT/name, name)
    for name in ('OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PUBLIC_V1.csv',
                 'OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json',
                 'OFFICIAL416_REFERENCE_DISPOSITIONS_PRIVATE_V1.json',
                 'P52_EXACT_COSTUME_GENERATION_GUARDS_PRIVATE_V1.json',
                 'P52_ACCEPTED_SAME_UID_ALIASES_PRIVATE_V1.json'):
        select(P/'official'/name, 'inventaires/'+name)
    select(N/'inventory/STATIC_ALL381_CATALOG_COMPACT_PUBLIC_V1.json',
           'inventaires/STATIC_ALL381_CATALOG_COMPACT_PUBLIC_V1.json')
    select(PUB/'VIEWED_REFERENCE_IMAGE_SOURCE_INDEX_PRIVATE_V1.json',
           'reference-images/REFERENCE_IMAGE_INDEX_PRIVATE_V1.json')
    for name in ('PORTABLE_ALL_SOURCE_BLOB_PIN_INDEX_PRIVATE_V1.json',
                 'VIEWED_REFERENCE_BINARY_GIT_PIN_INDEX_PRIVATE_V1.json',
                 'LATEST_AUTHORED_METADATA_SNAPSHOT_PRIVATE_V1.json'):
        select(PUB/name, 'verification/'+name)
    snapshot_receipt = load(PUB/'LATEST_AUTHORED_METADATA_SNAPSHOT_PRIVATE_V1.json')
    snapshot = pathlib.Path(snapshot_receipt['path'])
    validate_snapshot(snapshot, snapshot_receipt)
    select(snapshot, snapshot.name)
    for historical in sorted(OUT.glob('P52_AUTHORED_METADATA_*_PRIVATE_V1.tar.gz')):
        if historical != snapshot:
            select(historical, 'checkpoints/'+historical.name)
    for name in ('P52_NEW_SOURCE_FRAME_QA_PRIVATE_V1.json',
                 'FRAME_SELECTION_CORRECTIONS_PRIVATE_V1.json',
                 'ROOT_STATIC_ART_REVIEW_INDEX_PRIVATE_V1.json',
                 'CATALOG_FINAL_HANDOFF_PRIVATE_V1.json'):
        select(P/'catalog'/name, 'verification/'+name, required=False)
    for path in sorted((P/'catalog/qa').rglob('*')):
        if path.is_file() and path.suffix.lower() in ('.json','.png'):
            if args.qa_reports_only and path.suffix.lower() == '.png':
                continue
            select(path, 'verification/catalog-qa/'+path.relative_to(P/'catalog/qa').as_posix())
    # Root may explicitly select final browser evidence or extra authored reports.
    extra = PUB/'FINAL_EXTRA_DELIVERY_FILES_PRIVATE_V1.json'
    if extra.exists():
        inputs[str(extra)] = digest(extra)
        for row in load(extra)['rows']:
            path = pathlib.Path(row['source'])
            assert path.is_relative_to(P) and path.suffix.lower() in ('.json','.png','.md','.csv','.txt')
            assert 'extension17' not in path.parts and '/frames/' not in str(path)
            select(path, row['relativeGitPath'])

    known = known_blobs()
    def pin(item):
        path,target = item
        return pin_file(path,known), target
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for proof,target in pool.map(pin, files):
            add(target,proof['gitBlobOID'])
            proofs.append(dict(proof,gitPath=target))
            inputs[proof['source']] = proof['sha256']
    for path,sha in inputs.items():
        assert digest(pathlib.Path(path)) == sha, 'Input changed during plan; rerun: '+path
    plan = {'schema':'cqc.p52.final-delivery-tree-plan/1',
            'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'prefix':PREFIX, 'branch':BRANCH, 'treeEntries':len(entries),
            'treeChunkImmediateChildrenMaximum':CHUNK_SIZE,
            'missingRequiredFiles':missing, 'allRequiredFilesPresent':not missing,
            'inputSHA256':inputs, 'exactMetadataFiles':proofs,
            'branchReferenceMoved':False, 'commitsCreated':0,
            'gameFilesModified':0, 'tree':list(entries.values())}
    json_write(PUB/'FINAL_DELIVERY_TREE_PLAN_PRIVATE_V1.json',plan)
    print(json.dumps({k:v for k,v in plan.items() if k not in ('tree','exactMetadataFiles','inputSHA256')}),flush=True)
    return plan, entries, proofs

def commit(plan, entries, proofs):
    final = load(OUT/'P52_FINAL_VERIFICATION_PUBLIC_V1.json')
    assert final['status'] == 'PASS_FINAL' and final.get('errorCount') == 0, 'Final verification has not passed.'
    assert final['manifestSHA256'] == digest(P/'catalog/manifest-all381.json'), 'Final verification does not match current manifest.'
    assert plan['allRequiredFilesPresent'], 'Final metadata incomplete: '+str(plan['missingRequiredFiles'])
    assert not (PUB/'PRESERVATION_SINGLE_WRITER.lock').exists(), 'Source watcher still active.'
    watch = load(PUB/'WATCH_STATUS_PRIVATE_V1.json')
    assert watch['stopping'] and watch['pendingRawPages'] == 0
    assert not (PUB/'WATCH_ERROR_PRIVATE_V1.json').exists(), 'Unresolved watcher error.'
    lock = PUB/'FINAL_PUBLICATION_SINGLE_WRITER.lock'
    import os
    fd = os.open(lock, os.O_CREAT|os.O_EXCL|os.O_WRONLY, 0o600)
    os.write(fd,str(os.getpid()).encode()); os.close(fd)
    try:
        head = load(PUB/'CURRENT_HEAD_PRIVATE_V1.json')
        assert api('git/ref/heads/'+BRANCH)['object']['sha'] == head['commit'], 'Branch lease changed.'
        assert api('git/commits/'+head['commit'])['tree']['sha'] == head['tree'], 'Cursor tree does not match parent commit.'
        before = api('git/trees/'+head['tree']+'?recursive=1')
        assert before['sha'] == head['tree'] and not before.get('truncated')
        source_counts = verify_raw_and_p49_baseline(before)
        tree_sha, chunks = create_tree(entries,before)
        after = api('git/trees/'+tree_sha+'?recursive=1')
        changed, protected = validate_preservation(before,after,entries)
        assert verify_raw_and_p49_baseline(after) == source_counts
        for path,sha in plan['inputSHA256'].items():
            assert digest(pathlib.Path(path)) == sha, 'Delivery changed before commit: '+path
        assert load(PUB/'CURRENT_HEAD_PRIVATE_V1.json') == head, 'Parent cursor changed.'
        assert api('git/ref/heads/'+BRANCH)['object']['sha'] == head['commit'], 'Branch lease changed before commit.'
        made = api('git/commits', {
            'message':'art(cqc): deliver P52 official static costumes and updated Excel [skip ci]\n\nOne static RIGHT pose per qualified costume. Exact prior P49 and new P52 raw PNGs preserved; portable catalogue, selected visual proofs, inventories, review and authored metadata. No animation, runtime, stage or deployment changes.',
            'tree':tree_sha, 'parents':[head['commit']]})
        json_write(PUB/'FINAL_DELIVERY_PRE_REF_ATTEMPT_PRIVATE_V1.json',
                   {'parent':head['commit'],'commit':made['sha'],'tree':tree_sha,
                    'branch':BRANCH,'referenceNotYetUpdated':True})
        assert api('git/ref/heads/'+BRANCH)['object']['sha'] == head['commit'], 'Branch lease changed after commit object.'
        api('git/refs/heads/'+BRANCH, {'sha':made['sha'],'force':False},method='PATCH')
        assert api('git/ref/heads/'+BRANCH)['object']['sha'] == made['sha'], 'Final ref readback failed.'
        report = {'schema':'cqc.p52.final-git-delivery/1',
                  'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  'branch':BRANCH,'parent':head['commit'],'commit':made['sha'],'tree':tree_sha,
                  'deliveryEntriesVerified':len(entries),'changedPathsFromParent':len(changed),
                  'allChangedPathsWithinP52':True,'removedExistingPaths':0,
                  'protectedP49AndArtistPNGPathsVerified':len(protected),
                  'preservedSourceCounts':source_counts,
                  'immediateTreeChildLimit':CHUNK_SIZE,'createdTreeChunks':chunks,
                  'sourceWriterStopped':True,'gameFilesModified':0,'newAnimations':0,
                  'metadataBinaryProofs':proofs}
        json_write(PUB/'FINAL_DELIVERY_GIT_COMMIT_PRIVATE_V1.json',report)
        json_write(PUB/'CURRENT_HEAD_PRIVATE_V1.json',{'commit':made['sha'],'tree':tree_sha})
        json_write(PUB/'FINAL_DELIVERY_FULL_GIT_TREE_PRIVATE_V1.json',after)
        print(json.dumps({k:v for k,v in report.items() if k not in ('createdTreeChunks','metadataBinaryProofs')}),flush=True)
    finally:
        lock.unlink(missing_ok=True)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--commit',action='store_true',help='Root only; publish after stopping watcher.')
    parser.add_argument('--acknowledge-watcher-stopped',action='store_true')
    parser.add_argument('--qa-reports-only',action='store_true',help='Export QA JSON but omit rendered QA PNGs.')
    args = parser.parse_args()
    if args.commit and not args.acknowledge_watcher_stopped:
        parser.error('--commit requires --acknowledge-watcher-stopped; Root executes final publication.')
    plan,entries,proofs = prepare(args)
    if args.commit:
        commit(plan,entries,proofs)

if __name__ == '__main__':
    main()
