import pathlib,json,datetime
from git_blob_store import N
manifest=N/'p52/catalog/manifest-all381.json';m=json.loads(manifest.read_text());bySHA={}
for p in sorted(list((N/'publication').glob('SOURCE_COMMIT_*_PRIVATE_V1.json'))+list((N/'p50/publication').glob('SOURCE_COMMIT_*_PRIVATE_V1.json'))+list((N/'p51/publication').glob('SOURCE_COMMIT_*_PRIVATE_V1.json'))+list((N/'p52/publication').glob('SOURCE_COMMIT_*_PRIVATE_V1.json'))):
 d=json.loads(p.read_text())
 for r in d['rows']:bySHA.setdefault(r['sha256'],{'commit':d['commit'],'path':r['path'],'gitBlobOID':r['sha']})
baseline=json.loads((N/'p52/base/manifest-all381.json').read_text());prior={(e['uid'],e['costumeId']):e for e in baseline['entries']}
count=0
for e in m['entries']:
 source=e.get('source')or{};old=prior.get((e['uid'],e['costumeId']),{}).get('source')or{}
 if source.get('sha256')==old.get('sha256'):
  source.update({k:old[k]for k in['immutableURL','immutableSourceCommit','gitBlobOID']if k in old})
 r=None if source.get('sha256')==old.get('sha256')and old.get('immutableURL')else bySHA.get(source.get('sha256'))
 if r:
  source.update(immutableURL='https://raw.githubusercontent.com/darknigthmare/shadow-codec-ops/'+r['commit']+'/'+r['path'],immutableSourceCommit=r['commit'],gitBlobOID=r['gitBlobOID']);count+=1
manifest.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'newSourcesAnnotatedThisPass':count,'allGeneratedPoseEntriesWithImmutableURLs':sum(bool(e.get('source',{}).get('immutableURL'))for e in m['entries']),'rawHashesInLedger':len(bySHA)}))
