#!/usr/bin/env python3
"""Read-only P52 data audit, adapted from the inspected P51 verifier.

P51 (93aa7663cfe0b4293db37fe7ab62ca85bc2434e8) is the immutable baseline.
The 381x9 inventory and published 382-UID roster are separate invariants.
No Original correction, guard change, art, pixel edit, runtime or Git write is
authorized here. Run final mode only after Root freezes and packages P52.
"""
import argparse
import collections
import concurrent.futures
import hashlib
import io
import json
import math
from pathlib import Path

from PIL import Image
from p52_verification_common import (
    N, P, PUB, now, sha, exact, load, file_pin, publish, changed,
    source_path, png_structure,
)
from resolve_p52_metadata_pins import run as resolve_pins

ROOT_AUTHORIZED_ORIGINAL_SOURCE_PINS = {}
BASELINE_COMMIT = '93aa7663cfe0b4293db37fe7ab62ca85bc2434e8'
PRIOR = N / 'p51'
DELIVERY = N / 'p52/delivery'
OFFICIAL = N / 'p52/official'
INVENTORY = N / 'inventory/STATIC_ALL381_CATALOG_COMPACT_PUBLIC_V1.json'
QA_FIELDS = ('rect', 'pivot', 'bodyBounds', 'clipPolygon')
PENDING_STATES = {
    'REFERENCE_AND_STATIC_SOURCE_PENDING', 'BODY_FORM_CHANGE_SCOPE_REVIEW_PENDING',
    *{f'P{p}_{s}' for p in (50, 51, 52)
      for s in ('IMAGE_GENERATION_REFUSED', 'CONTENT_GUARD_NO_GENERATION')},
}
ALIAS_STATES = {f'P{p}_EXISTING_SAME_UID_APPEARANCE_REUSED' for p in (50, 51, 52)}


def run(mode='provisional', workers=4):
    start = now()
    errors, warnings, snapshot_pins = [], [], []

    def check(ok, reason, **details):
        if not ok:
            errors.append(dict(reason=reason, **details))

    def input_json(path):
        raw = exact(path)
        snapshot_pins.append(dict(path=str(path), sha256=sha(raw), bytes=len(raw)))
        return json.loads(raw)

    def current_document(folder, stem, prior_path):
        for name in (f'P52_{stem}_PRIVATE_V1.json', f'P51_{stem}_PRIVATE_V1.json'):
            path = folder / name
            if path.is_file():
                return input_json(path)
        return input_json(prior_path)

    m = input_json(P / 'manifest-all381.json')
    base_path = N / 'p52/base/manifest-all381.json'
    base = input_json(base_path)
    active = input_json(P / 'ACTIVE_ARTIST_REGISTRATIONS_PRIVATE_V1.json')
    mapping = input_json(OFFICIAL / 'OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json')
    baseline_map = input_json(N / 'p52/base/OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json')
    inventory = input_json(INVENTORY)
    prior_aggregate = input_json(PRIOR / 'delivery/P51_FINAL_VERIFICATION_PUBLIC_V1.json')
    prior_detail_path = PRIOR / 'publication/P51_FULL_VERIFICATION_FINAL_PRIVATE_V1.json'
    prior_detail = input_json(prior_detail_path)
    base_pin = next(pin for pin in snapshot_pins if pin['path'] == str(base_path))
    detail_pin = next(pin for pin in snapshot_pins if pin['path'] == str(prior_detail_path))
    check(prior_aggregate.get('status') == prior_detail.get('status') == 'PASS_FINAL',
          'Published P51 baseline evidence is not PASS_FINAL')
    check(prior_aggregate.get('manifestSHA256') == base_pin['sha256'],
          'P52 baseline is not the exact published P51 canonical manifest')
    check(prior_aggregate.get('detailReportSHA256') == detail_pin['sha256'],
          'P51 detail proof does not match its published aggregate hash')

    entries = m['entries']
    by = {(e['uid'], e['costumeId']): e for e in entries}
    old = {(e['uid'], e['costumeId']): e for e in base['entries']}
    uids = {e['uid'] for e in entries}
    published_uids = {e['uid'] for e in base['entries']}
    baseline_uids = {r['uid'] for r in inventory['rows']}
    expected_matrix = {(r['uid'], r['family']) for r in inventory['rows']}
    check(len(by) == len(entries), 'Duplicate UID/costume key')
    check(len(inventory['rows']) == len(expected_matrix) == 3429 and len(baseline_uids) == 381,
          'Original 381x9 inventory matrix malformed')
    check(len(published_uids) == 382 and uids == published_uids,
          'P52 must exactly preserve published 382 UIDs including existing XOF1984',
          missing=sorted(published_uids-uids), unexpected=sorted(uids-published_uids))

    approval_path = P / 'P52_AUTHORIZED_ORIGINAL_CORRECTIONS_PRIVATE_V1.json'
    approval_rows = input_json(approval_path).get('entries', []) if approval_path.is_file() else []
    check(not ROOT_AUTHORIZED_ORIGINAL_SOURCE_PINS and not approval_rows,
          'No Original corrections are authorized in P52')
    prior_registry_path = PRIOR / 'catalog/P51_ADDITIONAL_DISTINCT_INCARNATIONS_PRIVATE_V1.json'
    prior_registry = input_json(prior_registry_path)
    registry = current_document(P, 'ADDITIONAL_DISTINCT_INCARNATIONS', prior_registry_path)
    check(registry == prior_registry, 'Preexisting distinct-incarnation registry changed in P52')
    registry_rows = registry.get('entries', [])
    extra_uids = {r['uid'] for r in registry_rows}
    check(extra_uids == published_uids-baseline_uids and len(extra_uids) == 1,
          'Preexisting additional Original set changed')
    check(registry.get('baselineRosterUIDs') == 381 and registry.get('baselineMatrixRows') == 3429,
          'Distinct-incarnation registry changed the baseline matrix')
    additional_checks = []
    for row in registry_rows:
        key = (row['uid'], row.get('costumeID'))
        entry = by.get(key, {})
        own = [e for e in entries if e['uid'] == row['uid']]
        source = entry.get('source') or {}
        ok = bool(entry.get('family') == 'original' and entry.get('frame')
                  and entry.get('additionalDistinctIncarnation') is True
                  and source.get('sha256') == row.get('requiredSourceSHA256')
                  and row.get('rootAuthorizedIdentitySplit') is True
                  and row.get('notHistoricalAlias') is True
                  and row.get('newFamilyMatrixRowsClaimed') == 0
                  and len(own) == 1 and key[1] == 'original')
        check(ok, 'Preexisting XOF1984 Original not preserved exactly', key=key)
        additional_checks.append(dict(key=key, sourceSHA256=source.get('sha256'),
                                      preexistingFromP50=True, consistent=ok))
        related = next((r for r in mapping['rows'] if r['historicalID'] == row.get('relatedHistoricalID')), None)
        check(related is not None and related.get('resolutionState') == 'REFERENCE_AND_STATIC_SOURCE_PENDING',
              'Existing XOF1984 Original falsely closes related hospital historical row',
              historicalID=row.get('relatedHistoricalID'))

    prior_guards_path = PRIOR / 'official/P51_EXACT_COSTUME_GENERATION_GUARDS_PRIVATE_V1.json'
    prior_guards = input_json(prior_guards_path)
    guards = current_document(OFFICIAL, 'EXACT_COSTUME_GENERATION_GUARDS', prior_guards_path)
    check(guards == prior_guards, 'Frozen official generation guard document changed')
    official_guard_keys = {(r['uid'], r['costumeId']) for r in guards['entries']}
    guard_before = {k: e for k, e in old.items() if e.get('generationGuard')}
    guard_now = {k: e for k, e in by.items() if e.get('generationGuard')}
    check(len(guard_before) == 12 and set(guard_now) == set(guard_before),
          'Frozen 12 generation guard scopes changed', expected=12, actual=len(guard_now))
    check(len(official_guard_keys) == 5, 'Expected five inherited canonical official guard scopes')
    frozen_guard_checks = []
    for key, entry in guard_before.items():
        current = by.get(key, {})
        same = all(current.get(field) == entry.get(field)
                   for field in ('generationGuard', 'source', 'frame'))
        check(same, 'Frozen guard, Source or frame differs from P51', key=key)
        frozen_guard_checks.append(dict(key=key, unchanged=same, sourcePresent=bool(entry.get('source'))))
    for key in official_guard_keys:
        e = by.get(key, {})
        check(e.get('generationGuard') and not e.get('source') and not e.get('frame'),
              'Official guarded goal gained Source/frame or lost guard', key=key)

    planned = [e for e in entries if e['family'] != 'canonical' and e['uid'] in baseline_uids]
    planned_keys = {(e['uid'], e['family']) for e in planned}
    aliases = {(e['uid'], e['family']) for e in m['aliasesCoveredByOriginal']}
    excluded = {(e['uid'], e['family']) for e in m['notApplicableExcluded']}
    matrix = planned_keys | aliases | excluded
    check(len(planned_keys) == len(planned), 'Duplicate planned UID/family')
    check(not (planned_keys & aliases or planned_keys & excluded or aliases & excluded),
          'Planned, alias and excluded baseline matrix overlap')
    check(matrix == expected_matrix, '381x9 baseline matrix not fully preserved',
          missing=sorted(expected_matrix-matrix)[:10], unexpected=sorted(matrix-expected_matrix)[:10])
    check(m['aliasesCoveredByOriginal'] == base['aliasesCoveredByOriginal'], 'Baseline Original-equivalent aliases changed')
    check(m['notApplicableExcluded'] == base['notApplicableExcluded'], 'Baseline exclusions changed')
    originals = [e for e in planned if e['family'] == 'original']
    check(len(originals) == 381 and all(e.get('source') and e.get('frame') for e in originals),
          'All 381 inventory Originals must retain Source/frame')
    uncovered = [(e['uid'], e['costumeId']) for e in planned if not e.get('source') and not e.get('generationGuard')]
    check(not uncovered, 'Unguarded planned rows lack Source', rows=uncovered)

    old_map = {r['historicalID']: r for r in baseline_map['rows']}
    current_map = {r['historicalID']: r for r in mapping['rows']}
    check(len(current_map) == 416 and set(current_map) == set(old_map), 'Historical 416 ID set changed')
    for historical_id, row in current_map.items():
        previous = old_map.get(historical_id, {})
        check(all(row.get(k) == previous.get(k) for k in ('targetUID', 'historicalUID', 'reconciledOfficialID')),
              'Historical incarnation identity or official ID changed', historicalID=historical_id)
    accepted_alias_path = OFFICIAL / 'P52_ACCEPTED_SAME_UID_ALIASES_PRIVATE_V1.json'
    accepted_aliases = input_json(accepted_alias_path) if accepted_alias_path.is_file() else {'entries': []}
    accepted_alias_checks = []
    for alias in accepted_aliases.get('entries', []):
        historical_id = alias['historicalID']
        key = (alias['targetUID'], alias['targetCostumeID'])
        e, previous, row = by.get(key, {}), old.get(key, {}), current_map.get(historical_id, {})
        ok = bool(alias.get('uid') == alias.get('targetUID') and alias.get('reviewer')
                  and alias.get('proofPaths') and e.get('source')
                  and e.get('source') == previous.get('source')
                  and e.get('frame') == previous.get('frame')
                  and row.get('resolutionState') == 'P52_EXISTING_SAME_UID_APPEARANCE_REUSED'
                  and row.get('targetCostumeID') == key[1])
        check(ok, 'Root-accepted P52 alias lacks exact same-UID baseline Source/frame', historicalID=historical_id, key=key)
        accepted_alias_checks.append(dict(historicalID=historical_id, targetKey=key, consistent=ok, newArt=False))
    aliases_by_key = {(r['targetUID'], r['reconciledOfficialID']): r for r in mapping['rows']
                      if r.get('resolutionState') in ALIAS_STATES}
    accepted_ids = {a['historicalID'] for a in accepted_aliases.get('entries', [])}
    for row in mapping['rows']:
        if row.get('resolutionState') == 'P52_EXISTING_SAME_UID_APPEARANCE_REUSED':
            check(row['historicalID'] in accepted_ids, 'P52 alias is absent from Root acceptance registry', historicalID=row['historicalID'])
    missing_old, changed_old, removed_empty = [], [], []
    for key, entry in old.items():
        current = by.get(key)
        if current is None:
            (missing_old if entry.get('source') else removed_empty).append(key)
        elif entry.get('source') and (entry['source']['sha256'] != (current.get('source') or {}).get('sha256')
                                       or entry.get('frame') != current.get('frame')):
            changed_old.append(dict(key=key, priorSHA256=entry['source']['sha256'],
                                    selectedSHA256=(current.get('source') or {}).get('sha256'),
                                    frameChanged=entry.get('frame') != current.get('frame')))
    check(not missing_old, 'Previously sourced entry removed', keys=missing_old)
    check(not changed_old, 'Previously selected Source/frame changed; no P52 Original exceptions', rows=changed_old)
    check(all(key in aliases_by_key for key in removed_empty), 'Removed empty placeholder is not a documented exact alias',
          keys=[key for key in removed_empty if key not in aliases_by_key])

    paths_by_sha, source_dims, selected_generated = {}, {}, set()
    frame_checks = 0
    for e in entries:
        source, frame, key = e.get('source'), e.get('frame'), (e['uid'], e['costumeId'])
        if not source:
            check(not frame, 'Frame without Source', key=key)
            continue
        check(frame is not None, 'Source without frame', key=key)
        try:
            q = source_path(source)
            wanted, dims = source['sha256'], (source['width'], source['height'])
            paths_by_sha.setdefault(wanted, set()).add(str(q))
            check(wanted not in source_dims or source_dims[wanted] == dims, 'Same Source SHA has conflicting dimensions', key=key)
            source_dims[wanted] = dims
            if source.get('kind') == 'generated-atlas':
                selected_generated.add(wanted)
            x, y, w, h = frame['rect']
            check(all(type(v) is int for v in (x, y, w, h)) and x >= 0 and y >= 0 and w > 0 and h > 0
                  and x+w <= dims[0] and y+h <= dims[1], 'Invalid Source frame rectangle', key=key)
            pivot = frame['pivot']
            check(isinstance(pivot, list) and len(pivot) == 2
                  and all(type(v) in (int, float) and math.isfinite(v) and 0 <= v <= 1 for v in pivot),
                  'Invalid normalized frame pivot', key=key)
            check(e.get('facing') == 'right', 'Selected frame not declared RIGHT', key=key)
            check(not e.get('generationRequired'), 'Selected Source still marked requires generation', key=key)
            frame_checks += 1
        except Exception as exc:
            errors.append(dict(reason='Selected Source/frame lookup failed', key=key, error=f'{type(exc).__name__}: {exc}'))
    prior_png_info = {r['sha256']: r for r in prior_detail.get('selectedPNGVerification', []) if not r.get('error')}
    preserved_originals = []
    for row in prior_detail.get('priorOriginalSourcesPreserved', []):
        wanted, q = row['sha256'], Path(row['path'])
        info = prior_png_info[wanted]
        paths_by_sha.setdefault(wanted, set()).add(str(q))
        source_dims[wanted] = (info['width'], info['height'])
        preserved_originals.append(dict(row, preexistingPreservationFromP51=True))
    check(len(preserved_originals) == 4, 'Expected four inherited superseded Original Sources')
    selected_shas = {e['source']['sha256'] for e in entries if e.get('source')}

    def verify_group(item):
        wanted, paths = item
        try:
            first, physical = None, []
            for path in sorted(paths):
                raw = exact(Path(path))
                assert sha(raw) == wanted, 'SHA256 mismatch'
                physical.append(dict(path=path, bytes=len(raw), sha256=wanted))
                if first is None:
                    first = raw
            info = png_structure(first)
            with Image.open(io.BytesIO(first)) as im:
                im.load()
                dims, image_mode = im.size, im.mode
            assert dims == (info['width'], info['height']) == source_dims[wanted], 'Decoded/IHDR/Source dimensions mismatch'
            oid = hashlib.sha1(b'blob '+str(len(first)).encode()+b'\0'+first).hexdigest()
            return dict(sha256=wanted, bytes=len(first), width=dims[0], height=dims[1], mode=image_mode,
                        chunkCount=len(info['chunks']), allChunkCRCsExact=True, fullRasterDecoded=True,
                        animatedPNGRejected=True, gitBlobOID=oid, physicalPaths=physical, selectedCurrent=wanted in selected_shas)
        except Exception as exc:
            return dict(sha256=wanted, physicalPaths=sorted(paths), error=f'{type(exc).__name__}: {exc}', selectedCurrent=wanted in selected_shas)

    records = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
        for index, record in enumerate(pool.map(verify_group, sorted(paths_by_sha.items())), 1):
            records.append(record)
            if index % 200 == 0:
                print(json.dumps(dict(progressUniquePNG=index, total=len(paths_by_sha))), flush=True)
    for record in records:
        if record.get('error'):
            errors.append(dict(reason='PNG integrity/decode failed', **record))
    verified = {r['sha256']: r for r in records if not r.get('error')}
    check(selected_shas <= set(verified), 'Some selected PNGs not fully verified', missing=sorted(selected_shas-set(verified)))

    ledger, ledger_pins = {}, []
    for folder in (N/'publication', N/'p50/publication', PRIOR/'publication', PUB):
        for path in sorted(folder.glob('SOURCE_COMMIT_*_PRIVATE_V1.json')):
            raw = exact(path)
            doc = json.loads(raw)
            ledger_pins.append(dict(path=str(path), sha256=sha(raw), bytes=len(raw)))
            for row in doc.get('rows', []):
                ledger.setdefault(row['sha256'], []).append(dict(row, commit=doc.get('commit'), receiptPath=str(path)))
    prior_ledger = {r['sha256']: r for r in prior_detail.get('generatedSourceLedgerChecks', [])}
    baseline_generated = {e['source']['sha256'] for e in base['entries']
                          if (e.get('source') or {}).get('kind') == 'generated-atlas'}
    generated_checks = []
    for wanted in sorted(selected_generated):
        record = verified.get(wanted)
        matches = [r for r in ledger.get(wanted, []) if record and r.get('sha') == record['gitBlobOID'] and r.get('bytes') == record['bytes']]
        inherited = bool(wanted in baseline_generated and record and prior_ledger.get(wanted, {}).get('matchingLedgerRows', 0) > 0
                         and prior_png_info.get(wanted, {}).get('gitBlobOID') == record['gitBlobOID']
                         and prior_png_info.get(wanted, {}).get('bytes') == record['bytes'])
        ok = bool(matches) or inherited
        generated_checks.append(dict(sha256=wanted, matchingLedgerRows=len(matches),
                                     inheritedPublishedP51LedgerProof=inherited,
                                     inheritedProofDetailSHA256=detail_pin['sha256'] if inherited else None,
                                     ledgerReceipts=sorted({r['receiptPath'] for r in matches}), consistent=ok))
        check(ok, 'Generated Source lacks matching local ledger or exact published P51 proof', sha256=wanted)
    for e in entries:
        source = e.get('source') or {}
        if source.get('kind') == 'generated-atlas':
            key = (e['uid'], e['costumeId'])
            check(bool(source.get('immutableURL')), 'Generated Source lacks immutable URL', key=key)
            if source.get('gitBlobOID') and source['sha256'] in verified:
                check(source['gitBlobOID'] == verified[source['sha256']]['gitBlobOID'], 'Generated Source blob metadata mismatch', key=key)

    map_checks = []
    for row in mapping['rows']:
        key = (row['targetUID'], row.get('targetCostumeID') or row['reconciledOfficialID'])
        e = by.get(key)
        pending = row['resolutionState'] in PENDING_STATES
        ok = bool(e) and (not e.get('source') if pending else bool(e.get('source') and e.get('frame')))
        check(ok, 'Historical map/Source state inconsistent', historicalID=row['historicalID'], key=key, resolutionState=row['resolutionState'])
        map_checks.append(dict(historicalID=row['historicalID'], targetKey=key, state=row['resolutionState'],
                               expectedSource=not pending, sourcePresent=bool(e and e.get('source')), consistent=ok))

    fixes = input_json(P/'FRAME_SELECTION_CORRECTIONS_PRIVATE_V1.json')
    p50_qa = input_json(P/'P50_NEW_SOURCE_FRAME_QA_PRIVATE_V1.json')
    p51_qa = input_json(P/'P51_NEW_SOURCE_FRAME_QA_PRIVATE_V1.json')
    for name, document in [('FRAME_SELECTION_CORRECTIONS_PRIVATE_V1.json', fixes),
                           ('P50_NEW_SOURCE_FRAME_QA_PRIVATE_V1.json', p50_qa),
                           ('P51_NEW_SOURCE_FRAME_QA_PRIVATE_V1.json', p51_qa)]:
        check(document == input_json(PRIOR/'catalog'/name), 'Inherited geometry QA document changed', file=name)
    p52_qa_path = P/'P52_NEW_SOURCE_FRAME_QA_PRIVATE_V1.json'
    if p52_qa_path.is_file():
        p52_qa = input_json(p52_qa_path)
    else:
        p52_qa = {'corrections': []}
        (errors if mode == 'final' else warnings).append(dict(reason='P52 Source/frame QA document pending'))

    def audit_qa(document, label, locked=True):
        checks, applied, superseded, fields_count = [], [], [], collections.Counter()
        for fix in document.get('corrections', []):
            key = (fix['uid'], fix['costumeId'])
            e = by.get(key)
            result = dict(uid=key[0], costumeId=key[1], lockedSourceSHA256=fix['sourceSHA256'], fieldsChecked=[], mismatchedFields=[])
            if not e or not e.get('source'):
                check(False, label+' reviewed geometry entry missing', key=key)
                result['state'] = 'MISSING_ENTRY'
            elif e['source']['sha256'] != fix['sourceSHA256']:
                result.update(state='SUPERSEDED_BY_SELECTED_DIFFERENT_SOURCE', selectedSourceSHA256=e['source']['sha256'])
                superseded.append(result)
            else:
                if locked:
                    check(fix.get('requiresSourceSHAMatch') is True, label+' correction lacks explicit Source SHA lock', key=key)
                for field in QA_FIELDS:
                    if field in fix:
                        result['fieldsChecked'].append(field)
                        fields_count[field] += 1
                        if e['frame'].get(field) != fix[field]:
                            result['mismatchedFields'].append(field)
                review = e.get('frameReview') or {}
                if review.get('reviewer') != fix.get('reviewer'):
                    result['mismatchedFields'].append('frameReview.reviewer')
                if locked and review.get('sourceSHA256') != fix['sourceSHA256']:
                    result['mismatchedFields'].append('frameReview.sourceSHA256')
                if locked and 'footprint' in fix and review.get('sourceFootDatum') != fix['footprint']:
                    result['mismatchedFields'].append('frameReview.sourceFootDatum')
                check(not result['mismatchedFields'], label+' active geometry not applied exactly', key=key, fields=result['mismatchedFields'])
                result['state'] = 'NOT_APPLIED' if result['mismatchedFields'] else 'APPLIED_EXACT'
                if not result['mismatchedFields']:
                    applied.append(key)
            checks.append(result)
        return dict(checks=checks, applied=applied, superseded=superseded, fields=dict(fields_count))

    qa = {label: audit_qa(doc, label, label != 'P49')
          for label, doc in [('P49', fixes), ('P50', p50_qa), ('P51', p51_qa), ('P52', p52_qa)]}
    check(len(qa['P49']['applied']) == 31 and len(qa['P49']['superseded']) == 1, 'P49 QA must retain 31 active and one prior superseded correction')
    check(len(p50_qa.get('corrections', [])) == len(qa['P50']['applied']) == 60, 'All 60 P50 QA corrections must remain applied')
    check(len(p51_qa.get('corrections', [])) == len(qa['P51']['applied']) == 5, 'All five P51 QA corrections must remain applied')
    newly_sourced = {key for key, e in by.items() if e.get('source') and not (old.get(key) or {}).get('source')}
    check(newly_sourced <= set(qa['P52']['applied']), 'New P52 Sources lack active exact QA', keys=sorted(newly_sourced-set(qa['P52']['applied'])))
    pin_report = resolve_pins(mode)
    check(pin_report['errorCount'] == 0, 'Historical/active metadata-pin resolution errors', count=pin_report['errorCount'])

    portable_checks = browser_binding = model_binding = None
    if mode == 'final':
        portable_root = DELIVERY/'catalogue'
        portable = input_json(portable_root/'manifest.json')
        portable_by = {(e['uid'], e['costumeId']): e for e in portable['entries']}
        portable_errors, portable_paths = [], {}
        if set(portable_by) != set(by):
            portable_errors.append(dict(reason='Portable entry keys differ from canonical manifest'))
        for key, e in by.items():
            pe = portable_by.get(key)
            if pe is None:
                continue
            canonical_entry, portable_entry = json.loads(json.dumps(e)), json.loads(json.dumps(pe))
            for item in (canonical_entry, portable_entry):
                if item.get('source'):
                    item['source'].pop('src', None)
                    item['source'].pop('localPath', None)
            if canonical_entry != portable_entry:
                portable_errors.append(dict(reason='Portable entry metadata differs beyond Source transport paths', key=key))
            if pe.get('source'):
                source = pe['source']
                q = portable_root/source['src']
                try:
                    safe = q.is_relative_to(portable_root) and q.resolve(strict=True) == q
                except FileNotFoundError:
                    safe = False
                if not safe:
                    portable_errors.append(dict(reason='Missing/unsafe portable Source path', key=key))
                else:
                    portable_paths.setdefault(source['sha256'], set()).add(q)
        ignored = {'entries', 'inventoryInput', 'portableCatalog', 'sourceVersionPolicy'}
        if ({k: v for k, v in m.items() if k not in ignored}
                != {k: v for k, v in portable.items() if k not in ignored}
                or portable.get('portableCatalog') is not True):
            portable_errors.append(dict(reason='Portable top-level preserved metadata differs'))
        for name in ('index.html', 'catalog.mjs', 'catalog.css', 'manifest-model.mjs'):
            if exact(P/name) != exact(portable_root/name):
                portable_errors.append(dict(reason='Portable UI/model file differs', file=name))
        portable_verified = 0
        for wanted, paths in portable_paths.items():
            try:
                for path in paths:
                    raw = exact(path)
                    assert sha(raw) == wanted and wanted in verified, 'Portable hash differs from decoded canonical Source'
                    assert len(raw) == verified[wanted]['bytes'], 'Portable length differs'
                portable_verified += 1
            except Exception as exc:
                portable_errors.append(dict(reason='Portable Source exact readback failed', sha256=wanted, error=str(exc)))
        check(portable_verified == len(selected_shas), 'Portable bundle does not contain all selected unique PNGs')
        portable_checks = dict(portableManifestSHA256=file_pin(portable_root/'manifest.json')['sha256'],
                               entryKeysCompared=len(portable_by), selectedUniquePNGsSHAComparedToDecodedCanonical=portable_verified,
                               allSelectedFramesSourcesAndGuardsMatch=not portable_errors, errors=portable_errors)
        errors.extend(portable_errors)
        browser = input_json(DELIVERY/'P52_BROWSER_VERIFICATION_PRIVATE_V1.json')
        browser_ok = bool(browser.get('manifestSHA256') == portable_checks['portableManifestSHA256']
                          and browser.get('sourceLoadErrors') == 0 and not browser.get('uncaughtBrowserExceptions')
                          and len(browser.get('cases', [])) >= 20 and browser.get('filterPaginationAndRepeatedSourceLoads') is True
                          and browser.get('desktop') == [1440, 1000] and browser.get('mobile') == [390, 844]
                          and all(c.get('errors') == 0 and not c.get('overflow') and c.get('cards', 0) > 0
                                  and c.get('loaded') == c.get('sources') for c in browser.get('cases', [])))
        check(browser_ok, 'Root browser proof is unbound to final portable manifest or reports errors')
        browser_binding = dict(manifestSHA256=browser.get('manifestSHA256'), portableManifestSHA256=portable_checks['portableManifestSHA256'],
                               caseCount=len(browser.get('cases', [])), boundAndNoErrors=browser_ok, atUTC=browser.get('atUTC'))
        model = input_json(DELIVERY/'P52_MODEL_TESTS_PRIVATE_V1.json')
        canonical_sha = next(pin['sha256'] for pin in snapshot_pins if pin['path'] == str(P/'manifest-all381.json'))
        model_ok = (model.get('status') == 'PASS' and model.get('checks', 0) >= 13
                    and model.get('exitCode') == 0 and model.get('manifestSHA256') == canonical_sha)
        check(model_ok, 'Root meaningful model proof is not PASS or is unbound to current canonical manifest')
        model_binding = dict(status=model.get('status'), checks=model.get('checks'), atUTC=model.get('atUTC'),
                             manifestSHA256=model.get('manifestSHA256'), canonicalManifestSHA256=canonical_sha,
                             boundAndNoErrors=model_ok, testScriptSHA256=model.get('testScriptSHA256'))

    changed_inputs = [pin['path'] for pin in snapshot_pins+ledger_pins if changed(pin)]
    stable = not changed_inputs and pin_report['inputSnapshotStable']
    status = ('FAIL' if errors else ('PASS_PROVISIONAL' if mode == 'provisional' else 'PASS_FINAL')) if stable else 'LIVE_INPUTS_CHANGED_RERUN_REQUIRED'
    metrics = dict(rosterUIDs=len(uids), catalogEntries=len(entries), plannedRows=len(planned), plannedMatrixRows=len(matrix),
                   baselineAliasRows=len(aliases), baselineExcludedRows=len(excluded), baselineRosterUIDs=len(baseline_uids),
                   publishedBaselineRosterUIDs=len(published_uids), newRosterUIDsAdded=len(uids-published_uids),
                   originalPosesPresent=len(originals)+len(additional_checks), baselineOriginalPosesPresent=len(originals),
                   additionalOriginalPosesPresent=len(additional_checks), additionalDistinctIncarnationUIDs=len(extra_uids),
                   selectedSourcedEntries=sum(bool(e.get('source')) for e in entries), selectedUniquePNGs=len(selected_shas),
                   selectedUniquePNGsSHA256CRCAndDecoded=sum(r['selectedCurrent'] and not r.get('error') for r in records),
                   allVerifiedPNGsIncludingSupersededOriginals=len(verified),
                   uniqueSelectedPNGBytes=sum(r['bytes'] for r in records if r['selectedCurrent'] and not r.get('error')),
                   selectedRIGHTRectPivotChecks=frame_checks, generatedSelectedUniquePNGs=len(selected_generated),
                   generatedSelectedUniquePNGsWithLedger=sum(r['consistent'] for r in generated_checks),
                   generatedInheritedPublishedP51Proofs=sum(r['inheritedPublishedP51LedgerProof'] for r in generated_checks),
                   activeCandidatePages=len(active.get('pages', [])), activePoseCandidates=active.get('activePoseCandidates'),
                   baselineSelectedKeysRetained=sum(bool(e.get('source')) for e in base['entries'])-len(missing_old),
                   baselineSelectedSourcesAndFramesUnchanged=sum(bool(e.get('source')) for e in base['entries'])-len(missing_old)-len(changed_old),
                   approvedOriginalCorrections=0, newP52SourcedEntries=len(newly_sourced),
                   removedUnbackedPlaceholdersAliased=len(removed_empty), generationGuardScopes=len(guard_now),
                   frozenGuardScopesExactlyPreserved=sum(r['unchanged'] for r in frozen_guard_checks),
                   newGuardSources=sum(bool(e.get('generationGuard') and e.get('source'))
                                       and (old.get((e['uid'], e['costumeId']), {}).get('source') or {}).get('sha256')
                                       != e['source']['sha256'] for e in entries if e.get('source')),
                   guardedOfficialRowsNoSource=sum(key in by and not by[key].get('source') for key in official_guard_keys),
                   officialHistoricalRowsReconciled=len(map_checks), officialHistoricalStates=dict(collections.Counter(r['state'] for r in map_checks)),
                   acceptedP52AliasChecks=sum(r['consistent'] for r in accepted_alias_checks),
                   historicalMetadataPinsExact=pin_report['summary']['historicalPinsExactlyResolved'],
                   activeMetadataPinsExact=pin_report['summary']['activeImmutablePinsExact'])
    for label, document in [('P49', fixes), ('P50', p50_qa), ('P51', p51_qa), ('P52', p52_qa)]:
        prefix = label.lower()
        metrics.update({prefix+'ReviewedCorrections': len(document.get('corrections', [])),
                        prefix+'ReviewedCorrectionsApplied': len(qa[label]['applied']),
                        prefix+'ReviewedCorrectionsSuperseded': len(qa[label]['superseded']),
                        prefix+'ReviewedFieldsChecked': qa[label]['fields']})
    for label in ('p50', 'p51', 'p52'):
        metrics[label+'Summary'] = {k: v for k, v in mapping.get(label+'Summary', {}).items() if k != 'proposalDocuments'}
    report = dict(schema='cqc.p52.static-delivery-full-verification/1', mode=mode, startedAtUTC=start, finishedAtUTC=now(),
                  status=status, inputSnapshotStable=stable, changedLiveInputs=changed_inputs, inputPins=snapshot_pins,
                  baselinePublishedCommit=BASELINE_COMMIT, publishedBaselineManifestSHA256=base_pin['sha256'],
                  inheritedP51DetailEvidenceSHA256=detail_pin['sha256'], metrics=metrics,
                  approvedOriginalChanges=[], exactOriginalApprovalChecks=[], frozenGuardChecks=frozen_guard_checks,
                  acceptedP52AliasChecks=accepted_alias_checks, additionalDistinctIncarnations=additional_checks,
                  priorOriginalSourcesPreserved=preserved_originals, selectedPNGVerification=records,
                  generatedSourceLedgerChecks=generated_checks, sourceLedgerPins=ledger_pins,
                  officialMappingChecks=map_checks, geometryQALayers=qa,
                  metadataPinReport=str(PUB/f'P52_METADATA_PIN_RESOLUTION_{mode.upper()}_PRIVATE_V1.json'),
                  finalPortableBundleVerification=portable_checks, finalBrowserEvidenceBinding=browser_binding,
                  finalModelTestEvidence=model_binding, errors=errors, warnings=warnings, errorCount=len(errors),
                  newArtGenerated=False, SourcePixelsEdited=False, catalogMapperImporterBuildModified=False,
                  GitRefsTouched=False, runtimeModified=False, newAnimations=0, pixelPerfectFidelityCertified=False,
                  limitations=[
                      'Checks integrity, decoded PNGs and declared RIGHT geometry; visual likeness/anatomy and runtime admission are not certified.',
                      'All 12 P51 guards are frozen, including one inherited preexisting Source; no new guarded Source is allowed.',
                      'P51 source-ledger proof is inherited only for exact unchanged baseline bytes/blob OIDs and bound to the published P51 aggregate.',
                      'Inventory381 and matrix3429 are fixed; published roster382 already included XOF1984. No new Original exception is authorized.',
                      'Provisional input snapshots require rerun after Root freeze; this verifier does not publish or merge Git refs.',
                  ])
    detail_out = publish(PUB/f'P52_FULL_VERIFICATION_{mode.upper()}_PRIVATE_V1.json', report)
    aggregate = build_public_aggregate(report, detail_out)
    print(json.dumps(dict(detail_out, status=status, metrics=metrics, errorCount=len(errors), changedInputs=changed_inputs)), flush=True)
    return report


def build_public_aggregate(report, detail_pin):
    manifest_pin = next(p for p in report['inputPins'] if p['path'] == str(P/'manifest-all381.json'))
    metrics = json.loads(json.dumps(report['metrics']))
    for name in ('p50Summary', 'p51Summary', 'p52Summary'):
        extras = metrics.get(name, {}).pop('unmappedAdditionalProposals', [])
        metrics.get(name, {})['additionalDistinctOfficialAppearances'] = len(extras)
    aggregate = dict(schema='cqc.p52.final-verification-aggregate/1', atUTC=report['finishedAtUTC'], status=report['status'],
                     mode=report['mode'], finalFreezeClaimed=report['mode'] == 'final' and report['inputSnapshotStable'],
                     baselinePublishedCommit=BASELINE_COMMIT, manifestSHA256=manifest_pin['sha256'], manifestBytes=manifest_pin['bytes'],
                     detailReportSHA256=detail_pin['sha256'], inputSnapshotStable=report['inputSnapshotStable'],
                     errorCount=report['errorCount'], metrics=metrics,
                     browserVerification=report['finalBrowserEvidenceBinding'], modelTests=report['finalModelTestEvidence'],
                     portableBundleVerification=report['finalPortableBundleVerification'], newArtByVerifier=False,
                     sourcePixelsEdited=False, catalogOrRuntimeModifiedByVerifier=False, GitRefsTouched=False,
                     pixelPerfectFidelityCertified=False,
                     coverageCaveat='Reference-pending looks and all frozen guarded goals remain explicit. Integrity and declared static geometry do not certify visual 1:1 or combat/animation admission.')
    DELIVERY.mkdir(parents=True, exist_ok=True)
    path = DELIVERY/('P52_FINAL_VERIFICATION_PUBLIC_V1.json' if report['mode'] == 'final' else 'P52_PROVISIONAL_VERIFICATION_PUBLIC_V1.json')
    raw = (json.dumps(aggregate, ensure_ascii=False, indent=2)+'\n').encode()
    temp = path.with_name('.'+path.name+'.tmp')
    temp.write_bytes(raw)
    __import__('os').replace(temp, path)
    assert exact(path) == raw
    print(json.dumps(dict(publicAggregate=str(path), sha256=sha(raw), status=aggregate['status'], manifestSHA256=manifest_pin['sha256'])), flush=True)
    return aggregate


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=('provisional', 'final'), default='provisional')
    parser.add_argument('--workers', type=int, default=4)
    args = parser.parse_args()
    result = run(args.mode, args.workers)
    raise SystemExit(bool(result['errorCount']) or not result['inputSnapshotStable'])
