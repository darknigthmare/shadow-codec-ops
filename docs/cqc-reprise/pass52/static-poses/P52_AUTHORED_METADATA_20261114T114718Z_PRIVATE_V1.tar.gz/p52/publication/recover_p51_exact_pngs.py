#!/usr/bin/env python3
"""Restore exact pinned P51 PNG bytes and TMP aliases. Never writes /workspace."""
import base64
import collections
import concurrent.futures
import datetime
import glob
import hashlib
import json
import os
import pathlib
import stat
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

N = "/tmp/cqc-static-20261113"
PUB = N + "/p52/publication"
CAT = N + "/p51/catalog"
PORTABLE = N + "/p51/delivery/catalogue"
REPO = "darknigthmare/shadow-codec-ops"
COMMIT = "93aa7663cfe0b4293db37fe7ab62ca85bc2434e8"
PREFIX = "docs/cqc-reprise/pass51/static-poses/catalogue/"
INDEX = N + "/p51/publication/PORTABLE_STATIC_CATALOG_SOURCE_INDEX_PRIVATE_V1.json"
REPORT = PUB + "/P52_P51_EXACT_PNG_RECOVERY_PRIVATE_V1.json"
PROGRESS = PUB + "/P52_P51_EXACT_PNG_RECOVERY_PROGRESS_PRIVATE_V1.json"
MAX_WORKERS = 6
START = time.time()
LOCK = threading.Lock()
COUNTS = collections.Counter()
RESULTS = []
ERRORS = []
ALIASES = {}
UNMAPPED = []
PNG = b"\x89PNG\r\n\x1a\n"

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest_data(data):
    return hashlib.sha256(data).hexdigest()

def safe_tmp(path):
    path = os.path.abspath(path)
    if not path.startswith(N + "/"):
        raise ValueError("Destination outside authorized TMP root")
    current = pathlib.Path(path).parent
    while str(current) != N and str(current).startswith(N + "/"):
        if current.is_symlink():
            raise ValueError("Symlinked destination ancestor")
        current = current.parent
    return path

def read_exact(path, expected_sha=None, expected_bytes=None):
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NOATIME
    fd = os.open(path, flags)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode):
            raise ValueError("Not a regular file")
        if expected_bytes is not None and before.st_size != expected_bytes:
            raise ValueError("Byte count mismatch")
        chunks = []
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            chunks.append(chunk)
        after = os.fstat(fd)
    finally:
        os.close(fd)
    unchanged = all(getattr(before, k) == getattr(after, k) for k in
                    ("st_dev", "st_ino", "st_size", "st_atime_ns", "st_mtime_ns", "st_ctime_ns", "st_nlink"))
    if not unchanged:
        raise ValueError("Source stat changed during no-atime read")
    data = b"".join(chunks)
    if expected_sha is not None and digest_data(data) != expected_sha:
        raise ValueError("SHA256 mismatch")
    return data, {
        "path": path, "sourceStatsUnchanged": unchanged, "sourceReadsNoAtime": True,
        "sourceReadNoFollow": True, "device": before.st_dev, "inode": before.st_ino,
        "bytes": before.st_size, "atimeNs": before.st_atime_ns,
        "mtimeNs": before.st_mtime_ns, "ctimeNs": before.st_ctime_ns,
    }

def verify_data(data, record):
    if len(data) != record["bytes"]:
        raise ValueError("Exact byte count mismatch")
    if not data.startswith(PNG):
        raise ValueError("Invalid PNG signature")
    if digest_data(data) != record["sha256"]:
        raise ValueError("Exact SHA256 mismatch")
    oid = record.get("gitBlobOID")
    if oid and hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() != oid:
        raise ValueError("Git blob OID mismatch")

def write_atomic_exact(path, data, record):
    path = safe_tmp(path)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    temp = path + ".recover-" + str(os.getpid()) + "-" + str(threading.get_ident()) + ".part"
    try:
        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        try:
            view = memoryview(data)
            while view:
                written = os.write(fd, view)
                view = view[written:]
            os.fsync(fd)
        finally:
            os.close(fd)
        try:
            os.link(temp, path, follow_symlinks=False)
        except FileExistsError:
            existing, _ = read_exact(path, record["sha256"], record["bytes"])
            verify_data(existing, record)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)

def public_raw(record, git_path):
    url = "https://raw.githubusercontent.com/" + REPO + "/" + COMMIT + "/" + urllib.parse.quote(git_path, safe="/")
    last = None
    for attempt in range(1, 4):
        try:
            request = urllib.request.Request(url, headers={"User-Agent": "Codex-P51-exact-byte-recovery"})
            with urllib.request.urlopen(request, timeout=40) as response:
                data = response.read(record["bytes"] + 1)
                status = response.status
            verify_data(data, record)
            return data, {"method": "pinned-public-raw", "url": url, "httpStatus": status, "attempt": attempt}
        except urllib.error.HTTPError as exc:
            last = exc
            if exc.code in (401, 403, 404):
                break
        except Exception as exc:
            last = exc
        if attempt < 3:
            time.sleep(attempt * 0.4)
    raise RuntimeError("Public raw failed: " + str(last))

def github_blob(record):
    endpoint = "repos/" + REPO + "/git/blobs/" + record["gitBlobOID"]
    last = None
    for attempt in range(1, 4):
        try:
            completed = subprocess.run(
                ["gh", "api", "--method", "GET", endpoint],
                capture_output=True, timeout=50, check=False)
            if completed.returncode:
                raise RuntimeError("GitHub blob GET returned nonzero exit " + str(completed.returncode))
            payload = json.loads(completed.stdout)
            if payload.get("encoding") != "base64" or payload.get("truncated"):
                raise ValueError("Invalid or truncated blob payload")
            data = base64.b64decode(payload["content"], validate=False)
            verify_data(data, record)
            return data, {"method": "github-api-exact-blob-base64", "gitBlobOID": record["gitBlobOID"], "attempt": attempt}
        except Exception as exc:
            last = exc
        if attempt < 3:
            time.sleep(attempt * 0.4)
    raise RuntimeError("Exact blob GET failed after three attempts: " + str(last))

def recover(record):
    sha = record["sha256"]
    destination = record["recoveredPath"]
    failures = []
    for candidate in [destination, record.get("source")]:
        if not candidate:
            continue
        try:
            data, source_read = read_exact(candidate, sha, record["bytes"])
            verify_data(data, record)
            if candidate != destination:
                write_atomic_exact(destination, data, record)
            return {
                "sha256": sha, "bytes": len(data), "gitBlobOID": record.get("gitBlobOID"),
                "selected": record["selected"], "portablePath": record.get("portablePath"),
                "path": destination, "method": "existing-owned-tmp" if candidate == destination else "existing-source-noatime",
                "readProof": source_read, "priorRouteFailures": failures,
                "sha256Verified": True, "gitBlobOIDVerified": True,
            }
        except FileNotFoundError:
            pass
        except Exception as exc:
            failures.append({"route": "existing-source", "path": candidate, "error": str(exc)})
    for git_path in record.get("gitPaths", []):
        try:
            data, receipt = public_raw(record, git_path)
            write_atomic_exact(destination, data, record)
            return {
                "sha256": sha, "bytes": len(data), "gitBlobOID": record.get("gitBlobOID"),
                "selected": record["selected"], "portablePath": record.get("portablePath"),
                "path": destination, **receipt, "priorRouteFailures": failures,
                "sha256Verified": True, "gitBlobOIDVerified": True,
            }
        except Exception as exc:
            failures.append({"route": "pinned-public-raw", "gitPath": git_path, "error": str(exc)})
    data, receipt = github_blob(record)
    write_atomic_exact(destination, data, record)
    return {
        "sha256": sha, "bytes": len(data), "gitBlobOID": record.get("gitBlobOID"),
        "selected": record["selected"], "portablePath": record.get("portablePath"),
        "path": destination, **receipt, "priorRouteFailures": failures,
        "sha256Verified": True, "gitBlobOIDVerified": True,
    }

def add_alias(path, sha, reason):
    if not path or not isinstance(path, str) or not path.startswith(N + "/"):
        return
    path = safe_tmp(path)
    if path in ALIASES and ALIASES[path]["sha256"] != sha:
        raise ValueError("Conflicting metadata SHAs for " + path)
    item = ALIASES.setdefault(path, {"sha256": sha, "reasons": []})
    if reason not in item["reasons"]:
        item["reasons"].append(reason)

def save_json(path, obj):
    temp = path + ".part"
    with open(temp, "w") as handle:
        json.dump(obj, handle, indent=2, ensure_ascii=False)
    os.replace(temp, path)

os.makedirs(PUB, exist_ok=True)
index_data, _ = read_exact(INDEX)
index = json.loads(index_data)
selected = index["records"]
records = {}
for source_record in selected:
    record = dict(source_record)
    portable = record["portablePath"]
    if portable.startswith("/") or ".." in pathlib.PurePosixPath(portable).parts:
        raise ValueError("Unsafe portable path")
    record.update(selected=True, recoveredPath=safe_tmp(PORTABLE + "/" + portable), gitPaths=[PREFIX + portable])
    records[record["sha256"]] = record
    if record["source"].startswith(N + "/"):
        add_alias(record["source"], record["sha256"], "selected-index-record.source")

parent_tree = json.load(open(N + "/p51/publication/PARENT_FULL_GIT_TREE_PRIVATE_V1.json"))["tree"]
git_paths = collections.defaultdict(list)
for item in parent_tree:
    if item["type"] == "blob":
        git_paths[item["sha"]].append(item["path"])

metadata_paths = [INDEX]
registration_paths = []
for root in [N + "/catalog", N + "/p50/catalog", N + "/p51/catalog"]:
    registration_paths.extend(glob.glob(root + "/receipts/generation/*.registration.json"))
for path in registration_paths:
    metadata_paths.append(path)
    registration = json.load(open(path))
    src = registration.get("source", {})
    sha = src.get("sha256")
    if not sha:
        UNMAPPED.append({"metadata": path, "reason": "Registration lacks source SHA256"})
        continue
    if sha not in records:
        record = {k: src[k] for k in ("bytes", "sha256", "gitBlobOID")}
        record.update(source=src.get("path"), selected=False,
                      recoveredPath=PUB + "/recovered-registration-pngs/" + sha + ".png",
                      gitPaths=git_paths.get(src["gitBlobOID"], []))
        records[sha] = record
    add_alias(registration.get("canonicalPath"), sha, "recorded-registration.canonicalPath")
    relative = registration.get("relativePath")
    if relative and not relative.startswith("/") and ".." not in pathlib.PurePosixPath(relative).parts:
        for root in [N + "/catalog", N + "/p50/catalog", N + "/p51/catalog"]:
            add_alias(root + "/" + relative, sha, "registration-relativePath-compatible-catalog-root")

manifest_paths = glob.glob(CAT + "/manifest*.json")
manifest_asset_entries = 0
for path in manifest_paths:
    metadata_paths.append(path)
    manifest = json.load(open(path))
    entries = manifest.get("entries", []) if isinstance(manifest, dict) else manifest
    for entry in entries:
        src = entry.get("source", {})
        if not src:
            continue
        sha = src.get("sha256")
        if sha not in records:
            UNMAPPED.append({"metadata": path, "uid": entry.get("uid"), "src": src.get("src"),
                             "sha256": sha, "reason": "Manifest source SHA missing from available exact source records"})
            continue
        raw_src = src.get("src")
        if raw_src and not raw_src.startswith(("https://", "http://")):
            relative = raw_src.lstrip("/")
            if ".." in pathlib.PurePosixPath(relative).parts:
                raise ValueError("Unsafe manifest source path")
            add_alias(CAT + "/" + relative, sha, "P51-manifest.source.src")
            manifest_asset_entries += 1
        add_alias(src.get("localPath"), sha, "P51-manifest.source.localPath")

metadata_before = {path: digest_data(read_exact(path)[0]) for path in sorted(set(metadata_paths))}
queue = sorted(records.values(), key=lambda r: (not r["sha256"].startswith("5f12"), not r["selected"]))
save_json(PROGRESS, {"atUTC": now(), "phase": "recovering", "expectedSelected": len(selected),
                     "expectedExtraRegistrationPNGs": len(records)-len(selected), "completed": 0, "missing": 0})
print(json.dumps({"phase": "start", "selectedPNGs": len(selected), "selectedBytes": sum(r["bytes"] for r in selected),
                  "extraRegistrationPNGs": len(records)-len(selected), "aliasPaths": len(ALIASES),
                  "manifestSourceEntryCount": manifest_asset_entries, "maxWorkers": MAX_WORKERS,
                  "unmappedMetadata": UNMAPPED}), flush=True)
last_progress = time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
    futures = {pool.submit(recover, record): record for record in queue}
    for future in concurrent.futures.as_completed(futures):
        record = futures[future]
        try:
            result = future.result()
            RESULTS.append(result)
            COUNTS[result["method"]] += 1
            COUNTS["validatedBytes"] += result["bytes"]
            COUNTS["completed"] += 1
            COUNTS["selectedCompleted" if result["selected"] else "extraRegistrationCompleted"] += 1
            if result["sha256"].startswith("5f12"):
                add_alias(record.get("source"), result["sha256"], "priority-Virgil-source")
                source_alias = record.get("source")
                if source_alias and source_alias.startswith(N + "/"):
                    os.makedirs(os.path.dirname(source_alias), exist_ok=True)
                    try:
                        os.link(result["path"], source_alias, follow_symlinks=False)
                    except FileExistsError:
                        read_exact(source_alias, result["sha256"], result["bytes"])
                print(json.dumps({"phase": "priority-source-ready", "sha256": result["sha256"],
                                  "path": result["path"], "sourceAlias": source_alias}), flush=True)
        except Exception as exc:
            ERRORS.append({"sha256": record["sha256"], "selected": record["selected"],
                           "path": record["recoveredPath"], "error": str(exc)})
            COUNTS["failed"] += 1
        if COUNTS["completed"] % 50 == 0 or time.time() - last_progress >= 35:
            progress = {"atUTC": now(), "phase": "recovering", "elapsedSeconds": round(time.time()-START, 2),
                        "expectedSelected": len(selected), "expectedExtraRegistrationPNGs": len(records)-len(selected),
                        "counts": dict(COUNTS), "missing": len(ERRORS)}
            save_json(PROGRESS, progress)
            print(json.dumps(progress), flush=True)
            last_progress = time.time()

by_sha = {item["sha256"]: item for item in RESULTS}
alias_results = []
inode_cache = {}
def validated_path(path, sha, size):
    info = os.stat(path, follow_symlinks=False)
    inode = (info.st_dev, info.st_ino)
    if inode not in inode_cache:
        data, _ = read_exact(path, sha, size)
        inode_cache[inode] = (sha, len(data))
    if inode_cache[inode] != (sha, size):
        raise ValueError("Alias inode exact content mismatch")
    return info

for path, alias in sorted(ALIASES.items()):
    sha = alias["sha256"]
    if sha not in by_sha:
        ERRORS.append({"path": path, "sha256": sha, "error": "Alias source not recovered"})
        continue
    result = by_sha[sha]
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        created = False
        try:
            os.link(result["path"], path, follow_symlinks=False)
            created = True
        except FileExistsError:
            pass
        info = validated_path(path, sha, result["bytes"])
        source_info = os.stat(result["path"], follow_symlinks=False)
        alias_results.append({"path": path, "sha256": sha, "bytes": result["bytes"],
                              "created": created, "hardlinkToOwnedTMP": (info.st_dev, info.st_ino) == (source_info.st_dev, source_info.st_ino),
                              "reasons": alias["reasons"], "validated": True})
    except Exception as exc:
        ERRORS.append({"path": path, "sha256": sha, "error": str(exc)})

for result in RESULTS:
    try:
        validated_path(result["path"], result["sha256"], result["bytes"])
    except Exception as exc:
        ERRORS.append({"path": result["path"], "sha256": result["sha256"], "error": str(exc)})

metadata_changed = []
for path, expected in metadata_before.items():
    if digest_data(read_exact(path)[0]) != expected:
        metadata_changed.append(path)

selected_results = [result for result in RESULTS if result["selected"]]
extra_results = [result for result in RESULTS if not result["selected"]]
report = {
    "schema": "cqc.p52.p51-exact-png-recovery/1", "atUTC": now(), "reviewer": "static_artist_c",
    "pinnedRepository": REPO, "pinnedCommit": COMMIT, "sourceIndex": INDEX,
    "sourceIndexSHA256": digest_data(index_data), "expectedSelectedPNGs": len(selected),
    "expectedSelectedBytes": sum(record["bytes"] for record in selected),
    "selectedPNGsRecovered": len(selected_results), "selectedBytesValidated": sum(r["bytes"] for r in selected_results),
    "extraRegistrationPNGsRecovered": len(extra_results), "extraRegistrationBytesValidated": sum(r["bytes"] for r in extra_results),
    "aliasPathsExpected": len(ALIASES), "aliasPathsValidated": len(alias_results),
    "aliasHardlinksToOwnedTMP": sum(r["hardlinkToOwnedTMP"] for r in alias_results),
    "P51ManifestSourceEntriesChecked": manifest_asset_entries, "registrationFilesInspected": len(registration_paths),
    "metadataFilesCompared": len(metadata_before), "metadataFilesModified": metadata_changed,
    "missing": len(ERRORS) + len(UNMAPPED), "errors": ERRORS, "unmappedMetadata": UNMAPPED,
    "counts": dict(COUNTS), "maxWorkers": MAX_WORKERS, "elapsedSeconds": round(time.time()-START, 2),
    "sourceReadsNoAtime": True, "sourceReadsNoFollow": True, "sourcePixelsModified": False,
    "imageEdits": 0, "workspaceFilesWritten": 0, "GitRefsModified": 0, "indexManifestRegistrationsModifiedByRecovery": 0,
    "sourcePNGsDeleted": 0, "sourceDocsDeleted": 0,
    "records": sorted(RESULTS, key=lambda r: r["sha256"]), "aliases": alias_results,
}
save_json(REPORT, report)
save_json(PROGRESS, {key: value for key, value in report.items() if key not in ("records", "aliases")})
print(json.dumps({key: value for key, value in report.items() if key not in ("records", "aliases")}), flush=True)
if report["missing"] or metadata_changed:
    raise SystemExit(2)

