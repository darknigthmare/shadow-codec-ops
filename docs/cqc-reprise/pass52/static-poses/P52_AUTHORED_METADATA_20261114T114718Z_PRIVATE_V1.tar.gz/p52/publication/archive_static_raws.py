"""Preserve new static-pose PNGs in immutable Git blobs with whole binary readback."""
import base64,hashlib,json,os,pathlib,subprocess,tempfile,sys
N=pathlib.Path('/tmp/cqc-static-20261113');OUT=N/'p52/publication';REPO='darknigthmare/shadow-codec-ops'
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
def api(endpoint,payload=None):
 args=['gh','api','repos/'+REPO+'/'+endpoint];tmp=None
 try:
  if payload is not None:
   with tempfile.NamedTemporaryFile(mode='w',dir=OUT,suffix='.json',delete=False)as f:json.dump(payload,f);tmp=f.name
   args+=['--method','POST','--input',tmp]
  r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
  if r.returncode:raise RuntimeError(r.stderr.decode()[:1200])
  return json.loads(r.stdout)
 finally:
  if tmp:os.unlink(tmp)
paths=[pathlib.Path(x).resolve(strict=True)for x in sys.argv[1:]]if len(sys.argv)>1 else sorted(p for p in (N/'artists').rglob('*.png')if '-raw-v' in p.name and 'p52' in p.parts)
rows=[]
for p in paths:
 assert p.is_relative_to(N/'artists')and '-raw-v'in p.name and 'p52'in p.parts
 before=p.stat();raw=read(p);after=p.stat();assert before==after and raw[:8]==b'\x89PNG\r\n\x1a\n'and len(raw)<12*1024*1024
 assert raw[-12:]==b'\x00\x00\x00\x00IEND\xaeB\x60\x82','PNG not fully copied yet'
 digest=hashlib.sha256(raw).hexdigest();oid=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();receipt=OUT/(digest+'-RAW_BLOB_READBACK_PRIVATE_V1.json')
 if receipt.exists():
  old=json.loads(read(receipt));assert old['gitBlobOID']==oid and old['exactReadback']
 else:
  created=api('git/blobs',{'content':base64.b64encode(raw).decode(),'encoding':'base64'});assert created['sha']==oid
  got=api('git/blobs/'+oid);assert got['encoding']=='base64'and base64.b64decode(got['content'])==raw
  r={'schema':'cqc.static-pose.exact-raw-git-blob/1','path':str(p),'bytes':len(raw),'sha256':digest,'gitBlobOID':oid,'exactReadback':True,'runtimeAdmission':False,'status':'RAW_SOURCE_ONLY_REVIEW_STAGES_SEPARATE'};receipt.write_text(json.dumps(r,indent=2)+'\n')
 gitpath='docs/cqc-reprise/pass52/static-poses/'+p.relative_to(N).as_posix();rows.append({'path':gitpath,'mode':'100644','type':'blob','sha':oid,'bytes':len(raw),'sha256':digest,'localPath':str(p)})
 print(json.dumps({'file':p.name,'sha256':digest,'exactGitReadback':True}),flush=True)
(OUT/'RAW_CURRENT_TREE_INPUT_PRIVATE_V1.json').write_text(json.dumps({'schema':'cqc.static-pose.raw-tree-input/1','rows':rows,'allWholeBinaryReadbacksExact':True,'referencesMoved':False},indent=2)+'\n');print('PASS_RAW_SOURCE_BLOBS',len(rows),flush=True)
