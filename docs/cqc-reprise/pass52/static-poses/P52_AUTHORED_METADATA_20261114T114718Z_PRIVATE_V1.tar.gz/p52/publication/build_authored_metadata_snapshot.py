"""Preserve authored metadata and code, with exact archive readback."""
from pathlib import Path
import os,json,hashlib,datetime,tarfile,gzip,io,re
N=Path('/tmp/cqc-static-20261113');P=N/'p52';OUT=P/'delivery';OUT.mkdir(exist_ok=True)
def exact(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
rows=[];skipped=[]
roots=[P]+[p/'p52'for p in(N/'artists').iterdir()if p.is_dir()and(p/'p52').exists()]
required_global_dependencies=[N/'inventory/STATIC_ALL381_CATALOG_COMPACT_PUBLIC_V1.json',N/'official/OFFICIAL_COSTUMES_416_CURRENT_RECONCILIATION_PRIVATE_V1.json',N/'dispatch/HOLD_GUARDS_CURRENT_PUBLIC_V1.json',N/'artists/e/composites/ORIGINAL24_REFERENCE_INDEX_PRIVATE_V1.json']
assert all(p.is_file()for p in required_global_dependencies),'Required global snapshot dependency missing.'
for root in roots+required_global_dependencies:
 for p in([root]if root.is_file()else root.rglob('*')):
  if not p.is_file()or any('profile'in q or q in['__pycache__','node_modules','vendor','.git','pydeps']for q in p.parts)or p.name.startswith('tmp'):continue
  ext=p.suffix.lower();own=False
  if ext in['.json','.csv']:own='PRIVATE'in p.name or'PUBLIC'in p.name or ext=='.json'and(p.name in['manifest.json','manifest-all381.json']or p.is_relative_to(P/'catalog')or p.is_relative_to(P/'publication/metadata-pin-history'))
  elif ext in['.py','.mjs','.js','.css']:own=True
  elif ext=='.html':own=p.name=='index.html'and p.parent.name in['catalog','catalogue']
  elif ext=='.md':own=p.name.lower()in['readme.md','lire_moi.md']
  elif ext=='.txt':own='prompt'in p.name.lower()or p.name=='LIRE_MOI.txt'
  if not own or p.stat().st_size>30*1024*1024:continue
  raw=exact(p)
  if re.search(rb'data:image/[a-zA-Z0-9+.-]+;base64,[A-Za-z0-9+/=]{256,}',raw):skipped.append(str(p.relative_to(N)));continue
  if ext=='.json':json.loads(raw)
  rows.append((p.relative_to(N).as_posix(),raw))
assert all(p.relative_to(N).as_posix()in{n for n,_ in rows}for p in required_global_dependencies),'Required global snapshot dependency excluded.'
manifest={'schema':'cqc.p52.authored-source-metadata-snapshot/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':'93aa7663cfe0b4293db37fe7ab62ca85bc2434e8','scope':'Authored contracts, frame metadata, source provenance, inventories, source-only code and review. Exact PNGs are preserved separately in Git. Full third-party books, videos, binary packages and web payloads excluded.','files':[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}for n,b in rows],'skippedEmbeddedPayloads':skipped}
rows.append(('P52_COMPLETE_METADATA_MANIFEST_PRIVATE_V1.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode()))
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');target=OUT/('P52_AUTHORED_METADATA_'+stamp+'_PRIVATE_V1.tar.gz')
with target.open('xb')as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0,compresslevel=6)as gz:
  with tarfile.open(fileobj=gz,mode='w|')as archive:
   for name,raw in rows:
    info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o600;archive.addfile(info,io.BytesIO(raw))
with tarfile.open(target,'r:gz')as archive:
 assert len(archive.getmembers())==len(rows)
 for member,(name,raw)in zip(archive.getmembers(),rows):assert member.name==name and archive.extractfile(member).read()==raw
assert any(n=='p52/publication/build_authored_metadata_snapshot.py'for n,_ in rows)
r={'path':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(exact(target)).hexdigest(),'filesReadBackExact':len(rows),'pixelsEdited':False,'includesSnapshotBuilderSource':True};(P/'publication/LATEST_AUTHORED_METADATA_SNAPSHOT_PRIVATE_V1.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
