#!/usr/bin/env python3
"""P52 selected-pose delta versus frozen P51, never versus the older P49 catalogue."""
from pathlib import Path
import argparse
import collections
import datetime
import hashlib
import json
import os

N=Path('/tmp/cqc-static-20261113');P=N/'p52'

def exact(path):
    with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb') as stream:
        before=os.fstat(stream.fileno());raw=stream.read();after=os.fstat(stream.fileno())
    assert before==after and path.stat()==before
    return raw

def key(entry): return entry['uid'],entry['costumeId']
def present(entry): return bool(entry.get('source') and entry.get('frame',{}).get('rect'))
def guard_key(entry): return entry['uid'],entry.get('costumeId',entry.get('costumeID',entry.get('family')))

def compute(current,baseline,mapping,baseline_map,official_guards,resume):
    old={key(e):e for e in baseline['entries']}; assert len(old)==len(baseline['entries']),'Duplicate baseline entry keys'
    selected=[e for e in current['entries'] if present(e)]
    baseline_shas={e['source']['sha256'] for e in baseline['entries'] if present(e)}
    signature=lambda e:((e.get('source')or{}).get('sha256'),e.get('frame'))
    changed=[e for e in selected if signature(e)!=signature(old.get(key(e),{}))]
    current_by={key(e):e for e in current['entries']};assert len(current_by)==len(current['entries']),'Duplicate current entry keys'
    changed_prior=[{'uid':k[0],'costumeId':k[1]}for k,e in old.items()if present(e)and signature(e)!=signature(current_by.get(k,{}))]
    new=[e for e in changed if e['source'].get('kind')=='generated-atlas'
         and e['source']['sha256'] not in baseline_shas]
    pose=lambda e:(e['source']['sha256'],tuple(e['frame']['rect']))
    current_uids={e['uid'] for e in current['entries']};baseline_uids={e['uid'] for e in baseline['entries']}
    starting={r['historicalID'] for r in baseline_map['rows']
              if r['resolutionState']=='REFERENCE_AND_STATIC_SOURCE_PENDING' and not r.get('p50RelatedDistinctIncarnation')}
    by={r['historicalID']:r for r in mapping['rows']};assert len(by)==len(mapping['rows'])==416
    assert starting<=set(by);assert len(starting)==resume['startingActualMissing']
    quiet=by.get('core__quiet__alt__arrival_cloak',{})
    if quiet.get('resolutionState')=='P52_EXISTING_SAME_UID_APPEARANCE_REUSED':
        assert quiet.get('p52LabelCorrection')and quiet.get('p52AliasProof',{}).get('correctedHistoricalLabel')==quiet.get('historicalCostumeName'),'Quiet arrival reuse requires explicit label correction'
    groups=collections.defaultdict(list)
    for hid in sorted(starting):
        row=by[hid];state=row['resolutionState']
        group=('remainingReferenceRows' if state=='REFERENCE_AND_STATIC_SOURCE_PENDING' else
               'guardedOfficialRows' if 'REFUSED' in state or 'GUARD' in state else
               'sourceRowsWithCorrectionPending' if 'CORRECTION_PENDING' in state else
               'exactSameUIDAliases' if state.startswith('P52_') and 'REUSED' in state else
               'newSourceRows' if state.startswith('P52_') and row.get('newSource') else 'unclassifiedRows')
        groups[group].append(hid)
    assert not groups['unclassifiedRows'], 'Unexpected P52 progress states: '+str(groups['unclassifiedRows'])
    progress={name:len(groups[name]) for name in ('newSourceRows','sourceRowsWithCorrectionPending','exactSameUIDAliases','guardedOfficialRows','remainingReferenceRows')}
    progress.update(startingPending=len(starting),remainingUnproducedReferenceRows=progress['remainingReferenceRows'],
                    historicalEraSplitRowsAlreadyDrawnInP50=sum(bool(r.get('p50RelatedDistinctIncarnation'))for r in baseline_map['rows']),newAnimations=0,gameplayAdmissions=0)
    assert sum(progress[n]for n in groups if n!='unclassifiedRows')==len(starting)
    baseline_guards={guard_key(e) for e in baseline['entries'] if e.get('generationGuard')}
    manifest_guards={guard_key(e) for e in current['entries'] if e.get('generationGuard')}
    registry_guards={guard_key(g) for g in official_guards.get('entries',[])}
    cumulative_guards=baseline_guards|registry_guards;new_guards=cumulative_guards-baseline_guards
    old_aliases=[r for r in baseline_map['rows'] if r['resolutionState']in('P50_EXISTING_SAME_UID_APPEARANCE_REUSED','P51_EXISTING_SAME_UID_APPEARANCE_REUSED')]
    warnings=[]
    if changed_prior:warnings.append('Des sources ou cadrages antérieurs ont changé ; vérifier la conservation de la base P51 avant publication finale.')
    if manifest_guards!=cumulative_guards:warnings.append('Le catalogue et le registre exact des gardes ne sont pas encore synchronisés ; recalcul requis après actualisation par Root.')
    if current_uids!=baseline_uids:warnings.append('Le roster diffère de la base P51 figée ; vérification requise avant publication finale.')
    if progress['guardedOfficialRows']!=sum(g['historicalID']in starting for g in official_guards.get('entries',[])):
        warnings.append('Le rapprochement historique ne reprend pas encore toutes les nouvelles gardes officielles.')
    label_corrections=[{'historicalID':r['historicalID'],'previousLabel':r.get('historicalCostumeNameBeforeP52'),'correctedLabel':r.get('historicalCostumeName'),'reason':r['p52LabelCorrection']}for r in mapping['rows']if r.get('p52LabelCorrection')]
    return {'schema':'cqc.p52.delivery-metrics/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope':'P52: one static RIGHT pose per qualified remaining official costume. Delta measured against frozen published P51 manifest, including its existing XOF1984 Original. Prior raw versions retained; no animation/runtime change.',
        'characters':len(current_uids),'baselineCharacters':len(baseline_uids),'originalMatrixRosterUIDs':baseline['baselineRosterUIDs'],'plannedMatrixRows':baseline['baselineMatrixRows'],
        'newRosterUIDsSinceP51':sorted(current_uids-baseline_uids),
        'additionalDistinctIncarnations':len({r['uid']for r in current.get('additionalDistinctIncarnations',[])}),
        'newAdditionalDistinctIncarnationsSinceP51':len(current_uids-baseline_uids),
        'existingHospitalXOF1984Retained':'archive__xof_hospital_1984'in current_uids and'archive__xof_hospital_1984'in baseline_uids,
        'newUIDCostumePosesSinceP51':len(new),'newDistinctPhysicalPosesSinceP51':len({pose(e)for e in new}),
        'newDistinctPhysicalPNGsSinceP51':len({e['source']['sha256']for e in new}),
        'newSelectedPoseEntriesSinceP51':[dict(uid=e['uid'],character=e.get('character',e['uid']),incarnation=e.get('incarnation'),costumeId=e['costumeId'],costume=e.get('costume',e['costumeId']),sourceSHA256=e['source']['sha256'],sourceRect=e['frame']['rect'])for e in new],
        'newP52SameUIDReuseRows':[{'historicalID':by[hid]['historicalID'],'uid':by[hid].get('targetUID',by[hid].get('historicalUID')),'label':by[hid].get('historicalCostumeName'),'targetCostumeID':by[hid].get('targetCostumeID'),'reason':by[hid].get('resolutionReason')}for hid in groups['exactSameUIDAliases']],
        'newOfficialPoseEntriesSinceP51':sum(e.get('family')=='canonical'for e in new),
        'newOriginalCorrectionsSinceP51':sum(e.get('family')=='original'and key(e)in old for e in new),
        'changedSourcedEntryMappingsSinceP51':len(changed),
        'reusedBaselineSourceMappingsSinceP51':sum(e['source']['sha256']in baseline_shas for e in changed),
        'baselineManifestSourceFramesPreservedExact':not changed_prior,
        'priorSelectedSourceFrames':sum(present(e)for e in baseline['entries']),
        'changedPriorSourceFramesSinceP51':changed_prior,
        'sourceVersionPolicy':'Only selected newly drawn physical poses counted here. Superseded/raw versions and all prior PNGs remain preserved and are not multiplied into the drawing count.',
        'officialHistoricalP52Progress':progress,'explicitHistoricalLabelCorrections':label_corrections,'officialHistoricalCurrentCounts':dict(collections.Counter(r['resolutionState']for r in mapping['rows'])),
        'p50SummaryPreserved':mapping.get('p50Summary',{}),'p51SummaryPreserved':mapping.get('p51Summary',{}),
        'existingBaselineSameUIDAliases':len(old_aliases),
        'existingBaselineSameUIDAliasesRetained':sum(by[r['historicalID']]['resolutionState']==r['resolutionState']for r in old_aliases),
        'existingP50SameUIDAliases':sum(r['resolutionState'].startswith('P50_')for r in old_aliases),
        'existingP51SameUIDAliases':sum(r['resolutionState'].startswith('P51_')for r in old_aliases),
        'newP52SameUIDAliases':progress['exactSameUIDAliases'],
        'cumulativeP50P51P52SameUIDAliases':len(old_aliases)+progress['exactSameUIDAliases'],
        'cumulativeGenerationGuardScopes':len(cumulative_guards),'baselineP51GenerationGuardScopes':len(baseline_guards),
        'newGenerationGuardScopesSinceP51':len(new_guards),'canonicalOfficialGuardRows':len(registry_guards),
        'manifestGenerationGuardScopes':len(manifest_guards),'exactGuardRegistrySynchronized':manifest_guards==cumulative_guards,
        'allPoseEntriesPresent':len(selected),'sameOriginalFamilyAliases':len(current.get('aliasesCoveredByOriginal',[])),
        'notApplicableRows':len(current.get('notApplicableExcluded',[])),
        'sourceKinds':dict(collections.Counter(e['source']['kind']for e in selected)),
        'guardedEntries':[{k:e.get(k)for k in('uid','costumeId','family','generationGuard')}for e in current['entries']if e.get('generationGuard')],
        'officialRemainingWithoutSource':[{k:by[hid].get(k)for k in('historicalID','historicalCostumeName','historicalUID','resolutionReason')}for hid in groups['remainingReferenceRows']],
        'historicalPeriodErrorsWithExistingSeparateOriginal':[{k:r.get(k)for k in('historicalID','historicalCostumeName','historicalUID','p50RelatedDistinctIncarnation')}for r in baseline_map['rows']if r.get('p50RelatedDistinctIncarnation')],
        'snapshotWarnings':warnings,'newAnimations':0,'runtimeFilesModified':0,'manualVercelDeployments':0,'fidelityCertifiedPixelPerfect':False}

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--dry-run',action='store_true');args=parser.parse_args()
    pins=[]
    def load(path):
        raw=exact(path);pins.append({'path':str(path),'sha256':hashlib.sha256(raw).hexdigest()});return json.loads(raw)
    result=compute(load(P/'catalog/manifest-all381.json'),load(P/'base/manifest-all381.json'),
        load(P/'official/OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json'),
        load(P/'base/OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json'),
        load(P/'official/P52_EXACT_COSTUME_GENERATION_GUARDS_PRIVATE_V1.json'),load(P/'P52_RESUME_PRIVATE_V1.json'))
    result['inputPins']=pins
    portable=P/'publication/PORTABLE_STATIC_CATALOG_SOURCE_INDEX_PRIVATE_V1.json'
    if portable.exists():
        q=load(portable);result['portableCatalogue']={k:q.get(k)for k in('entries','uniquePNGs','bytesUniquePNGs','atUTC')}
    proof=P/'delivery/P52_TRACKING_BUILD_READBACK_PRIVATE_V1.json'
    if proof.exists():
        q=load(proof);output=Path(q['output']);source=Path(q['sourceWorkbook'])
        assert hashlib.sha256(exact(output)).hexdigest()==q['sha256'],'Workbook proof stale.'
        assert hashlib.sha256(exact(source)).hexdigest()==q['sourceWorkbookSHA256'],'Baseline workbook proof stale.'
        result['workbook']={k:q.get(k)for k in('oldSheets','newSheets','oldSheetsAndUnchangedZipMembersPreservedExact','sha256','bytes')}
        result['workbook']['totalSheets']=q['oldSheets']+q['newSheets']
    else: result['workbook']={'proofAvailable':False}
    final=P/'delivery/P52_FINAL_VERIFICATION_PUBLIC_V1.json'
    if final.exists():
        q=load(final);manifest_pin=next(r for r in pins if r['path']==str(P/'catalog/manifest-all381.json'))
        result['finalVerification']={'status':q.get('status'),'mode':q.get('mode'),'inputSnapshotStable':q.get('inputSnapshotStable'),
            'errorCount':q.get('errorCount'),'matchesCurrentManifest':q.get('manifestSHA256')==manifest_pin['sha256'],
            'finalFreezeClaimed':q.get('finalFreezeClaimed',False)}
    assert all(hashlib.sha256(exact(Path(pin['path']))).hexdigest()==pin['sha256']for pin in pins),'Inputs changed during metrics; rerun.'
    if not args.dry_run:
        target=P/'delivery/P52_LIVRAISON_POSES_UNIQUES_PUBLIC_V1.json';temp=target.with_suffix('.json.tmp')
        temp.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');temp.replace(target)
    summary_keys=('schema','characters','baselineCharacters','originalMatrixRosterUIDs','plannedMatrixRows','newRosterUIDsSinceP51','newDistinctPhysicalPosesSinceP51','newDistinctPhysicalPNGsSinceP51','newOriginalCorrectionsSinceP51','reusedBaselineSourceMappingsSinceP51','baselineManifestSourceFramesPreservedExact','officialHistoricalP52Progress','existingBaselineSameUIDAliases','existingP50SameUIDAliases','existingP51SameUIDAliases','newP52SameUIDAliases','newSelectedPoseEntriesSinceP51','newP52SameUIDReuseRows','cumulativeGenerationGuardScopes','baselineP51GenerationGuardScopes','newGenerationGuardScopesSinceP51','exactGuardRegistrySynchronized','sourceKinds','snapshotWarnings')
    print(json.dumps(dict(dryRun=args.dry_run,**{k:result[k]for k in summary_keys}),ensure_ascii=False))

if __name__=='__main__': main()
