import os,json,hashlib,datetime,copy
from pathlib import Path
Q=Path(__file__).resolve().parent;CAT=Q.parent.parent.parent
def read(path):
 with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
base=json.loads(read(Q/'BASE_REPORT_FROZEN_PRIVATE_V1.json'));current=json.loads(read(CAT/'P50_NEW_SOURCE_FRAME_QA_PRIVATE_V1.json'));assert current['corrections'][:41]==base['corrections']
quant=json.loads(read(Q/'QUANTITATIVE_FRAME_AUDIT_PRIVATE_V1.json'));snap=json.loads(read(Q/'PROPOSAL_SNAPSHOT_PRIVATE_V1.json'));inc=json.loads(read(Q/'INCREMENT_CORRECTIONS_PRIVATE_V1.json'));browser=json.loads(read(Q/'BROWSER_CORRECTED_PLACEMENT_ACTUAL_PRIVATE_V1.json'));copies=json.loads(read(Q/'QA_COPY_RECEIPTS_PRIVATE_V1.json'));rawindex=read(CAT/'ACTIVE_ARTIST_REGISTRATIONS_PRIVATE_V1.json');active=json.loads(rawindex)
assert len(browser['rendered'])==len(inc['corrections']);assert all(r['placement']['x']>=14-1e-6 and r['placement']['x']+r['placement']['width']<=306+1e-6 for r in browser['rendered'])
verified=[]
for p in snap:
 before=os.stat(p['png']);sha=hashlib.sha256(read(p['png'])).hexdigest();after=os.stat(p['png']);assert sha==p['sha'];assert (before.st_atime_ns,before.st_mtime_ns,before.st_ctime_ns)==(after.st_atime_ns,after.st_mtime_ns,after.st_ctime_ns);assert hashlib.sha256(read(p['proposal'])).hexdigest()==p['proposalSHA256'];verified.append({'source':p['png'],'sourceSHA256':sha,'sourceBytes':before.st_size,'statsUnchangedByVerification':True})
out=copy.deepcopy(current);out['atUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();correctionkeys={(c['uid'],c['costumeId'],c['sourceSHA256']):c for c in current['corrections']}
for correction in inc['corrections']:
 key=correction['uid'],correction['costumeId'],correction['sourceSHA256']
 if key in correctionkeys:assert correctionkeys[key]==correction,('Existingcorrectionchanged',key)
 else:out['corrections'].append(correction)
assert out['corrections'][:41]==base['corrections']
sources=[{'uid':p['uid'],'path':p['png'],'sha256':p['sha'],'proposalPath':p['proposal'],'proposalSHA256':p['proposalSHA256'],'width':p['dimensions'][0],'height':p['dimensions'][1]}for p in quant['rows']]
oldSourceSHAs={p['sha256']for p in current['snapshot']['sources']};out['snapshot']['sources']=current['snapshot']['sources']+[p for p in sources if p['sha256']not in oldSourceSHAs];out['snapshot']['pages']=len(out['snapshot']['sources']);out['snapshot']['logicalSlots']=current['snapshot']['logicalSlots']+sum(len(p['slots'])for p in quant['rows']if p['sha']not in oldSourceSHAs)
activeP50=[p for p in active['pages']if '/p50/'in p['source']];activeBySHA={p['sha256']:p for p in activeP50};reviewed={s['sha256']for s in out['snapshot']['sources']};missing=[p for p in activeP50 if p['sha256']not in reviewed]
out['snapshot']['currentActivePages']=len(activeP50);out['snapshot']['currentActivePoses']=sum(len(p['activeCostumes'])for p in activeP50);out['snapshot']['activeIndexAtUTC']=active['atUTC'];out['snapshot']['activeIndexSHA256']=hashlib.sha256(rawindex).hexdigest()
extraSuperseded=[]
baseSupersededKeys={(s['uid'],s['costumeId'],s['sourceSHA256'])for s in base['supersededSlotsExcluded']}
for p in out['snapshot']['sources']:
 doc=json.loads(read(p['proposalPath']))
 for s in doc['slots']:
  uid=s.get('uid',doc['uid']);costume=s.get('costumeID',s.get('costumeId'))
  if (uid,costume,p['sha256'])in baseSupersededKeys:continue
  if p['sha256']not in activeBySHA or costume not in activeBySHA[p['sha256']]['activeCostumes']:
   extraSuperseded.append({'uid':uid,'costumeId':costume,'sourceSHA256':p['sha256'],'reason':'Replaced by a later active source for the sameUID/costume in currentRoot index. Historical source and prior review preserved; never apply its geometry to replacementPNG.','preferredActiveSHA256':next((z['sha256']for z in activeP50 if z['uid']==uid and costume in z['activeCostumes']),None)})
out['supersededSlotsExcluded']=base['supersededSlotsExcluded']+extraSuperseded;out['snapshot']['supersededSlotsExcluded']=len(out['supersededSlotsExcluded'])
out['sourceInspection']['activePosesPhysicallyViewed']=sum(len(p['activeCostumes'])for p in activeP50 if p['sha256']in reviewed)
out['sourceInspection']['fullStrongSilhouetteCutsBySourceRect']+=sum(s['mainPixelsOutsideFrame']>0 for p in quant['rows']if p['sha']not in oldSourceSHAs for s in p['slotAnalysis']if s['mainPixelsOutsideFrame']is not None);out['sourceInspection']['strongSourcePageEdgePixels']+=sum(sum(p['edgesByThreshold']['64'].values())for p in quant['rows']if p['sha']not in oldSourceSHAs)
out['pendingProposalsDiscoveredAfterSnapshot']=[p['metadataDocument']for p in missing]
out['incrementalReview']={'atUTC':out['atUTC'],'baselineSourcePages':58,'baselineCorrectionsPreserved':41,'newSourcePages':len(snap),'newActivePosesViewed':sum(len(p['slots'])for p in snap),'newCorrections':len(inc['corrections']),'newSourceRectCuts':0,'newNeighborIntersections':0,'strongSourceEdgePixels':sum(sum(p['edgesByThreshold']['64'].values())for p in quant['rows']),'actualCanvas':[320,360],'actualPlacementFunctionSource':browser['actualPlacementFunctionSource'],'correctedPosesRenderedAndPhysicallyViewed':len(browser['rendered']),'allCorrectedFramesFit14PixelHorizontalMargins':True,'sourceVerification':verified,'evidenceDirectory':str(Q),'specialReviewedNonCorrections':inc['specialReviewedNonCorrections'],'mechanicalReviewScope':'Whole silhouettes, real ground support and frame fit were inspected. Root independently compared Ballista653376 and PFrockets2bd407 to actual references and approved plausible geometry; this static framing review does not certify pixel-perfect mechanical details.','historicalScopeNote':'Delta medical VirtuousMission a52ff is an authorizedextra costume. It does not resolve archive__naked_delta__alt__prisoner_bandaged.'}
out['status']='PHYSICALLY_REVIEWED_INCREMENTAL_CORRECTIONS_READY_FOR_ROOT_IMPORT'+('_ADDITIONAL_ACTIVE_SOURCES_PENDING'if missing else '')
(CAT/'P50_NEW_SOURCE_FRAME_QA_PRIVATE_V1.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'snapshotSourcePages':out['snapshot']['pages'],'currentActivePages':len(activeP50),'currentActivePoses':out['snapshot']['currentActivePoses'],'reviewedActivePoses':out['sourceInspection']['activePosesPhysicallyViewed'],'newPages':len(snap),'newPoses':out['incrementalReview']['newActivePosesViewed'],'oldCorrectionsPreserved':41,'newCorrections':len(inc['corrections']),'totalCorrections':len(out['corrections']),'pendingActivePages':missing,'reportSHA256':hashlib.sha256(read(CAT/'P50_NEW_SOURCE_FRAME_QA_PRIVATE_V1.json')).hexdigest()}))
