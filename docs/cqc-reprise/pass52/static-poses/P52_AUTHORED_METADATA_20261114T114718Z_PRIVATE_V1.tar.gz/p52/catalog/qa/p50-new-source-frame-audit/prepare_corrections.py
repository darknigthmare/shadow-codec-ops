import json,hashlib,datetime,math
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.ndimage import label
Q=Path(__file__).resolve().parent
pages=json.loads((Q/'QUANTITATIVE_FRAME_AUDIT_PRIVATE_V1.json').read_text())['rows']
supports=json.loads((Q/'SUPPORT_CONTACTS_MEASURED_PRIVATE_V1.json').read_text())['rows']
data={(s['uid'],s['costumeId'],s['sourceSHA256']):s for s in supports}
corrections=[];checks=[]
def normalized(poly,rect):
 x,y,w,h=rect;return [[round((a-x)/w,9),round((b-y)/h,9)]for a,b in poly]
def inside_points(poly,x,y):
 inside=np.zeros(x.shape,dtype=bool)
 for k in range(len(poly)):
  x1,y1=poly[k];x2,y2=poly[(k+1)%len(poly)]
  if y1==y2:continue
  hit=((y1>y)!=(y2>y))&(x<(x2-x1)*(y-y1)/(y2-y1)+x1);inside^=hit
 return inside
for p in pages:
 for s in p['slotAnalysis']:
  if s['superseded']:continue
  key=s['uid'],s['id'],p['sha'];m=data.get(key)
  if not m:continue
  old=s['rect'];rect=list(old);body=s['bodyX'];floor=s['footY'];reason=[];poly=None
  x,y,w,h=old
  if s['uid'] in ['archive__gustava_heffner','core__ninja_mg2','core__snake_mg2']:
   l,t,r,b=s['mainComponent']['bbox'];rect=[max(0,l-3),max(0,t-3),min(p['dimensions'][0],r+3)-max(0,l-3),min(p['dimensions'][1],b+3)-max(0,t-3)]
   reason.append('Tighten metadata frame around the complete retro drawing; the full1536px source rectangle made this pose much smaller than the other human poses. Source PNG remains intact. Preserve the already reviewed two-foot support datum; merged pixel-art calves do not constitute one physical foot.')
  else:
   count=len(m['supportContactGroups']);candidate=m['candidateBodyX'];scale=min(304/h,292/w)
   if count in [2,4] and abs(candidate-body)*scale>=2:
    body=candidate
    reason.append(('Center the ground anchor between four physically viewed paws/hooves' if count==4 else 'Center the ground anchor between the two physically viewed boot/foot contacts')+' using opaque sole bands, rather than the weapon/head/tail or lower-leg bounding-box midpoint.')
   if s['uid']=='archive__dhorse' and abs(m['candidateFootY']-floor)>=2:
    floor=m['candidateFootY'];reason.append('Use the lowest genuine hoof contact, preserving the higher far hooves projected in depth; do not flatten the stance.')
  if s['uid']=='archive__ddog':
   if s['id']=='official--sneaking-suit-stun':poly=[[51,49],[741,49],[741,280],[716,300],[716,693],[51,693]]
   elif s['id']=='official--battle-dress':poly=[[746,50],[1422,50],[1422,692],[728,692],[728,300],[746,275]]
   if poly:
    reason.append('The rectangular atlas frame includes a narrow visible piece of the adjacent dog. This display-only polygon follows the empty inter-silhouette gap, preserving the complete own nose/tail/paws while excluding the neighbor; no source pixels are altered.')
    a=np.asarray(Image.open(Q/'sources'/(p['sha']+'.png')).convert('RGBA'))[:,:,3];ll,n=label(a>64,np.ones((3,3)));yy,xx=np.where(ll==s['mainComponent']['id']);lost=int((~inside_points(poly,xx+.5,yy+.5)).sum());intruded=0
    for other in s['otherLargeComponentsInFrame']:
     yy,xx=np.where(ll==other['id']);intruded+=int(inside_points(poly,xx+.5,yy+.5).sum())
    assert lost==0 and intruded==0,(s['id'],lost,intruded)
    checks.append({'uid':s['uid'],'costumeId':s['id'],'sourceSHA256':p['sha'],'ownStrongPixelsLostByClip':lost,'neighborStrongPixelsIncludedAfterClip':intruded,'beforeNeighborStrongPixels':sum(c['pixelsInFrame']for c in s['otherLargeComponentsInFrame'])})
  if not reason:continue
  x,y,w,h=rect
  row={'uid':s['uid'],'costumeId':s['id'],'sourceSHA256':p['sha'],'rect':rect,'pivot':[round((body-x)/w,9),round((floor-y)/h,9)],'footprint':{'x':body,'y':floor},'reason':' '.join(reason),'reviewer':'/root/static_catalog','sourcePath':p['png'],'proposalPath':p['proposal'],'previousFrame':{'rect':old,'pivot':[(s['bodyX']-old[0])/old[2],(s['footY']-old[1])/old[3]]},'supportContactGroups':m['supportContactGroups'],'requiresSourceSHAMatch':True,'sourcePixelsModified':False}
  if poly:row['clipPolygon']=normalized(poly,rect)
  corrections.append(row)
out={'schema':'cqc.static.p50-new-source-frame-qa/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/static_catalog','scope':'P50 new static-source proposals only; no P49 corrections modified. No generated image, source modification, index, build, map, game or Git mutation.','snapshot':{'pages':len(pages),'logicalSlots':sum(len(p['slots'])for p in pages),'supersededSlotsExcluded':sum(s['superseded']for p in pages for s in p['slotAnalysis']),'sources':[{'uid':p['uid'],'path':p['png'],'sha256':p['sha'],'proposalPath':p['proposal'],'proposalSHA256':p.get('proposalSHA256'),'width':p['dimensions'][0],'height':p['dimensions'][1]}for p in pages]},'sourceInspection':{'fullStrongSilhouetteCutsBySourceRect':0,'strongSourcePageEdgeCuts':0,'allActivePosesPhysicallyViewedInReader':True,'readerCanvas':[320,360],'placementFunction':'p50/catalog/manifest-model.mjs placement()','weakFringes':'Do not treat colored RGB under alpha0 or1 as opaque background. D-Dog red/yellow5184pixels at alpha>=1, only13at alpha>=8; all strongly colored surroundings are invisible fringes except13isolated pixels, not a large opaque backing.','specialPoses':[{'uid':'core__raiden_mgs4','costumeId':'official--epilogue-human-shell','decision':'PASS complete seated hospital-bed composition; support refers to the bed base, not concealed feet. No standing-body pivot inferred.'},{'uid':'roster50__huey_mgsv','costumeId':'official--without-exoskeleton','decision':'PASS complete kneeling pose and folded legs; preserve the reviewed kneeling support datum. No hidden foot was invented or forced into a standing footprint.'}]},'corrections':corrections,'clipValidation':checks,'drawingIssues':[],'rendererIssues':[{'id':'placement-asymmetric-pivot-horizontal-fit','severity':'visible-body-cut-in-reader','function':'p50/catalog/manifest-model.mjs placement','reason':'Width-only scale (W-28)/w assumes pivot.x=0.5; asymmetric pivots can crop a complete source silhouette outside the Canvas. Observed on D-Dog BattleDress/Fulton, D-Horse BattleDress and long D-Walker FultonBallista. Centering actual feet increases the need for proper anchor-aware fit.','recommendedScale':'min(heightScale,(W/2-14)/(px*w),(W/2-14)/((1-px)*w)) with zero-denominator guards','codeModifiedByThisAudit':False}],'evidenceDirectory':str(Q),'status':'CORRECTIONS_PROPOSED_PENDING_ROOT_IMPORT_AND_ANCHOR_AWARE_RENDERER_FIX'}
(Q.parent.parent/'P50_NEW_SOURCE_FRAME_QA_PRIVATE_V1.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'pages':len(pages),'corrections':len(corrections),'clips':len(checks),'path':str(Q.parent.parent/'P50_NEW_SOURCE_FRAME_QA_PRIVATE_V1.json')}))
