import os,json,io,hashlib,datetime
from pathlib import Path
import numpy as np
from scipy import ndimage
from PIL import Image
Q=Path(__file__).resolve().parent
snap=json.loads((Q/'PROPOSAL_SNAPSHOT_PRIVATE_V1.json').read_text());pages=[];allslots=[]
for page in snap:
 path=Q/'sources'/(page['sha']+'.png')
 with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:raw=f.read()
 assert hashlib.sha256(raw).hexdigest()==page['sha'];im=Image.open(io.BytesIO(raw)).convert('RGBA');a=np.asarray(im)[:,:,3];mask=a>64;labels,n=ndimage.label(mask,np.ones((3,3)));counts=np.bincount(labels.ravel());objects=ndimage.find_objects(labels);components=[]
 for i,sl in enumerate(objects,1):
  if sl is None or counts[i]<400:continue
  yy,xx=sl;components.append({'id':i,'pixels':int(counts[i]),'bbox':[xx.start,yy.start,xx.stop,yy.stop]})
 edges={str(t):{'top':int((a[0]>t).sum()),'bottom':int((a[-1]>t).sum()),'left':int((a[:,0]>t).sum()),'right':int((a[:,-1]>t).sum())}for t in [0,7,16,64,127,192,240]}
 p={**page,'dimensions':[im.width,im.height],'componentsAlpha64':components,'alphaZeroFraction':float((a==0).mean()),'edgesByThreshold':edges,'slotAnalysis':[]}
 for slot in page['slots']:
  x,y,w,h=slot['rect'];x,y,w,h=map(int,[x,y,w,h]);region=labels[y:y+h,x:x+w];cs=np.bincount(region.ravel(),minlength=n+1);rank=sorted(({'id':c['id'],'pixelsInFrame':int(cs[c['id']]),'componentPixels':c['pixels'],'bbox':c['bbox']}for c in components if cs[c['id']]>0),key=lambda c:c['pixelsInFrame'],reverse=True);main=rank[0]if rank else None;flags=[];support=[]
  if main:
   outside=main['componentPixels']-main['pixelsInFrame'];bb=main['bbox'];cut=[max(0,x-bb[0]),max(0,y-bb[1]),max(0,bb[2]-(x+w)),max(0,bb[3]-(y+h))]
   if outside>100 and max(cut)>2:flags.append('main-component-extends-beyond-rect')
   if any(c['pixelsInFrame']>100 for c in rank[1:]):flags.append('rect-intersects-another-large-component')
   bot=bb[3];top=max(bb[1],int(bot-(bb[3]-bb[1])*.13));low=labels[top:bot,bb[0]:bb[2]]==main['id'];ll,nn=ndimage.label(low,np.ones((3,3)));ct=np.bincount(ll.ravel());obs=ndimage.find_objects(ll)
   for k,s in enumerate(obs,1):
    if s is None or ct[k]<40:continue
    yy,xx=s;support.append({'bbox':[bb[0]+xx.start,top+yy.start,bb[0]+xx.stop,top+yy.stop],'centerX':(bb[0]+xx.start+bb[0]+xx.stop)/2,'bottomY':top+yy.stop,'pixels':int(ct[k])})
   if len(support)>1:
    centers=[r['centerX']for r in support];candidate=sum(centers)/len(centers)
    if slot['bodyX']is not None and abs(candidate-slot['bodyX'])>max(8,(bb[2]-bb[0])*.035):flags.append('body-pivot-differs-from-lower-support-mean')
   if min(bb[0],bb[1],im.width-bb[2],im.height-bb[3])<2:flags.append('strong-silhouette-reaches-page-edge')
  else:outside=None;cut=None
  r={**slot,'uid':slot['uid'],'sourceSHA256':page['sha'],'source':page['png'],'proposalPath':page['proposal'],'mainComponent':main,'otherLargeComponentsInFrame':rank[1:],'mainPixelsOutsideFrame':outside,'cutDistancesLTRY':cut,'lowerBandComponentsNotYetFeetReviewed':support,'flags':flags,'superseded':bool(slot.get('status')and'SUPERSEDED'in slot['status'])};p['slotAnalysis'].append(r);allslots.append(r)
 pages.append(p)
out={'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pages':len(pages),'slots':len(allslots),'pixelsWritten':False,'flagsAreCandidatesNotValidatedCorrections':True,'flaggedSlots':[r for r in allslots if r['flags']and not r['superseded']],'rows':pages};(Q/'QUANTITATIVE_FRAME_AUDIT_PRIVATE_V1.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'pages':len(pages),'slots':len(allslots),'flagged':len(out['flaggedSlots']),'flags':[{'uid':r['uid'],'id':r['id'],'flags':r['flags'],'outside':r['mainPixelsOutsideFrame'],'cut':r['cutDistancesLTRY'],'neighbors':[(c['id'],c['pixelsInFrame'])for c in r['otherLargeComponentsInFrame']],'support':r['lowerBandComponentsNotYetFeetReviewed']}for r in out['flaggedSlots']]},ensure_ascii=False))
