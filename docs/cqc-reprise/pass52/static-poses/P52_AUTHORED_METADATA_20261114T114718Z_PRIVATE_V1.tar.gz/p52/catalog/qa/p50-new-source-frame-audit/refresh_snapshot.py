import os,json,hashlib,datetime
from pathlib import Path
Q=Path(__file__).resolve().parent
P=Path('/tmp/cqc-static-20261113/artists')
def read_noatime(path):
 fd=os.open(path,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as f:return f.read()
rows=[];receipts=[]
for path in sorted(P.glob('*/p50/**/*ARTIFACT_PROPOSAL*.json')):
 raw=read_noatime(path);j=json.loads(raw)
 if not isinstance(j.get('rawPNG'),dict) or not j.get('slots'):continue
 source=Path(j['rawPNG']['path']);before=source.stat();data=read_noatime(source);sha=hashlib.sha256(data).hexdigest()
 assert sha==j['rawPNG']['sha256'],source
 target=Q/'sources'/(sha+'.png')
 if not target.exists():
  fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o644)
  with os.fdopen(fd,'wb')as f:f.write(data)
 after=source.stat();assert (before.st_atime_ns,before.st_mtime_ns,before.st_ctime_ns,before.st_size)==(after.st_atime_ns,after.st_mtime_ns,after.st_ctime_ns,after.st_size)
 slots=[]
 for s in j['slots']:
  status=s.get('sourceStatus');preferred=s.get('preferredSourceProposal')
  if j['uid']=='core__snake_acid' and s.get('costumeID')=='official--link-battle-red' and path.name.endswith('_V1.json') and path.with_name(path.name.replace('_V1.json','_V2.json')).exists():
   status='SUPERSEDED_BY_TARGETED_FACE_REVIEW_V2';preferred=str(path.with_name(path.name.replace('_V1.json','_V2.json')))
  slots.append({'uid':s.get('uid',j['uid']),'id':s.get('costumeID',s.get('costumeId')),'rect':s['sourceRect'],'bodyX':s.get('bodyDatumX'),'footY':s.get('footDatumY'),'bodyBounds':s.get('bodyBounds'),'support':s.get('support'),'status':status,'preferred':preferred})
 rows.append({'proposal':str(path),'proposalSHA256':hashlib.sha256(raw).hexdigest(),'uid':j['uid'],'png':str(source),'sha':sha,'atlas':j['atlas'],'slots':slots})
 receipts.append({'canonicalSource':str(source),'qaExactCopy':str(target),'sourceSHA256':sha,'sourceBytes':len(data),'proposalPath':str(path),'sourceStatsUnchanged':True})
for name in ['PROPOSAL_SNAPSHOT_PRIVATE_V1.json','QA_COPY_RECEIPTS_PRIVATE_V1.json','QUANTITATIVE_FRAME_AUDIT_PRIVATE_V1.json','BROWSER_PLACEMENT_ACTUAL_PRIVATE_V1.json']:
 old=Q/name;save=Q/(name.replace('_V1.json','_INITIAL43_V1.json'))
 if old.exists() and not save.exists():save.write_bytes(read_noatime(old))
(Q/'PROPOSAL_SNAPSHOT_PRIVATE_V1.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
(Q/'QA_COPY_RECEIPTS_PRIVATE_V1.json').write_text(json.dumps({'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'receipts':receipts},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'pages':len(rows),'slots':sum(len(r['slots'])for r in rows)}))
