import json,io
import numpy as np
from PIL import Image
from scipy import ndimage
from pathlib import Path
Q=Path(__file__).resolve().parent
j=json.loads((Q/'QUANTITATIVE_FRAME_AUDIT_PRIVATE_V1.json').read_text());out=[]
for p in j['rows']:
 a=np.asarray(Image.open(Q/'sources'/(p['sha']+'.png')).convert('RGBA'))[:,:,3]
 for s in p['slotAnalysis']:
  if s['superseded']:continue
  feet=[]
  for group in s['lowerBandComponentsNotYetFeetReviewed']:
   l,t,r,b=group['bbox'];low=max(t,b-12);yy,xx=np.where(a[low:b,l:r]>192)
   if not len(xx):continue
   feet.append({'contactRect':[l+int(xx.min()),low+int(yy.min()),int(xx.max()-xx.min()+1),int(yy.max()-yy.min()+1)],'centerX':float(l+(xx.min()+xx.max()+1)/2),'bottomY':int(low+yy.max()+1)})
  xx=float(np.mean([f['centerX'] for f in feet])) if feet else s['bodyX']; yy=max((f['bottomY']for f in feet),default=s['footY'])
  out.append({'uid':s['uid'],'costumeId':s['id'],'sourceSHA256':p['sha'],'rect':s['rect'],'beforeBodyX':s['bodyX'],'beforeFootY':s['footY'],'candidateBodyX':round(xx,3),'candidateFootY':yy,'supportContactGroups':feet,'quantFlags':s['flags']})
(Q/'SUPPORT_CONTACTS_MEASURED_PRIVATE_V1.json').write_text(json.dumps({'qualification':'Measurements only; final corrections require physical review. Sole bands alpha>192, last12 sourcepixels of each visually identified foot/hoof group.','rows':out},indent=2)+'\n')
for r in out:print(r['uid'],r['costumeId'],r['beforeBodyX'],'->',r['candidateBodyX'],'floor',r['beforeFootY'],'->',r['candidateFootY'],len(r['supportContactGroups']))
