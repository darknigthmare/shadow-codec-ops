import os,json,hashlib,datetime
from pathlib import Path
BASE=Path(__file__).resolve().parent
CAT=BASE.parent.parent
DEST=BASE/'increment-final'
DEST.mkdir(exist_ok=True);(DEST/'sources').mkdir(exist_ok=True)
def read(path):
 with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
main=json.loads(read(CAT/'P50_NEW_SOURCE_FRAME_QA_PRIVATE_V1.json'))
baseline=DEST/'BASE_REPORT_FROZEN_PRIVATE_V1.json'
if not baseline.exists():
 fd=os.open(baseline,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o644)
 with os.fdopen(fd,'wb')as f:f.write(read(CAT/'P50_NEW_SOURCE_FRAME_QA_PRIVATE_V1.json'))
main=json.loads(read(baseline));known={s['sha256']for s in main['snapshot']['sources']}
indexraw=read(CAT/'ACTIVE_ARTIST_REGISTRATIONS_PRIVATE_V1.json');index=json.loads(indexraw)
pages=[p for p in index['pages']if '/p50/'in p['source']and p['sha256']not in known]
rows=[];receipts=[]
for page in pages:
 proposal=page['metadataDocument'];raw=read(proposal);j=json.loads(raw);source=Path(page['source']);before=source.stat();data=read(source);sha=hashlib.sha256(data).hexdigest();assert sha==page['sha256']==j['rawPNG']['sha256']
 target=DEST/'sources'/(sha+'.png')
 if not target.exists():
  with os.fdopen(os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o644),'wb')as f:f.write(data)
 after=source.stat();assert (before.st_atime_ns,before.st_mtime_ns,before.st_ctime_ns)==(after.st_atime_ns,after.st_mtime_ns,after.st_ctime_ns)
 slots=[]
 for s in j['slots']:
  costume=s.get('costumeID',s.get('costumeId'))
  if costume not in page['activeCostumes']:continue
  slots.append({'uid':s.get('uid',j['uid']),'id':costume,'rect':s['sourceRect'],'bodyX':s.get('bodyDatumX'),'footY':s.get('footDatumY'),'bodyBounds':s.get('bodyBounds'),'clipPolygon':s.get('clipPolygon'),'support':s.get('support'),'status':s.get('sourceStatus'),'preferred':s.get('preferredSourceProposal')})
 rows.append({'proposal':proposal,'proposalSHA256':hashlib.sha256(raw).hexdigest(),'uid':j['uid'],'png':str(source),'sha':sha,'atlas':j['atlas'],'slots':slots})
 receipts.append({'canonicalSource':str(source),'qaExactCopy':str(target),'sourceSHA256':sha,'sourceBytes':len(data),'proposalPath':proposal,'sourceStatsUnchanged':True})
(DEST/'PROPOSAL_SNAPSHOT_PRIVATE_V1.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
(DEST/'QA_COPY_RECEIPTS_PRIVATE_V1.json').write_text(json.dumps({'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'activeIndexAtUTC':index['atUTC'],'activeIndexSHA256':hashlib.sha256(indexraw).hexdigest(),'receipts':receipts},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'atUTC':index['atUTC'],'newActivePages':len(rows),'newActivePoses':sum(len(r['slots'])for r in rows),'sources':[{'uid':p['uid'],'sha':p['sha']}for p in rows]}))
