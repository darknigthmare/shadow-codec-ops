import json,pathlib,hashlib,os,datetime
Q=pathlib.Path(__file__).resolve().parent
reportpath=Q.parent.parent/'P50_NEW_SOURCE_FRAME_QA_PRIVATE_V1.json'
report=json.loads(reportpath.read_text());snap=json.loads((Q/'PROPOSAL_SNAPSHOT_PRIVATE_V1.json').read_text());quant=json.loads((Q/'QUANTITATIVE_FRAME_AUDIT_PRIVATE_V1.json').read_text());browser=json.loads((Q/'BROWSER_CORRECTED_PLACEMENT_ACTUAL_PRIVATE_V1.json').read_text())
assert len(browser['rendered'])==len(report['corrections'])
allfit=all(p['placement']['x']>=14-1e-6 and p['placement']['x']+p['placement']['width']<=306+1e-6 for p in browser['rendered']);assert allfit
verified=[]
for page in snap:
 before=os.stat(page['png']);fd=os.open(page['png'],os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb')as f:sha=hashlib.sha256(f.read()).hexdigest()
 after=os.stat(page['png']);assert sha==page['sha'];assert (before.st_atime_ns,before.st_mtime_ns,before.st_ctime_ns)==(after.st_atime_ns,after.st_mtime_ns,after.st_ctime_ns)
 fd=os.open(page['proposal'],os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb')as f:proposalsha=hashlib.sha256(f.read()).hexdigest()
 assert proposalsha==page['proposalSHA256']
 verified.append({'path':page['png'],'sha256':sha,'unchanged':True,'proposalPath':page['proposal'],'proposalSHA256':proposalsha})
known={p['proposal']for p in snap};pending=[str(p)for p in pathlib.Path('/tmp/cqc-static-20261113/artists').glob('*/p50/**/*ARTIFACT_PROPOSAL*.json')if str(p)not in known]
report['atUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();report['status']='PHYSICALLY_REVIEWED_CORRECTIONS_READY_FOR_ROOT_IMPORT'
report['sourceInspection']['activePosesPhysicallyViewed']=sum(not s['superseded']for p in quant['rows']for s in p['slotAnalysis'])
report['sourceInspection']['fullStrongSilhouetteCutsBySourceRect']=sum(s['mainPixelsOutsideFrame']>0 for p in quant['rows']for s in p['slotAnalysis']if s['mainPixelsOutsideFrame'] is not None)
report['sourceInspection']['strongSourcePageEdgePixels']=sum(sum(p['edgesByThreshold']['64'].values())for p in quant['rows'])
report['rendererIssues'][0]['status']='FIXED_BY_ROOT_AND_VERIFIED_WITH_ACTUAL_PLACEMENT'
report['rendererIssues'][0]['verifiedCases']=['archive__ddog:official--battle-dress','archive__ddog:official--tactical-fulton','archive__dhorse:official--battle-dress','archive__dhorse:official--furicorn','archive__dwalker:official--fulton-ballista']
report['correctedReaderVerification']={'posesRenderedAndPhysicallyViewed':len(browser['rendered']),'canvas':[320,360],'allFrameHorizontalBoundsWithin14PixelMargins':allfit,'actualFunction':browser['actualPlacementFunctionSource'],'sourcePNGHashesRechecked':len(verified),'allSourceBytesUnchanged':True,'actualBrowserRecord':str(Q/'BROWSER_CORRECTED_PLACEMENT_ACTUAL_PRIVATE_V1.json'),'screenshots':[str(Q/('corrected-render-'+str(i).zfill(3)+'.png'))for i in range(0,len(browser['rendered']),6)]}
report['supersededSlotsExcluded']=[{'uid':s['uid'],'costumeId':s['id'],'sourceSHA256':p['sha'],'reason':s['status'],'preferredProposal':s['preferred']}for p in quant['rows']for s in p['slotAnalysis']if s['superseded']]
report['pendingProposalsDiscoveredAfterSnapshot']=pending
reportpath.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');(Q/'SOURCE_BYTES_UNCHANGED_FINAL_CHECK_PRIVATE_V1.json').write_text(json.dumps({'atUTC':report['atUTC'],'verified':verified},indent=2)+'\n')
print(json.dumps({'pages':len(snap),'activePoses':report['sourceInspection']['activePosesPhysicallyViewed'],'corrections':len(report['corrections']),'rectChanges':sum(r['rect']!=r['previousFrame']['rect']for r in report['corrections']),'clipChanges':sum('clipPolygon'in r for r in report['corrections']),'pendingProposals':pending,'reportSHA256':hashlib.sha256(reportpath.read_bytes()).hexdigest()}))
