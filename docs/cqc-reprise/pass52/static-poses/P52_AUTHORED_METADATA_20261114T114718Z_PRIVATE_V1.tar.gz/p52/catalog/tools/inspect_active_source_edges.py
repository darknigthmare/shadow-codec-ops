#!/usr/bin/env python3
import pathlib,json,hashlib,io,os,datetime,numpy as np
from PIL import Image
N=pathlib.Path('/tmp/cqc-static-20261113');index=json.loads((N/'catalog/ACTIVE_ARTIST_REGISTRATIONS_PRIVATE_V1.json').read_text());rows=[]
for p in index['pages']:
 source=pathlib.Path(p['source'])
 with os.fdopen(os.open(source,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:raw=f.read()
 assert hashlib.sha256(raw).hexdigest()==p['sha256'];a=np.asarray(Image.open(io.BytesIO(raw)).convert('RGBA'))[:,:,3];edges={'top':int((a[0]>16).sum()),'bottom':int((a[-1]>16).sum()),'left':int((a[:,0]>16).sum()),'right':int((a[:,-1]>16).sum())};rows.append({'uid':p['uid'],'sourceSHA256':p['sha256'],'source':str(source),'activeCostumes':p['activeCostumes'],'edgeAlpha16':edges,'alphaZeroFraction':float((a==0).mean()),'requiresVisualEdgeReview':any(edges.values())})
r={'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pagesInspected':len(rows),'flagged':[r for r in rows if r['requiresVisualEdgeReview']],'rows':rows,'pixelsModified':False,'artApprovalInferred':False};(N/'catalog/qa/ACTIVE_SOURCE_EDGE_ANALYSIS_PRIVATE_V1.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'pages':len(rows),'flagged':r['flagged']},ensure_ascii=False))
