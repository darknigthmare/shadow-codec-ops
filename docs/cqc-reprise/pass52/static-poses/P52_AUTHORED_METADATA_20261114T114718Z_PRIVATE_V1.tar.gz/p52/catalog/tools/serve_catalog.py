#!/usr/bin/env python3
"""Local-only catalogue server with a read-only mount of public CQC assets."""
import argparse,http.server,os,pathlib,urllib.parse
CAT=pathlib.Path('/tmp/cqc-static-20261113/catalog')
NATIVE=pathlib.Path('/workspace/cqc-pass21-application/public/cqc')
CAPTURES=pathlib.Path('/tmp/cqc-static-20261113/artists/e/composites')
class Handler(http.server.SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(CAT),**kw)
 def translate_path(self,path):
  decoded=urllib.parse.unquote(urllib.parse.urlsplit(path).path)
  if '\\'in decoded or any(x=='..'for x in decoded.split('/')):return str(CAT/'__denied__')
  if decoded.startswith('/native/'):
   target=NATIVE/decoded[len('/native/'):]
   if not target.is_relative_to(NATIVE)or target.resolve(strict=False)!=target:return str(CAT/'__denied__')
   return str(target)
  if decoded.startswith('/captures/'):
   name=decoded[len('/captures/'):];target=CAPTURES/name
   if '/'in name or not name.endswith('.png')or target.resolve(strict=False)!=target:return str(CAT/'__denied__')
   return str(target)
  parts=decoded.lstrip('/').split('/')
  allowed=parts[0]in['','index.html','catalog.css','catalog.mjs','manifest-model.mjs','assets']or(len(parts)==1 and parts[0].startswith('manifest')and parts[0].endswith('.json'))
  if not allowed:return str(CAT/'__denied__')
  return super().translate_path(path)
 def end_headers(self):
  self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');super().end_headers()
 def list_directory(self,path):self.send_error(403,'Directory listing disabled');return None
 def copyfile(self,source,outputfile):
  # Native assets must be read without changing their recorded access time.
  path=pathlib.Path(source.name)
  if path.is_relative_to(NATIVE)or path.is_relative_to(CAPTURES):
   with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:
    while chunk:=f.read(1024*1024):outputfile.write(chunk)
  else:super().copyfile(source,outputfile)
def main():
 global CAT,NATIVE
 a=argparse.ArgumentParser();a.add_argument('--port',type=int,default=8149);a.add_argument('--catalog-root',default=str(CAT));a.add_argument('--native-root',default=str(NATIVE));args=a.parse_args()
 CAT=pathlib.Path(args.catalog_root).resolve(strict=True);NATIVE=pathlib.Path(args.native_root).resolve(strict=True)
 if not CAT.is_dir()or not NATIVE.is_dir():raise ValueError('Both catalogue and native public asset roots must be directories')
 print(f'http://127.0.0.1:{args.port}/',flush=True);http.server.ThreadingHTTPServer(('127.0.0.1',args.port),Handler).serve_forever()
if __name__=='__main__':main()
