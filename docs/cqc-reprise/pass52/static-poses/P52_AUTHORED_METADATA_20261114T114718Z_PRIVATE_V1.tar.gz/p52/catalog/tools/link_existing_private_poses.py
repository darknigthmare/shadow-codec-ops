#!/usr/bin/env python3
"""Select one already drawn static pose; retain source PNG bytes exactly."""
import hashlib,json,pathlib,os,io
from PIL import Image
N=pathlib.Path('/tmp/cqc-static-20261113');CAT=N/'catalog';d=json.loads((N/'reuse-private/FATMAN_TUXEDO_EXISTING_STATIC_REUSE_PRIVATE_V1.json').read_text());p=pathlib.Path(d['sourcePNG'])
with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:raw=f.read()
assert hashlib.sha256(raw).hexdigest()==d['sha256'];target=CAT/'assets/reused-sources'/p.name;target.parent.mkdir(exist_ok=True)
if not target.exists():target.write_bytes(raw)
assert target.read_bytes()==raw
im=Image.open(io.BytesIO(raw));x,y,w,h=d['frameRect'];fp=d['footprint'];entry={'uid':d['uid'],'costumeId':d['costumeId'],'status':'drawn','source':{'kind':'existing-private-frame','src':target.relative_to(CAT).as_posix(),'sha256':d['sha256'],'width':im.width,'height':im.height,'verified':True},'frame':{'rect':d['frameRect'],'pivot':[(fp['x']-x)/w,(fp['y']-y)/h]},'facing':'right','note':'Pose RIGHT déjà dessinée et relue. La réserve historique porte sur un autre cadre LEFT ; aucun nouveau dessin ni animation.','artReview':{'status':'approved','reviewer':'Root direct visual inspection','sourceSHA256':d['sha256'],'note':d['RootVisualReview']},'generationRequired':False,'reusedExistingStaticPose':True}
(CAT/'EXISTING_PRIVATE_POSE_OVERLAYS_PUBLIC_V1.json').write_text(json.dumps({'entries':[entry]},ensure_ascii=False,indent=2)+'\n');print('Existing Fatman tux RIGHT linked; PNG unchanged, one pose selected.')
