#!/usr/bin/env python3
"""Register a source PNG exactly; never redraw, delete, overwrite, or publish it."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat
import struct
import sys
import zlib

BASE = Path('/tmp/cqc-static-20261113')
DEFAULT_ROOT = BASE / 'catalog'
MAX_BYTES = 64 * 1024 * 1024
TOKEN = re.compile(r'[a-z0-9][a-z0-9_-]{0,95}\Z')


def stat_pin(s: os.stat_result) -> dict:
    return {'device': s.st_dev, 'inode': s.st_ino, 'mode': stat.S_IMODE(s.st_mode),
            'uid': s.st_uid, 'gid': s.st_gid, 'nlink': s.st_nlink, 'bytes': s.st_size,
            'atimeNs': s.st_atime_ns, 'mtimeNs': s.st_mtime_ns, 'ctimeNs': s.st_ctime_ns,
            'allocatedBytes': s.st_blocks * 512}


def read_exact_noatime(path: Path, limit: int = MAX_BYTES) -> tuple[bytes, dict]:
    fd = os.open(path, os.O_RDONLY | os.O_NOATIME | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as handle:
        before = os.fstat(handle.fileno())
        if not stat.S_ISREG(before.st_mode) or before.st_size > limit:
            raise ValueError('Source must be a bounded regular file')
        raw = handle.read(limit + 1)
        after = os.fstat(handle.fileno())
    if len(raw) > limit or len(raw) != before.st_size:
        raise ValueError('Source length changed or exceeds the limit')
    if stat_pin(before) != stat_pin(after) or stat_pin(after) != stat_pin(os.stat(path, follow_symlinks=False)):
        raise ValueError('Source identity or metadata changed during the read')
    return raw, stat_pin(after)


def png_structure(raw: bytes) -> dict:
    if raw[:8] != b'\x89PNG\r\n\x1a\n':
        raise ValueError('Not a PNG signature')
    at, chunks, header, idats, ended, last_type = 8, [], None, 0, False, None
    palette = False
    while at < len(raw):
        if len(raw) - at < 12:
            raise ValueError('Truncated PNG chunk')
        length = int.from_bytes(raw[at:at + 4], 'big')
        kind = raw[at + 4:at + 8]
        end = at + 12 + length
        if not all(65 <= c <= 90 or 97 <= c <= 122 for c in kind) or end > len(raw):
            raise ValueError('Invalid PNG chunk boundary/type')
        payload = raw[at + 8:at + 8 + length]
        crc = int.from_bytes(raw[at + 8 + length:end], 'big')
        if zlib.crc32(kind + payload) & 0xffffffff != crc:
            raise ValueError('PNG chunk CRC mismatch')
        name = kind.decode('ascii')
        if kind in (b'acTL', b'fcTL', b'fdAT'):
            raise ValueError('Animated PNG chunks are outside this static-pose pass')
        if not chunks and kind != b'IHDR':
            raise ValueError('IHDR must be first')
        if kind == b'IHDR':
            if header is not None or length != 13:
                raise ValueError('Invalid or duplicate IHDR')
            width, height, depth, color, compression, filtering, interlace = struct.unpack('>IIBBBBB', payload)
            valid_depths = {0: {1, 2, 4, 8, 16}, 2: {8, 16}, 3: {1, 2, 4, 8}, 4: {8, 16}, 6: {8, 16}}
            if (not 1 <= width <= 16384 or not 1 <= height <= 16384 or width * height > 32 * 1024 * 1024
                    or depth not in valid_depths.get(color, set()) or compression != 0
                    or filtering != 0 or interlace not in (0, 1)):
                raise ValueError('Unsupported or invalid PNG header')
            header = {'width': width, 'height': height, 'bitDepth': depth, 'colorType': color,
                      'interlace': interlace, 'alphaChannelDeclared': color in (4, 6)}
        elif kind == b'PLTE':
            if palette or idats or not length or length % 3 or length > 768:
                raise ValueError('Invalid PNG palette')
            palette = True
        elif kind == b'IDAT':
            if idats and last_type != b'IDAT':
                raise ValueError('IDAT chunks must be contiguous')
            idats += 1
        elif kind == b'IEND':
            if length != 0 or not idats or end != len(raw):
                raise ValueError('Invalid IEND or trailing bytes')
            ended = True
        elif not kind[0] & 32:
            raise ValueError('Unknown critical PNG chunk')
        chunks.append({'type': name, 'bytes': length})
        if len(chunks) > 10000:
            raise ValueError('Too many PNG chunks')
        at, last_type = end, kind
        if ended:
            break
    if not ended or header is None or (header['colorType'] == 3 and not palette):
        raise ValueError('Incomplete PNG structure')
    return dict(header, chunks=chunks, chunkCRCsVerified=True, rasterDecoded=False,
                transparencyPixelsVerified=False, rasterModified=False)


def safe_token(value: str) -> str:
    if not TOKEN.fullmatch(value):
        raise ValueError('UID/outfit must be a lowercase safe identifier (maximum 96 characters)')
    return value


def safe_directory(path: Path) -> Path:
    path = path.absolute()
    if path.resolve(strict=False) != path or not path.is_relative_to(BASE):
        raise ValueError('Output must be a nonsymlink path below the task TMP root')
    path.mkdir(parents=True, exist_ok=True)
    if not path.is_dir() or path.resolve(strict=True) != path:
        raise ValueError('Output directory is not a real directory')
    return path


def page_grid(metadata: dict) -> dict:
    cells = metadata.get('cells', [])
    if not isinstance(cells, list) or len(cells) > 9:
        raise ValueError('At most nine cell definitions are permitted')
    count = max(1, len(cells))
    columns = metadata.get('columns', min(3, count))
    if type(columns) is not int or not 1 <= columns <= 9:
        raise ValueError('Grid columns must be a positive integer no greater than nine')
    rows = metadata.get('rows', (count + columns - 1) // columns)
    if type(rows) is not int or not 1 <= rows <= 9 or columns * rows > 9:
        raise ValueError('Grid rows must be positive and total capacity no greater than nine')
    if len(cells) > columns * rows:
        raise ValueError('Grid capacity is smaller than the cell count')
    return {'columns': columns, 'rows': rows}


def normalized_cells(metadata: dict, width: int, height: int, uid: str) -> list:
    cells = metadata.get('cells', [])
    if not isinstance(cells, list) or len(cells) > 9:
        raise ValueError('At most nine cell definitions are permitted')
    grid = page_grid(metadata)
    columns, rows = grid['columns'], grid['rows']
    result, slots, outfits = [], set(), set()
    for cell in cells:
        if not isinstance(cell, dict):
            raise ValueError('Each cell must be an object')
        slot = cell.get('slot')
        if type(slot) is not int or not 0 <= slot < columns * rows or slot in slots:
            raise ValueError('Cell slots must be unique integers within the effective grid capacity')
        outfit = safe_token(cell['outfit'])
        if outfit in outfits or cell.get('uid', uid) != uid or cell.get('facing', 'right') != 'right':
            raise ValueError('Each outfit must be unique and match the page UID/right facing')
        col, row = slot % columns, slot // columns
        x0, y0 = width * col // columns, height * row // rows
        default_rect = {'x': x0, 'y': y0, 'width': width * (col + 1) // columns - x0,
                        'height': height * (row + 1) // rows - y0}
        rect = cell.get('frameRect', default_rect)
        if (not isinstance(rect, dict) or set(rect) != {'x', 'y', 'width', 'height'}
                or any(type(v) is not int for v in rect.values()) or rect['x'] < 0 or rect['y'] < 0
                or rect['width'] <= 0 or rect['height'] <= 0 or rect['x'] + rect['width'] > width
                or rect['y'] + rect['height'] > height):
            raise ValueError('Frame rectangle must lie within the PNG')
        footprint = cell.get('footprint')
        if footprint is not None:
            if (not isinstance(footprint, dict) or set(footprint) != {'x', 'y'}
                    or any(type(v) not in (int, float) or not math.isfinite(v) for v in footprint.values())
                    or not rect['x'] <= footprint['x'] <= rect['x'] + rect['width']
                    or not rect['y'] <= footprint['y'] <= rect['y'] + rect['height']):
                raise ValueError('Footprint must be a finite source-pixel point within its frame')
        label = cell.get('label', outfit)
        if not isinstance(label, str) or len(label) > 160:
            raise ValueError('Cell labels must be short text')
        result.append({'uid': uid, 'outfit': outfit, 'label': label, 'slot': slot, 'facing': 'right',
                       'frameRect': rect, 'footprint': footprint,
                       'groundY': footprint['y'] if footprint else None,
                       'frameRectVisuallyReviewed': False, 'artReviewed': False,
                       'staticArtCandidate': True, 'runtimeAdmitted': False})
        slots.add(slot)
        outfits.add(outfit)
    return result


def register(args: argparse.Namespace) -> dict:
    uid, outfit = safe_token(args.uid), safe_token(args.outfit)
    if not 1 <= args.page_no <= 999:
        raise ValueError('Page number must be between one and 999')
    source = Path(args.source).absolute()
    raw, source_stat = read_exact_noatime(source)
    info = png_structure(raw)
    metadata, metadata_pin = {}, None
    if args.metadata_json:
        path = Path(args.metadata_json).absolute()
        meta_raw, meta_stat = read_exact_noatime(path, 1024 * 1024)
        metadata = json.loads(meta_raw)
        if not isinstance(metadata, dict):
            raise ValueError('Metadata must be a JSON object')
        metadata_pin = {'path': str(path), 'bytes': len(meta_raw), 'sha256': hashlib.sha256(meta_raw).hexdigest(),
                        'stats': meta_stat}
    grid = page_grid(metadata)
    cells = normalized_cells(metadata, info['width'], info['height'], uid)
    sha = hashlib.sha256(raw).hexdigest()
    oid = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    page_id = f'{uid}--{outfit}--p{args.page_no:03d}'
    root = safe_directory(Path(args.catalog_root))
    pages, receipts = safe_directory(root / 'assets/source-pages'), safe_directory(root / 'receipts/generation')
    target = pages / f'{page_id}-{sha[:12]}.png'
    receipt = receipts / f'{page_id}-{sha[:12]}.registration.json'
    if target.exists() or target.is_symlink() or receipt.exists() or receipt.is_symlink():
        raise FileExistsError('Registration target already exists; nothing has been replaced')
    result = {'schema': 'cqc.static-source-page-registration/1', 'stage': 'registration_started',
              'pageId': page_id, 'uid': uid, 'outfitGroup': outfit, 'pageNo': args.page_no,
              'source': {'path': str(source), 'bytes': len(raw), 'sha256': sha, 'gitBlobOID': oid, 'stats': source_stat},
              'canonicalPath': str(target), 'relativePath': target.relative_to(root).as_posix(),
              'receiptPath': str(receipt), 'PNG': info, 'metadataPin': metadata_pin, 'cells': cells,
              'columns': grid['columns'], 'rows': grid['rows'],
              'declaredPoseCount': len(cells), 'artReviewRequired': True, 'runtimeAdmitted': False,
              'imageGenerationProvenanceIndependentlyVerified': False,
              'SourcePixelsModified': False, 'sourceFileDeleted': False, 'GitWritten': False}
    receipt_fd = os.open(receipt, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        target_fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(target_fd, 'wb') as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        copied, target_stat = read_exact_noatime(target)
        if copied != raw or stat_pin(os.stat(source, follow_symlinks=False)) != source_stat:
            raise ValueError('Canonical copy differs or source metadata changed')
        result.update(stage='source_png_registered', exactCanonicalReadback=True,
                      sourceAllStatsUnchanged=True, canonicalStats=target_stat,
                      registeredAtUTC=dt.datetime.now(dt.timezone.utc).isoformat())
    except Exception as exc:
        result.update(stage='incomplete_registration_not_delivered', error=f'{type(exc).__name__}: {exc}')
        raise
    finally:
        with os.fdopen(receipt_fd, 'w', encoding='utf-8') as handle:
            json.dump(result, handle, ensure_ascii=False, indent=2)
            handle.write('\n')
            handle.flush()
            os.fsync(handle.fileno())
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True)
    parser.add_argument('--uid', required=True)
    parser.add_argument('--outfit', required=True, help='A safe outfit or page-group identifier')
    parser.add_argument('--page-no', required=True, type=int)
    parser.add_argument('--metadata-json', help='Optional {columns,rows,cells} object, maximum nine cells')
    parser.add_argument('--catalog-root', default=str(DEFAULT_ROOT))
    args = parser.parse_args()
    try:
        result = register(args)
        summary = {k: result[k] for k in ['stage', 'pageId', 'canonicalPath', 'relativePath', 'receiptPath',
                                         'declaredPoseCount', 'columns', 'rows', 'exactCanonicalReadback', 'sourceAllStatsUnchanged']}
        summary.update(sha256=result['source']['sha256'], gitBlobOID=result['source']['gitBlobOID'],
                       width=result['PNG']['width'], height=result['PNG']['height'])
        print(json.dumps(summary, ensure_ascii=False))
        return 0
    except (ValueError, OSError, KeyError, TypeError, json.JSONDecodeError) as exc:
        print(f'Registration refused: {type(exc).__name__}: {exc}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
