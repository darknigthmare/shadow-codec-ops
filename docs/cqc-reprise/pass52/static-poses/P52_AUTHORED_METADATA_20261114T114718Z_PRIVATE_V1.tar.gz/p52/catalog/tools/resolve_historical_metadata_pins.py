#!/usr/bin/env python3
"""Resolve historical metadata pins without changing receipts or PNG assets.

Run after the last artist-page registration:
    python3 catalog/tools/resolve_historical_metadata_pins.py

Historical JSON bytes are reconstructed from the six original cell fields,
with the original importer serialization. A candidate is accepted only when
both its SHA256 and byte length match the receipt's metadataPin exactly.
History files are exclusively created read-only and never overwritten. The
resolution report is refreshed atomically; receipt and existing metadata bytes
and timestamps are never changed. No importer, build, PNG or runtime is read.
"""

import argparse
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import tempfile


CELL_FIELDS = ('slot', 'outfit', 'label', 'facing', 'frameRect', 'footprint')
REPORT_NAME = 'HISTORICAL_METADATA_PIN_RESOLUTION_PRIVATE_V1.json'


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def snapshot(path):
    value = os.lstat(path)
    if not stat.S_ISREG(value.st_mode):
        raise ValueError(f'Expected a regular non-symlink file: {path}')
    return {
        'device': value.st_dev, 'inode': value.st_ino,
        'mode': stat.S_IMODE(value.st_mode), 'bytes': value.st_size,
        'atimeNs': value.st_atime_ns, 'mtimeNs': value.st_mtime_ns,
        'ctimeNs': value.st_ctime_ns,
    }


def read_exact_noatime(path):
    before = snapshot(path)
    # Fail closed if the filesystem cannot honor O_NOATIME/O_NOFOLLOW.
    flags = os.O_RDONLY | os.O_NOATIME | os.O_NOFOLLOW
    with os.fdopen(os.open(path, flags), 'rb') as handle:
        raw = handle.read()
    if snapshot(path) != before or len(raw) != before['bytes']:
        raise RuntimeError(f'Input changed during no-atime read: {path}')
    return raw


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def ensure_safe_directory(path):
    path = Path(os.path.abspath(path))
    for component in reversed((path, *path.parents)):
        if component.is_symlink():
            raise ValueError(f'Refusing a symlink directory: {component}')
        if component.exists() and not component.is_dir():
            raise ValueError(f'Expected a directory: {component}')
    path.mkdir(parents=True, exist_ok=True)
    return path


def preserve_history(path, raw):
    """Return whether newly created; never rewrite an existing history file."""
    if os.path.lexists(path):
        if read_exact_noatime(path) != raw:
            raise RuntimeError(f'Immutable history collision: {path}')
        if snapshot(path)['mode'] & 0o222:
            raise RuntimeError(f'Existing history file is writable: {path}')
        return False
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW
    with os.fdopen(os.open(path, flags, 0o444), 'wb') as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    if read_exact_noatime(path) != raw:
        raise RuntimeError(f'History readback mismatch: {path}')
    return True


def publish_report(path, raw):
    if os.path.lexists(path):
        snapshot(path)  # Reject an existing symlink or non-regular report.
    descriptor, temporary = tempfile.mkstemp(prefix='.metadata-pin-report-', dir=path.parent)
    try:
        with os.fdopen(descriptor, 'wb') as handle:
            os.fchmod(handle.fileno(), 0o444)
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    if read_exact_noatime(path) != raw:
        raise RuntimeError('Resolution-report readback mismatch')


def resolve(catalog):
    catalog = ensure_safe_directory(catalog)
    history = ensure_safe_directory(catalog / 'import-metadata' / 'history')
    audit_path = catalog.parent / 'inventory' / 'FINAL_PLANNED_STATIC_COVERAGE_AUDIT_PRIVATE_V1.json'
    audit_raw = read_exact_noatime(audit_path)
    audit = json.loads(audit_raw)
    drifted = {
        change['receipt'] for change in audit['rawSourceAttributionReadback']
        ['metadataPinSemanticAnalysis']['changes']
    }
    active_path = catalog / 'ACTIVE_ARTIST_REGISTRATIONS_PRIVATE_V1.json'
    active_raw = read_exact_noatime(active_path)
    active = {item['receipt'] for item in json.loads(active_raw)['registrations']}
    receipts = sorted((catalog / 'receipts' / 'generation').glob('*.json'))
    entries, unresolved, snapshots = [], [], {}
    created = reused = 0

    for path in receipts:
        snapshots[path] = snapshot(path)
        receipt_raw = read_exact_noatime(path)
        receipt = json.loads(receipt_raw)
        pin = receipt.get('metadataPin')
        if not pin or not re.fullmatch(r'[0-9a-f]{64}', pin.get('sha256', '')):
            unresolved.append({'receiptPath': str(path), 'reason': 'Missing or invalid metadataPin'})
            continue
        cells = [{key: cell[key] for key in CELL_FIELDS} for cell in receipt['cells']]
        reconstructed = json_bytes({
            'columns': receipt['columns'], 'rows': receipt['rows'], 'cells': cells,
        })
        if sha256(reconstructed) != pin['sha256'] or len(reconstructed) != pin['bytes']:
            unresolved.append({
                'receiptPath': str(path), 'historicalMetadataPin': pin,
                'reason': 'Reconstructed bytes do not match historical SHA256 and length',
                'reconstructedSHA256': sha256(reconstructed),
                'reconstructedBytes': len(reconstructed),
            })
            continue
        resolved_path = history / (pin['sha256'] + '.json')
        if preserve_history(resolved_path, reconstructed):
            created += 1
        else:
            reused += 1
        try:
            current = read_exact_noatime(pin['path'])
            current_sha, current_bytes = sha256(current), len(current)
            current_matches = current_sha == pin['sha256'] and current_bytes == pin['bytes']
        except FileNotFoundError:
            current_sha = current_bytes = None
            current_matches = False
        entries.append({
            'receiptPath': str(path), 'receiptSHA256': sha256(receipt_raw),
            'receiptBytes': len(receipt_raw), 'uid': receipt['uid'], 'pageId': receipt['pageId'],
            'activeAtSnapshot': str(path) in active,
            'flaggedDriftInCoverageAudit': str(path) in drifted,
            'historicalMetadataPin': {key: pin[key] for key in ('path', 'bytes', 'sha256')},
            'currentPinnedPathReadback': {
                'path': pin['path'], 'bytes': current_bytes, 'sha256': current_sha,
                'matchesHistoricalPin': current_matches,
            },
            'resolvedMetadata': {
                'path': str(resolved_path), 'bytes': len(reconstructed),
                'sha256': sha256(reconstructed), 'modeOctal': oct(snapshot(resolved_path)['mode']),
                'SHA256MatchesHistoricalPin': True, 'byteLengthMatchesHistoricalPin': True,
                'exactFileReadback': True,
            },
            'resolutionMethod': 'EXACT_RECONSTRUCTION_FROM_RECEIPT_ORIGINAL_FIELDS',
            'columns': receipt['columns'], 'rows': receipt['rows'], 'cellCount': len(cells),
            'historicalReceiptModified': False,
        })

    changed = [str(path) for path, before in snapshots.items() if snapshot(path) != before]
    if changed:
        raise RuntimeError(f'Receipt inputs changed; report not published: {changed}')
    counts = collections.Counter(item['currentPinnedPathReadback']['matchesHistoricalPin'] for item in entries)
    report = {
        'schema': 'cqc.static.historical-metadata-pin-resolution/1',
        'atUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'resolver': '/root/static_artist_b; exact repair script rerun by Root',
        'scope': 'All historical generated-page receipts discovered in this snapshot, including active and superseded pages; exact historical pin recovery only. No current geometry rollback.',
        'inputAudit': {'path': str(audit_path), 'sha256': sha256(audit_raw), 'bytes': len(audit_raw)},
        'activeRegistrationSnapshot': {
            'path': str(active_path), 'sha256': sha256(active_raw),
            'bytes': len(active_raw), 'activeReceipts': len(active),
        },
        'summary': {
            'historicalReceipts': len(receipts),
            'activeReceiptsCovered': sum(item['activeAtSnapshot'] for item in entries),
            'historicalPins': len(receipts), 'historicalPinsExactlyResolved': len(entries),
            'coverageAuditDriftedPins': len(drifted),
            'coverageAuditDriftedPinsExactlyRecovered': sum(item['flaggedDriftInCoverageAudit'] for item in entries),
            'currentPinnedPathsStillMatching': counts[True], 'currentPinnedPathsDrifted': counts[False],
            'uniqueHistoricalSHA256Files': len({item['resolvedMetadata']['sha256'] for item in entries}),
            'historyFilesCreated': created, 'historyFilesAlreadyExact': reused,
            'unresolvedPins': len(unresolved), 'historicalReceiptSHAAndAllStatsUnchanged': True,
        },
        'reconstruction': {
            'topLevelFieldsInOrder': ['columns', 'rows', 'cells'],
            'cellFieldsInOrder': list(CELL_FIELDS),
            'nestedOrderAndNumericValues': 'Preserved exactly from historical normalized receipt.cells; no float/int or coordinate normalization.',
            'serialization': 'UTF-8 json.dumps(meta, ensure_ascii=False, indent=2) + one LF',
            'acceptance': 'Both expected metadataPin SHA256 and expected byte length must match reconstructed bytes; then exact stored file readback.',
            'historyPathRule': 'catalog/import-metadata/history/<metadataPin.sha256>.json',
            'immutability': 'Exclusive O_EXCL/O_NOFOLLOW creation, permission0444; never overwrite an existing path, verify identical bytes if already present.',
            'readPolicy': 'All input file bytes read with O_NOATIME/O_NOFOLLOW. No W checkpoint search required.',
        },
        'entries': entries, 'unresolved': unresolved,
        'historicalReceiptsModified': False, 'existingMetadataFilesModified': False,
        'importerBuildIndexModified': False, 'PNGFilesReadOrModified': False,
        'artGenerated': False, 'runtimeModified': False, 'newAnimations': 0,
    }
    path = catalog / REPORT_NAME
    raw = json_bytes(report)
    publish_report(path, raw)
    print(json.dumps({'path': str(path), 'bytes': len(raw), 'sha256': sha256(raw),
                      'summary': report['summary']}, ensure_ascii=False))
    return 1 if unresolved else 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--catalog-root', type=Path, default=Path(__file__).absolute().parent.parent)
    args = parser.parse_args()
    return resolve(args.catalog_root)


if __name__ == '__main__':
    raise SystemExit(main())
