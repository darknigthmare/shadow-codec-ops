#!/usr/bin/env python3
"""Small format/ownership checks; the fixed transparent fixture is not artwork."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import tempfile
import zlib

HERE = Path(__file__).parent
spec = importlib.util.spec_from_file_location('register_source_page', HERE / 'register_source_page.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def chunk(kind, data):
    return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)


def fixture_png(width=1, height=1):
    # Fixed one-pixel transparent test data; never part of the catalog/art count.
    fixed_idat = {(1, 1): '789c6360606060000000050001',
                  (3, 1): '789c6360400200000d0001', (3, 2): '789c6360c00500001a0001'}
    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0))
            + chunk(b'IDAT', bytes.fromhex(fixed_idat[(width, height)])) + chunk(b'IEND', b''))


with tempfile.TemporaryDirectory(prefix='registration-check-', dir=HERE) as directory:
    base = Path(directory)
    source = base / 'fixed-format-fixture.png'
    source.write_bytes(fixture_png())
    metadata = base / 'metadata.json'
    valid = {'cells': [{'slot': 0, 'outfit': 'fixture', 'label': 'Format fixture, not art',
                        'frameRect': {'x': 0, 'y': 0, 'width': 1, 'height': 1},
                        'footprint': {'x': 0.5, 'y': 1}, 'facing': 'right'}]}
    metadata.write_text(json.dumps(valid))
    args = argparse.Namespace(source=str(source), uid='fixture__test', outfit='metadata-only', page_no=1,
                              metadata_json=str(metadata), catalog_root=str(base / 'catalog'))
    start = module.stat_pin(source.stat())
    result = module.register(args)
    assert result['exactCanonicalReadback'] and result['sourceAllStatsUnchanged']
    copied, _ = module.read_exact_noatime(Path(result['canonicalPath']))
    assert copied == fixture_png() and module.stat_pin(source.stat()) == start
    assert not result['runtimeAdmitted'] and not result['cells'][0]['artReviewed']
    checks = [{'name': 'exact_copy_source_all_stats_and_pending_review', 'pass': True}]
    output_before = Path(result['canonicalPath']).stat()
    receipt_before = module.read_exact_noatime(Path(result['receiptPath']))[0]
    try:
        module.register(args)
        raise AssertionError('An existing output was replaced')
    except FileExistsError:
        assert Path(result['canonicalPath']).stat() == output_before
        assert module.read_exact_noatime(Path(result['receiptPath']))[0] == receipt_before
    checks.append({'name': 'duplicate_refused_without_overwrite', 'pass': True})
    bad = bytearray(fixture_png())
    bad[20] ^= 1
    animated = fixture_png()[:33] + chunk(b'acTL', struct.pack('>II', 2, 0)) + fixture_png()[33:]
    for name, raw in [('bad_crc', bytes(bad)), ('trailing_data', fixture_png() + b'x'), ('animated_png', animated)]:
        try:
            module.png_structure(raw)
            raise AssertionError('Invalid PNG accepted')
        except ValueError:
            checks.append({'name': name + '_refused', 'pass': True})
    link = base / 'source-link.png'
    link.symlink_to(source)
    try:
        module.read_exact_noatime(link)
        raise AssertionError('A symlink was read')
    except OSError:
        checks.append({'name': 'source_symlink_refused', 'pass': True})
    try:
        module.safe_directory(Path('/workspace/not-a-catalog-registration-target'))
        raise AssertionError('Non-TMP output accepted')
    except ValueError:
        checks.append({'name': 'output_outside_task_tmp_refused', 'pass': True})
    for name, cells in [
        ('too_many_cells', [{'slot': n, 'outfit': f'outfit{n}'} for n in range(10)]),
        ('out_of_bounds_rect', [{'slot': 0, 'outfit': 'test', 'frameRect': {'x': 0, 'y': 0, 'width': 2, 'height': 1}}]),
        ('wrong_facing', [{'slot': 0, 'outfit': 'test', 'facing': 'left'}]),
        ('unsafe_outfit', [{'slot': 0, 'outfit': '../unsafe'}])
    ]:
        try:
            module.normalized_cells({'cells': cells}, 1, 1, 'fixture__test')
            raise AssertionError('Invalid metadata accepted')
        except ValueError:
            checks.append({'name': name + '_refused', 'pass': True})
    assert module.stat_pin(source.stat()) == start
    for number, (columns, rows, count, explicit) in enumerate([(3, 1, 3, True), (3, 2, 6, False)], start=2):
        grid_source = base / f'fixed-format-grid-{columns}x{rows}.png'
        grid_source.write_bytes(fixture_png(columns, rows))
        grid_metadata = base / f'grid-{number}.json'
        data = {'cells': [{'slot': n, 'outfit': f'fixture{n}'} for n in range(count)]}
        if explicit:
            data.update(columns=columns, rows=rows)
        grid_metadata.write_text(json.dumps(data))
        grid_args = argparse.Namespace(source=str(grid_source), uid='fixture__test', outfit='metadata-only',
                                       page_no=number, metadata_json=str(grid_metadata), catalog_root=str(base / 'catalog'))
        grid_result = module.register(grid_args)
        assert (grid_result['columns'], grid_result['rows']) == (columns, rows)
        assert grid_result['exactCanonicalReadback'] and grid_result['sourceAllStatsUnchanged']
        for cell in grid_result['cells']:
            assert cell['frameRect'] == {'x': cell['slot'] % columns, 'y': cell['slot'] // columns,
                                         'width': 1, 'height': 1}
        checks.append({'name': f'grid_{columns}x{rows}_full_registration_' + ('explicit' if explicit else 'default'), 'pass': True})
    report = {'schema': 'cqc.static-source-registration-selfcheck/1', 'status': 'PASS',
              'checks': checks, 'checkCount': len(checks), 'fixtureIsArtwork': False,
              'spriteDeliveryClaimed': False, 'fixtureRasterEditingOfRealSource': False,
              'WASGitMutations': False, 'helperSHA256': hashlib.sha256((HERE / 'register_source_page.py').read_bytes()).hexdigest()}

(HERE / 'REGISTER_SOURCE_PAGE_SELFTEST_RECEIPT_PRIVATE_V1.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
