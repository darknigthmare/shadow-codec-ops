import fs from 'node:fs';
import {placement} from '/tmp/cqc-static-20261113/p51/catalog/manifest-model.mjs';
const root=new URL('.',import.meta.url).pathname;
const corrected=process.argv.includes('--corrected');
const selectedSHA=process.argv.find(x=>x.startsWith('--sha='))?.slice(6);
const outputPrefix=selectedSHA?'single-'+selectedSHA.slice(0,12)+'-':'';
const correctionRows=corrected?JSON.parse(fs.readFileSync(root+'P51_NEW_SOURCE_FRAME_QA_PROPOSAL_PRIVATE_V1.json')).corrections:[];
const rows=JSON.parse(fs.readFileSync(root+'QUANTITATIVE_FRAME_AUDIT_PRIVATE_V1.json')).rows;
const manifest=JSON.parse(fs.readFileSync('/tmp/cqc-static-20261113/p51/catalog/manifest-all381.json'));
const entries=[];
for(const page of rows) for(const slot of page.slotAnalysis){
 if(slot.superseded)continue;
 if(selectedSHA&&page.sha!==selectedSHA)continue;
 const existing=manifest.entries.find(e=>e.uid===slot.uid&&e.costumeId===slot.id&&JSON.stringify(e).includes(page.sha));
 const [x,y,w,h]=slot.rect;
 if(corrected&&!correctionRows.some(c=>c.uid===slot.uid&&c.costumeId===slot.id&&c.sourceSHA256===page.sha))continue;
 entries.push({uid:slot.uid,id:slot.id,sha:page.sha,src:'sources/'+page.sha+'.png',
  frame:existing?.frame||{rect:slot.rect,pivot:[(slot.bodyX-x)/w,(slot.footY-y)/h],...(slot.bodyBounds?{bodyBounds:slot.bodyBounds}:{})},
  supports:slot.lowerBandComponentsNotYetFeetReviewed,flags:slot.flags,placementSource:'actual p51/catalog/manifest-model.mjs placement()'});
}
fs.writeFileSync(root+outputPrefix+(corrected?'BROWSER_CORRECTED_ENTRIES_PRIVATE_V1.json':'BROWSER_BASE_ENTRIES_PRIVATE_V1.json'),JSON.stringify(entries,null,2));
const html=`<!doctype html><meta charset="utf-8"><style>body{margin:0;background:#111a20;color:#f2f4f4;font:13px monospace}header{padding:8px;height:22px}main{display:grid;grid-template-columns:repeat(3,320px);gap:8px;padding:8px}.card{width:320px;background:#202b31}.label{padding:5px;height:42px;overflow:hidden}canvas{display:block;background:repeating-conic-gradient(#263138 0% 25%,#222d34 0% 50%) 50% / 18px 18px}</style><header></header><main></main><script>const placement=${placement.toString()};window.entries=${JSON.stringify(entries)};window.show=async(start=0,count=6,corrections=[])=>{document.querySelector('main').innerHTML='';document.querySelector('header').textContent='P51 STATIC SOURCE QA '+start+'–'+Math.min(entries.length,start+count)+' / '+entries.length;let out=[];for(let i=start;i<Math.min(entries.length,start+count);i++){const e=entries[i],c=corrections.find(c=>c.uid===e.uid&&c.costumeId===e.id&&c.sourceSHA256===e.sha),frame=c?{...e.frame,rect:c.rect,pivot:c.pivot,clipPolygon:c.clipPolygon,...(c.bodyBounds?{bodyBounds:c.bodyBounds}:{})}:e.frame;const card=document.createElement('article');card.className='card';const label=document.createElement('div');label.className='label';label.textContent=i+' '+e.uid+' / '+e.id+(c?' [CORRECTED]':'');card.append(label);let cv=document.createElement('canvas');cv.width=320;cv.height=360;card.append(cv);document.querySelector('main').append(card);const ctx=cv.getContext('2d'),im=new Image();im.src=e.src;await im.decode();const p=placement(frame,320,360);ctx.strokeStyle='#00d58a';ctx.beginPath();ctx.moveTo(0,p.groundY+.5);ctx.lineTo(320,p.groundY+.5);ctx.moveTo(160,0);ctx.lineTo(160,360);ctx.stroke();ctx.save();if(frame.clipPolygon){ctx.beginPath();frame.clipPolygon.forEach(([x,y],j)=>j?ctx.lineTo(p.x+x*p.width,p.y+y*p.height):ctx.moveTo(p.x+x*p.width,p.y+y*p.height));ctx.closePath();ctx.clip()}ctx.imageSmoothingEnabled=!e.id.includes('retro');ctx.drawImage(im,...frame.rect,p.x,p.y,p.width,p.height);ctx.restore();out.push({index:i,uid:e.uid,costumeId:e.id,sourceSHA256:e.sha,frame,placement:p});}window.rendered=out;return out};window.ready=true;</script>`;
fs.writeFileSync(root+'index.html',html);
const target=await(await fetch('http://127.0.0.1:9225/json/new?about:blank',{method:'PUT'})).json();
const ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise((r,j)=>{ws.onopen=r;ws.onerror=j});let id=0;const jobs=new Map();ws.onmessage=({data})=>{const x=JSON.parse(data);if(x.id){let j=jobs.get(x.id);if(j){jobs.delete(x.id);x.error?j.reject(Error(x.error.message)):j.resolve(x.result)}}};
const call=(method,params={})=>new Promise((resolve,reject)=>{let n=++id;jobs.set(n,{resolve,reject});ws.send(JSON.stringify({id:n,method,params}));setTimeout(()=>{if(jobs.has(n)){jobs.delete(n);reject(Error('timeout '+method))}},20000)});
const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value};
await call('Page.enable');await call('Runtime.enable');await call('Emulation.setDeviceMetricsOverride',{width:1040,height:950,deviceScaleFactor:1,mobile:false});await call('Page.navigate',{url:'http://127.0.0.1:8163/'});
for(let i=0;i<100;i++){if(await ev('!!window.ready'))break;await new Promise(r=>setTimeout(r,100))}
const rendered=[];
for(let start=0;start<entries.length;start+=6){rendered.push(...await ev('show('+start+',6,'+JSON.stringify(correctionRows)+')'));const shot=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});fs.writeFileSync(root+outputPrefix+(corrected?'corrected-render-':'render-')+String(start).padStart(3,'0')+'.png',Buffer.from(shot.data,'base64'));}
fs.writeFileSync(root+outputPrefix+(corrected?'BROWSER_CORRECTED_PLACEMENT_ACTUAL_PRIVATE_V1.json':'BROWSER_PLACEMENT_ACTUAL_PRIVATE_V1.json'),JSON.stringify({targetId:target.id,sourcePixelsWritten:false,sourceFunction:'p51/catalog/manifest-model.mjs placement',actualPlacementFunctionSource:placement.toString(),canvas:[320,360],rendered},null,2));
ws.close();console.log(JSON.stringify({targetId:target.id,entries:entries.length,screenshots:Math.ceil(entries.length/6)}));process.exit(0);
