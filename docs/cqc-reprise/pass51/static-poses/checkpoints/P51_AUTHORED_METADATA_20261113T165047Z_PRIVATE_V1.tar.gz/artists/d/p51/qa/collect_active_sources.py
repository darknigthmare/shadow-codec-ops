import json,os,hashlib,datetime
from pathlib import Path
Q=Path(__file__).resolve().parent;CAT=Path('/tmp/cqc-static-20261113/p51/catalog');(Q/'sources').mkdir(exist_ok=True)
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:return f.read()
rawindex=read(CAT/'ACTIVE_ARTIST_REGISTRATIONS_PRIVATE_V1.json');index=json.loads(rawindex);rows=[];checks=[]
for p in index['pages']:
 if '/p51/'not in p['source']:continue
 raw=read(p['metadataDocument']);j=json.loads(raw);before=os.stat(p['source']);b=read(p['source']);sha=hashlib.sha256(b).hexdigest();assert sha==p['sha256']==j['rawPNG']['sha256'];target=Q/'sources'/(sha+'.png')
 if not target.exists():
  with os.fdopen(os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o644),'wb')as f:f.write(b)
 after=os.stat(p['source']);assert (before.st_atime_ns,before.st_mtime_ns,before.st_ctime_ns)==(after.st_atime_ns,after.st_mtime_ns,after.st_ctime_ns)
 slots=[]
 for s in j['slots']:
  cid=s.get('costumeID',s.get('costumeId'))
  if cid not in p['activeCostumes']:continue
  slots.append({'uid':s.get('uid',j['uid']),'id':cid,'rect':s['sourceRect'],'bodyX':s.get('bodyDatumX'),'footY':s.get('footDatumY'),'bodyBounds':s.get('bodyBounds'),'clipPolygon':s.get('clipPolygon'),'support':s.get('support'),'status':s.get('sourceStatus'),'preferred':s.get('preferredSourceProposal')})
 rows.append({'proposal':p['metadataDocument'],'proposalSHA256':hashlib.sha256(raw).hexdigest(),'uid':p['uid'],'png':p['source'],'sha':sha,'atlas':j['atlas'],'slots':slots});checks.append({'source':p['source'],'qaExactCopy':str(target),'sha256':sha,'bytes':len(b),'sourceStatsUnchanged':True})
(Q/'PROPOSAL_SNAPSHOT_PRIVATE_V1.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');(Q/'SOURCE_COPY_RECEIPTS_PRIVATE_V1.json').write_text(json.dumps({'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'activeIndexAtUTC':index['atUTC'],'activeIndexSHA256':hashlib.sha256(rawindex).hexdigest(),'checks':checks},indent=2)+'\n')
print(json.dumps({'pages':len(rows),'poses':sum(len(p['slots'])for p in rows),'indexAtUTC':index['atUTC']}))
