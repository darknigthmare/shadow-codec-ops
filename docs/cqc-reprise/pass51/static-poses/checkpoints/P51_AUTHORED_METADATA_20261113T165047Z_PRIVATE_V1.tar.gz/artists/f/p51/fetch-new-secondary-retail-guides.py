import urllib.request,json,hashlib,concurrent.futures,re,html
from pathlib import Path

B=Path('/tmp/cqc-static-20261113/artists/f/p51/references');out=[]
urls=[('automaton-mosquito','https://automaton-media.com/articles/newsjp/20180302-63858/'),('glorbo-mosquito','https://www.glorbo.tv/post/metal-gear-solid-v-the-phantom-pain-walkthrough-mission-22-retake-the-platform'),('gosunoob-malak','https://www.gosunoob.com/metal-gear-solid-5/angel-with-broken-wings-guide/')]
def get(row):
 key,url=row;rec={'key':key,'URL':url}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0','Referer':url});r=urllib.request.urlopen(req,timeout=35);raw=r.read(2500000);p=B/(key+'.html');p.write_bytes(raw);text=raw.decode('utf-8','replace');rec.update(status=r.status,path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw));imgs=[]
  for tag in re.findall(r'<img\b[^>]*>',text,re.I):
   dic={k:html.unescape(v) for k,v in re.findall(r'''(src|data-src|srcset|data-srcset|alt)=["']([^"']*)''',tag)}
   if dic not in imgs:imgs.append(dic)
  rec['images']=imgs
 except Exception as e:rec['error']=str(e)
 return rec
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as ex:out=list(ex.map(get,urls))
p=B/'THREE_NEW_SECONDARY_RETAIL_GUIDE_HTTP_PRIVATE_V1.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
for r in out:print(json.dumps(r,ensure_ascii=False)[:11000])
