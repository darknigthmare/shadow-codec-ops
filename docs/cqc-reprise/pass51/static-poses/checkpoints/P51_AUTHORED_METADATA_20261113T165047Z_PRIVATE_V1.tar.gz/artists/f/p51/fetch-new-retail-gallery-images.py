import urllib.request,json,hashlib,concurrent.futures,re
from pathlib import Path
B=Path('/tmp/cqc-static-20261113/artists/f/p51/references');rows=json.load(open(B/'THREE_NEW_SECONDARY_RETAIL_GUIDE_HTTP_PRIVATE_V1.json'));jobs=[]
for row in rows:
 if row['key']=='automaton-mosquito':
  for i in [2,3]:jobs.append((f'automaton-mosquito-{i:03}.jpg',f'https://automaton-media.com/wp-content/uploads/2018/03/20180302-63858-{i:03}.jpg',row['URL']))
 if row['key']=='glorbo-mosquito':
  for i,x in enumerate(z for z in row['images']if 'ca60db_'in z.get('src','')and '~mv2.png' in z.get('src','')and 'Company' not in str(z)):
   u=x['src'].split('/v1/')[0]
   if '8ef9d772' in u or '8d4b898e' in u or '28cf7a68' in u or 'db536f' in u or 'c1aae5f' in u or '10868062' in u or '2f16f403' in u:jobs.append((f'glorbo-retail-{i:02}.png',u,row['URL']))
def get(job):
 name,url,page=job;r={'name':name,'URL':url,'pageURL':page,'viewed':False}
 try:
  z=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0','Referer':page}),timeout=40);raw=z.read(6000000);p=B/name;p.write_bytes(raw);r.update(status=z.status,path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
 except Exception as e:r['error']=str(e)
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as ex:out=list(ex.map(get,jobs))
p=B/'NEW_AUTOMATON_GLORBO_RETAIL_IMAGES_FETCH_PRIVATE_V1.json';p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False))
