"""Decode whole frames via seek/range only; no pixel transformation or video download."""
from pathlib import Path
import os,subprocess,hashlib,json,concurrent.futures,struct,sys
D=Path(__file__).parent
jobs=json.loads(Path(sys.argv[1]).read_text());out=Path(sys.argv[2]);assert not out.exists()
def capture(job):
 target=Path(job['path']);assert target.is_relative_to(D/'references');target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists()
 env=os.environ.copy()
 if env.get('HTTPS_PROXY'):env['http_proxy']=env['HTTPS_PROXY'];env['https_proxy']=env['HTTPS_PROXY']
 command=['ffmpeg','-hide_banner','-loglevel','error','-rw_timeout','20000000','-ss',str(job['timestampSeconds']),'-i',job['URL'],'-frames:v','1','-an','-sn','-n',str(target)]
 try:
  r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=55)
  if r.returncode:return dict(job,error=r.stderr.decode(errors='replace')[:250])
  b=target.read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n';return dict(job,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),dimensions=list(struct.unpack('>II',b[16:24])),viewed=False,operation='Whole public retail frame decoded; no crop/resize/retouch')
 except subprocess.TimeoutExpired:return dict(job,error='Range decoder timed out55s')
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:rows=list(pool.map(capture,jobs))
out.write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
