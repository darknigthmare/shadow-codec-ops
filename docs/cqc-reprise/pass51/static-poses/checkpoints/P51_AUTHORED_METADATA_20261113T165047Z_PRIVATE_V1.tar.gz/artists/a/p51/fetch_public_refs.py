"""Fetch only public bounded reference payloads; no authenticated endpoints."""
import urllib.request,hashlib,json,concurrent.futures,datetime
from pathlib import Path
D=Path(__file__).parent/'research';D.mkdir(exist_ok=True)
jobs=[('new-content-library-metadata.json','https://archive.org/metadata/youtube-gnwcYtH3YdY'),('mgcvt-uniforms.html','https://mgcvt.com/guide/mgspw/uniform.htm'),('darage-enemy-classes.html','https://darage.com/enjoygame/mgspw/db12.html'),('appmedia-uniforms.html','https://appmedia.jp/mgspw/80325952'),('appmedia-enemy-ops.html','https://appmedia.jp/mgspw/80329243')]
def one(job):
 name,url=job;r={'URL':url,'path':str(D/name),'viewed':False}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
  with urllib.request.urlopen(req,timeout=25)as f:r.update(status=f.status,contentType=f.headers.get('Content-Type'));b=f.read(4_000_001)
  assert len(b)<=4_000_000; (D/name).write_bytes(b);r.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 except Exception as e:r['error']=str(e)
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:rows=list(pool.map(one,jobs))
(D/'P51_NEW_PUBLIC_REFERENCE_FETCH_PRIVATE_V1.json').write_text(json.dumps({'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':rows},indent=2)+'\n');print(json.dumps(rows))
