#!/usr/bin/env python3
"""Read-only bounds check for the published PC DLP reader; never runs tool code.

Layout source: MGS4DirtyTools v0.7 camo_texture.read_chunks and
mgs4core.dlp_chunks, statically inspected from narrowly ranged public asset.
The PS3 bytes are not assumed to have the PC layout. Failure is a result,
not a reason to reinterpret an arbitrary slice as a texture.
"""
import argparse
import hashlib
import json
import os
import struct
from pathlib import Path


def inspect(path):
    before = path.stat()
    fd = os.open(path, os.O_RDONLY | os.O_NOATIME | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as stream:
        data = stream.read()
    after = path.stat()
    assert (before.st_atime_ns, before.st_mtime_ns) == (
        after.st_atime_ns, after.st_mtime_ns)
    row = {"path": str(path), "bytes": len(data),
           "sha256": hashlib.sha256(data).hexdigest(),
           "sourceStatsUnchanged": True, "interpretations": {}}
    for endian, label in (("<", "documented-PC-little-endian"),
                          (">", "big-endian-geometry-control-only")):
        if len(data) < 16:
            row["interpretations"][label] = {"valid": False, "reason": "short header"}
            continue
        count = struct.unpack_from(endian + "I", data, 8)[0]
        result = {"count": count, "valid": False, "chunks": []}
        if count > 256 or 16 + 16 * count > len(data):
            result["reason"] = "declared table exceeds file bounds or bounded count"
        else:
            for index in range(count):
                off = 16 + 16 * index
                ident, payload, size, pad = struct.unpack_from(endian + "IIII", data, off)
                good = payload <= len(data) and size <= len(data) - payload
                result["chunks"].append({"index": index, "ID": ident,
                    "type": data[off + 3], "offset": payload, "size": size,
                    "payloadInBounds": good})
            result["valid"] = all(x["payloadInBounds"] for x in result["chunks"])
            if not result["valid"]:
                result["reason"] = "one or more declared payloads exceed file bounds"
        row["interpretations"][label] = result
    row["decodedTextureCount"] = 0
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("files", nargs="+", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    report = {"schema": "cqc.p51.documented-pc-dlp-native-bounds/1",
              "executionOfDownloadedCode": False, "xorHeuristicUsed": False,
              "newPNGs": 0, "rows": [inspect(p) for p in args.files]}
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    main()
