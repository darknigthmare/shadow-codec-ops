"""Preserve selected inspected visual references, excluding books and private screenings."""
from pathlib import Path
import json, hashlib, os, datetime
N=Path('/tmp/cqc-static-20261113'); P=N/'p51'; OUT=P/'delivery/reference-images'
OUT.mkdir(parents=True,exist_ok=True)
mapping=json.loads((P/'official/OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json').read_text())
records={}; omitted=[]
def visit(x, historicalID):
    if isinstance(x,list):
        for a in x: visit(a,historicalID)
    elif isinstance(x,dict):
        path=x.get('path'); url=x.get('URL',x.get('url'))
        if path and url and x.get('viewed') and x.get('sha256'):
            p=Path(path); low=str(p).lower()
            # Full third-party guide pages and content-guard screenings stay local.
            if any(s in low for s in ('piggyback','/guide','guidepage','prima','/paz')) or ('guide' in p.name.lower() and '/video-captures/' not in low) or p.suffix.lower() not in ('.png','.jpg','.jpeg','.webp'):
                omitted.append({'historicalID':historicalID,'path':path,'url':url,'sha256':x['sha256'],'reason':'Locator/hash retained; book page or non-image not exported.'})
            elif p.is_file() and p.resolve()==p and p.is_relative_to(N):
                with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb') as f: raw=f.read()
                sha=hashlib.sha256(raw).hexdigest();assert sha==x['sha256'],path
                target=OUT/(sha+p.suffix.lower())
                if not target.exists():os.link(p,target)
                r=records.setdefault(sha,{'source':path,'portablePath':target.relative_to(P/'delivery').as_posix(),'bytes':len(raw),'sha256':sha,'gitBlobOID':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'uses':[]})
                r['uses'].append({'historicalID':historicalID,'url':url,'atSeconds':x.get('atSeconds'),'page':x.get('page',x.get('pageno')),'subject':x.get('subject',x.get('scope'))})
        for v in x.values():
            if isinstance(v,(dict,list)):visit(v,historicalID)
for row in mapping['rows']:
    if not row['resolutionState'].startswith('P51_') or 'GUARD' in row['resolutionState'] or 'REFUSED' in row['resolutionState']:continue
    visit(row.get('p51Evidence',{}),row['historicalID'])
for row in mapping['rows']:
    a=row.get('p51AliasProof')
    if not a:continue
    doc=Path(a['sourceDispositionPath']);d=json.loads(doc.read_text())
    visit(d,row['historicalID'])
    for ref in d.get('physicallyViewedReferences',[]):visit(dict(ref,viewed=True),row['historicalID'])
for p in (N/'artists').rglob('*ARTIFACT_PROPOSAL*.json'):
    if 'p51' not in p.parts:continue
    d=json.loads(p.read_text())
    if isinstance(d,dict) and any(s.get('classification')=='distinct-incarnation-reference-pose' for s in d.get('slots',[])):
        visit(d.get('referenceSources',[]),'distinct-incarnation:'+d['uid'])
result={'schema':'cqc.p51.selected-viewed-visual-reference-pool/1','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':list(records.values()),'images':len(records),'bytes':sum(r['bytes'] for r in records.values()),'notExportedLocators':omitted,'wholeBooksVideosPackagesExported':False,'guardedScreeningsExported':False}
(P/'publication/VIEWED_REFERENCE_IMAGE_SOURCE_INDEX_PRIVATE_V1.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('records','notExportedLocators')}))
