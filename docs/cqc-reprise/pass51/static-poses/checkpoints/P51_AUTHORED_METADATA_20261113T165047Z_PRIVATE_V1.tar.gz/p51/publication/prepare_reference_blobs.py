#!/usr/bin/env python3
"""Prepare only Root-selected P51 reference images, never move a Git reference."""
import argparse
from pin_selected_images import prepare
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workers', type=int, default=4, choices=range(1,5))
    prepare('references', parser.parse_args().workers)
