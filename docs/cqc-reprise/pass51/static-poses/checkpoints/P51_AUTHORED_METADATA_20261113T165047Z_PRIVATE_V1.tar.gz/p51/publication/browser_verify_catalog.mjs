import fs from 'node:fs';
import assert from 'node:assert/strict';
const out='/tmp/cqc-static-20261113/p51/delivery';
const target=await(await fetch('http://127.0.0.1:9225/json/new?about:blank',{method:'PUT'})).json();
const ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise((r,j)=>{ws.onopen=r;ws.onerror=j});
let id=0;const jobs=new Map(),errors=[];
ws.onmessage=({data})=>{const x=JSON.parse(data);if(x.method==='Runtime.exceptionThrown')errors.push(x.params.exceptionDetails);if(x.id){const j=jobs.get(x.id);if(j){jobs.delete(x.id);x.error?j.reject(Error(x.error.message)):j.resolve(x.result)}}};
const call=(method,params={})=>new Promise((resolve,reject)=>{const n=++id;jobs.set(n,{resolve,reject});ws.send(JSON.stringify({id:n,method,params}));setTimeout(()=>{if(jobs.has(n)){jobs.delete(n);reject(Error('timeout '+method))}},30000)});
const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value};
await call('Runtime.enable');await call('Page.enable');await call('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});await call('Page.navigate',{url:'http://127.0.0.1:8155/'});
for(let n=0;n<100;n++){if(await ev('document.documentElement.dataset.catalogReady==="true"'))break;await new Promise(r=>setTimeout(r,100))}
assert(await ev('document.documentElement.dataset.catalogReady==="true"'));
const cases=[];
async function filter(query,origin='official',family=''){
 const result=await ev(`(async()=>{document.getElementById('search').value=${JSON.stringify(query)};document.getElementById('origin').value=${JSON.stringify(origin)};document.getElementById('family').value=${JSON.stringify(family)};document.getElementById('search').dispatchEvent(new Event('input',{bubbles:true}));await Promise.all([...document.querySelectorAll('.stage')].map(s=>s._load?.()));return{query:${JSON.stringify(query)},cards:document.querySelectorAll('.card').length,loaded:document.querySelectorAll('.stage[data-loaded="true"]').length,sources:document.querySelectorAll('.stage canvas').length,errors:document.querySelectorAll('.stage.error').length,overflow:document.documentElement.scrollWidth>innerWidth,summary:document.getElementById('summary').textContent,keys:[...document.querySelectorAll('.card')].map(c=>c.dataset.key)}})()`);
 assert(result.cards>0,query);assert.equal(result.errors,0,query);assert.equal(result.loaded,result.sources,query);assert.equal(result.overflow,false,query);cases.push(result);return result;
}
await filter('Prisonnier');await filter('borgne');await filter('Ninja');await filter('Smoking');await filter('Malak');await filter('Mosquito','original');await filter('XOF','original');await filter('Captif secouru');await filter('Quiet');await filter('roquettes');await filter('Ballista');
let shot=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});fs.writeFileSync(out+'/P51_BROWSER_DESKTOP_PRIVATE_V1.png',Buffer.from(shot.data,'base64'));
await filter('Snake','official');
await ev(`document.getElementById('next').click();Promise.all([...document.querySelectorAll('.stage')].map(s=>s._load?.()))`);
assert.equal(await ev('document.querySelectorAll(".stage.error").length'),0);
await ev(`document.getElementById('previous').click();Promise.all([...document.querySelectorAll('.stage')].map(s=>s._load?.()))`);
for(const q of ['Teliko','Otacon','Snake','Quiet','Walker','Otacon','Quiet'])await filter(q);
await call('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});await filter('Quiet');
shot=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});fs.writeFileSync(out+'/P51_BROWSER_MOBILE_PRIVATE_V1.png',Buffer.from(shot.data,'base64'));
assert.equal(errors.length,0,JSON.stringify(errors));
const manifestSHA256=await ev(`(async()=>{const b=await(await fetch('manifest.json',{cache:'no-store'})).arrayBuffer();const h=await crypto.subtle.digest('SHA-256',b);return [...new Uint8Array(h)].map(x=>x.toString(16).padStart(2,'0')).join('')})()`);
const report={manifestSHA256,atUTC:new Date().toISOString(),url:'http://127.0.0.1:8155/',cases,desktop:[1440,1000],mobile:[390,844],sourceLoadErrors:0,uncaughtBrowserExceptions:errors,filterPaginationAndRepeatedSourceLoads:true,sourcePNGsModified:false,newAnimations:0,runtimeFilesModified:0};
fs.writeFileSync(out+'/P51_BROWSER_VERIFICATION_PRIVATE_V1.json',JSON.stringify(report,null,2)+'\n');
ws.close();console.log(JSON.stringify({cases:cases.length,sourceLoadErrors:0,uncaughtBrowserExceptions:0,horizontalOverflow:false}));process.exit(0);
