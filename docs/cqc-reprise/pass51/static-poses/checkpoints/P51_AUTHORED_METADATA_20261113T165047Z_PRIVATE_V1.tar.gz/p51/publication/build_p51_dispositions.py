#!/usr/bin/env python3
"""Append P51 evidence to frozen P50 dispositions; execute only after Root refresh."""
from pathlib import Path
import argparse
import collections
import copy
import datetime
import hashlib
import json
import os

N = Path('/tmp/cqc-static-20261113')
P = N / 'p51'

def exact(path):
    with os.fdopen(os.open(path, os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb') as stream:
        before=os.fstat(stream.fileno()); raw=stream.read(); after=os.fstat(stream.fileno())
    assert before==after and path.stat()==before
    return raw

def build(base, mapping, reports):
    previous={r['historicalID']:r for r in base['rows']}
    current={r['historicalID']:r for r in mapping['rows']}
    assert len(previous)==len(current)==416 and set(previous)==set(current)
    rows=[]
    for historical_id,old in previous.items():
        row=copy.deepcopy(old); now=current[historical_id]
        row['p50DispositionPreserved']={k:copy.deepcopy(old.get(k)) for k in
            ('currentMappingState','referenceDisposition','reason')}
        row['currentMappingState']=now['resolutionState']
        if now['resolutionState'].startswith('P51_'):
            state=now['resolutionState']; row['reason']=now['resolutionReason']
            row['referenceDisposition']=(
                'P51_IMAGE_GENERATION_REFUSED_NO_PNG' if 'REFUSED' in state else
                'P51_GUARDED_WITHOUT_GENERATION' if 'GUARD' in state else
                'P51_STATIC_SOURCE_CORRECTION_PENDING' if 'CORRECTION_PENDING' in state else
                'P51_EXACT_SAME_UID_APPEARANCE_REUSED' if 'REUSED' in state else
                'P51_QUALIFIED_STATIC_SOURCE_DRAWN_REVIEW_PENDING')
            row['p51Evidence']=copy.deepcopy(now.get('p51Evidence',{}))
            if now.get('newSource'): row['p51NewSource']=copy.deepcopy(now['newSource'])
            if now.get('p51AliasProof'): row['p51AliasProof']=copy.deepcopy(now['p51AliasProof'])
            if now.get('p51GenerationGuard'): row['p51Guard']=copy.deepcopy(now['p51GenerationGuard'])
        if now.get('p50RelatedDistinctIncarnation'):
            row['p50RelatedDistinctIncarnation']=copy.deepcopy(now['p50RelatedDistinctIncarnation'])
            if now['resolutionState']=='REFERENCE_AND_STATIC_SOURCE_PENDING':
                row['reason']=now['resolutionReason']
                row['referenceDisposition']='HISTORICAL_PERIOD_ERROR_DISTINCT_ORIGINAL_ALREADY_AVAILABLE_IN_P50'
        row['p51ResearchReports']=reports.get(historical_id,[])
        # Every old authored/evidence field remains, except these three current views.
        overwritten={'currentMappingState','referenceDisposition','reason'}
        assert all(row[key]==value for key,value in old.items() if key not in overwritten)
        rows.append(row)
    return {'schema':'cqc.p51.official-reference-dispositions/1',
            'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'inputMap':str(P/'official/OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json'),
            'counts':dict(collections.Counter(r['currentMappingState'] for r in rows)),
            'p50SummaryPreserved':copy.deepcopy(mapping.get('p50Summary',{})),
            'p51Summary':copy.deepcopy(mapping.get('p51Summary',{})),
            'qualification':'Frozen P50 research and all P49/P50 evidence fields retained. Current P51 source/frame map is authoritative; P51 artist reports are evidence snapshots, not automatic admission. Existing hospital XOF1984 belongs to P50 baseline. One static pose only; no animation/runtime admission.',
            'rows':rows}

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--dry-run',action='store_true');args=parser.parse_args()
    base_path=P/'base/OFFICIAL416_REFERENCE_DISPOSITIONS_PRIVATE_V1.json'
    map_path=P/'official/OFFICIAL416_HISTORICAL_TO_CURRENT_ID_MAP_PRIVATE_V1.json'
    base_raw=exact(base_path);map_raw=exact(map_path);reports={}
    for path in sorted((N/'artists').rglob('*.json')):
        if 'p51' not in path.parts or not any(k in path.name for k in ('DISPOSITION','HANDOFF')):continue
        try:
            raw=exact(path); data=json.loads(raw)
        except (OSError,ValueError):continue
        if not isinstance(data,dict):continue
        for row in data.get('rows',[]):
            if not isinstance(row,dict) or not row.get('historicalID'):continue
            reports.setdefault(row['historicalID'],[]).append({
                'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),
                'reportedStatus':row.get('status',row.get('resolutionState')),
                'reason':row.get('reason',row.get('resolutionReason')),
                'evidenceURLs':row.get('evidenceURLs',row.get('referenceURLs',[])),
                'proposalPath':row.get('proposalPath'),'targetCostumeID':row.get('targetCostumeID')})
    result=build(json.loads(base_raw),json.loads(map_raw),reports)
    result['inputPins']=[{'path':str(path),'sha256':hashlib.sha256(raw).hexdigest()}
                         for path,raw in ((base_path,base_raw),(map_path,map_raw))]
    assert exact(base_path)==base_raw and exact(map_path)==map_raw, 'Inputs changed during reporting; rerun.'
    if not args.dry_run:
        target=P/'official/OFFICIAL416_REFERENCE_DISPOSITIONS_PRIVATE_V1.json'
        temp=target.with_suffix('.json.tmp');temp.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');temp.replace(target)
    print(json.dumps({'dryRun':args.dry_run,'rows':len(result['rows']),'counts':result['counts'],
                      'p51ResearchReports':sum(map(len,reports.values()))},ensure_ascii=False))

if __name__=='__main__': main()
