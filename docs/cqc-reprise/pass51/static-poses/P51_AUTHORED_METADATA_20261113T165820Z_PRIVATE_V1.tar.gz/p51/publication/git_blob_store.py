"""Exact binary/text Git object preparation; branch mutation belongs to one publisher."""
import pathlib,json,os,subprocess,tempfile,hashlib,base64
N=pathlib.Path('/tmp/cqc-static-20261113');PUB=N/'p51/publication';REPO='darknigthmare/shadow-codec-ops'
def read(p):
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW),'rb')as f:before=os.fstat(f.fileno());b=f.read();after=os.fstat(f.fileno())
 assert before==after and p.stat()==before;return b
def _api_once(endpoint,payload=None,method=None):
 args=['gh','api','repos/'+REPO+'/'+endpoint];temp=None
 try:
  if payload is not None:
   with tempfile.NamedTemporaryFile(mode='w',dir=PUB,suffix='.json',delete=False)as f:json.dump(payload,f);temp=f.name
   args+=['--method',method or'POST','--input',temp]
  elif method:args+=['--method',method]
  p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
  if p.returncode:raise RuntimeError(p.stderr.decode()[:1000])
  return json.loads(p.stdout)
 finally:
  if temp:os.unlink(temp)
def api(endpoint,payload=None,method=None):
 # GitHub occasionally truncates a first large GET response. Retrying the same
 # immutable read is safe; mutations are never replayed automatically.
 import time
 for attempt in range(3):
  try:return _api_once(endpoint,payload,method)
  except (RuntimeError,json.JSONDecodeError)as exc:
   readonly=payload is None and method in(None,'GET')
   incomplete='unexpected end of JSON input'in str(exc)or isinstance(exc,json.JSONDecodeError)
   if not readonly or not incomplete or attempt==2:raise
   print('RETRY_INCOMPLETE_GITHUB_READ',endpoint,'attempt',attempt+1,flush=True)
   time.sleep(.3*(attempt+1))
def known_blobs():
 d=json.loads(read(N/'reuse-private/BASE72807_GIT_TREE_PRIVATE_V1.json'));known={r['sha']for r in d['tree']if r['type']=='blob'}
 # P51 starts from the completed P49 delivery: reuse its exact immutable blobs,
 # including portable sources whose individual preparation receipt is absent.
 p49tree=N/'publication/FINAL_DELIVERY_FULL_GIT_TREE_PRIVATE_V1.json'
 if p49tree.exists():
  prior=json.loads(read(p49tree));assert not prior.get('truncated')
  known.update(r['sha']for r in prior['tree']if r['type']=='blob')
 p50tree=N/'p50/publication/FINAL_DELIVERY_FULL_GIT_TREE_PRIVATE_V1.json'
 if p50tree.exists():
  prior=json.loads(read(p50tree));assert not prior.get('truncated');known.update(r['sha']for r in prior['tree']if r['type']=='blob')
 for suffix in ['*-RAW_BLOB_READBACK_PRIVATE_V1.json','*-PORTABLE_BLOB_READBACK_PRIVATE_V1.json','*-BINARY_SOURCE_BLOB_READBACK_PRIVATE_V1.json']:
  for p in list(PUB.glob(suffix))+list((N/'publication').glob(suffix))+list((N/'p50/publication').glob(suffix)):
   r=json.loads(read(p))
   if r.get('exactReadback'):known.add(r['gitBlobOID'])
 return known
def pin_file(path,known=None):
 p=pathlib.Path(path).absolute();assert p.resolve(strict=True)==p and(p.is_relative_to(N)or p.is_relative_to(pathlib.Path('/workspace/cqc-static-20261113/checkpoints')));b=read(p);assert len(b)<50*1024*1024;sha=hashlib.sha256(b).hexdigest();oid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();r={'source':str(p),'bytes':len(b),'sha256':sha,'gitBlobOID':oid,'branchReferenceMoved':False}
 if oid in(known if known is not None else known_blobs()):return dict(r,gitObjectVerified=True,proof='Exact local Git blob hash matches immutable tree or prior binary readback receipt.',uploadedNow=False)
 receipt=PUB/(sha+'-BINARY_SOURCE_BLOB_READBACK_PRIVATE_V1.json')
 if receipt.exists():
  old=json.loads(read(receipt));assert old['gitBlobOID']==oid and old['exactReadback'];return dict(r,gitObjectVerified=True,proof=str(receipt),uploadedNow=False)
 created=api('git/blobs',{'encoding':'base64','content':base64.b64encode(b).decode()});assert created['sha']==oid;got=api('git/blobs/'+oid);assert got['encoding']=='base64'and base64.b64decode(got['content'])==b;r.update(exactReadback=True);receipt.write_text(json.dumps(r,indent=2)+'\n');return dict(r,gitObjectVerified=True,proof=str(receipt),uploadedNow=True)
