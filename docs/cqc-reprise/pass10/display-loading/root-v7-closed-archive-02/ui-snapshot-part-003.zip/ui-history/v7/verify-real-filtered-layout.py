"""Actual V7 layout cases; the distinct V4 loading proof stays closed."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import argparse,hashlib,importlib.util,json,datetime
HERE=Path(__file__).resolve().parent
R=Path('/workspace/cqc-game-working/cqc-versus-v056');S=Path('/workspace/shadow-codec-recovered')
SHA='67f45e65e504cfee9f9a7cc7cd014da735e9a05a651ca1040e6187b541eb4e06'
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def guard():
 out=[]
 for name in ['modules/unified-versus-v055.html','src/cqc-sprite-renderer.js','src/cqc-sprite-catalog.js','src/chronicles-portraits-v056.js','src/chronicles-art-v056.js','src/chronicles-cinema-v056.js']:
  a=pin(R/name);b=pin(S/'public/cqc'/name);assert a['sha256']==b['sha256'];out.extend([a,b])
  if name.startswith('modules/'):assert a['sha256']==SHA
 out.append(pin(S/'public/cqc/runtime-manifest.json'))
 count=0
 for row in json.loads(Path('/workspace/cqc-pass9-final-qa/actual43-source-freeze.json').read_text())['files']:
  p=Path(row['path'])
  if p.suffix.lower()=='.png':assert pin(p)['sha256']==row['sha256'];count+=1
 assert count==271
 return out
GEOMETRY=r'''(()=>{
 const rect=e=>{if(!e)return null;const r=e.getBoundingClientRect();return{left:r.left,top:r.top,right:r.right,bottom:r.bottom,width:r.width,height:r.height};};
 const api=window.__CQC055Versus;
 const cards=[...document.querySelectorAll('.fighter-card')].map(card=>{const canvas=card.querySelector('canvas'),box=rect(card),c=rect(canvas),name=card.querySelector('b').textContent,f=api.fighters.find(f=>f.name===name),s=getComputedStyle(canvas),roster=card.parentElement,r=rect(roster),center={x:c.left+c.width/2,y:c.top+c.height/2},hit=document.elementFromPoint(center.x,center.y);return{name,uid:f?.uid,native:!!window.CQC_COMBAT_SPRITES.has(f?.uid),state:canvas.dataset.artState,card:box,canvas:c,buffer:{width:canvas.width,height:canvas.height},objectFit:s.objectFit,boxAnisotropy:(c.width/canvas.width)/(c.height/canvas.height),insideRoster:box.left>=r.left-.1&&box.right<=r.right+.1,center:{...center,insideViewport:center.x>=0&&center.y>=0&&center.x<innerWidth&&center.y<innerHeight,insideVisibleRoster:center.x>=r.left&&center.x<r.right&&center.y>=r.top&&center.y<r.bottom,reached:hit===card||card.contains(hit)}};});
 const roster=document.querySelector('.roster'),gallery=document.querySelector('.stage-preview'),canvas=document.querySelector('#stagePreview'),cs=getComputedStyle(canvas),g=rect(gallery),c=rect(canvas),title=rect(gallery.querySelector('.stage-title')),scale=Math.min(c.width/canvas.width,c.height/canvas.height);
 return{viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio},query:document.querySelector('#search').value,resultCount:cards.length,page:document.querySelector('#pageLabel').textContent,center:rect(document.querySelector('.center')),rosterWrap:rect(document.querySelector('.roster-wrap')),roster:{rect:rect(roster),columns:getComputedStyle(roster).gridTemplateColumns,rows:getComputedStyle(roster).gridTemplateRows,overflow:getComputedStyle(roster).overflowY,scrollHeight:roster.scrollHeight,clientHeight:roster.clientHeight,scrollTop:roster.scrollTop},cards,gallery:{rect:g,canvas:c,title,fit:cs.objectFit,display:cs.display,painted:{width:canvas.width*scale,height:canvas.height*scale},titlePosition:getComputedStyle(gallery.querySelector('.stage-title')).position,meta:document.querySelector('#galleryMeta').textContent},documentScroll:{clientWidth:document.documentElement.clientWidth,scrollWidth:document.documentElement.scrollWidth},launch:rect(document.querySelector('#launch'))};
})()'''
FIT=r'''(()=>{
 const card=document.querySelector('.fighter-card'),visible=card.querySelector('canvas'),api=window.__CQC055Versus,f=api.fighters.find(f=>f.uid==='core__crying_wolf');
 const canvas=document.createElement('canvas');canvas.width=visible.width;canvas.height=visible.height;const c=canvas.getContext('2d',{willReadFrequently:true}),drawImage=c.drawImage.bind(c),draws=[];
 c.drawImage=function(...args){const m=c.getTransform();draws.push({matrix:{a:m.a,b:m.b,c:m.c,d:m.d},source:args.slice(1,5),destination:args.slice(5)});return drawImage(...args);};
 const padding=Math.min(canvas.width,canvas.height)*.055,drawn=window.CQC_COMBAT_SPRITES.drawFitted(c,f,{x:0,y:0,width:canvas.width,height:canvas.height,padding},-1,{time:0,actionTime:0});
 const pixels=c.getImageData(0,0,canvas.width,canvas.height).data;let left=canvas.width,top=canvas.height,right=-1,bottom=-1,count=0;
 for(let y=0;y<canvas.height;y++)for(let x=0;x<canvas.width;x++)if(pixels[(y*canvas.width+x)*4+3]){left=Math.min(left,x);top=Math.min(top,y);right=Math.max(right,x);bottom=Math.max(bottom,y);count++;}
 return{uid:f.uid,drawn,width:canvas.width,height:canvas.height,padding,alpha:{left,top,right,bottom,count},draws};
})()'''
def main(a):
 out=Path(a.output);out.mkdir(exist_ok=False);before=guard()
 spec=importlib.util.spec_from_file_location('pass10_v7_common','/workspace/cqc-pass6-browser-common.py');C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)
 rows=[];commands=[];photos=[];sessions=[];errors=[];failure=None
 def record(b,name,code=GEOMETRY):
  value=b.evaluate(code);rows.append({'name':name,'result':value});return value
 def shot(b,name):
  p=out/(name+'.jpg');b.call('screenshot',str(p));photos.append(pin(p))
 def check_geometry(g,n):
  assert g['resultCount']==n,(n,g['resultCount'],g['page'])
  assert g['documentScroll']['scrollWidth']<=g['documentScroll']['clientWidth']+1,g['documentScroll']
  assert g['center']['bottom']<=g['viewport']['height']+.5,g['center']
  assert g['launch']['top']>=0 and g['launch']['bottom']<=g['viewport']['height']+.5,g['launch']
  for card in g['cards']:
   assert card['insideRoster'] and card['objectFit']=='contain' and abs(card['boxAnisotropy']-1)<.025,card
   if card['center']['insideViewport'] and card['center']['insideVisibleRoster']:assert card['center']['reached'],card
  if n==1:assert g['cards'][0]['card']['width']>=g['roster']['rect']['width']-2,g
  if g['viewport']['width']==390:
   heights=[float(v.removesuffix('px')) for v in g['roster']['rows'].split()]
   assert all(v>=91.99 for v in heights),g['roster']
   if n in (1,2,6):assert abs(sum(heights)+7*(len(heights)-1)-g['roster']['rect']['height'])<2,g['roster']
 def wait_native(b):b.evaluate("(async()=>{for(let i=0;i<100;i++){const c=document.querySelector('.fighter-card canvas');if(c?.dataset.artState==='ready')return true;await new Promise(r=>setTimeout(r,100));}throw Error('Native wolf portrait timeout')})()")
 for width,height,dpr in [(1366,768,1),(390,844,3)]:
  b=C.Browser(out,'cqc-pass10-v7-layout-'+str(width));sessions.append(b.session);b.env['AGENT_BROWSER_SCREENSHOT_FORMAT']='jpeg';b.env['AGENT_BROWSER_SCREENSHOT_QUALITY']='45';b.prefix[b.prefix.index('--args')+1]='--no-sandbox,--disk-cache-size=1,--media-cache-size=1'
  try:
   b.call('set','viewport',str(width),str(height),str(dpr));b.call('open',a.base.rstrip('/')+'/cqc/modules/unified-versus-v055.html');b.call('wait','--load','networkidle')
   served=record(b,str(width)+'-actual-served-module-byte-pin',"(async()=>{const r=await fetch(location.href,{cache:'reload'}),b=await r.arrayBuffer(),h=await crypto.subtle.digest('SHA-256',b);return{url:location.href,status:r.status,bytes:b.byteLength,sha256:[...new Uint8Array(h)].map(v=>v.toString(16).padStart(2,'0')).join('')};})()");assert served['status']==200 and served['sha256']==SHA and served['bytes']==3461717,served
   b.evaluate("(()=>{window.__pass10LayoutInputs=[];for(const kind of ['wheel','pointerdown','click'])addEventListener(kind,e=>{const c=e.target.closest?.('.fighter-card');window.__pass10LayoutInputs.push({kind,trusted:e.isTrusted,deltaY:e.deltaY??null,name:c?.querySelector('b')?.textContent??null});},{capture:true,passive:true});return true;})()")
   b.call('fill','#search','CRYING WOLF');wait_native(b);b.call('click','.fighter-card');b.evaluate('new Promise(resolve=>setTimeout(()=>resolve(true),150))')
   g=record(b,str(width)+'-one-native-wolf-card');check_geometry(g,1);shot(b,str(width)+'-one-native-wolf-card')
   fit=record(b,str(width)+'-native-wolf-uniform-full-frame-alpha',FIT);assert fit['drawn'] and fit['alpha']['count']>0
   assert fit['alpha']['left']>=fit['padding']-2 and fit['alpha']['top']>=fit['padding']-2
   assert fit['alpha']['right']<=fit['width']-fit['padding']+1 and fit['alpha']['bottom']<=fit['height']-fit['padding']+1
   for draw in fit['draws']:
    m=draw['matrix'];src=draw['source'];dst=draw['destination'];assert abs(abs(m['a'])-abs(m['d']))<1e-7 and abs(m['b'])<1e-7 and abs(m['c'])<1e-7;assert abs(dst[2]/src[2]-dst[3]/src[3])<1e-7
   b.call('fill','#search','CRYING');b.evaluate('new Promise(resolve=>setTimeout(()=>resolve(true),150))');g=record(b,str(width)+'-two-real-filter-results');check_geometry(g,2);shot(b,str(width)+'-two-real-filter-results')
   b.call('fill','#search','BIG BOSS');b.evaluate('new Promise(resolve=>setTimeout(()=>resolve(true),150))');g=record(b,str(width)+'-six-real-filter-results');check_geometry(g,6);shot(b,str(width)+'-six-real-filter-results')
   b.call('fill','#search','');b.evaluate('new Promise(resolve=>setTimeout(()=>resolve(true),150))');g=record(b,str(width)+'-full-real-page-before-scroll');check_geometry(g,18)
   if width==390:
    assert g['roster']['scrollHeight']>g['roster']['clientHeight'],g['roster']
    b.call('mouse','move',str(g['roster']['rect']['left']+g['roster']['rect']['width']/2),str(g['roster']['rect']['top']+g['roster']['rect']['height']/2));b.call('mouse','wheel','400');b.evaluate('new Promise(resolve=>setTimeout(()=>resolve(true),150))');g=record(b,str(width)+'-full-real-page-after-trusted-scroll');check_geometry(g,18)
    inputs=record(b,str(width)+'-actual-trusted-wheel-event',"window.__pass10LayoutInputs.filter(e=>e.kind==='wheel')");assert inputs and all(e['trusted'] for e in inputs),inputs
    assert g['roster']['scrollTop']>0,g['roster'];assert g['cards'][-1]['center']['insideVisibleRoster'] and g['cards'][-1]['center']['reached'],g['cards'][-1]
    shot(b,str(width)+'-full-page-trusted-scroll-last-card')
   b.call('click','.fighter-card:last-child');inputs=record(b,str(width)+'-last-card-actual-trusted-click',"window.__pass10LayoutInputs.filter(e=>e.kind==='click')");assert inputs[-1]['trusted'],inputs;g=record(b,str(width)+'-full-page-last-card-trusted-selection');check_geometry(g,18)
   b.call('click','#openGallery');b.call('wait','--load','networkidle');g=record(b,str(width)+'-stage-gallery-whole-native-image')
   preview=g['gallery'];assert preview['fit']=='contain' and preview['display']=='block';assert abs(preview['painted']['width']/preview['painted']['height']-16/9)<1e-6
   if width==390:
    assert preview['titlePosition']=='static',preview;assert preview['title']['top']>=preview['canvas']['bottom']-.5,preview
    assert preview['title']['bottom']<=preview['rect']['bottom']+.5,preview
   shot(b,str(width)+'-stage-gallery-whole-native-image');b.call('click','#closeGallery')
   click=record(b,str(width)+'-actual-buttons-reachable',"(()=>{const c=document.querySelector('.fighter-card:last-child'),r=c.getBoundingClientRect(),e=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);return{reached:e===c||c.contains(e),name:c.innerText}})()");assert click['reached']
   error=b.call('errors');errors.append({'session':b.session,'result':error});assert not error.get('errors'),error
  except Exception as e:failure=repr(e)
  finally:b.close();commands.extend(b.commands)
  if failure:break
 after=guard();assert before==after
 proof={'status':'failed' if failure else 'passed','failure':failure,'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rootReady':a.root_ready,'actualModuleSHA256':SHA,'tool':pin(Path(__file__)),'sourceBefore':before,'sourceAfter':after,'native271PNGByteExact':True,'ownedSessions':sessions,'observations':rows,'commands':commands,'screenshots':photos,'pageErrors':errors,'cleanup':'All owned browser sessions closed.','qualification':['Actual V7 layout cases use native browser fill/click through the normal filter and selection UI; counts1/2/6 and the full18 page are real results; mobile filtered rows fill available height, while the full page keeps92px minimum rows and scrolls through a native browser gesture.','Native full equipment/body bounds use the real renderer on a transparent detached QA canvas; uniform drawImage transforms are observed without replacing any UI drawing function.','Mobile stage title participates in flow below the whole16/9 image, so it does not cover native scene actors.','No application/source/PNG/Git/deployment mutation, CSS injection, mocked network or fake engine frames.','Loading/cancel/pause/retry behavior remains qualified by the separate closed V4 proof; all inline JS are exactly unchanged in V7.']}
 p=out/'REAL_FILTERED_LAYOUT_VERIFICATION.json';p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':proof['status'],'failure':failure,'observations':len(rows),'commands':len(commands),'proof':pin(p),'screenshots':photos},ensure_ascii=False,indent=2))
 if failure:raise SystemExit(1)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');p.add_argument('--root-ready');p.add_argument('--base',default='http://127.0.0.1:5179');p.add_argument('--output',default=str(HERE/'actual-filtered-layout-01'));a=p.parse_args()
 if not a.execute:print(json.dumps({'status':'prepared-not-executed','requiresRootV7SyncReady':True,'moduleSHA256':SHA}));raise SystemExit(0)
 assert a.root_ready
 main(a)
