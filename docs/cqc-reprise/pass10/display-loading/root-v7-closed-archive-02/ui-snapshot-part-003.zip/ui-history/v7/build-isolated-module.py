"""PASS10 V7 prepares only an isolated candidate; Root owns final promotion."""
from pathlib import Path
import hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parent
BASE=ROOT/'closed-before/modules/unified-versus-v055.html'
SHA='e4c5739b2ee30f4467819e3cdc06dc4f2ccab26d9857e9797f9fcf185b2a740d'
raw=BASE.read_bytes();assert hashlib.sha256(raw).hexdigest()==SHA
before=raw.decode();old='.center{min-width:0;display:grid;grid-template-rows:auto 1fr auto;gap:10px}'
new='.center{min-width:0;min-height:0;display:grid;grid-template-rows:auto 1fr auto;gap:10px}'
assert before.count(old)==1
text=before.replace(old,new,1)
scripts=re.findall(r'<script(?:\s[^>]*)?>([\s\S]*?)</script>',before);assert scripts==re.findall(r'<script(?:\s[^>]*)?>([\s\S]*?)</script>',text)
preserved=[];decoder=json.JSONDecoder()
for name,prefix in [('RAW_FIGHTERS','const FIGHTERS='),('RAW_FIN','globalThis.CQC_FINISHERS_053 = ')]:
 i=before.index(prefix)+len(prefix);_,end=decoder.raw_decode(before[i:]);part=before[i:i+end];assert part in text
 preserved.append({'name':name,'bytes':len(part.encode()),'sha256':hashlib.sha256(part.encode()).hexdigest()})
engine=next(s for s in scripts if s.strip());preserved.append({'name':'RAW_INLINE_ENGINE','bytes':len(engine.encode()),'sha256':hashlib.sha256(engine.encode()).hexdigest()})
syntax=[]
for index,script in enumerate(scripts):
 if not script.strip():continue
 result=subprocess.run(['node','--check','--input-type=commonjs'],input=script,text=True,capture_output=True);assert result.returncode==0
 syntax.append({'script':index,'bytes':len(script.encode()),'sha256':hashlib.sha256(script.encode()).hexdigest(),'exitCode':result.returncode})
p=ROOT/'candidate/modules/unified-versus-v055.html';p.parent.mkdir(parents=True,exist_ok=True)
with p.open('xb') as out:out.write(text.encode())
b=p.read_bytes()
receipt={'schema':'cqc-pass10-isolated-module-candidate/v7','status':'PREPARED_NOT_PROMOTED','baseline':{'path':str(BASE),'bytes':len(raw),'sha256':SHA},'candidate':{'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'gitBlob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()},'changes':[{'name':'Constrain the center grid minimum height so full mobile lists scroll inside the available roster area','before':old,'after':new}],'allInlineScriptsByteIdenticalToV6':True,'allInlineScriptsByteIdenticalToV5':True,'allInlineScriptsByteIdenticalToV4':True,'nodeSyntax':syntax,'preservedLiteralRegions':preserved,'RWritten':False,'SWritten':False,'nativePNGEdited':False,'previousCandidateRetained':str(ROOT.parent/'v6/candidate/modules/unified-versus-v055.html'),'previousProofRetained':str(ROOT.parent/'v6/actual-filtered-layout-01/REAL_FILTERED_LAYOUT_VERIFICATION.json'),'limits':['Final candidate awaits Root promotion and S sync-ready.','Real V7 QA must verify filtered1/2/6 rows fill height and the full page retains minimum92px with working scroll.','The roster and roster-wrap already have min-height:0; this change completes that constraint at their parent center grid.','The closed V4 loading proof qualifies the identical JS; it does not certify this new layout.']}
p=ROOT/'ISOLATED_CANDIDATE_RECEIPT.json'
with p.open('x') as out:json.dump(receipt,out,ensure_ascii=False,indent=2);out.write('\n')
print(json.dumps({'candidate':receipt['candidate'],'receipt':str(p),'receiptSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'inlineScriptsExact':True,'syntaxChecks':len(syntax),'preserved':preserved},indent=2))
