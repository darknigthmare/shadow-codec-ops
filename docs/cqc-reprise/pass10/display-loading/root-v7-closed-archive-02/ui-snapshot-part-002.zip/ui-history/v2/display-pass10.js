// PASS10 changes presentation and preparation, never actor balance or combat coordinates.
const portraitRefreshRequestsReprise=new WeakMap(),portraitTargetsPass10=new WeakMap(),portraitCanvasesPass10=new Set(),stageRefreshRequestsPass10=new WeakMap();
const portraitOptionsPass10={action:'idle',face:-1};
let portraitResizeFramePass10=0,galleryFramePass10=0,matchRequestPass10=null,matchRequestSequencePass10=0;
const portraitResizeObserverPass10=typeof ResizeObserver==='function'?new ResizeObserver(entries=>{
 for(const {target} of entries){if(!target.isConnected){releasePortraitPass10(target);continue;}const f=portraitTargetsPass10.get(target);if(f)drawPortrait(target,f);}
}):null;
function hasNativePortraitPass10(uid){const api=window.CQC_COMBAT_SPRITES;return api?.has?api.has(uid):api?.status(uid)?.renderer==='png';}
function registerPortraitPass10(canvas,f){
 portraitTargetsPass10.set(canvas,f);
 if(!portraitCanvasesPass10.has(canvas)){portraitCanvasesPass10.add(canvas);portraitResizeObserverPass10?.observe(canvas);}
 const rect=canvas.getBoundingClientRect?.()||{width:0,height:0},dpr=Math.max(1,Math.min(3,window.devicePixelRatio||1));
 if(rect.width>0&&rect.height>0){const w=Math.max(1,Math.round(rect.width*dpr)),h=Math.max(1,Math.round(rect.height*dpr));if(canvas.width!==w)canvas.width=w;if(canvas.height!==h)canvas.height=h;}
 canvas.setAttribute?.('role','img');
}
function releasePortraitPass10(canvas){portraitResizeObserverPass10?.unobserve(canvas);portraitCanvasesPass10.delete(canvas);portraitTargetsPass10.delete(canvas);portraitRefreshRequestsReprise.delete(canvas);}
function releaseRosterPortraitsPass10(){for(const canvas of $('#roster').querySelectorAll('canvas'))releasePortraitPass10(canvas);}
addEventListener('resize',()=>{cancelAnimationFrame(portraitResizeFramePass10);portraitResizeFramePass10=requestAnimationFrame(()=>{for(const canvas of portraitCanvasesPass10){if(!canvas.isConnected){releasePortraitPass10(canvas);continue;}const f=portraitTargetsPass10.get(canvas);if(f)drawPortrait(canvas,f);}});});
function portraitStatusPass10(canvas,f,state){
 const holder=canvas.parentElement;if(!holder)return;let label=holder.querySelector(':scope > .portrait-status-pass10');
 if(state==='ready'||state==='legacy'){label?.remove();canvas.dataset.artState=state;canvas.setAttribute('aria-label',f.name);return;}
 if(!label){label=document.createElement('span');label.className='portrait-status-pass10';label.setAttribute('role','status');label.setAttribute('aria-live','polite');holder.appendChild(label);}
 label.textContent=state==='failed'?'Portrait indisponible':'Chargement du portrait…';
 canvas.dataset.artState=state;canvas.setAttribute('aria-label',f.name+' · '+label.textContent);
}
function refreshPortraitWhenReadyReprise(canvas,f){
 const token={uid:f.uid};portraitRefreshRequestsReprise.set(canvas,token);
 const sprites=window.CQC_COMBAT_SPRITES,status=sprites?.status(f.uid,portraitOptionsPass10);
 if(!sprites?.whenReady||status?.renderer!=='png'||status.ready||!status.states?.some(s=>s==='loading'||s==='not-requested'))return;
 sprites.whenReady(f.uid,portraitOptionsPass10).then(()=>{if(canvas.isConnected&&portraitRefreshRequestsReprise.get(canvas)===token)drawPortrait(canvas,f);}).catch(()=>{if(canvas.isConnected&&portraitRefreshRequestsReprise.get(canvas)===token)portraitStatusPass10(canvas,f,'failed');});
}
function drawPortrait(canvas,f){
 registerPortraitPass10(canvas,f);refreshPortraitWhenReadyReprise(canvas,f);
 const c=canvas.getContext('2d'),w=canvas.width,h=canvas.height,sprites=window.CQC_COMBAT_SPRITES;
 c.clearRect(0,0,w,h);const g=c.createRadialGradient(w*.5,h*.35,0,w*.5,h*.35,Math.max(w,h)*.8);g.addColorStop(0,tone(f.color,.15));g.addColorStop(1,'#07110d');c.fillStyle=g;c.fillRect(0,0,w,h);
 if(hasNativePortraitPass10(f.uid)){
  const drawn=!!sprites?.drawFitted?.(c,f,{x:0,y:0,width:w,height:h,padding:Math.min(w,h)*.055},-1,{time:0,actionTime:0});
  const status=sprites?.status(f.uid,portraitOptionsPass10),failed=status?.ready&&!drawn||status?.states?.some(s=>s==='failed'||s==='unavailable');
  portraitStatusPass10(canvas,f,drawn?'ready':failed?'failed':'loading');return;
 }
 portraitStatusPass10(canvas,f,'legacy');
 if(window.CQC_ORIGINAL_FIGHTERS?.drawPortrait(canvas,f))return;
 c.strokeStyle=f.accent+'55';for(let x=-h;x<w;x+=42){c.beginPath();c.moveTo(x,0);c.lineTo(x+h,h);c.stroke();}
 const sc=Math.min(w/260,h/300)*.95;drawFighter(c,f,w*.5,h*.96,-1,sc,{time:0});
}
function retryPortraitPass10(canvas,f){
 const sprites=window.CQC_COMBAT_SPRITES,status=sprites?.status(f.uid,portraitOptionsPass10);
 if(!hasNativePortraitPass10(f.uid)||!status?.states?.some(s=>s==='failed'||s==='unavailable'))return;
 const token={uid:f.uid};portraitRefreshRequestsReprise.set(canvas,token);
 sprites.whenReady(f.uid,{...portraitOptionsPass10,retry:true}).then(()=>{if(canvas.isConnected&&portraitRefreshRequestsReprise.get(canvas)===token)drawPortrait(canvas,f);}).catch(()=>{});
}
function nativeStagePreviewPass10(c,stage,time,cam,preview,options){
 const api=window.CQC_STAGE_LAYERS,status=api?.status(stage);if(!status?.approved)return false;
 if(api.drawBackground(c,stage,{...options,time,camera:cam,motion:stageMotionReprise(),preview})){if(c.canvas?.dataset)c.canvas.dataset.stageArtState='ready';return true;}
 const failed=['error','invalid','failed'].includes(status.state);c.save();c.fillStyle='#081712';c.fillRect(0,0,1280,720);c.fillStyle='#b7c5ae';c.textAlign='center';c.font='700 40px ui-monospace';c.fillText(failed?'Scène indisponible':'Chargement de la scène…',640,100);c.restore();
 if(c.canvas?.dataset)c.canvas.dataset.stageArtState=failed?'failed':'loading';
 if(!failed&&c.canvas){const canvas=c.canvas,key=stage.id||stage.name,previous=stageRefreshRequestsPass10.get(canvas);if(previous?.key!==key){const token={key};stageRefreshRequestsPass10.set(canvas,token);api.preload(stage).then(()=>{if(!canvas.isConnected||stageRefreshRequestsPass10.get(canvas)!==token)return;stageRefreshRequestsPass10.delete(canvas);if(canvas.id==='stageMini')drawMiniStage();else if(canvas.id==='stagePreview'&&!$('#galleryScreen').classList.contains('hidden'))drawGallery();}).catch(()=>{});}}
 return true;
}
function hideMatchLoadingPass10(){const overlay=$('#matchLoadingPass10');overlay.classList.add('hidden');overlay.setAttribute('aria-hidden','true');}
function restorePreviousMatchPass10(request){
 const previous=request.previousMatch;
 if(!previous?.running||!previous.state||state!==previous.state||$('#fightScreen').classList.contains('hidden'))return;
 // Keep the old pause state; a techniques panel closes through its existing resume path.
 running=true;paused=previous.paused;keys.clear();pressed.clear();acc43=0;last=performance.now();cancelAnimationFrame(raf43);raf43=requestAnimationFrame(loop);
}
function cancelPreparedMatchPass10(notify=true){
 const request=matchRequestPass10;if(!request)return;matchRequestPass10=null;request.cancelled=true;clearTimeout(request.timer);hideMatchLoadingPass10();request.resolve(false);if(notify){restorePreviousMatchPass10(request);request.onCancel?.();}if(request.previousFocus?.isConnected)request.previousFocus.focus();
}
function matchAssetsPass10(request,retry){
 const sprites=window.CQC_COMBAT_SPRITES,stageAPI=window.CQC_STAGE_LAYERS,jobs=[];
 for(const uid of new Set(request.fighters.map(f=>f.uid)))if(hasNativePortraitPass10(uid))jobs.push(sprites.whenReady(uid,{retry}));
 if(stageAPI?.status(request.stage)?.approved)jobs.push(stageAPI.preload(request.stage,{retry}));
 return Promise.all(jobs).then(results=>results.every(Boolean));
}
function attemptPreparedMatchPass10(request,retry=false){
 if(matchRequestPass10!==request||request.cancelled)return;
 const attempt=++request.attempt,overlay=$('#matchLoadingPass10');request.status='loading';overlay.classList.remove('hidden');overlay.setAttribute('aria-hidden','false');$('#matchLoadingTextPass10').textContent='Chargement des personnages et de la scène…';$('#matchRetryPass10').classList.add('hidden');$('#matchCancelPass10').focus();
 const timeout=new Promise((_,reject)=>{request.timer=setTimeout(()=>reject(Error('Le chargement a pris trop de temps.')),30000);});
 Promise.race([matchAssetsPass10(request,retry),timeout]).then(ready=>{
  if(matchRequestPass10!==request||request.cancelled||request.attempt!==attempt)return;
  clearTimeout(request.timer);if(!ready)throw Error('Les illustrations n’ont pas pu être chargées.');
  if(request.selection&&[p1,p2,stageIndex].some((v,i)=>v!==request.selection[i])){cancelPreparedMatchPass10(false);return;}
  matchRequestPass10=null;hideMatchLoadingPass10();try{request.start();}catch(error){matchRequestPass10=request;throw error;}if(request.pauseOnStart&&running)pause43(true);request.resolve(true);
 }).catch(error=>{
  if(matchRequestPass10!==request||request.cancelled||request.attempt!==attempt)return;
  clearTimeout(request.timer);request.status='failed';$('#matchLoadingTextPass10').textContent=String(error.message||'Le chargement a échoué.');$('#matchRetryPass10').classList.remove('hidden');$('#matchRetryPass10').focus();request.onError?.(error);
 });
}
function requestPreparedMatchPass10(start,options={}){
 const previousMatch=matchRequestPass10?.previousMatch||{running,state,paused};cancelPreparedMatchPass10(false);running=false;cancelAnimationFrame(raf43);keys.clear();pressed.clear();acc43=0;
 return new Promise(resolve=>{const request={id:++matchRequestSequencePass10,start,resolve,fighters:options.fighters||[FIGHTERS[p1],FIGHTERS[p2]],stage:options.stage||STAGES[stageIndex],selection:options.selection===false?null:[p1,p2,stageIndex],onError:options.onError,onCancel:options.onCancel,previousFocus:document.activeElement,previousMatch,attempt:0,status:'loading',cancelled:false,pauseOnStart:false};matchRequestPass10=request;attemptPreparedMatchPass10(request);});
}
function prepareExternalPass10(cfg,onStarted,onError,onCancel){
 const a=findFighter47(cfg.p1),b=findFighter47(cfg.p2);if(a<0||b<0)throw Error('Fighter not found');const stage=STAGES[findStage47(cfg.stage)],config={...cfg};
 return requestPreparedMatchPass10(()=>{startExternal48(config);onStarted?.();},{fighters:[FIGHTERS[a],FIGHTERS[b]],stage,selection:false,onError,onCancel});
}
function prepareReplayPass10(rep,ghostSlot){
 if(!rep?.meta||!Array.isArray(rep.frames))throw Error('Replay invalide');const a=findFighter47(rep.meta.p1),b=findFighter47(rep.meta.p2);if(a<0||b<0)throw Error('Combattant du replay introuvable');
 return requestPreparedMatchPass10(()=>beginReplay48(rep,ghostSlot),{fighters:[FIGHTERS[a],FIGHTERS[b]],stage:STAGES[findStage47(rep.meta.stage)],selection:false,onError:error=>parent.postMessage({type:'cqc-versus-error',message:String(error.message||error)},'*')});
}
$('#matchCancelPass10').onclick=()=>cancelPreparedMatchPass10(true);
$('#matchRetryPass10').onclick=()=>{if(matchRequestPass10)attemptPreparedMatchPass10(matchRequestPass10,true);};
addEventListener('keydown',event=>{
 if(!matchRequestPass10)return;
 if(event.code==='Escape'){event.preventDefault();event.stopImmediatePropagation();cancelPreparedMatchPass10(true);return;}
 if(event.code==='Tab'){const buttons=[$('#matchRetryPass10'),$('#matchCancelPass10')].filter(b=>!b.classList.contains('hidden'));const index=buttons.indexOf(document.activeElement),next=(index+(event.shiftKey?-1:1)+buttons.length)%buttons.length;event.preventDefault();buttons[next].focus();}
 event.stopImmediatePropagation();
},true);
