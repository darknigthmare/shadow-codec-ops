'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const crypto = require('node:crypto');
const here = __dirname;
const candidate = fs.readFileSync(path.join(here, 'candidate/modules/unified-versus-v055.html'), 'utf8');
const fragment = fs.readFileSync(path.join(here, 'display-pass10.js'), 'utf8');
const helpers = fragment.slice(fragment.indexOf('function hideMatchLoadingPass10'), fragment.indexOf('function prepareExternalPass10'));
const engineLoop = candidate.slice(candidate.indexOf('function advance43('), candidate.indexOf("$('#launch').onclick"));
assert(helpers.includes('previousMatch'));
assert(engineLoop.includes('function loop(t)'));
const result = [];
const source = `
let matchRequestPass10=null,matchRequestSequencePass10=0,running=false,paused=false,state=null,raf43=0,acc43=0,last=0;
let finishWindow46=null,finishScene46=null,frameStep43=1000/60,now=1000,starts=0,rafSequence=0;
let techOpen45=false,techPaused45=false;
const keys=new Set(),pressed=new Set(),rafCallbacks=new Map(),waits=[],els=new Map();
function $(id){if(!els.has(id)){const classes=new Set();els.set(id,{classList:{add:k=>classes.add(k),remove:k=>classes.delete(k),contains:k=>classes.has(k),toggle:(k,on)=>on?classes.add(k):classes.delete(k)},setAttribute(){},focus(){},getContext(){return{}},textContent:'',isConnected:true});}return els.get(id);}
const $$=()=>[],performance={now:()=>now},document={activeElement:null};
const FIGHTERS=[{uid:'a'},{uid:'b'}],STAGES=[{id:'test-stage'}];let p1=0,p2=1,stageIndex=0;
function deferred(){let resolve;const promise=new Promise(r=>resolve=r);const value={promise,resolve};waits.push(value);return value;}
const window={CQC_COMBAT_SPRITES:{whenReady:()=>deferred().promise},CQC_STAGE_LAYERS:{status:()=>({approved:false})}};
function hasNativePortraitPass10(){return true;}
function requestAnimationFrame(fn){const id=++rafSequence;rafCallbacks.set(id,fn);return id;}
function cancelAnimationFrame(id){rafCallbacks.delete(id);}
function drawGame(){}function drawDojo(){}function drawFinisher46(){}function advanceFinisher46(){}
function update(){state.frame++;}
function pause43(on){paused=on;keys.clear();pressed.clear();acc43=0;last=performance.now();}
${helpers}
${engineLoop}
${candidate.slice(candidate.indexOf('function closeTech45('),candidate.indexOf('function buildTech45('))}
function beginOldMatch(onPause=false){if(matchRequestPass10)cancelPreparedMatchPass10(false);rafCallbacks.clear();waits.length=0;starts=0;state={frame:20,finished:false};running=true;paused=onPause;now=1000;last=500;acc43=100;techOpen45=false;$('#fightScreen').classList.remove('hidden');return state;}
async function flush(){await Promise.resolve();await Promise.resolve();await Promise.resolve();await Promise.resolve();await Promise.resolve();}
function settle(w,ready=true){for(const wait of w)wait.resolve(ready);}
function check(name,fn){return Promise.resolve().then(fn).then(()=>result.push({name,pass:true}));}
(async()=>{
 await check('User cancel restores visible same match and skips the loading gap',async()=>{
  const old=beginOldMatch();const pending=requestPreparedMatchPass10(()=>starts++),late=[...waits];
  assert.equal(running,false);assert.equal(advance43(60000),0);assert.equal(old.frame,20);
  now=61000;cancelPreparedMatchPass10(true);assert.equal(await pending,false);assert.equal(running,true);assert.equal(paused,false);assert.equal(last,61000);assert.equal(acc43,0);
  loop(now+frameStep43);assert.equal(old.frame,21);settle(late);await flush();assert.equal(starts,0);assert.equal(old.frame,21);
 });
 await check('Paused techniques cancel preserves pause; actual closeTech resumes normally',async()=>{
  const old=beginOldMatch(true);techOpen45=true;techPaused45=false;const pending=requestPreparedMatchPass10(()=>starts++);
  now=61000;cancelPreparedMatchPass10(true);assert.equal(await pending,false);assert.equal(running,true);assert.equal(paused,true);
  loop(now+frameStep43);assert.equal(old.frame,20);assert.equal(acc43,0);closeTech45(true);assert.equal(paused,false);
  loop(now+frameStep43);assert.equal(old.frame,21);settle([...waits]);await flush();assert.equal(starts,0);
 });
 await check('Already paused match remains paused after cancel and techniques close',async()=>{
  const old=beginOldMatch(true);techOpen45=true;techPaused45=true;const pending=requestPreparedMatchPass10(()=>starts++);
  now=61000;cancelPreparedMatchPass10(true);await pending;closeTech45(true);assert.equal(paused,true);loop(now+frameStep43);assert.equal(old.frame,20);settle([...waits]);await flush();
 });
 await check('Abort cancel never restores old running state',async()=>{
  beginOldMatch();const pending=requestPreparedMatchPass10(()=>starts++);cancelPreparedMatchPass10(false);assert.equal(await pending,false);assert.equal(running,false);assert.equal(rafCallbacks.size,0);settle([...waits]);await flush();assert.equal(starts,0);
 });
 await check('Changed state or hidden fight prevents restoration',async()=>{
  beginOldMatch();let pending=requestPreparedMatchPass10(()=>starts++);state={frame:77};cancelPreparedMatchPass10(true);await pending;assert.equal(running,false);settle([...waits]);await flush();
  beginOldMatch();pending=requestPreparedMatchPass10(()=>starts++);$('#fightScreen').classList.add('hidden');cancelPreparedMatchPass10(true);await pending;assert.equal(running,false);settle([...waits]);await flush();
 });
 await check('Replacement preserves original recovery context and ignores old readiness',async()=>{
  const old=beginOldMatch();const first=requestPreparedMatchPass10(()=>starts++),firstWaits=[...waits];
  const second=requestPreparedMatchPass10(()=>starts++),secondWaits=waits.slice(firstWaits.length);assert.equal(await first,false);assert.equal(running,false);settle(firstWaits);await flush();assert.equal(starts,0);
  now=61000;cancelPreparedMatchPass10(true);assert.equal(await second,false);assert.equal(running,true);assert.equal(state,old);settle(secondWaits);await flush();assert.equal(starts,0);
 });
 await check('Only current fully ready request starts; no update while pending',async()=>{
  const old=beginOldMatch();const pending=requestPreparedMatchPass10(()=>{starts++;running=true;state={frame:0}});assert.equal(advance43(60000),0);assert.equal(old.frame,20);assert.equal(starts,0);
  settle([...waits]);await flush();assert.equal(await pending,true);assert.equal(starts,1);assert.equal(matchRequestPass10,null);assert.equal(state.frame,0);
 });
 await check('Failed readiness retains error state then real retry starts once',async()=>{
  beginOldMatch();const pending=requestPreparedMatchPass10(()=>starts++);settle([...waits],false);await flush();assert.equal(matchRequestPass10.status,'failed');assert.equal(starts,0);
  const failedCount=waits.length;attemptPreparedMatchPass10(matchRequestPass10,true);settle(waits.slice(failedCount));await flush();assert.equal(await pending,true);assert.equal(starts,1);
 });
 return result;
})()
`;
vm.runInNewContext(source, {assert, result, setTimeout, clearTimeout}, {timeout: 2000}).then(checks => {
 const receipt = {status:'PASS',candidateSha256:crypto.createHash('sha256').update(candidate).digest('hex'),method:'Executes preparation functions extracted from candidate plus original advance43/loop/closeTech45, with deferred asset promises and observable frame updates. No browser or image/source mutation.',checks};
 const target=path.join(here,'PREPARATION_CANCEL_VERIFICATION.json');
 fs.writeFileSync(target,JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
 process.stdout.write(JSON.stringify({receipt:target,sha256:crypto.createHash('sha256').update(fs.readFileSync(target)).digest('hex'),checks:checks.length,status:'PASS'})+'\n');
}).catch(error=>{process.stderr.write(error.stack+'\n');process.exitCode=1;});
