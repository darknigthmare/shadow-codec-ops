# Candidat isolé V2 PASS10

Le candidat V1 et sa receipt restent fermés, inchangés et indépendants. V2 utilise la même sauvegarde originale indépendante et ajoute uniquement le contexte de reprise de l’ancien combat.

Annuler explicitement restaure l’ancien `running` et sa RAF de présentation seulement si cet ancien combat était encore lancé, si l’objet `state` est identique et si fightScreen reste visible. `paused` conserve sa valeur d’origine : un combat en pause reste en pause et aucune physique n’avance. Fermer Techniques appelle ensuite la fonction existante qui choisit de reprendre ou de garder la pause. L’horloge `last` et l’accumulateur `acc43` sont réinitialisés pour ne rattraper aucun temps de chargement.

Abort, remplacement, sélection et lancement synchrone explicite utilisent l’annulation silencieuse sans restauration. Une demande remplacée transmet le contexte initial à sa remplaçante ; les anciens callbacks de readiness ne lancent jamais une demande annulée.

Les huit contrôles pratiques dans PREPARATION_CANCEL_VERIFICATION.json exécutent les fonctions de préparation et les fonctions originales advance43/loop/closeTech45, avec promesses d’assets différées et compteur observable d’updates. Ils couvrent annulation sans rattrapage, pause Techniques puis fermeture, pause préalable conservée, abort, état remplacé ou écran caché, demande remplacée et callback tardif, readiness complète, échec puis retry. Cette qualification ciblée ne remplace pas la revue physique et le navigateur réel après synchronisation de S.

Les trois scripts du candidat passent node --check. Les régions RAW_FIGHTERS, RAW_FIN et moteur inline restent identiques. Le promoteur exécuté sans --execute vérifie 271 PNG inchangées, n’écrit ni R ni S. V2 attend toujours la revue et le GO de root après stockage V8.
