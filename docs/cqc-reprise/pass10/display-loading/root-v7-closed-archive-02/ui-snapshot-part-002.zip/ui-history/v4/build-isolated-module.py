"""PASS10 V4: remove inline canvas baseline space; preserve closed V3."""
from pathlib import Path
import hashlib,json,re,subprocess

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'closed-before/modules/unified-versus-v055.html'
BASE_SHA='2ef8d058ce1c615af92374220a0259ff8eacaa3c63d508e2dafc5276ff85a107'
raw=BASE.read_bytes();assert hashlib.sha256(raw).hexdigest()==BASE_SHA
before=raw.decode();old='.stage-mini canvas,.stage-preview canvas{object-fit:contain}';new='.stage-mini canvas,.stage-preview canvas{display:block;object-fit:contain}'
assert before.count(old)==1
text=before.replace(old,new,1)
preserved=[];decoder=json.JSONDecoder()
for name,prefix in [('RAW_FIGHTERS','const FIGHTERS='),('RAW_FIN','globalThis.CQC_FINISHERS_053 = ')]:
 i=before.index(prefix)+len(prefix);_,end=decoder.raw_decode(before[i:]);section=before[i:i+end];assert section in text
 preserved.append({'name':name,'sha256':hashlib.sha256(section.encode()).hexdigest(),'bytes':len(section.encode())})
engine=[script for script in re.findall(r'<script(?:\s[^>]*)?>([\s\S]*?)</script>',before) if script.strip()][0];assert engine in text
preserved.append({'name':'RAW_INLINE_ENGINE','sha256':hashlib.sha256(engine.encode()).hexdigest(),'bytes':len(engine.encode())})
candidate=ROOT/'candidate/modules/unified-versus-v055.html';candidate.parent.mkdir(parents=True,exist_ok=True)
with candidate.open('xb') as out:out.write(text.encode())
checks=[]
for index,script in enumerate(re.findall(r'<script(?:\s[^>]*)?>([\s\S]*?)</script>',text)):
 if not script.strip():continue
 r=subprocess.run(['node','--check','--input-type=commonjs'],input=script,text=True,capture_output=True);checks.append({'script':index,'bytes':len(script.encode()),'exitCode':r.returncode,'stderr':r.stderr[:3000]});assert r.returncode==0
b=candidate.read_bytes()
receipt={'schema':'cqc-pass10-isolated-module-candidate/v4','status':'PREPARED_NOT_PROMOTED','baseline':{'path':str(BASE),'bytes':len(raw),'sha256':BASE_SHA},'candidate':{'path':str(candidate),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'gitBlob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()},'changes':[{'name':'Mini-stage and gallery canvases are block elements, preventing inline baseline gaps while contain preserves painted image aspect','before':old,'after':new}],'nodeSyntax':checks,'preservedLiteralRegions':preserved,'RWritten':False,'SWritten':False,'nativePNGEdited':False,'previousV3CandidateRetained':str(ROOT.parent/'v3/candidate/modules/unified-versus-v055.html'),'previousV3ReceiptRetained':str(ROOT.parent/'v3/ISOLATED_CANDIDATE_RECEIPT.json'),'limits':['CSS box aspect and contained painted image aspect are measured separately in actual browser QA.','Root ongoing build/tests started on V3 qualify V3 only; V4 browser QA remains pending.']}
p=ROOT/'ISOLATED_CANDIDATE_RECEIPT.json'
with p.open('x') as out:json.dump(receipt,out,ensure_ascii=False,indent=2);out.write('\n')
print(json.dumps({'candidate':receipt['candidate'],'receipt':str(p),'receiptSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'nodeChecks':checks,'preserved':preserved},indent=2))
