"""ROOT-only, opt-in promotion of the exact reviewed isolated module to R only."""
from pathlib import Path
import argparse,hashlib,json,os,uuid

ROOT=Path('/workspace/cqc-pass10-display-loading-implementation/v5')
TARGET=Path('/workspace/cqc-game-working/cqc-versus-v056/modules/unified-versus-v055.html')
RECEIPT=ROOT/'ISOLATED_CANDIDATE_RECEIPT.json'
FREEZE=Path('/workspace/cqc-pass9-final-qa/actual43-source-freeze.json')
def pin(p):
 b=p.read_bytes()
 return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
p=argparse.ArgumentParser()
p.add_argument('--execute',action='store_true')
p.add_argument('--root-reviewed-candidate-sha256',required=True)
a=p.parse_args()
plan=json.loads(RECEIPT.read_text());candidate=Path(plan['candidate']['path']);archive=Path(plan['baseline']['path'])
assert plan['status']=='PREPARED_NOT_PROMOTED' and len(a.root_reviewed_candidate_sha256)==64
assert pin(candidate)=={k:v for k,v in plan['candidate'].items() if k!='gitBlob'}
assert pin(candidate)['sha256']==a.root_reviewed_candidate_sha256
assert pin(archive)==plan['baseline'] and archive.stat().st_nlink==1
assert pin(TARGET)['sha256']==plan['baseline']['sha256'] and pin(TARGET)['bytes']==plan['baseline']['bytes']
native=[]
for item in json.loads(FREEZE.read_text())['files']:
 source=Path(item['path'])
 if source.suffix.lower()!='.png':continue
 assert pin(source)['sha256']==item['sha256'] and source.stat().st_size==item['bytes'],str(source)
 native.append(item['sha256'])
if not a.execute:
 print(json.dumps({'status':'VERIFIED_NOT_PROMOTED','target':str(TARGET),'candidate':plan['candidate'],'nativePNGsVerified':len(native),'RWritten':False,'SWritten':False,'reviewedSHA256':a.root_reviewed_candidate_sha256},indent=2))
 raise SystemExit(0)
assert not (ROOT/'ROOT_RUNTIME_PROMOTION.json').exists(),'Keep existing promotion receipt; do not overwrite it'
previous=TARGET.stat();temporary=TARGET.parent/('.pass10-reviewed-'+uuid.uuid4().hex+'.html')
with temporary.open('xb') as out:
 out.write(candidate.read_bytes());out.flush();os.fsync(out.fileno())
os.chmod(temporary,previous.st_mode&0o777)
assert pin(temporary)['sha256']==a.root_reviewed_candidate_sha256 and temporary.stat().st_nlink==1
os.replace(temporary,TARGET)
assert pin(TARGET)['sha256']==a.root_reviewed_candidate_sha256 and TARGET.stat().st_nlink==1
assert pin(archive)==plan['baseline']
result={'schema':'cqc-pass10-reviewed-module-runtime-promotion/v1','status':'PROMOTED_R_ONLY','reviewedSHA256':a.root_reviewed_candidate_sha256,'target':pin(TARGET),'nlink':TARGET.stat().st_nlink,'closedOriginal':pin(archive),'candidateReceipt':pin(RECEIPT),'nativePNGsVerified':len(native),'nativeImageEdited':False,'SWritten':False,'gitCommitCreated':False,'deploymentCreated':False}
q=ROOT/'ROOT_RUNTIME_PROMOTION.json'
with q.open('x') as out:json.dump(result,out,indent=2);out.write('\n')
print(json.dumps(result,indent=2))
print('Receipt SHA256 '+pin(q)['sha256'])
