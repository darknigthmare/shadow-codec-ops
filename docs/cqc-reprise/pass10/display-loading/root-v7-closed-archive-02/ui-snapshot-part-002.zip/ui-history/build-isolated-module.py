"""Build only an isolated PASS10 candidate; runtime promotion requires explicit ROOT GO."""
from pathlib import Path
import hashlib,json,re,subprocess,os

ROOT=Path('/workspace/cqc-pass10-display-loading-implementation')
BASE=ROOT/'closed-before/modules/unified-versus-v055.html'
BASE_SHA='847ec162d224388058ad2e54490e0922636b042608c063c40c06149205bafea7'
raw=BASE.read_bytes();assert hashlib.sha256(raw).hexdigest()==BASE_SHA
text=raw.decode();changes=[]
def replace(old,new,name):
 global text
 assert text.count(old)==1,(name,text.count(old))
 text=text.replace(old,new,1)
 changes.append({'name':name,'beforeBytes':len(old.encode()),'afterBytes':len(new.encode()),'beforeSHA256':hashlib.sha256(old.encode()).hexdigest(),'afterSHA256':hashlib.sha256(new.encode()).hexdigest()})

css=(ROOT/'display-pass10.css').read_text()
js=(ROOT/'display-pass10.js').read_text()
markup=(ROOT/'match-loading-pass10.html').read_text()
replace('</style>',css+'</style>','presentation CSS only')
replace('<script>/* CQC Versus',markup+'<script>/* CQC Versus','accessible loading UI before module code')
old=re.search(r'const portraitRefreshRequestsReprise=new WeakMap\(\);\n[\s\S]*?(?=\nfunction drawMiniStage)',text).group()
replace(old,js.rstrip(),'portrait fitting, readiness and isolated preparation helpers')
replace('if(window.CQC_COMBAT_SPRITES?.draw(c,f,x,y,face,scale,pose))return;c.save();','if(window.CQC_COMBAT_SPRITES?.draw(c,f,x,y,face,scale,pose))return;if(hasNativePortraitPass10(f.uid))return;c.save();','native fighter never impersonated by temporary procedural fallback')
replace('function drawStage(c,stage,time=0,cam=0,preview=false,options={}){if(window.CQC_STAGE_LAYERS?.drawBackground(c,stage,{...options,time,camera:cam,motion:stageMotionReprise(),preview}))return;','function drawStage(c,stage,time=0,cam=0,preview=false,options={}){if(nativeStagePreviewPass10(c,stage,time,cam,preview,options))return;if(window.CQC_STAGE_LAYERS?.drawBackground(c,stage,{...options,time,camera:cam,motion:stageMotionReprise(),preview}))return;','approved stage shows explicit waiting instead of legacy artwork')
replace("const box=$('#roster');box.innerHTML='';","const box=$('#roster');releaseRosterPortraitsPass10();box.innerHTML='';",'release observers from departed roster cards')
replace("b.innerHTML='<canvas width=\"260\" height=\"150\"></canvas><span class=\"source\">'","b.innerHTML='<div class=\"fighter-portrait-pass10\"><canvas width=\"260\" height=\"150\"></canvas></div><span class=\"source\">'",'roster artwork fills a flex box with stable labels')
replace('b.onclick=()=>{if(activeSlot===1)p1=i;else p2=i;buildRoster();updateSides()};','b.onclick=()=>{retryPortraitPass10(b.querySelector(\'canvas\'),f);if(activeSlot===1)p1=i;else p2=i;buildRoster();updateSides()};','reselecting a failed native portrait retries its idle sheet')
replace('function startMatch(){\n preloadCombatSpritesReprise();','function startMatch(){\n cancelPreparedMatchPass10(false);\n preloadCombatSpritesReprise();','raw synchronous launch cancels a stale preparation')
replace("$('#launch').onclick=startMatch;$('#leaveFight').onclick=()=>{","$('#launch').onclick=()=>requestPreparedMatchPass10(startMatch);$('#leaveFight').onclick=()=>{cancelPreparedMatchPass10(false);",'actual launch waits for art; leave cancels it')
replace("$('#rematch').onclick=()=>{finishWindow46=null;finishScene46=null;trial45=null;startMatch()};","$('#rematch').onclick=()=>requestPreparedMatchPass10(()=>{finishWindow46=null;finishScene46=null;trial45=null;startMatch()});",'rematch waits before starting real physics')
replace("b.onclick=()=>{galleryIndex=i;stageIndex=i;buildGallery();drawGallery()};","b.onclick=()=>{if(window.CQC_STAGE_LAYERS?.status(s)?.state==='error')window.CQC_STAGE_LAYERS.preload(s,{retry:true});galleryIndex=i;stageIndex=i;buildGallery();drawGallery()};",'failed stage preview can retry on real reselection')
replace('function drawGallery(){const galleryTime=','function drawGallery(){if($(\'#galleryScreen\').classList.contains(\'hidden\'))return;cancelAnimationFrame(galleryFramePass10);const galleryTime=','gallery has one actual animation loop')
replace("if(!$('#galleryScreen').classList.contains('hidden'))requestAnimationFrame(drawGallery)","if(!$('#galleryScreen').classList.contains('hidden'))galleryFramePass10=requestAnimationFrame(drawGallery)",'own gallery animation frame')
replace("$('#closeGallery').onclick=()=>{$('#galleryScreen').classList.add('hidden');","$('#closeGallery').onclick=()=>{cancelAnimationFrame(galleryFramePass10);galleryFramePass10=0;$('#galleryScreen').classList.add('hidden');",'gallery exit cancels animation')
for action,button in [('execute','practice45'),('confirm','confirm45'),('link','link45')]:
 replace("$('#"+button+"').onclick=()=>practice45('"+action+"');","$('#"+button+"').onclick=()=>requestPreparedMatchPass10(()=>practice45('"+action+"'),{fighters:[techF45(),FIGHTERS[p2]||FIGHTERS[0]],stage:STAGES[stageIndex],selection:false});",'real practice '+action+' prepares future actors')
replace("select:(a,b)=>{p1=", "select:(a,b)=>{cancelPreparedMatchPass10(false);p1=",'programmatic selection cancels old preparation')
replace("function abort55(){running=false;", "function abort55(){cancelPreparedMatchPass10(false);running=false;",'external abort cancels pending assets before they can start')
replace("try{startExternal48(d.config||d)}", "try{prepareExternalPass10(d.config||d,null,error=>parent.postMessage({type:'cqc-versus-error',message:String(error.message||error)},'*'))}",'external real battle waits for actual art')
replace('try{beginReplay48(d.replay,null)}','try{prepareReplayPass10(d.replay,null)}','message replay waits for art')
replace('try{beginReplay48(d.replay,d.liveSlot===1?0:1)}','try{prepareReplayPass10(d.replay,d.liveSlot===1?0:1)}','message ghost waits for art')
replace("if(d.type==='cqc-versus-pause'&&running)","if(d.type==='cqc-versus-pause'&&matchRequestPass10)matchRequestPass10.pauseOnStart=true;if(d.type==='cqc-versus-resume'&&matchRequestPass10)matchRequestPass10.pauseOnStart=false;if(d.type==='cqc-versus-pause'&&running)",'pause intent retained while preparing')
replace("setTimeout(()=>startExternal48({p1:'oc__parallaxe'", "setTimeout(()=>prepareExternalPass10({p1:'oc__parallaxe'",'original mode auto-start prepares assets')
old="if(link55.token===d.token){parent.postMessage({type:'cqc55.started',token:d.token},'*');return;}const cfg=config55(d.config);abort55();link55.token=d.token;link55.starts++;startExternal48(cfg);parent.postMessage({type:'cqc55.started',token:d.token},'*');"
new="if(link55.token===d.token){if(!matchRequestPass10)parent.postMessage({type:'cqc55.started',token:d.token},'*');return;}const cfg=config55(d.config);abort55();link55.token=d.token;parent.postMessage({type:'cqc55.loading',token:d.token},'*');prepareExternalPass10(cfg,()=>{if(link55.token!==d.token)return;link55.starts++;parent.postMessage({type:'cqc55.started',token:d.token},'*');},error=>{if(link55.token===d.token)parent.postMessage({type:'cqc55.error',token:d.token,message:String(error.message||error)},'*');},()=>{if(link55.token===d.token)parent.postMessage({type:'cqc55.error',token:d.token,message:'Chargement annulé.'},'*');});"
replace(old,new,'story loading protocol: validated token, deferred actual start, truthful ACK')
replace("if(d.token!==link55.token||!state){link55.rejected++;return;}","if(d.token===link55.token&&matchRequestPass10){if(d.type==='cqc55.pause'){matchRequestPass10.pauseOnStart=true;parent.postMessage({type:'cqc55.paused',token:d.token},'*');return;}if(d.type==='cqc55.resume'){matchRequestPass10.pauseOnStart=false;return;}if(d.type==='cqc55.input')return;}if(d.token!==link55.token||!state){link55.rejected++;return;}",'story controls never reach an unprepared actor')
replace("window.__CQC053Versus.aiProfiles=", "window.__CQC053Versus.getLoadingState=()=>matchRequestPass10?{id:matchRequestPass10.id,status:matchRequestPass10.status,attempt:matchRequestPass10.attempt,fighters:matchRequestPass10.fighters.map(f=>f.uid),stage:matchRequestPass10.stage.id}:null;window.__CQC053Versus.aiProfiles=",'passive diagnostics for real preparation QA')

# Literal engine and embedded roster/finisher data must survive every UI edit.
preserved=[]
decoder=json.JSONDecoder()
for name,prefix in [('RAW_FIGHTERS','const FIGHTERS='),('RAW_FIN','globalThis.CQC_FINISHERS_053 = ')]:
 i=raw.decode().index(prefix)+len(prefix)
 value,end=decoder.raw_decode(raw.decode()[i:]);section=raw.decode()[i:i+end]
 assert section in text,name
 preserved.append({'name':name,'sha256':hashlib.sha256(section.encode()).hexdigest(),'bytes':len(section.encode())})
engine_before=[s for s in re.findall(r'<script(?:\s[^>]*)?>([\s\S]*?)</script>',raw.decode()) if s.strip()][0]
assert engine_before in text
preserved.append({'name':'RAW_INLINE_ENGINE','sha256':hashlib.sha256(engine_before.encode()).hexdigest(),'bytes':len(engine_before.encode())})

candidate=ROOT/'candidate/modules/unified-versus-v055.html'
candidate.parent.mkdir(parents=True,exist_ok=True)
with candidate.open('xb') as stream:stream.write(text.encode())
scripts=re.findall(r'<script(?:\s[^>]*)?>([\s\S]*?)</script>',text)
syntax=[]
for index,script in enumerate(scripts):
 if not script.strip():continue
 result=subprocess.run(['node','--check','--input-type=commonjs'],input=script,text=True,capture_output=True)
 syntax.append({'script':index,'bytes':len(script.encode()),'exitCode':result.returncode,'stderr':result.stderr[:3000]})
 assert result.returncode==0,syntax[-1]
b=candidate.read_bytes()
receipt={'schema':'cqc-pass10-isolated-module-candidate/v1','status':'PREPARED_NOT_PROMOTED','baseline':{'path':str(BASE),'bytes':len(raw),'sha256':BASE_SHA},'candidate':{'path':str(candidate),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'gitBlob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()},'changes':changes,'nodeSyntax':syntax,'preservedLiteralRegions':preserved,'RWritten':False,'SWritten':False,'nativePNGEdited':False,'rendererOwner':'root','requiredRendererAPI':['has(uid)','drawFitted(context,fighter,box,face,pose)','status(uid,{action,face})','whenReady(uid,{action,face,retry})'],'requiredStageAPI':'preload(stage,{retry:true}) with decode before ready','requiredParentChronicles':'cqc55.loading extends the validated pending-token ACK wait to 60 seconds; child waits at most 30 seconds per attempt','limits':['Candidate has syntax checks only; actual browser and engine verification remain pending before promotion.','Raw synchronous engine APIs remain synchronous. User launch, rematch, practice and real external/replay/story messages use the preparation layer.','Failed or loading known native UIDs never draw a different procedural actor. Genuine UIDs without native art retain their existing fallback.']}
p=ROOT/'ISOLATED_CANDIDATE_RECEIPT.json'
with p.open('x') as h:json.dump(receipt,h,indent=2,ensure_ascii=False);h.write('\n')
print(json.dumps({'candidate':receipt['candidate'],'changes':len(changes),'syntaxChecks':syntax,'receipt':str(p),'receiptSHA256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2))
