"""Root-gated real browser QA. Preparation without --execute never opens a browser."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,subprocess

HERE=Path(__file__).resolve().parent
R=Path('/workspace/cqc-game-working/cqc-versus-v056')
S=Path('/workspace/shadow-codec-recovered')
FREEZE=Path('/workspace/cqc-pass9-final-qa/actual43-source-freeze.json')
EXPECTED='2ef8d058ce1c615af92374220a0259ff8eacaa3c63d508e2dafc5276ff85a107'
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def guard():
 paths=['modules/unified-versus-v055.html','src/cqc-sprite-renderer.js','src/cqc-sprite-catalog.js','src/chronicles-portraits-v056.js','src/chronicles-art-v056.js','src/chronicles-cinema-v056.js']
 result=[]
 for name in paths:
  a=pin(R/name);b=pin(S/'public/cqc'/name);assert a['sha256']==b['sha256'],name
  if name.startswith('modules/'):assert a['sha256']==EXPECTED
  result.extend([a,b])
 result.append(pin(S/'public/cqc/runtime-manifest.json'))
 count=0
 for f in json.loads(FREEZE.read_text())['files']:
  p=Path(f['path'])
  if p.suffix.lower()!='.png':continue
  assert p.stat().st_size==f['bytes'] and pin(p)['sha256']==f['sha256'],str(p);count+=1
 assert count==271
 return result

GEOMETRY=r'''(()=>{
 const rows=[];
 for(const selector of ['#p1Portrait','#p2Portrait','.fighter-card canvas','#stageMini','#stagePreview','#techPortrait45','#finishPortrait46'])for(const canvas of [...document.querySelectorAll(selector)].slice(0,8)){
  const r=canvas.getBoundingClientRect(),style=getComputedStyle(canvas),parent=canvas.parentElement.getBoundingClientRect();if(!r.width||!r.height)continue;
  rows.push({selector,id:canvas.id||null,name:canvas.closest('.fighter-card')?.querySelector('b')?.textContent,intrinsic:{width:canvas.width,height:canvas.height},css:{width:r.width,height:r.height,objectFit:style.objectFit},anisotropy:(r.width/canvas.width)/(r.height/canvas.height),parent:{width:parent.width,height:parent.height},bounds:{left:r.left,top:r.top,right:r.right,bottom:r.bottom},state:canvas.dataset.artState,stageState:canvas.dataset.stageArtState});
 }
 return{viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio},rows,trace:window.__pass10LayoutTrace||[],rosterScroll:document.querySelector('.roster')?.scrollHeight,galleryMeta:document.querySelector('#galleryMeta')?.textContent};
})()'''

STATE=r'''(()=>{const a=window.__CQC055Versus,s=a.getState();return{state:s?{p1:s.a.f.uid,p2:s.b.f.uid,frame:s.frame,phase:s.phase,finished:!!s.finished}:null,pending:a.getLoadingState(),diagnostics:a.diagnostics(),modalVisible:!document.querySelector('#matchLoadingPass10').classList.contains('hidden'),modalText:document.querySelector('#matchLoadingTextPass10').textContent,clicks:window.__pass10RealClicks||[],network:window.__pass10Network||[]};})()'''

FITTED=r'''(()=>{
 const api=window.__CQC055Versus,sprites=window.CQC_COMBAT_SPRITES,visible=document.querySelector('#p1Portrait'),rows=[];
 for(const uid of ['core__boss','core__snake','core__crying_wolf']){
  const f=api.fighters.find(a=>a.uid===uid),state=sprites.status(uid,{action:'idle',face:-1});if(!state.ready)continue;
  const canvas=document.createElement('canvas');canvas.width=visible.width;canvas.height=visible.height;const c=canvas.getContext('2d',{willReadFrequently:true}),native=c.drawImage.bind(c),draws=[];
  c.drawImage=function(...args){const m=c.getTransform();draws.push({matrix:{a:m.a,b:m.b,c:m.c,d:m.d,e:m.e,f:m.f},sourceRect:args.slice(1,5),destinationRect:args.slice(5)});return native(...args);};
  const padding=Math.min(canvas.width,canvas.height)*.055,drawn=sprites.drawFitted(c,f,{x:0,y:0,width:canvas.width,height:canvas.height,padding},-1,{time:0,actionTime:0});
  const data=c.getImageData(0,0,canvas.width,canvas.height).data;let left=canvas.width,top=canvas.height,right=-1,bottom=-1,pixels=0;
  for(let y=0;y<canvas.height;y++)for(let x=0;x<canvas.width;x++)if(data[(y*canvas.width+x)*4+3]){left=Math.min(left,x);top=Math.min(top,y);right=Math.max(right,x);bottom=Math.max(bottom,y);pixels++;}
  rows.push({uid,drawn,buffer:{width:canvas.width,height:canvas.height},padding,alphaBounds:{left,top,right,bottom,pixels},draws});
 }
 return rows;
})()'''

def execute(args):
 out=Path(args.output);out.mkdir(exist_ok=False)
 before=guard();spec=importlib.util.spec_from_file_location('pass10_common','/workspace/cqc-pass6-browser-common.py');C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)
 observations=[];commands=[];screenshots=[];sessions=[];failure=None;errors=[]
 def make_browser(tag):
  b=C.Browser(out,tag);b.env['AGENT_BROWSER_INIT_SCRIPTS']=str(HERE/'passive-layout-loading-observer.js');b.env['AGENT_BROWSER_SCREENSHOT_FORMAT']='jpeg';b.env['AGENT_BROWSER_SCREENSHOT_QUALITY']='45';b.prefix[b.prefix.index('--args')+1]='--no-sandbox,--disk-cache-size=1,--media-cache-size=1';sessions.append(b.session);return b
 def record(b,name,code=STATE):
  value=b.evaluate(code);observations.append({'name':name,'result':value});return value
 def wait_js(b,condition):
  return b.evaluate('(async()=>{for(let i=0;i<100;i++){if('+condition+')return true;await new Promise(r=>setTimeout(r,100));}throw Error("Actual browser state timeout")})()')
 def screenshot(b,name):
  p=out/(name+'.jpg');b.call('screenshot',str(p));screenshots.append(pin(p))
 def assert_geometry(g):
  for row in g['rows']:
   if row['selector'] in ['#p1Portrait','#p2Portrait','.fighter-card canvas','#techPortrait45','#finishPortrait46']:assert abs(row['anisotropy']-1)<.025,row
   if row['selector']=='#stageMini':assert abs(row['css']['width']/row['css']['height']-16/9)<.015,row
   if row['selector']=='#stagePreview':assert row['css']['objectFit']=='contain',row
  native_rows=[r for t in g['trace'] for r in t['rows']];assert native_rows and not any(r['state']=='legacy' for r in native_rows),native_rows
 b=make_browser('cqc-pass10-layout-desktop')
 try:
  b.call('set','viewport','1366','768');b.call('open',args.base.rstrip('/')+'/cqc/modules/unified-versus-v055.html');b.call('wait','--load','networkidle')
  gut=record(b,'immediate-dev-server-browser-gut-check',"(()=>({title:document.title,bodyCharacters:document.body.innerText.trim().length,launch:!!document.querySelector('#launch'),errorOverlay:!!document.querySelector('vite-error-overlay,.vite-error-overlay,[data-nextjs-dialog]')}))()");assert gut['bodyCharacters']>100 and gut['launch'] and not gut['errorOverlay'];b.call('snapshot','-i');initial_errors=b.call('errors');assert not initial_errors.get('errors'),initial_errors
  wait_js(b,"document.querySelector('#p1Portrait').dataset.artState==='ready'&&document.querySelector('#p2Portrait').dataset.artState==='ready'")
  g=record(b,'desktop-cold-selection',GEOMETRY);assert_geometry(g);screenshot(b,'desktop-cold-selection')
  b.call('click','#techSelect45');g=record(b,'desktop-technique',GEOMETRY);assert_geometry(g);b.call('click','#techClose45')
  b.call('click','#finishSelect46');g=record(b,'desktop-finisher',GEOMETRY);assert_geometry(g);b.call('click','#finishClose46')
  b.call('set','viewport','1280','900','2');b.evaluate('new Promise(resolve=>setTimeout(()=>resolve(true),150))');g=record(b,'desktop-retina-real-resize',GEOMETRY);assert_geometry(g);assert g['viewport']['dpr']==2
  b.call('set','viewport','1366','768','1');b.evaluate('new Promise(resolve=>setTimeout(()=>resolve(true),150))')
  b.call('click','#openGallery');g=record(b,'desktop-gallery',GEOMETRY);assert_geometry(g);assert 'DÉCOR HÉRITÉ' not in g['galleryMeta'];screenshot(b,'desktop-gallery');b.call('click','#closeGallery')
  b.call('click','#launch');wait_js(b,"window.__CQC055Versus.getState()&&!window.__CQC055Versus.getLoadingState()")
  old=record(b,'old-match-launched-through-real-ui');assert old['diagnostics']['running'];assert old['state']
  b.call('set','offline','on')
  cfg={'p1':'core__crying_wolf','p2':'core__snake','stage':'shadow_heliport','mode':'training','dummy':'idle','autoheal':False,'freeResource':False,'rounds':1,'seconds':99,'finishers':'off','source':'pass10-real-network-ui-qa'}
  b.evaluate('window.postMessage('+json.dumps({'type':'cqc-versus-start','config':cfg})+',"*");true')
  wait_js(b,"window.__CQC055Versus.getLoadingState()?.status==='failed'")
  stopped=record(b,'real-offline-failed-assets-stop-old-loop');assert not stopped['diagnostics']['running'];assert stopped['pending']['status']=='failed'
  b.evaluate('new Promise(resolve=>setTimeout(()=>resolve(true),350))');still=record(b,'no-hidden-physics-while-failed');assert still['state']['frame']==stopped['state']['frame']
  b.call('click','#matchCancelPass10');resumed=record(b,'trusted-cancel-restores-same-old-match');assert resumed['pending'] is None and resumed['diagnostics']['running'] and not resumed['diagnostics']['paused'];assert resumed['state']['p1']==stopped['state']['p1']
  b.evaluate('new Promise(resolve=>setTimeout(()=>resolve(true),300))');after=record(b,'natural-frames-after-cancel');assert after['state']['frame']>stopped['state']['frame']
  b.call('click','#pauseBtn');paused=record(b,'trusted-old-match-pause');assert paused['diagnostics']['paused']
  b.evaluate('window.postMessage('+json.dumps({'type':'cqc-versus-start','config':cfg})+',"*");true');wait_js(b,"window.__CQC055Versus.getLoadingState()?.status==='failed'");b.call('click','#matchCancelPass10');kept=record(b,'trusted-cancel-keeps-previous-pause');assert kept['diagnostics']['running'] and kept['diagnostics']['paused']
  b.evaluate('new Promise(resolve=>setTimeout(()=>resolve(true),300))');held=record(b,'paused-match-no-physics-after-cancel');assert held['state']['frame']==kept['state']['frame'];b.call('click','#pauseBtn')
  b.call('set','offline','off');b.evaluate('window.postMessage('+json.dumps({'type':'cqc-versus-start','config':cfg})+',"*");true');wait_js(b,"window.__CQC055Versus.getLoadingState()?.status==='failed'");b.call('click','#matchRetryPass10')
  wait_js(b,"window.__CQC055Versus.getState()?.a.f.uid==='core__crying_wolf'&&!window.__CQC055Versus.getLoadingState()")
  retried=record(b,'trusted-real-retry-ready-native-match');assert retried['diagnostics']['running'] and retried['state']['p1']=='core__crying_wolf';assert any(c['id']=='matchRetryPass10' and c['trusted'] for c in retried['clicks']);assert sum(c['id']=='matchCancelPass10' and c['trusted'] for c in retried['clicks'])>=2
  assert any(n['type']=='offline' and n['trusted'] for n in retried['network']) and any(n['type']=='online' and n['trusted'] for n in retried['network'])
  b.call('click','#leaveFight');b.call('fill','#search','CRYING WOLF');b.call('click','.fighter-card');wait_js(b,"document.querySelector('#p1Portrait').dataset.artState==='ready'")
  g=record(b,'desktop-quadruped-native-full-body',GEOMETRY);assert_geometry(g);screenshot(b,'desktop-quadruped-native')
  fit=record(b,'native-frame-uniform-fit-and-equipment-bounds',FITTED);assert len(fit)==3
  for f in fit:
   assert f['drawn'] and f['alphaBounds']['pixels']>0
   assert f['alphaBounds']['left']>=f['padding']-2 and f['alphaBounds']['top']>=f['padding']-2
   assert f['alphaBounds']['right']<=f['buffer']['width']-f['padding']+1 and f['alphaBounds']['bottom']<=f['buffer']['height']-f['padding']+1
   for draw in f['draws']:
    m=draw['matrix'];assert abs(abs(m['a'])-abs(m['d']))<1e-7 and abs(m['b'])<1e-7 and abs(m['c'])<1e-7
    src=draw['sourceRect'];dst=draw['destinationRect'];assert len(src)==4 and len(dst)==4;assert abs(dst[2]/src[2]-dst[3]/src[3])<1e-7
  error=b.call('errors');errors.append({'session':b.session,'result':error});assert not error.get('errors'),error
 except Exception as e:failure=repr(e)
 finally:b.close();commands.extend(b.commands)
 if not failure:
  b=make_browser('cqc-pass10-layout-mobile')
  try:
   b.call('set','viewport','390','844','3');b.call('open',args.base.rstrip('/')+'/cqc/modules/unified-versus-v055.html');b.call('wait','--load','networkidle')
   g=record(b,'mobile-cold-selection',GEOMETRY);assert_geometry(g);screenshot(b,'mobile-cold-selection')
   b.call('click','#openGallery');g=record(b,'mobile-gallery-16-by-9-contain',GEOMETRY);assert_geometry(g);screenshot(b,'mobile-gallery');b.call('click','#closeGallery')
   error=b.call('errors');errors.append({'session':b.session,'result':error});assert not error.get('errors'),error
  except Exception as e:failure=repr(e)
  finally:b.close();commands.extend(b.commands)
 after=guard();assert before==after,'Source pins changed during the browser QA'
 proof={'status':'failed' if failure else 'passed','failure':failure,'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rootReady':args.root_ready,'candidateSHA256':EXPECTED,'tool':pin(Path(__file__)),'passiveObserver':pin(HERE/'passive-layout-loading-observer.js'),'sourcePinsBefore':before,'sourcePinsAfter':after,'old271NativePNGByteExact':True,'ownedSessions':sessions,'observations':observations,'commands':commands,'screenshots':screenshots,'pageErrors':errors,'cleanup':'Owned browsers closed; real network restored before second session.','limits':['UI launch/cancel/pause/retry use real browser clicks and trusted events; external preparation uses the real accepted parent-message boundary in standalone mode.','Failure comes from actual browser offline on uncached native sheets; no response mocking, CSS injection, fake readiness, modified PNG or artificial engine frames.','Fit bounds use a detached QA canvas through the actual sprite renderer and native image, with an observational drawImage wrapper; no UI drawing function is replaced.','Fresh desktop/mobile sessions each observe native portrait state through passive RAF reads. Native legacy count zero is combined with branch/source review, not a claim of profiling every drawing instruction.']}
 p=out/'REAL_LAYOUT_LOADING_VERIFICATION.json';p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':proof['status'],'failure':failure,'observations':len(observations),'commands':len(commands),'proof':pin(p),'screenshots':screenshots},ensure_ascii=False,indent=2))
 if failure:raise SystemExit(1)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');p.add_argument('--root-ready');p.add_argument('--base',default='http://127.0.0.1:5179');p.add_argument('--output',default='/workspace/cqc-pass10-display-loading-implementation/v3/actual-local-layout-01');args=p.parse_args()
 if not args.execute:print(json.dumps({'status':'prepared-not-executed','requiresRootSyncReady':True,'candidateSHA256':EXPECTED,'cases':'fresh cold desktop/mobile portraits, dynamic buffer geometry, mini/gallery aspect, real offline fail, trusted cancel pause/retry, real native uniform fit + full alpha bounds'}));raise SystemExit(0)
 assert args.root_ready,'Explicit Root S sync-ready context is required'
 execute(args)
