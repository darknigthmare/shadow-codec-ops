(() => {
  const trace=[],clicks=[],network=[];
  window.__pass10LayoutTrace=trace;
  window.__pass10RealClicks=clicks;
  window.__pass10Network=network;
  addEventListener('click',event=>{
    if(clicks.length<90)clicks.push({id:event.target.id||event.target.closest('button')?.id||null,text:event.target.closest('button')?.innerText.slice(0,70)||'',trusted:event.isTrusted,time:Math.round(performance.now())});
  },{capture:true,passive:true});
  for(const type of ['offline','online'])addEventListener(type,event=>network.push({type,trusted:event.isTrusted,online:navigator.onLine,time:Math.round(performance.now())}),{passive:true});
  let previous='';
  function observe(){
    const api=window.__CQC055Versus,sprites=window.CQC_COMBAT_SPRITES;
    if(api?.fighters&&sprites?.has){
      const rows=[];
      for(const canvas of document.querySelectorAll('#p1Portrait,#p2Portrait,.fighter-card canvas')){
        const name=canvas.closest('.fighter-card')?.querySelector('b')?.textContent||document.querySelector(canvas.id==='p1Portrait'?'#p1Info h2':'#p2Info h2')?.textContent;
        const actor=api.fighters.find(f=>f.name===name);
        if(!actor||!sprites.has(actor.uid))continue;
        const rect=canvas.getBoundingClientRect();
        rows.push({uid:actor.uid,id:canvas.id||'roster',state:canvas.dataset.artState||'missing',visible:!!(rect.width&&rect.height),label:canvas.getAttribute('aria-label')});
      }
      const pending=api.getLoadingState?.();
      const signature=JSON.stringify({rows,pending:pending?{id:pending.id,status:pending.status}:null});
      if(signature!==previous&&trace.length<100){previous=signature;trace.push({time:Math.round(performance.now()),rows,pending:pending?{id:pending.id,status:pending.status}:null});}
    }
    requestAnimationFrame(observe);
  }
  requestAnimationFrame(observe);
})();
