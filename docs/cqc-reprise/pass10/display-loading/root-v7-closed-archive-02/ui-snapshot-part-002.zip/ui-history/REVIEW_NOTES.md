# Candidat isolé PASS10

Aucun fichier R/S n’est écrit par le builder. La sauvegarde complète indépendante du module original est dans `closed-before/modules/unified-versus-v055.html` (SHA 847ec162…, 3 445 760 octets). Le candidat et ses fragments CSS/HTML/JS restent dans ce dossier en attendant la revue et le GO de root après le stockage V8.

Le builder applique 28 remplacements uniques et vérifie littéralement le roster JSON, le catalogue de finishers JSON et le script inline du moteur. Les trois scripts inline du résultat passent `node --check`. Ces vérifications de préparation ne remplacent pas les contrôles réels de navigateur/engine après promotion et synchronisation de S.

Les buffers des portraits suivent les dimensions des boîtes, avec DPR borné à 3 pour contrôler leur allocation. Le renderer root applique un facteur uniforme à la frame complète ; aucune taille de combat, pivot, rect ou image native n’est modifiée. Les thumbs utilisent un conteneur flexible ; les panneaux sélectionnés utilisent leur hauteur restante. Mini-stage et galerie conservent les pixels 16/9 par contain. Le vrai canvas de combat et ses règles de taille restent inchangés.

Les portraits utilisent `status/whenReady(uid,{action:'idle',face:-1})`, sans charger les six feuilles de chaque carte. Les combattants sélectionnés et les lancements utilisent toujours la readiness de toutes les actions/directions. Des tokens empêchent qu’un ancien portrait ou stage redessine la nouvelle sélection. Les callbacks false redessinent l’état d’échec ; un échec ne conserve pas un texte « chargement » indéfiniment. Les observateurs des cartes quittées ou canvases détachés sont libérés.

Les UID connues du renderer natif n’affichent jamais de mannequin temporaire si le PNG manque ou charge. Les UID sans entry native conservent le fallback existant. Les stages approuvés affichent une attente neutre ; les stages inconnus conservent le comportement hérité.

Les vrais lancements UI, rematchs, exercices et messages de battle/replay/ghost/story attendent le décodage des deux acteurs et du stage avant d’appeler les fonctions synchrones existantes. Pendant cette préparation, la boucle précédente est arrêtée et aucune simulation ne démarre. Annulation, abort, demande remplacée, sélection différente et callbacks tardifs ne lancent pas un ancien duel. Les erreurs offrent retry et annulation. Chaque tentative enfant expire à 30 secondes ; un retry réutilise les fichiers sains et relance uniquement les fichiers défaillants via les API root.

Le chemin Chronicles valide la configuration et le token, émet `cqc55.loading`, puis émet `cqc55.started` seulement après le vrai démarrage. Root doit faire accepter ce message par le parent pour remplacer sa garde ACK de 7 secondes par une garde de 60 secondes. Ce délai ne sert pas de faux pourcentage ou heartbeat. Les pause/resume reçus pendant la préparation sont conservés ; les commandes de mouvement sont ignorées tant que le nouveau combat n’est pas prêt.

Les API synchrones `start`, `startExternal`, `startReplay`, `startGhost` et `practice` restent synchrones pour le moteur et les intégrations qui préparent déjà leurs ressources. Un lancement synchrone explicite annule la préparation précédente ; le gameplay et ses valeurs ne changent pas. `getLoadingState()` est une lecture de la préparation UI pour les contrôles réels.

Après revue et GO, root peut utiliser `promote-reviewed-module.py --execute --root-reviewed-candidate-sha256 <SHA fermé>`. Sans `--execute`, il vérifie les mêmes pins et n’écrit rien. Il ne promeut que le module R, vérifie toutes les PNG du gel précédent, conserve l’original indépendant, remplace atomiquement le fichier et exige un nouveau fichier indépendant. Aucun commit, aucune publication et aucune écriture S ne sont effectués.

Vérification encore nécessaire : navigateur réel desktop/mobile/original, ratio de l’image peinte, équipements entièrement visibles, resize/DPR, pagination, choix A→B rapides, chargement froid sans mannequin, échec/retry/cancel, absence d’avance cachée, protocole Chronicles, replay/ghost et invariance des profils/moteur. Le candidat n’est pas encore qualifié comme production.
