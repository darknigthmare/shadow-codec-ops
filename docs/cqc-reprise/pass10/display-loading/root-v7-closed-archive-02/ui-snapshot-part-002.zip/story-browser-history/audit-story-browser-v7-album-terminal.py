"""Owned real browsers + byte-exact HTTP source; passive observers, real UI only."""
import sys
sys.dont_write_bytecode=True
import json,pathlib,time,datetime,hashlib,importlib.util,threading,http.server,socket,urllib.parse
ROOT=pathlib.Path('/workspace/cqc-game-working/cqc-versus-v056')
OUT=pathlib.Path('/workspace/cqc-pass10-story-loading-browser-QA/actual-07');OUT.mkdir(exist_ok=False)
OBSERVER=OUT.parent/'passive-story-observer-v2.js'
spec=importlib.util.spec_from_file_location('readonly_common','/workspace/cqc-pass6-browser-common.py');C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)
policy={'case':'initial','nativeDelay':0,'atlasDelay':0,'stageDelay':0,'plateDelay':0,'failNative':False,'failAtlas':False}
requests=[];lock=threading.Lock()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
files=['modules/chronicles-v056.html','modules/unified-versus-v055.html','src/chronicles-v056.js','src/chronicles-v056.css','src/chronicles-cinema-v056.js','src/chronicles-portraits-v056.js','src/chronicles-art-v056.js','src/cqc-sprite-renderer.js','src/cqc-sprite-catalog.js','src/cqc-stage-layers.js','src/cqc-stage-layer-data.js','docs/ALBUM_LOCAL_354_RECITS_v0.56.html']
before=[pin(ROOT/f) for f in files]
class Handler(http.server.SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(ROOT),**kw)
 def log_message(self,*a):pass
 def end_headers(self):self.send_header('Cache-Control','no-store');super().end_headers()
 def send_response(self,code,message=None):
  if getattr(self,'_audit_row',None) is not None:self._audit_row['httpStatus']=code
  return super().send_response(code,message)
 def do_GET(self):
  path=urllib.parse.urlsplit(self.path).path
  native='/assets/combat-sprites/' in path
  atlas='/assets/portraits-v056/' in path
  stage='/assets/stages' in path and path.endswith('.png')
  plate='/assets/illustrations' in path or '/assets/cinema-v056/' in path
  rules=policy.copy();delay=rules['nativeDelay'] if native else rules['atlasDelay'] if atlas else rules['stageDelay'] if stage else rules['plateDelay'] if plate else 0
  if native and not any('/'+u+'/' in path for u in ('archive__laughing_beauty','core__laughing_octopus')):delay=0
  if atlas and not any(x in path for x in ('atlas-21.webp','atlas-07.webp')):delay=0
  row={'path':path,'case':rules['case'],'native':native,'atlas':atlas,'stage':stage,'plate':plate,'delaySeconds':delay,'requestedAt':time.monotonic()}
  self._audit_row=row
  with lock:requests.append(row)
  if delay:time.sleep(delay)
  if (native and rules['failNative']) or (atlas and rules['failAtlas']):
   row['failure']='controlled-real-socket-abort';row['finishedAt']=time.monotonic()
   try:self.connection.shutdown(socket.SHUT_RDWR)
   except OSError:pass
   self.connection.close();return
  try:super().do_GET();row['finishedAt']=time.monotonic()
  except (BrokenPipeError,ConnectionResetError):row['clientCancelled']=True;row['finishedAt']=time.monotonic()
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True
threading.Thread(target=server.serve_forever,daemon=True).start();port=server.server_address[1]
base=f'http://127.0.0.1:{port}'
allcases=[('album-terminal-failure',album_terminal,{'failNative':True,'failAtlas':True})]
try:
 for name,case,config in cases:
  policy.update(case=name,nativeDelay=0,atlasDelay=0,stageDelay=0,plateDelay=0,failNative=False,failAtlas=False);policy.update(config)
  b=new_browser(name)
  try:case(b)
  except Exception as e:
   errors.append({'case':name,'failure':repr(e)});print('FAIL '+name+' '+repr(e),flush=True)
   try:capture(b,'failure-current-actual-ui')
   except Exception as cap:errors.append({'case':name,'failedCapture':repr(cap)})
  finally:save_case(b)
finally:
 server.shutdown();server.server_close()
 after=[pin(ROOT/f) for f in files]
 changed=[{'before':a,'after':z} for a,z in zip(before,after) if a!=z]
 report={'schema':'cqc.pass10.independent-story-album-loading-real-browser/1','status':'failed' if errors else 'observed','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ownedHTTPOrigin':base,'ownedHTTPStopped':True,'sourcePinsBefore':before,'sourcePinsAfter':after,'sourceChangedDuringAudit':changed,'caseReceipts':allcases,'errors':errors,'passiveObserver':pin(OBSERVER),'tool':pin(pathlib.Path(__file__)),'networkRequests':requests,'noSourceOrGitMutationByAudit':True,'noMockedReadinessOrRendering':True,'noSyntheticChapterMessagesOrResults':True,'limits':['Controlled local HTTP server serves original bytes with no-store headers and configurable real response latency; failure case closes real image request sockets. No dummy replacement image, JavaScript readiness override or CSS injection.','Initial standalone and iframe loads run in independently owned fresh Chromium sessions.','All354 selectable roster UIDs have mapped atlases. Unmapped renderer compatibility is inspected read-only; no fictional unmapped character is inserted into actual UI.','Source pin changes are reported, not suppressed, if another agent updates the shared game during this independent audit.']}
 p=OUT/'REAL_STORY_ALBUM_BROWSER_QA.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');manifest=[pin(q) for q in sorted(OUT.rglob('*')) if q.is_file()];(OUT/'FILE_PINS.json').write_text(json.dumps(manifest,indent=2)+'\n');total=sum(q.stat().st_size for q in OUT.parent.rglob('*') if q.is_file());print(json.dumps({'status':report['status'],'report':pin(p),'proofFolderBytes':total,'budgetBytes':20*1048576,'sourcePinChanges':len(changed)},indent=2),flush=True)
 if total>20*1048576:raise AssertionError('Proof exceeds20MiB; keep files and notify root')
if errors:raise SystemExit(1)
