(() => {
  const observed = window.__cqcStoryLoadingPassive = {version:1, startedAt:performance.now(), states:[], messages:[], errors:[]};
  let last='',lastTime=0;
  const visibility = el => {
    if(!el)return null;
    const s=getComputedStyle(el),r=el.getBoundingClientRect();
    return {hidden:el.hidden,display:s.display,visibility:s.visibility,visible:r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'};
  };
  const minimalSprite = (w,uid) => {
    const s=w.CQC_COMBAT_SPRITES?.status(uid);
    return s?{uid,renderer:s.renderer,ready:s.ready,states:s.states||null}:null;
  };
  const engine = () => {
    try{
      const w=document.querySelector('#engine')?.contentWindow;
      if(!w?.__CQC055Versus)return null;
      const s=w.__CQC055Versus.getState(),d=w.__CQC055Versus.diagnostics();
      return {diagnostics:d,state:s?{phase:s.phase,finished:s.finished,timerSeconds:Math.floor(s.timer/60),stage:s.stage?.id,actors:[s.a,s.b].map(a=>({uid:a.f.uid,life:a.life,max:a.max,wins:a.wins}))}:null,actors:s?[minimalSprite(w,s.a.f.uid),minimalSprite(w,s.b.f.uid)]:[],stage:s?w.CQC_STAGE_LAYERS?.status(s.stage):null,stageCache:w.CQC_STAGE_LAYERS?.cacheInfo?.(),loadingOverlay:visibility(w.document.querySelector('#matchLoadingPass10')),fightScreen:visibility(w.document.querySelector('#fightScreen'))};
    }catch(e){return {readError:String(e)}}
  };
  const snap = () => {
    const s=window.CQC56?.snapshot?.(),uid=s?.profile?.selected||document.querySelector('#choice')?.value;
    const active=s?.profile?.active;
    const canvases=[...document.querySelectorAll('#heroArt,#sceneArt,#portrait,#intro canvas,#outro canvas')].map(c=>({id:c.id||c.getAttribute('aria-label'),data:{...c.dataset},busy:c.getAttribute('aria-busy'),visible:visibility(c),width:c.width,height:c.height}));
    const roster=[...document.querySelectorAll('#roster canvas')].slice(0,18).map(c=>({uid:c.parentElement.dataset.uid,data:{...c.dataset},busy:c.getAttribute('aria-busy')}));
    return {url:location.href,parent:parent!==window,selected:uid||null,screen:s?.screen||null,profile:active?{uid:active.uid,index:active.index,page:active.page,phase:active.phase,won:active.won,continues:active.continues,spent:active.spent}:null,replay:s?.replay||null,pending:s?.pending||null,paused:s?.paused||false,auto:s?.profile?.settings?.auto||false,diagnostics:s?.diagnostics||null,wait:visibility(document.querySelector('#wait')),waitText:document.querySelector('#wait')?.textContent||null,canvases,roster,sprite:uid?minimalSprite(window,uid):null,portrait:uid?window.CQC56_PORTRAITS?.status(uid):null,cinema:window.CQC56_CINEMA?.diagnostics?.(),engine:engine()};
  };
  observed.snapshot=snap;
  addEventListener('message',e=>{
    const d=e.data;
    if(!d?.type?.startsWith?.('cqc55.'))return;
    const w=document.querySelector('#engine')?.contentWindow;
    if(observed.messages.length<1000)observed.messages.push({at:performance.now(),type:d.type,data:JSON.parse(JSON.stringify(d)),fromActualEngine:e.source===w,engineAtReceipt:engine()});
  });
  addEventListener('error',e=>{if(observed.errors.length<100)observed.errors.push({message:e.message,filename:e.filename,at:performance.now()})});
  addEventListener('unhandledrejection',e=>{if(observed.errors.length<100)observed.errors.push({message:String(e.reason),at:performance.now()})});
  function frame(t){
    if(t-lastTime>=80){lastTime=t;const state=snap(),key=JSON.stringify(state);if(key!==last){last=key;if(observed.states.length<2400)observed.states.push({at:t,...state})}}
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
