"""Owned real browsers + byte-exact HTTP source; passive observers, real UI only."""
import sys
sys.dont_write_bytecode=True
import json,pathlib,time,datetime,hashlib,importlib.util,threading,http.server,socket,urllib.parse
ROOT=pathlib.Path('/workspace/cqc-game-working/cqc-versus-v056')
OUT=pathlib.Path('/workspace/cqc-pass10-story-loading-browser-QA/actual-01');OUT.mkdir(exist_ok=False)
OBSERVER=OUT.parent/'passive-story-observer.js'
spec=importlib.util.spec_from_file_location('readonly_common','/workspace/cqc-pass6-browser-common.py');C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)
policy={'case':'initial','nativeDelay':0,'atlasDelay':0,'stageDelay':0,'plateDelay':0,'failNative':False,'failAtlas':False}
requests=[];lock=threading.Lock()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
files=['modules/chronicles-v056.html','modules/unified-versus-v055.html','src/chronicles-v056.js','src/chronicles-v056.css','src/chronicles-cinema-v056.js','src/chronicles-portraits-v056.js','src/chronicles-art-v056.js','src/cqc-sprite-renderer.js','src/cqc-sprite-catalog.js','src/cqc-stage-layers.js','src/cqc-stage-layer-data.js','docs/ALBUM_LOCAL_354_RECITS_v0.56.html']
before=[pin(ROOT/f) for f in files]
class Handler(http.server.SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(ROOT),**kw)
 def log_message(self,*a):pass
 def end_headers(self):self.send_header('Cache-Control','no-store');super().end_headers()
 def do_GET(self):
  path=urllib.parse.urlsplit(self.path).path
  native='/assets/combat-sprites/' in path
  atlas='/assets/portraits-v056/' in path
  stage='/assets/stages' in path and path.endswith('.png')
  plate='/assets/illustrations' in path or '/assets/cinema-v056/' in path
  rules=policy.copy();delay=rules['nativeDelay'] if native else rules['atlasDelay'] if atlas else rules['stageDelay'] if stage else rules['plateDelay'] if plate else 0
  row={'path':path,'case':rules['case'],'native':native,'atlas':atlas,'stage':stage,'delaySeconds':delay,'requestedAt':time.monotonic()}
  with lock:requests.append(row)
  if delay:time.sleep(delay)
  if (native and rules['failNative']) or (atlas and rules['failAtlas']):
   row['failure']='controlled-real-socket-abort';row['finishedAt']=time.monotonic()
   try:self.connection.shutdown(socket.SHUT_RDWR)
   except OSError:pass
   self.connection.close();return
  try:super().do_GET();row['finishedAt']=time.monotonic()
  except (BrokenPipeError,ConnectionResetError):row['clientCancelled']=True;row['finishedAt']=time.monotonic()
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True
threading.Thread(target=server.serve_forever,daemon=True).start();port=server.server_address[1]
base=f'http://127.0.0.1:{port}'
allcases=[];errors=[];browsers=[]
def new_browser(case):
 p=OUT/case;p.mkdir();b=C.Browser(p,'pass10-story-'+case);b.env['AGENT_BROWSER_INIT_SCRIPTS']=str(OBSERVER);b.env['AGENT_BROWSER_SCREENSHOT_FORMAT']='jpeg';b.env['AGENT_BROWSER_SCREENSHOT_QUALITY']='55';b.prefix[b.prefix.index('--args')+1]='--no-sandbox,--disk-cache-size=1,--media-cache-size=1';browsers.append(b);b.call('set','viewport','1366','768');return b

def evaluate(b):return b.evaluate('window.__cqcStoryLoadingPassive.snapshot()')
def capture(b,name):
 row={'name':name,'snapshot':evaluate(b)};b.checks.append(row);b.call('screenshot',str(b.out/(name+'.jpg')));return row['snapshot']
def save_case(b):
 try:
  observed=b.evaluate('(()=>{const o=window.__cqcStoryLoadingPassive;return{version:o.version,states:o.states,messages:o.messages,errors:o.errors}})()');b.save('passive-observations.json',observed);b.save('browser-errors.json',b.call('errors'));b.save('checks.json',b.checks)
 except Exception as e:errors.append({'case':b.out.name,'collectionError':repr(e)})
 finally:b.close();b.save('commands.json',b.commands)
 allcases.append({'case':b.out.name,'session':b.session,'commands':len(b.commands),'checks':len(b.checks)})
def waitfn(b,fn):b.call('wait','--fn',fn)
def ui_menu(b):
 screen=b.evaluate('window.CQC56.snapshot().screen')
 if screen=='scene':b.call('click','#exitBtn')
 elif screen=='gallery':b.call('click','#galleryBack')
 elif screen=='fight':b.call('click','#quitBtn');b.call('click','#modalActions button:last-child')
def choose(b,uid):
 ui_menu(b);name=b.evaluate('window.CQC56.data.fighters.find(f=>f.uid==='+json.dumps(uid)+').name');b.call('fill','#search',name);b.call('click','[data-uid="'+uid+'"]')
def begin(b):
 b.call('click','#beginBtn')
 if b.evaluate('document.querySelector("#modal").open'):b.call('click','#modalActions button:last-child')
def options_for_fast_real_duel(b):
 b.call('click','#optionsBtn');b.call('select','#modalContent label:nth-of-type(7) select','legend');b.call('select','#modalContent label:nth-of-type(8) select','1');b.call('select','#modalContent label:nth-of-type(9) select','off');b.call('click','#modalActions button:last-child')
try:
 # Case1: atlas and native scene redraw; old pending native chapter cancelled through actual UI.
 policy.update(case='direct-cold-cancel',nativeDelay=9,atlasDelay=3,stageDelay=9,plateDelay=1)
 b=new_browser('direct-cold-cancel')
 try:
  b.call('open',base+'/modules/chronicles-v056.html');b.call('wait','--load','networkidle');b.save('initial-snapshot.json',b.call('snapshot','-i'));capture(b,'initial-direct-ui')
  choose(b,'core__campbell_mpo');capture(b,'campbell-atlas-loading');waitfn(b,'document.querySelector("#heroArt").dataset.actorRenderer === "portrait"');capture(b,'campbell-atlas-ready')
  choose(b,'archive__laughing_beauty');capture(b,'beauty-native-loading');begin(b);b.call('click','#skipBtn');b.call('click','#nextBtn');waitfn(b,'window.CQC56.snapshot().pending?.loading === true');old=capture(b,'actual-chapter-pending-before-cancel');oldtoken=old['pending']['token'];b.save('cancelled-token.json',{'token':oldtoken,'profile':old['profile']})
  b.call('click','#quitBtn');b.call('click','#modalActions button:last-child');choose(b,'core__campbell_mpo');begin(b);capture(b,'replacement-campbell-chapter');b.call('wait','11500');after=capture(b,'replacement-after-old-pngs-finish');assert after['profile']['uid']=='core__campbell_mpo' and after['pending'] is None and after['screen']=='scene'
  msgs=b.evaluate('window.__cqcStoryLoadingPassive.messages');assert not any(m['type']=='cqc55.started' and m['data'].get('token')==oldtoken for m in msgs),'Cancelled real engine must not emit stale started ACK'
  ui_menu(b);choose(b,'core__snake');capture(b,'full-scene-clean-hero');begin(b);waitfn(b,'document.querySelector("#sceneArt").dataset.artState === "ready"');s=capture(b,'full-scene-clean-story');assert s['canvases'][1]['data']['composition']=='full-scene'
  print('Direct cold cancel/replace, mapped atlas/native and full-scene case complete.',flush=True)
 finally:save_case(b)
 # Case2: fully real chapter starts only after both actor sources and all four stage planes decode.
 policy.update(case='actual-chapter-progression',nativeDelay=8,atlasDelay=1,stageDelay=8,plateDelay=0)
 b=new_browser('actual-chapter-progression')
 try:
  b.call('open',base+'/modules/chronicles-v056.html');b.call('wait','--load','networkidle');options_for_fast_real_duel(b);choose(b,'archive__laughing_beauty');begin(b);b.call('click','#skipBtn');before_start=capture(b,'pre-chapter-profile');b.call('click','#nextBtn');waitfn(b,'window.CQC56.snapshot().pending?.loading === true');capture(b,'real-chapter-loading');waitfn(b,'window.CQC56.snapshot().pending?.started === true');started=capture(b,'real-chapter-started')
  assert started['engine']['stage']['state']=='ready' and started['engine']['stage']['layers']==4 and all(a['ready'] for a in started['engine']['actors'])
  assert started['wait']['hidden'] is True and started['wait']['visible'] is False,'Parent wait overlay must really disappear, not merely have hidden=true'
  assert started['engine']['loadingOverlay']['visible'] is False
  print('Real chapter loading→started: four stage planes and two native actors decoded before ACK.',flush=True)
  # Let the real Legend CPU run; never inject a result, state, step, draw or postMessage.
  result=None
  for i in range(8):
   b.call('wait','15000');result=evaluate(b)
   if result['screen']=='scene' and result['profile']['phase'] in ('post','defeat'):break
   print('Actual combat is still running at '+str((i+1)*15)+'s; waiting for its real result.',flush=True)
  if not(result and result['screen']=='scene' and result['profile']['phase'] in ('post','defeat')):raise AssertionError('Real combat did not finish within120s; no synthetic result permitted')
  capture(b,'actual-result-progression');actual=b.evaluate('window.__cqcStoryLoadingPassive.messages.filter(m=>m.type==="cqc55.result")');assert actual and all(m['fromActualEngine'] for m in actual)
  if result['profile']['phase']=='defeat':assert result['profile']['continues']==before_start['profile']['continues']-1 and result['profile']['won']==before_start['profile']['won']
  else:assert result['profile']['won']==before_start['profile']['won']+1
  assert result['diagnostics']['accepted']==1
  # Enable actual Auto setting, then open actual unlocked prologue replay; auto must not advance replay.
  b.call('click','#optionsBtn');b.call('check','#modalContent label:nth-of-type(2) input');b.call('click','#modalActions button:last-child');b.call('click','#galleryBtn');b.call('fill','#gallerySearch','LAUGHING BEAUTY');b.call('click','article[data-uid="archive__laughing_beauty"] button:first-child');replay_before=capture(b,'actual-gallery-replay-auto-enabled');delay=b.evaluate('Math.max(7000,window.CQC56.data.stories[window.CQC56.snapshot().replay.uid].intro[0].text.length*55)+600');b.save('replay-auto-delay.json',{'delayMs':delay})
  remaining=delay
  while remaining>0:
   chunk=min(20000,remaining);b.call('wait',str(chunk));remaining-=chunk
  replay_after=capture(b,'gallery-replay-after-auto-window');assert replay_after['replay']==replay_before['replay'] and replay_after['profile']==replay_before['profile'],'Replay and active story must not auto-progress'
  print('Actual combat result accepted through UI; replay remains unchanged with Auto enabled.',flush=True)
 finally:save_case(b)
 # Case3: real failing network transfers, neutral mapped art failure and no automatic retry.
 policy.update(case='direct-terminal-network-failures',nativeDelay=0,atlasDelay=0,stageDelay=0,plateDelay=0,failNative=True,failAtlas=True)
 b=new_browser('direct-terminal-network-failures')
 try:
  b.call('open',base+'/modules/chronicles-v056.html');b.call('wait','--load','networkidle');choose(b,'core__campbell_mpo');waitfn(b,'document.querySelector("#heroArt").dataset.actorRenderer === "failed-portrait"');capture(b,'atlas-terminal-neutral');choose(b,'archive__laughing_beauty');waitfn(b,'document.querySelector("#heroArt").dataset.actorRenderer === "failed-combat-png"');capture(b,'native-terminal-neutral');n=len([r for r in requests if r['case']==policy['case'] and r['native']]);b.call('wait','2000');assert len([r for r in requests if r['case']==policy['case'] and r['native']])==n;capture(b,'terminal-state-no-retry')
  unknown=b.evaluate('window.CQC_COMBAT_SPRITES.status("__unknown-not-a-fighter__")');b.save('unknown-renderer-readonly.json',unknown);assert unknown['renderer']=='procedural-canvas'
  print('Real socket failures: mapped native/atlas remain neutral, terminal state does not auto-retry.',flush=True)
 finally:save_case(b)
 # Case4: actual standalone album with six independently rendered cards and loading callbacks.
 policy.update(case='album-cold',nativeDelay=6,atlasDelay=3,stageDelay=5,plateDelay=1,failNative=False,failAtlas=False)
 b=new_browser('album-cold')
 try:
  b.call('open',base+'/docs/ALBUM_LOCAL_354_RECITS_v0.56.html');b.call('wait','--load','networkidle');b.save('initial-snapshot.json',b.call('snapshot','-i'));capture(b,'initial-album-ui');b.call('select','#choice','core__campbell_mpo');capture(b,'album-atlas-composition-loading');waitfn(b,'[...document.querySelectorAll("#intro canvas,#outro canvas")].every(c=>c.dataset.portraitReady==="true")');capture(b,'album-atlas-composition-ready');b.call('select','#choice','archive__laughing_beauty');capture(b,'album-native-composition-loading');waitfn(b,'[...document.querySelectorAll("#intro canvas,#outro canvas")].every(c=>c.dataset.portraitReady==="true")');capture(b,'album-native-composition-ready');b.call('select','#choice','core__snake');waitfn(b,'[...document.querySelectorAll("#intro canvas,#outro canvas")].every(c=>c.dataset.artState==="ready")');s=capture(b,'album-six-full-scenes-clean');cards=[x for x in s['canvases'] if x['id']!='portrait'];assert len(cards)==6 and all(c['data']['composition']=='full-scene' and c['data']['portraitReady']=='not-required' for c in cards)
  print('Standalone album: atlas/native callbacks and six full scenes observed.',flush=True)
 finally:save_case(b)
except Exception as e:
 errors.append({'failure':repr(e)});print('FAIL '+repr(e),flush=True)
finally:
 server.shutdown();server.server_close()
 after=[pin(ROOT/f) for f in files]
 changed=[{'before':a,'after':z} for a,z in zip(before,after) if a!=z]
 report={'schema':'cqc.pass10.independent-story-album-loading-real-browser/1','status':'failed' if errors else 'observed','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ownedHTTPOrigin':base,'ownedHTTPStopped':True,'sourcePinsBefore':before,'sourcePinsAfter':after,'sourceChangedDuringAudit':changed,'caseReceipts':allcases,'errors':errors,'passiveObserver':pin(OBSERVER),'tool':pin(pathlib.Path(__file__)),'networkRequests':requests,'noSourceOrGitMutationByAudit':True,'noMockedReadinessOrRendering':True,'noSyntheticChapterMessagesOrResults':True,'limits':['Controlled local HTTP server serves original bytes with no-store headers and configurable real response latency; failure case closes real image request sockets. No dummy replacement image, JavaScript readiness override or CSS injection.','Initial standalone and iframe loads run in independently owned fresh Chromium sessions.','All354 selectable roster UIDs have mapped atlases. Unmapped renderer compatibility is inspected read-only; no fictional unmapped character is inserted into actual UI.','Source pin changes are reported, not suppressed, if another agent updates the shared game during this independent audit.']}
 p=OUT/'REAL_STORY_ALBUM_BROWSER_QA.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');manifest=[pin(q) for q in sorted(OUT.rglob('*')) if q.is_file()];(OUT/'FILE_PINS.json').write_text(json.dumps(manifest,indent=2)+'\n');total=sum(q.stat().st_size for q in OUT.parent.rglob('*') if q.is_file());print(json.dumps({'status':report['status'],'report':pin(p),'proofFolderBytes':total,'budgetBytes':20*1048576,'sourcePinChanges':len(changed)},indent=2),flush=True)
 if total>20*1048576:raise AssertionError('Proof exceeds20MiB; keep files and notify root')
if errors:raise SystemExit(1)
