"""Owned real browsers + byte-exact HTTP source; passive observers, real UI only."""
import sys
sys.dont_write_bytecode=True
import json,pathlib,time,datetime,hashlib,importlib.util,threading,http.server,socket,urllib.parse
ROOT=pathlib.Path('/workspace/cqc-game-working/cqc-versus-v056')
OUT=pathlib.Path('/workspace/cqc-pass10-story-loading-browser-QA/actual-04');OUT.mkdir(exist_ok=False)
OBSERVER=OUT.parent/'passive-story-observer-v2.js'
spec=importlib.util.spec_from_file_location('readonly_common','/workspace/cqc-pass6-browser-common.py');C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)
policy={'case':'initial','nativeDelay':0,'atlasDelay':0,'stageDelay':0,'plateDelay':0,'failNative':False,'failAtlas':False}
requests=[];lock=threading.Lock()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
files=['modules/chronicles-v056.html','modules/unified-versus-v055.html','src/chronicles-v056.js','src/chronicles-v056.css','src/chronicles-cinema-v056.js','src/chronicles-portraits-v056.js','src/chronicles-art-v056.js','src/cqc-sprite-renderer.js','src/cqc-sprite-catalog.js','src/cqc-stage-layers.js','src/cqc-stage-layer-data.js','docs/ALBUM_LOCAL_354_RECITS_v0.56.html']
before=[pin(ROOT/f) for f in files]
class Handler(http.server.SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(ROOT),**kw)
 def log_message(self,*a):pass
 def end_headers(self):self.send_header('Cache-Control','no-store');super().end_headers()
 def send_response(self,code,message=None):
  if getattr(self,'_audit_row',None) is not None:self._audit_row['httpStatus']=code
  return super().send_response(code,message)
 def do_GET(self):
  path=urllib.parse.urlsplit(self.path).path
  native='/assets/combat-sprites/' in path
  atlas='/assets/portraits-v056/' in path
  stage='/assets/stages' in path and path.endswith('.png')
  plate='/assets/illustrations' in path or '/assets/cinema-v056/' in path
  rules=policy.copy();delay=rules['nativeDelay'] if native else rules['atlasDelay'] if atlas else rules['stageDelay'] if stage else rules['plateDelay'] if plate else 0
  if native and not any('/'+u+'/' in path for u in ('archive__laughing_beauty','core__laughing_octopus')):delay=0
  if atlas and not any(x in path for x in ('atlas-21.webp','atlas-07.webp')):delay=0
  row={'path':path,'case':rules['case'],'native':native,'atlas':atlas,'stage':stage,'plate':plate,'delaySeconds':delay,'requestedAt':time.monotonic()}
  self._audit_row=row
  with lock:requests.append(row)
  if delay:time.sleep(delay)
  if (native and rules['failNative']) or (atlas and rules['failAtlas']):
   row['failure']='controlled-real-socket-abort';row['finishedAt']=time.monotonic()
   try:self.connection.shutdown(socket.SHUT_RDWR)
   except OSError:pass
   self.connection.close();return
  try:super().do_GET();row['finishedAt']=time.monotonic()
  except (BrokenPipeError,ConnectionResetError):row['clientCancelled']=True;row['finishedAt']=time.monotonic()
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True
threading.Thread(target=server.serve_forever,daemon=True).start();port=server.server_address[1]
base=f'http://127.0.0.1:{port}'
allcases=[];errors=[];browsers=[]
def new_browser(case):
 p=OUT/case;p.mkdir();b=C.Browser(p,'sqa'+str(len(browsers)));b.env['AGENT_BROWSER_INIT_SCRIPTS']=str(OBSERVER);b.env['AGENT_BROWSER_SCREENSHOT_FORMAT']='jpeg';b.env['AGENT_BROWSER_SCREENSHOT_QUALITY']='55';b.prefix[b.prefix.index('--args')+1]='--no-sandbox,--disk-cache-size=1,--media-cache-size=1';browsers.append(b);b.call('set','viewport','1366','768');return b

def evaluate(b):return b.evaluate('window.__cqcStoryLoadingPassive.snapshot()')
def capture(b,name):
 row={'name':name,'snapshot':evaluate(b)};b.checks.append(row);b.call('screenshot',str(b.out/(name+'.jpg')));return row['snapshot']
def save_case(b):
 try:
  observed=b.evaluate('(()=>{const o=window.__cqcStoryLoadingPassive;return{version:o.version,states:o.states,messages:o.messages,errors:o.errors}})()');b.save('passive-observations.json',observed);b.save('browser-errors.json',b.call('errors'));b.save('checks.json',b.checks)
 except Exception as e:errors.append({'case':b.out.name,'collectionError':repr(e)})
 finally:b.close();b.save('commands.json',b.commands)
 allcases.append({'case':b.out.name,'session':b.session,'commands':len(b.commands),'checks':len(b.checks)})
def waitfn(b,fn):b.call('wait','--fn',fn)
def ui_menu(b):
 screen=b.evaluate('window.CQC56.snapshot().screen')
 if screen=='scene':b.call('click','#exitBtn')
 elif screen=='gallery':b.call('click','#galleryBack')
 elif screen=='fight':b.call('click','#quitBtn');b.call('click','#modalActions button:last-child')
def choose(b,uid):
 ui_menu(b);name=b.evaluate('window.CQC56.data.fighters.find(f=>f.uid==='+json.dumps(uid)+').name');b.call('fill','#search',name);b.call('click','[data-uid="'+uid+'"]')
def begin(b):
 b.call('click','#beginBtn')
 if b.evaluate('document.querySelector("#modal").open'):b.call('click','#modalActions button:last-child')
def options_for_fast_real_duel(b):
 b.call('click','#optionsBtn');b.call('select','#modalContent label:nth-of-type(7) select','legend');b.call('select','#modalContent label:nth-of-type(8) select','1');b.call('select','#modalContent label:nth-of-type(9) select','off');b.call('click','#modalActions button:last-child')
def wait_long(b,fn,max_ms=120000):
 start=time.monotonic()
 while (time.monotonic()-start)*1000<max_ms:
  if b.evaluate('Boolean('+fn+')'):return
  b.call('wait','1500')
 raise AssertionError('Condition remained false for '+str(max_ms)+'ms: '+fn)
def direct_cancel(b):
 b.call('open',base+'/modules/chronicles-v056.html');b.call('wait','--load','networkidle');b.save('initial-snapshot.json',b.call('snapshot','-i'));capture(b,'initial-direct-ui')
 choose(b,'roster50__otacon_mobile');capture(b,'otacon-atlas-loading');wait_long(b,'document.querySelector("#heroArt").dataset.actorRenderer === "portrait"');capture(b,'otacon-atlas-ready')
 choose(b,'archive__laughing_beauty');capture(b,'beauty-native-loading');begin(b);b.call('click','#skipBtn');b.call('click','#nextBtn');wait_long(b,'window.CQC56.snapshot().pending?.loading === true',30000);old=capture(b,'actual-chapter-pending-before-cancel');oldtoken=old['pending']['token'];b.save('cancelled-token.json',{'token':oldtoken,'profile':old['profile']})
 b.call('click','#quitBtn');b.call('click','#modalActions button:last-child');choose(b,'roster50__otacon_mobile');begin(b);capture(b,'replacement-otacon-chapter');b.call('wait','11500');after=capture(b,'replacement-after-old-pngs-finish');assert after['profile']['uid']=='roster50__otacon_mobile' and after['pending'] is None and after['screen']=='scene'
 msgs=b.evaluate('window.__cqcStoryLoadingPassive.messages');assert not any(m['type']=='cqc55.started' and m['data'].get('token')==oldtoken for m in msgs),'Cancelled real engine must not emit stale started ACK'
 print('PASS cancel/replace: actual old chapter never starts after replacement.',flush=True)
def full_scene(b):
 b.call('open',base+'/modules/chronicles-v056.html');b.call('wait','--load','networkidle');choose(b,'core__snake');wait_long(b,'document.querySelector("#heroArt").dataset.artState === "ready"',45000);capture(b,'full-scene-clean-hero');begin(b);wait_long(b,'document.querySelector("#sceneArt").dataset.artState === "ready"',45000);s=capture(b,'full-scene-clean-story');assert s['canvases'][1]['data']['composition']=='full-scene' and s['canvases'][1]['data']['portraitReady']=='not-required'
 print('PASS clean fullScene: real image decode, no additional actor/stage composition.',flush=True)
def chapter_progress(b):
 b.call('open',base+'/modules/chronicles-v056.html');b.call('wait','--load','networkidle');options_for_fast_real_duel(b);choose(b,'archive__laughing_beauty');begin(b);b.call('click','#skipBtn');before_start=capture(b,'pre-chapter-profile');b.call('click','#nextBtn');wait_long(b,'window.CQC56.snapshot().pending?.loading === true',30000);capture(b,'real-chapter-loading');wait_long(b,'window.CQC56.snapshot().pending?.started === true',120000);started=capture(b,'real-chapter-started')
 assert started['engine']['stage']['state']=='ready' and started['engine']['stage']['layers']==4 and all(a['ready'] for a in started['engine']['actors'])
 assert started['wait']['hidden'] is True and started['wait']['visible'] is False,'Parent wait overlay must really disappear'
 assert started['engine']['loadingOverlay']['visible'] is False
 print('PASS chapter started after2nativeactors+4stageplanes decoded; overlays disappear.',flush=True)
 result=None
 for i in range(10):
  b.call('wait','15000');result=evaluate(b)
  if result['screen']=='scene' and result['profile']['phase'] in ('post','defeat'):break
  print('Actual combat still running at '+str((i+1)*15)+'s.',flush=True)
 if not(result and result['screen']=='scene' and result['profile']['phase'] in ('post','defeat')):raise AssertionError('Real combat did not finish within150s; no synthetic result permitted')
 capture(b,'actual-result-progression');actual=b.evaluate('window.__cqcStoryLoadingPassive.messages.filter(m=>m.type==="cqc55.result")');assert actual and all(m['fromActualEngine'] for m in actual)
 if result['profile']['phase']=='defeat':assert result['profile']['continues']==before_start['profile']['continues']-1 and result['profile']['won']==before_start['profile']['won']
 else:assert result['profile']['won']==before_start['profile']['won']+1
 assert result['diagnostics']['accepted']==1
 b.call('click','#optionsBtn');b.call('check','#modalContent label:nth-of-type(2) input');b.call('click','#modalActions button:last-child');b.call('click','#galleryBtn');b.call('fill','#gallerySearch','LAUGHING BEAUTY');b.call('click','article[data-uid="archive__laughing_beauty"] button:first-child');replay_before=capture(b,'actual-gallery-replay-auto-enabled');delay=b.evaluate('Math.max(7000,window.CQC56.data.stories[window.CQC56.snapshot().replay.uid].intro[0].text.length*55)+600');b.save('replay-auto-delay.json',{'delayMs':delay})
 remaining=delay
 while remaining>0:
  chunk=min(20000,remaining);b.call('wait',str(chunk));remaining-=chunk
 replay_after=capture(b,'gallery-replay-after-auto-window');assert replay_after['replay']==replay_before['replay'] and replay_after['profile']==replay_before['profile'],'Replay and active story must not auto-progress'
 print('PASS actual engine result progression and gallery replay stays unchanged with Auto enabled.',flush=True)
def terminal_failures(b):
 b.call('open',base+'/modules/chronicles-v056.html');b.call('wait','--load','networkidle');choose(b,'roster50__otacon_mobile');wait_long(b,'document.querySelector("#heroArt").dataset.actorRenderer === "failed-portrait"',35000);capture(b,'atlas-terminal-neutral');choose(b,'archive__laughing_beauty');wait_long(b,'document.querySelector("#heroArt").dataset.actorRenderer === "failed-combat-png"',35000);capture(b,'native-terminal-neutral');n=len([r for r in requests if r['case']==policy['case'] and r['native']]);b.call('wait','2000');assert len([r for r in requests if r['case']==policy['case'] and r['native']])==n;capture(b,'terminal-state-no-retry')
 unknown=b.evaluate('window.CQC_COMBAT_SPRITES.status("__unknown-not-a-fighter__")');b.save('unknown-renderer-readonly.json',unknown);assert unknown['renderer']=='procedural-canvas'
 print('PASS actual failed image sockets produce neutral terminal actor states, no retry.',flush=True)
def album(b):
 b.call('open',base+'/docs/ALBUM_LOCAL_354_RECITS_v0.56.html');b.call('wait','--load','networkidle');b.save('initial-snapshot.json',b.call('snapshot','-i'));capture(b,'initial-album-ui');b.call('select','#choice','roster50__otacon_mobile');capture(b,'album-atlas-composition-loading');wait_long(b,'[...document.querySelectorAll("#intro canvas,#outro canvas")].every(c=>c.dataset.portraitReady==="true")',45000);capture(b,'album-atlas-composition-ready');b.call('select','#choice','archive__laughing_beauty');capture(b,'album-native-composition-loading');wait_long(b,'[...document.querySelectorAll("#intro canvas,#outro canvas")].every(c=>c.dataset.portraitReady==="true")',90000);capture(b,'album-native-composition-ready');b.call('select','#choice','core__snake');wait_long(b,'[...document.querySelectorAll("#intro canvas,#outro canvas")].every(c=>c.dataset.artState==="ready")',90000);s=capture(b,'album-six-full-scenes-clean');cards=[x for x in s['canvases'] if x['id']!='portrait'];assert len(cards)==6 and all(c['data']['composition']=='full-scene' and c['data']['portraitReady']=='not-required' for c in cards)
 print('PASS standalone album actual atlas/native callbacks and6cleanfullscenes.',flush=True)
cases=[('actual-chapter-progression',chapter_progress,{'nativeDelay':3,'atlasDelay':1,'stageDelay':3,'plateDelay':0})]
try:
 for name,case,config in cases:
  policy.update(case=name,nativeDelay=0,atlasDelay=0,stageDelay=0,plateDelay=0,failNative=False,failAtlas=False);policy.update(config)
  b=new_browser(name)
  try:case(b)
  except Exception as e:
   errors.append({'case':name,'failure':repr(e)});print('FAIL '+name+' '+repr(e),flush=True)
   try:capture(b,'failure-current-actual-ui')
   except Exception as cap:errors.append({'case':name,'failedCapture':repr(cap)})
  finally:save_case(b)
finally:
 server.shutdown();server.server_close()
 after=[pin(ROOT/f) for f in files]
 changed=[{'before':a,'after':z} for a,z in zip(before,after) if a!=z]
 report={'schema':'cqc.pass10.independent-story-album-loading-real-browser/1','status':'failed' if errors else 'observed','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ownedHTTPOrigin':base,'ownedHTTPStopped':True,'sourcePinsBefore':before,'sourcePinsAfter':after,'sourceChangedDuringAudit':changed,'caseReceipts':allcases,'errors':errors,'passiveObserver':pin(OBSERVER),'tool':pin(pathlib.Path(__file__)),'networkRequests':requests,'noSourceOrGitMutationByAudit':True,'noMockedReadinessOrRendering':True,'noSyntheticChapterMessagesOrResults':True,'limits':['Controlled local HTTP server serves original bytes with no-store headers and configurable real response latency; failure case closes real image request sockets. No dummy replacement image, JavaScript readiness override or CSS injection.','Initial standalone and iframe loads run in independently owned fresh Chromium sessions.','All354 selectable roster UIDs have mapped atlases. Unmapped renderer compatibility is inspected read-only; no fictional unmapped character is inserted into actual UI.','Source pin changes are reported, not suppressed, if another agent updates the shared game during this independent audit.']}
 p=OUT/'REAL_STORY_ALBUM_BROWSER_QA.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');manifest=[pin(q) for q in sorted(OUT.rglob('*')) if q.is_file()];(OUT/'FILE_PINS.json').write_text(json.dumps(manifest,indent=2)+'\n');total=sum(q.stat().st_size for q in OUT.parent.rglob('*') if q.is_file());print(json.dumps({'status':report['status'],'report':pin(p),'proofFolderBytes':total,'budgetBytes':20*1048576,'sourcePinChanges':len(changed)},indent=2),flush=True)
 if total>20*1048576:raise AssertionError('Proof exceeds20MiB; keep files and notify root')
if errors:raise SystemExit(1)
