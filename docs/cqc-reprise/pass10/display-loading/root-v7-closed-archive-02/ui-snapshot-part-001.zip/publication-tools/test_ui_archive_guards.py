"""Isolated synthetic ZIP/staging boundary checks; never touches real R/S."""
import sys
sys.dont_write_bytecode=True
import argparse,hashlib,importlib.util,json,pathlib,tempfile,unittest,random,datetime
from unittest.mock import patch
B=pathlib.Path('/workspace/cqc-pass10-ui-publication-preparation')
s=importlib.util.spec_from_file_location('archive_guard_tests',B/'prepare_ui_only_archive_v2.py')
tool=importlib.util.module_from_spec(s);s.loader.exec_module(tool)

class Guards(unittest.TestCase):
 def test_catalog_json_excluded(self):self.assertFalse(tool.permitted(pathlib.Path('data/combat-sprite-catalog-v1.json')))
 def test_runtime_catalog_js_excluded(self):self.assertFalse(tool.permitted(pathlib.Path('src/cqc-sprite-catalog.js')))
 def test_assets_excluded(self):self.assertFalse(tool.permitted(pathlib.Path('assets/combat-sprites/source.png')))
 def test_generation_excluded(self):self.assertFalse(tool.permitted(pathlib.Path('native-attempts/source.png')))
 def test_references_excluded(self):self.assertFalse(tool.permitted(pathlib.Path('references/art.png')))
 def test_ui_screenshot_allowed(self):self.assertTrue(tool.permitted(pathlib.Path('actual-ui/mobile-cold-selection.jpg')))
 def test_ui_module_allowed(self):self.assertTrue(tool.permitted(pathlib.Path('current-R/modules/unified-versus-v055.html')))
 def test_unsafe_archive_path_rejected(self):
  for name in ['/tmp/x','a/../b','a\\b','a//b','a\n.txt']:
   with self.assertRaises(RuntimeError):tool.safe_name(name)
 def test_zip_segments_roundtrip_every_sha_and_byte(self):
  with tempfile.TemporaryDirectory(dir=B)as name:
   base=pathlib.Path(name);out=base/'out';out.mkdir();rows=[];rng=random.Random(101)
   for i in range(4):
    p=base/(str(i)+'.txt');p.write_bytes(bytes(rng.randrange(256)for _ in range(1800)));rows.append({'member':'fixture/'+p.name,**tool.pin(p)})
   with patch.object(tool,'MAX_SEGMENT',5000):parts=tool.pack_segments(rows,out)
   self.assertGreater(len(parts),1);self.assertEqual(sum(len(x['members'])for x in parts),4)
   for row in parts:self.assertLess(row['bytes'],5000);self.assertTrue(row['allMembersSHA256RoundtripVerified'])
 def test_one_member_over_segment_limit_rejected_without_source_edit(self):
  with tempfile.TemporaryDirectory(dir=B)as name:
   base=pathlib.Path(name);out=base/'out';out.mkdir();p=base/'large.txt';rng=random.Random(102);p.write_bytes(bytes(rng.randrange(256)for _ in range(4000)));before=tool.pin(p)
   with patch.object(tool,'MAX_SEGMENT',3000):
    with self.assertRaises(RuntimeError):tool.pack_segments([{'member':'large.txt',**before}],out)
   self.assertEqual(before,tool.pin(p))
 def test_source_drift_rejected_before_zip(self):
  with tempfile.TemporaryDirectory(dir=B)as name:
   base=pathlib.Path(name);out=base/'out';out.mkdir();p=base/'source.txt';p.write_text('before');row={'member':'source.txt',**tool.pin(p)};p.write_text('after')
   with self.assertRaises(RuntimeError):tool.pack_segments([row],out)
 def test_symlink_source_rejected(self):
  with tempfile.TemporaryDirectory(dir=B)as name:
   base=pathlib.Path(name);p=base/'source.txt';p.write_text('original');link=base/'alias.txt';link.symlink_to(p)
   with self.assertRaises(RuntimeError):tool.pin(link)
 def test_staging_without_root_explicit_flag_rejected(self):
  a=argparse.Namespace(execute_stage_to_shadow=False)
  with self.assertRaises(RuntimeError):tool.stage(a)
 def test_staging_invalid_receipt_rejected_before_read_or_mutation(self):
  a=argparse.Namespace(execute_stage_to_shadow=True,stage_receipt=None)
  with self.assertRaises(RuntimeError):tool.stage(a)
 def test_candidate_plan_cannot_stage_to_shadow(self):
  with tempfile.TemporaryDirectory(dir=B)as name:
   base=pathlib.Path(name);p=base/'candidate.json';p.write_text(json.dumps({'schema':'cqc.pass10-display-loading.archive-candidate-plan/1','status':'candidate-not-QA'}));a=argparse.Namespace(execute_stage_to_shadow=True,stage_receipt=base/'new-stage-receipt.json',archive_plan=p,archive_plan_sha256=tool.pin(p)['sha256'])
   with self.assertRaises(RuntimeError):tool.stage(a)
   self.assertFalse(a.stage_receipt.exists())
 def test_root_pack_without_actual_qa_rejected(self):
  a=argparse.Namespace(qa_root=None,qa_root_sha256=None,runtime_candidate_sha256=None)
  with self.assertRaises(RuntimeError):tool.root_qa(a)

if __name__=='__main__':
 r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Guards));d={'schema':'cqc.pass10-ui-only.archive-preparation.synthetic-fixture-tests/1','status':'passed'if r.wasSuccessful()else'failed','fixtureOnly':True,'actualProductQA':False,'RorSWritten':False,'APIRequests':0,'GitMutations':0,'testsRun':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'toolSHA256':tool.pin(B/'prepare_ui_only_archive_v2.py')['sha256'],'limits':'Synthetic isolated ZIP/guard cases only. Actual final-source Root QA and staging authorization remain required.'};p=B/'ARCHIVE_SYNTHETIC_GUARD_TESTS_01.json';tool.write_new(p,d);print(json.dumps(d));sys.exit(0 if r.wasSuccessful()else 1)
