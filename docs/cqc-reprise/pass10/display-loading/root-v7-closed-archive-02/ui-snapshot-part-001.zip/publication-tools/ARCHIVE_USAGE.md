# Snapshot des seules sources UI et preuves

Utiliser `prepare_ui_only_archive_v2.py` (V1 reste intacte). Le script prépare des fichiers uniquement sous ce dossier de préparation ou `/tmp`. Il ne fait aucun appel Git/API. Il ne modifie aucune source R/S. Le mode `stage` est une frontière distincte réservée à l’exécution explicite de Root après QA réelle ; il copie seulement des documents nouveaux sous `S/docs/cqc-reprise/pass10/display-loading/` et refuse toute cible existante.

La collecte par défaut comprend les sept fichiers UI actuels de R, l’album354, les six tests UI/natif/histoire concernés, les répertoires historiques display-loading (y compris V1–V6 lorsqu’ils existent), audit avant modification, renderer, story-browser et outils de publication. Elle conserve les snapshots/candidats anciens et les rapports échoués comme historique. Les scripts de clôture de production des personnages `close_root_*` sont exclus de ce snapshot UI. Le cœur REST original épinglé et le helper commun navigateur sont inclus comme dépendances des outils.

Les dossiers d’assets, catalogues, art, références, génération et natifs sont exclus. Les captures de QA UI restent incluses sans édition. Les ZIP de sorties précédents sont conservés sur disque mais ne sont pas réembarqués récursivement. Ce snapshot contient le code UI et les preuves ; les assets et catalogues du parent Git restent des dépendances héritées, conformément au périmètre UI demandé. Il ne prétend pas être une sauvegarde autonome de tout le jeu926Mo.

`--baseline-root LABEL=/chemin/T` ajoute un dossier historique UI dédié. Ne fournir ni le projet entier ni un dossier d’assets. `--extra-file LABEL=/chemin/absolu` ajoute des logs ou sources explicites ; utiliser ce mécanisme pour le manifeste public final, les logs de build réellement existants et les cinq logs déjà identifiés par Root :

- `/tmp/cqc-pass10-ui-native-loading-35-tests-v6.log`
- `/tmp/cqc-pass10-ui-shadow-tests-network-enabled.log`
- `/tmp/cqc-pass10-historical-contour-tests.log`
- `/tmp/cqc-pass10-ui-actual-engine-regression.log`
- `/tmp/cqc-pass10-ui-pwa-v6.log`

Les reçus `ACTUAL_UI_SOURCE_PRESERVATION.json` et `BUILD_V6_RUNTIME_DELTA.json` sont collectés dans renderer-history. Le second prouve la conservation des bundles V3 et le delta module/manifeste V6 ; il ne constitue pas un build local complet neuf V6. Aucun ancien rapport `observed`, `failed` ou `prepared` n’est transformé en QA passante.

Modes disponibles :

- `inventory` : inventaire épinglé, statut `inventory-only-not-QA`, aucune archive ni écriture S.
- `candidate` : ZIP de sources candidats, statut `candidate-not-QA`, `rootLocalQAConfirmed:false`. Exige le SHA réel du module actuel R. Ces fichiers ne peuvent pas être utilisés comme plan de publication ou être stagés.
- `pack` : nouvel ensemble ZIP après QA finale réellement clôturée par Root ; aucun document S n’est encore écrit.
- `stage` : Root seul exécute la copie des nouveaux documents après revalidation du plan, de ses sources et de la QA finale.

Chaque segment ZIP indépendant fait strictement moins de7,500,000octets, donc moins de8Mo/Mio. Chaque membre est relu depuis le ZIP et sa taille/SHA256 vérifiée. L’ensemble des sources est rehashé après création ; toute dérive conserve les fichiers produits et un `FAILED_ATTEMPT.json`. Les sources, PNG et anciens artefacts ne sont jamais supprimés. Les noms ZIP sont relatifs, sans traversal ; les sources régulières/sans symlink sont obligatoires.

Le candidat V6 déjà fermé se trouve sous `archive-candidates/ui-v6-source-candidate-01/`. Ses218fichiers tiennent dans deux ZIP7463052B et2346149B. Tous les membres et les sources ont passé leur vérification de bytes ; son statut reste explicitement candidat, sans approbation de QA finale. L’inventaire initial201fichiers et le script V1 sont conservés.

Après la QA navigateur V6, le contrôle Story et la revue physique Root, fournir un JSON `QA_FINAL_ROOT.json` régulier avec `status:"passed"`, `confirmedByRoot:true`, `sourceState:"frozen"`, `runtimeCandidateSHA256` (ou `candidateSHA256`) égal au module actuel R et `reports`. Chaque rapport reprend les champs du contrat publisher : `name`, `role`, `path`, `bytes`, `sha256`, `status:"passed"`, `actualRun:true`, `closed:true`, et éventuellement `actualStatusField`/`actualReportStatus`. Rôles nécessaires : `actual-local-browser`, `root-physical-review`, `actual-source-preservation`. Le navigateur doit épingler le module final via son `candidateSHA256` réel.

Root lance alors une sortie fraîche, sans modifier les ZIP candidats précédents :

```sh
python /workspace/cqc-pass10-ui-publication-preparation/prepare_ui_only_archive_v2.py \
  --mode pack \
  --output /workspace/cqc-pass10-ui-publication-preparation/archive-candidates/ROOT_FRESH_FINAL_LABEL \
  --label ROOT_FRESH_FINAL_LABEL \
  --runtime-candidate-sha256 ROOT_ACTUAL_FINAL_MODULE_SHA256 \
  --qa-root /workspace/ROOT_CLOSED_QA_FINAL_ROOT.json \
  --qa-root-sha256 ROOT_QA_FILE_SHA256 \
  --extra-file runtime-public/runtime-manifest.json=/workspace/shadow-codec-recovered/public/cqc/runtime-manifest.json \
  --extra-file logs/tests35-v6.log=/tmp/cqc-pass10-ui-native-loading-35-tests-v6.log \
  --extra-file logs/shadow705-network.log=/tmp/cqc-pass10-ui-shadow-tests-network-enabled.log \
  --extra-file logs/historical-contours.log=/tmp/cqc-pass10-historical-contour-tests.log \
  --extra-file logs/engine28.log=/tmp/cqc-pass10-ui-actual-engine-regression.log \
  --extra-file logs/pwa-v6.log=/tmp/cqc-pass10-ui-pwa-v6.log
```

Remplacer les paramètres majuscules par les faits réellement fermés. Ajouter les autres logs de build fermés via `--extra-file` si disponibles. Le plan final `CLOSED_ARCHIVE_PLAN.json` fournit `files` et `closedReportPins` exactement dans le format attendu par le publisher UI V2. `files` ne contient que l’inventaire JSON et les segments ZIP nouveaux, tous inférieurs à8Mio. Les rapports réels et le fichier QA_FINAL_ROOT sont aussi conservés dans les ZIP ; leurs références absolues restent des pins de contrôle local.

Après examen du plan, Root peut stager seulement ces documents :

```sh
python /workspace/cqc-pass10-ui-publication-preparation/prepare_ui_only_archive_v2.py \
  --mode stage --execute-stage-to-shadow \
  --archive-plan /workspace/ROOT_FINAL_ARCHIVE_OUTPUT/CLOSED_ARCHIVE_PLAN.json \
  --archive-plan-sha256 ROOT_CLOSED_PLAN_SHA256 \
  --stage-receipt /workspace/cqc-pass10-ui-publication-preparation/ROOT_NEW_STAGE_RECEIPT.json
```

La sortie de staging doit être nouvelle et son parent doit exister. Ce sous-agent n’a exécuté aucun staging. Root produit ensuite ses faits publisher avec le commit/arbre réellement créés, puis lance le dry-run du publisher. La publication Git, le déploiement Vercel et sa QA live sont des étapes distinctes qui restent à prouver.
