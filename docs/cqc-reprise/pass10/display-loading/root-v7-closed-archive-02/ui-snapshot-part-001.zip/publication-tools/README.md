# Publication intermédiaire de l’affichage CQC

Le fichier final est `publish_verified_display_loading_ui_v2.py`. Il charge une instance isolée du cœur REST original, vérifié par SHA256 `508ef68e220b3af471b5fd80a350a6557e3b8d84a5602a39e21bb3219cd1f723`. Le cœur et la première version du wrapper restent intacts. V2 conserve les vérifications d’objets Git, les identités UTC, les nouvelles vérifications de gel avant chaque frontière de mutation, la reprise par journal et la mise à jour `force:false`. Son transport réessaie au plus quatre fois les délais réseau, HTTP429 et tous HTTP5xx, avec pauses10/20/30s. HTTP401 et les autres erreurs définitives échouent immédiatement. Les identifiants sont hérités par `gh`, jamais lus par ce wrapper.

Cette livraison prépare des outils ; elle ne contient ni futur commit, ni preuve que la version UI finale est déjà validée, ni requête API. Les30 tests sont des cas synthétiques de règles et de transport simulé, pas une QA du produit. Root doit fournir ses propres faits après QA réelle et gel du commit local.

La branche autorisée est `reprise/2026-10-02`. Son seul parent doit être `11b04442ec1e26d8962ac65289c0b020e2bd91d9`, arbre `00cc29955bbd163f2ad2498236847a9bac62abc7` ; `main` reste `9a37e0ca975021df2eb6db7fd28fe4dcd9a2550c`. Le wrapper n’accepte que les huit modifications suivantes et de nouveaux documents sous `docs/cqc-reprise/pass10/display-loading/` :

- `public/cqc/modules/unified-versus-v055.html`
- `public/cqc/src/chronicles-art-v056.js`
- `public/cqc/src/chronicles-cinema-v056.js`
- `public/cqc/src/chronicles-portraits-v056.js`
- `public/cqc/src/chronicles-v056.js`
- `public/cqc/src/cqc-sprite-renderer.js`
- `public/cqc/src/cqc-stage-layers.js`
- `public/cqc/runtime-manifest.json`

Chaque autre entrée Git héritée doit être identique, avec aucun chemin supprimé. Le manifeste officiel conserve exactement son ensemble de fichiers ; les sept arêtes approuvées ont les nouvelles tailles/SHA et toutes les autres métadonnées sont identiques. Ainsi catalogues43, PNG, anciens documents, App Shadow et sources héritées ne peuvent être modifiés par cette publication. Les SHA finales des huit fichiers sont des entrées de Root, pas des constantes de cette préparation. Chaque fichier runtime ou document inspecté par le wrapper est limité à8Mio ; les archives plus grandes doivent utiliser des fragments fermés dont chaque octet est épinglé.

Root fournit `QA_ROOT_FACTS.json` avec le schéma `cqc.github.pass10-display-loading-qa-facts/1` et les champs suivants :

- `status:"passed"`, `confirmedByRoot:true`, `sourceState:"frozen"`, `scope:"pass10-display-loading-ui-only"`.
- `localCommit` et `localTree` du futur commit réel ; `expectedParent`, `expectedParentTree`, `mainUnchanged` sont les valeurs ci-dessus.
- `historicalPathDeletions:0`, `preservedCatalogEntries:43`, `historicalNativeAndCatalogPathsUnchanged:true`, `shadowAppAndPreviousDocumentationUnchanged:true`.
- `productionFixAlreadyVerified:false` et `entireProjectRestored:false`. Un commit Git ne prouve ni déploiement Vercel actif ni restauration complète.
- `approvedRuntimeChanges` : huit objets, chacun avec `path`, `mode:"100644"`, `rootApproved:true`, `previousVersion` égal au parent, `previousBytes`, `previousSha256`, `previousGitBlobSHA1`, `bytes`, `sha256`, `gitBlobSHA1`. Les anciennes et nouvelles valeurs sont recalculées dans les objets Git.
- `documentationPins` : objets avec `targetPath`, `bytes`, `sha256`, `gitBlobSHA1`, `mode:"100644"`. `expectedNewDocumentationPaths` reprend leurs chemins dans le même ordre ; aucune cible n’existait dans le parent.
- `archivePlan` : `{path,bytes,sha256}` absolu, fichier JSON fermé régulier.
- `reports` : objets fermés avec `name`, `role`, `path` absolu, `bytes`, `sha256`, `status:"passed"`, `closed:true`, `actualRun:true`. Champs facultatifs `actualStatusField` (défaut `status`) et `actualReportStatus` (défaut `passed`).
- `commitMessage` facultatif ; lorsqu’il est fourni, les octets du message réel doivent correspondre.

Les rôles obligatoires sont `actual-local-browser`, `root-physical-review`, `actual-source-preservation`. Le rapport navigateur doit avoir `candidateSHA256` égal au SHA réel du module HTML final. Les rapports doivent porter un statut réellement passant ; un champ `verified:true` ne peut pas transformer un rapport `failed`, `observed` ou `prepared` en réussite. Les rapports de fixture/préparation et les échecs non clôturés sont refusés. L’audit avant modification, les tentatives échouées et les sources précédentes peuvent être archivés comme historique ; ils ne sont pas des rôles QA passants.

Le plan d’archive porte le schéma `cqc.pass10-display-loading.closed-archive-plan/1`, `status:"closed-after-root-local-QA"`, `sourceState:"frozen"`, `expectedParent` exact et `rootLocalQAConfirmed:true`. `files` contient chaque `source` absolue régulière et sa `targetPath`, `bytes`, `sha256`, `gitBlobSHA1`, `mode`. Ces valeurs doivent reproduire `documentationPins` exactement. `closedReportPins` reprend pour chaque rapport, dans l’ordre, les cinq champs `name,role,path,bytes,sha256` de `reports`. Un plan de préparation ne suffit pas.

Après QA réelle, archivage, commit local et worktree propre, Root lance d’abord la vérification sans API :

```sh
python /workspace/cqc-pass10-ui-publication-preparation/publish_verified_display_loading_ui_v2.py \
  --local-commit ROOT_FINAL_COMMIT40 \
  --qa-facts /workspace/ROOT_CLOSED_QA_ROOT_FACTS.json \
  --qa-facts-sha256 ROOT_FACTS_SHA256 \
  --proofs /workspace/ROOT_OWNED_PUBLICATION_PROOFS
```

Les majuscules sont des paramètres à remplacer, pas des preuves préparées. La réponse `read-only-ready` doit indiquer `remoteRequests:0` et `gitMutations:0`. Root peut ensuite utiliser la même commande avec `--execute`. Le wrapper vérifie de nouveau le parent distant et l’arbre local ; il n’avance jamais une branche ayant changé concurremment. Cette sous-tâche n’a exécuté aucune de ces deux commandes de publication.

Root archive les deux versions du wrapper, les tests, leurs reçus et le cœur original épinglé, puis ajoute son snapshot autonome, ses tests et ses preuves UI avant/après réellement fermées. Pour Vercel, un déploiement réel READY/PROMOTED et une QA live séparée restent nécessaires.
