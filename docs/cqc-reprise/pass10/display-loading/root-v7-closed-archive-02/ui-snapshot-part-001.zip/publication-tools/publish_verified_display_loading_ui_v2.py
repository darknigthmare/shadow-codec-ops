#!/usr/bin/env python3
"""Prepare or publish one frozen UI-only tree through the immutable REST core.

Default mode performs no API request and no Git object/index/ref mutation.
Only Root may use --execute after the real QA facts and local commit are closed.
"""
import sys
sys.dont_write_bytecode = True
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path

os.environ['GIT_OPTIONAL_LOCKS'] = '0'
os.environ['GIT_NO_LAZY_FETCH'] = '1'
BASE = Path('/workspace/cqc-pass9-publication-preparation/publish_verified_shadow_cqc_pass9.py')
BASE_SHA = '508ef68e220b3af471b5fd80a350a6557e3b8d84a5602a39e21bb3219cd1f723'
assert hashlib.sha256(BASE.read_bytes()).hexdigest() == BASE_SHA, 'Immutable REST core changed'
spec = importlib.util.spec_from_file_location('isolated_pass10_ui_rest_core', BASE)
core = importlib.util.module_from_spec(spec)
spec.loader.exec_module(core)

PARENT = '11b04442ec1e26d8962ac65289c0b020e2bd91d9'
PARENT_TREE = '00cc29955bbd163f2ad2498236847a9bac62abc7'
MAIN = '9a37e0ca975021df2eb6db7fd28fe4dcd9a2550c'
DOC_PREFIX = 'docs/cqc-reprise/pass10/display-loading/'
MANIFEST = 'public/cqc/runtime-manifest.json'
RUNTIME_PATHS = frozenset({
    'public/cqc/modules/unified-versus-v055.html',
    'public/cqc/src/chronicles-art-v056.js',
    'public/cqc/src/chronicles-cinema-v056.js',
    'public/cqc/src/chronicles-portraits-v056.js',
    'public/cqc/src/chronicles-v056.js',
    'public/cqc/src/cqc-sprite-renderer.js',
    'public/cqc/src/cqc-stage-layers.js',
    MANIFEST,
})
FACTS_SCHEMA = 'cqc.github.pass10-display-loading-qa-facts/1'
PLAN_SCHEMA = 'cqc.pass10-display-loading.closed-archive-plan/1'
PASSING = frozenset({'passed','completed','verified','accepted_closest_supported',
                    'approved-with-fidelity-qualifications','approved'})
REQUIRED_ROLES = frozenset({'actual-local-browser','root-physical-review','actual-source-preservation'})
EXPECTED_FACTS_SHA256 = None
core.PARENT = PARENT
core.DOC_PREFIX = DOC_PREFIX
core.PROOFS = Path('/workspace/cqc-pass10-ui-publication-preparation/publication')
require = core.require
git = core.git
git_text = core.git_text
sha256 = core.sha256
object_sha = core.object_sha
_base_commit_request = core.commit_request
_base_save_exact = core.save_exact
_base_announce = core.announce


def api(method, path, data=None):
    """Retain the closed REST transport, with four bounded retries for any5xx."""
    arguments = ['gh','api','--method',method,'repos/'+core.REPOSITORY+'/'+path,
                 '-H','Accept: application/vnd.github+json',
                 '-H','X-GitHub-Api-Version: 2022-11-28']
    if data is not None:arguments += ['--input','-']
    payload = json.dumps(data) if data is not None else None
    for attempt in range(4):
        try:
            response = core.subprocess.run(arguments,input=payload,text=True,
                                           capture_output=True,timeout=120)
        except core.subprocess.TimeoutExpired:
            if attempt == 3:raise RuntimeError('GitHub API timeout: '+method+' '+path)
            response = None
        if response is not None and response.returncode == 0:return json.loads(response.stdout)
        error = ('timeout' if response is None else response.stderr[:1600]+response.stdout[:1600])
        retryable = response is None or bool(core.re.search(r'http[^0-9]{0,8}5[0-9]{2}',error,core.re.IGNORECASE)) or any(x in error.lower()for x in ('http 429','rate limit'))
        if attempt == 3 or not retryable:raise RuntimeError('GitHub API '+method+' '+path+': '+error)
        delay = 10*(attempt+1)
        announce({'stage':'retry','method':method,'path':path,'attempt':attempt+1,'delaySeconds':delay})
        core.time.sleep(delay)
    raise RuntimeError('Unreachable GitHub retry state')


def regular_pin(row):
    require(type(row) is dict, 'Closed file pin must be an object')
    path = Path(row.get('path',''))
    require(path.is_absolute() and path.is_file() and not path.is_symlink()
            and path.resolve() == path, 'Closed regular absolute file required: ' + str(path))
    raw = path.read_bytes()
    require(type(row.get('bytes')) is int and row['bytes'] >= 0
            and len(raw) == row['bytes'] and core.SHA256.fullmatch(row.get('sha256',''))
            and sha256(raw) == row['sha256'], 'Closed file bytes changed: ' + str(path))
    return raw


def exact_blob_pin(row, previous=False):
    require(type(row) is dict, 'Regular Git blob pin required')
    prefix = 'previous' if previous else ''
    names = ('previousBytes','previousSha256','previousGitBlobSHA1') if previous else ('bytes','sha256','gitBlobSHA1')
    n, digest, blob = names
    require(type(row.get(n)) is int and row[n] >= 0
            and core.SHA256.fullmatch(row.get(digest,'')) and core.SHA1.fullmatch(row.get(blob,'')),
            'Exact size/SHA256/Git blob pins required for ' + str(row.get('path',row.get('targetPath'))))
    require(row.get('mode') == '100644', 'UI/proof files must use regular100644 Git mode')


def runtime_map(facts):
    rows = facts.get('approvedRuntimeChanges')
    require(type(rows) is list and len(rows) == 8, 'Exactly seven runtime modifications plus manifest required')
    result = {}
    for row in rows:
        exact_blob_pin(row)
        exact_blob_pin(row, previous=True)
        path = core.repository_path(row.get('path'))
        require(path in RUNTIME_PATHS and path not in result
                and row.get('rootApproved') is True and row.get('previousVersion') == PARENT,
                'Wrong, duplicate or unapproved UI runtime path')
        require(row['previousGitBlobSHA1'] != row['gitBlobSHA1'], 'An approved runtime path must actually change')
        result[path] = row
    require(set(result) == RUNTIME_PATHS, 'Runtime path set differs from the exact UI-only scope')
    return result


def documentation_map(facts):
    rows = facts.get('documentationPins')
    require(type(rows) is list and rows, 'Exact closed new documentation pins required')
    result = {}
    for row in rows:
        exact_blob_pin(row)
        name = core.repository_path(row.get('targetPath'), DOC_PREFIX)
        require(name not in result, 'Repeated documentation target')
        result[name] = row
    require(list(result) == facts.get('expectedNewDocumentationPaths'), 'Documentation order/set differs from facts')
    return result


def validate_actual_report(row):
    require(type(row) is dict and row.get('status') == 'passed'
            and row.get('closed') is True and row.get('actualRun') is True,
            'QA role must identify a closed actually executed proof')
    raw = regular_pin(row)
    actual = json.loads(raw)
    require(type(actual) is dict, 'Actual QA document must be an object')
    status = actual.get(row.get('actualStatusField','status'))
    approved = row.get('actualReportStatus','passed')
    require(type(status) is type(approved) and status == approved
            and (approved is True or (type(approved) is str and approved in PASSING)),
            'Actual QA report did not pass')
    require('status' not in actual or actual['status'] is True or
            (type(actual['status']) is str and actual['status'] in PASSING),
            'A failed/observed/prepared report cannot be reclassified by another flag')
    require(actual.get('failure') in (None,False), 'An actual report retains an unclosed failure')
    require(not core.re.search(r'(?:^|[./_-])(?:fixtures?|preparation|plan|draft)(?:[./_-]|$)',
                              str(actual.get('schema','')), core.re.IGNORECASE),
            'A fixture or preparation document cannot certify real QA')
    require(not any(actual.get(flag) is True for flag in
                    ('fixture','syntheticFixture','prepared','preparationOnly','planOnly')),
            'Synthetic/prepared proof cannot certify actual execution')
    return actual


def read_qa_facts(path, local_commit, local_tree):
    require(EXPECTED_FACTS_SHA256 is not None and core.SHA256.fullmatch(EXPECTED_FACTS_SHA256),
            'Root must supply the exact closed facts SHA256')
    require(path.is_absolute() and path.is_file() and not path.is_symlink() and path.resolve() == path,
            'Regular absolute Root facts path required')
    raw = path.read_bytes()
    require(sha256(raw) == EXPECTED_FACTS_SHA256, 'Root facts bytes changed')
    facts = json.loads(raw)
    require(facts.get('schema') == FACTS_SCHEMA and facts.get('status') == 'passed'
            and facts.get('confirmedByRoot') is True and facts.get('sourceState') == 'frozen',
            'Root has not closed real final-source UI QA')
    require(facts.get('localCommit') == local_commit and facts.get('localTree') == local_tree
            and facts.get('expectedParent') == PARENT and facts.get('expectedParentTree') == PARENT_TREE
            and facts.get('mainUnchanged') == MAIN, 'Wrong candidate commit/tree/parent/main')
    require(facts.get('scope') == 'pass10-display-loading-ui-only'
            and facts.get('historicalPathDeletions') == 0
            and facts.get('preservedCatalogEntries') == 43
            and facts.get('historicalNativeAndCatalogPathsUnchanged') is True
            and facts.get('shadowAppAndPreviousDocumentationUnchanged') is True
            and facts.get('productionFixAlreadyVerified') is False
            and facts.get('entireProjectRestored') is False,
            'UI-only preservation and local/production qualifications required')
    runtime_map(facts)
    docs = documentation_map(facts)
    plan = json.loads(regular_pin(facts.get('archivePlan',{})))
    require(plan.get('schema') == PLAN_SCHEMA and plan.get('status') == 'closed-after-root-local-QA'
            and plan.get('expectedParent') == PARENT and plan.get('sourceState') == 'frozen'
            and plan.get('rootLocalQAConfirmed') is True, 'Actual closed archive plan required')
    files = plan.get('files')
    require(type(files) is list and len(files) == len(docs), 'Archive file set differs')
    expected = []
    for row in files:
        name = core.repository_path(row.get('targetPath'), DOC_PREFIX)
        content = regular_pin({'path':row.get('source'), 'bytes':row.get('bytes'), 'sha256':row.get('sha256')})
        require(object_sha('blob',content) == row.get('gitBlobSHA1'), 'Archive source Git blob differs')
        expected.append({k:row[k] for k in ('targetPath','bytes','sha256','gitBlobSHA1','mode')})
    require(expected == facts['documentationPins'], 'Facts/documents do not bind the closed archive plan exactly')
    reports = facts.get('reports')
    require(type(reports) is list and reports, 'Closed actual UI/source/physical QA reports required')
    names,roles = set(),set()
    runtime = runtime_map(facts)
    for row in reports:
        require(type(row.get('name')) is str and row['name'] and row['name'] not in names,
                'Missing/repeated actual report name')
        names.add(row['name'])
        actual = validate_actual_report(row)
        roles.add(row.get('role'))
        if row.get('role') == 'actual-local-browser':
            require(actual.get('candidateSHA256') == runtime['public/cqc/modules/unified-versus-v055.html']['sha256'],
                    'Actual local browser report must bind the final module bytes')
    require(REQUIRED_ROLES <= roles, 'Required actual-local-browser/Root physical/source-preservation roles missing')
    require(plan.get('closedReportPins') == [{k:r[k] for k in ('name','role','path','bytes','sha256')} for r in reports],
            'Archive plan must pin the same actual closed QA roles as facts')
    return facts,raw


def validate_pass9_scope(changes, base, facts):
    runtime,docs = runtime_map(facts),documentation_map(facts)
    names = {row['path'] for row in changes}
    require(len(names) == len(changes) and names == RUNTIME_PATHS | set(docs),
            'Only eight exact UI runtime modifications and the closed new archive may change')
    for row in changes:
        name = core.repository_path(row['path'])
        require(row.get('type') == 'blob' and row.get('mode') == '100644', 'Only regular100644 blobs allowed')
        approved = runtime.get(name,docs.get(name))
        require(row.get('sha') == approved['gitBlobSHA1'] and row.get('mode') == approved['mode'],
                'Candidate path/blob/mode differs from exact Root pins')
        if name in runtime:
            require(name in base and base[name]['sha'] == approved['previousGitBlobSHA1']
                    and base[name]['mode'] == row['mode'] and base[name]['type'] == 'blob',
                    'Runtime change does not preserve its exact original parent pin')
        else:
            require(name.startswith(DOC_PREFIX) and name not in base, 'Historical documentation must never change')


def validate_candidate_configuration(local_commit, base, candidate, facts):
    for path,row in runtime_map(facts).items():
        before = core.bounded_candidate_blob(PARENT,path,base[path],
                    expected_bytes=row['previousBytes'],maximum_bytes=8*1024*1024)
        after = core.bounded_candidate_blob(local_commit,path,candidate[path],
                    expected_bytes=row['bytes'],maximum_bytes=8*1024*1024)
        require(sha256(before) == row['previousSha256'] and object_sha('blob',before) == row['previousGitBlobSHA1']
                and sha256(after) == row['sha256'] and object_sha('blob',after) == row['gitBlobSHA1'],
                'Committed UI old/new bytes differ from the closed Root pins: ' + path)
    for path,row in documentation_map(facts).items():
        raw = core.bounded_candidate_blob(local_commit,path,candidate[path],
                    expected_bytes=row['bytes'],maximum_bytes=8*1024*1024)
        require(sha256(raw) == row['sha256'] and object_sha('blob',raw) == row['gitBlobSHA1'],
                'Committed archive bytes differ from the closed plan: ' + path)


def validate_runtime_graph(local_commit, base, candidate, facts):
    require(git_text('rev-parse',PARENT+'^{tree}') == PARENT_TREE, 'Exact published parent tree changed')
    require(git_text('rev-parse','refs/heads/main') == MAIN, 'Main must remain unchanged')
    approvals = runtime_map(facts)
    raw = git('show',local_commit+':'+MANIFEST)
    old_raw = git('show',PARENT+':'+MANIFEST)
    require(sha256(raw) == approvals[MANIFEST]['sha256'] and len(raw) == approvals[MANIFEST]['bytes']
            and sha256(old_raw) == approvals[MANIFEST]['previousSha256'], 'Actual manifest old/new pins differ')
    expected = core.runtime_manifest_rows(json.loads(raw))
    old = core.runtime_manifest_rows(json.loads(old_raw))
    paths = {p for p in candidate if p.startswith(core.RUNTIME_PREFIX)}
    require(set(expected) == set(old) and paths == set(expected) | {MANIFEST},
            'UI-only manifest must preserve its complete original runtime path set')
    for name,row in expected.items():
        if name in approvals:
            require(row['sha256'] == approvals[name]['sha256'] and row['bytes'] == approvals[name]['bytes'],
                    'Changed runtime manifest edge differs from Root-approved bytes')
        else:
            require(row == old[name] and candidate[name] == base[name],
                    'Native/catalog/other runtime bytes or metadata changed outside UI scope')


def validate_catalog_candidate(local_commit, base, candidate, facts):
    require(set(base) <= set(candidate), 'No historical path may be deleted')
    docs = documentation_map(facts)
    for path,row in candidate.items():
        if path in RUNTIME_PATHS or path in docs:continue
        require(path in base and row == base[path], 'Historical App/native/catalog/documentation path changed: ' + path)


def commit_request(local_commit, local_tree):
    payload,raw = _base_commit_request(local_commit,local_tree)
    require(object_sha('commit',raw) == local_commit,
            'Root commit must retain its exact single parent, UTC identities and final LF bytes')
    return payload,raw


def qualify_publication(value):
    if type(value) is dict and value.get('schema') in ('cqc.github.pass9-publication-plan/1','cqc.github.pass9-publication/1'):
        value['schema'] = ('cqc.github.pass10-display-loading-publication-plan/1'
                           if 'plan/' in value['schema'] else 'cqc.github.pass10-display-loading-publication/1')
        value['scope'] = 'pass10-display-loading-ui-only'
        value['productionVerified'] = False
        value['entireProjectRestored'] = False
        if value.get('status') == 'published':
            value['evidence'] = ('The frozen UI-only candidate descends from exact published11b04442; '
                                'only seven approved runtime files, their manifest and new closed display/loading proof documents differ. '
                                'All other historical paths and native/catalog bytes are inherited unchanged. '
                                'Git publication does not certify a live Vercel deployment or complete project restoration.')
    return value


def save_exact(path,value):return _base_save_exact(path,qualify_publication(value))
def announce(value):
    if type(value) is dict and 'plan' in value:qualify_publication(value['plan'])
    return _base_announce(qualify_publication(value))


core.api = api
core.read_qa_facts = read_qa_facts
core.validate_pass9_scope = validate_pass9_scope
core.validate_candidate_configuration = validate_candidate_configuration
core.validate_runtime_graph = validate_runtime_graph
core.validate_catalog_candidate = validate_catalog_candidate
core.commit_request = commit_request
core.save_exact = save_exact
core.announce = announce


def main():
    global EXPECTED_FACTS_SHA256
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--local-commit',required=True)
    parser.add_argument('--qa-facts',type=Path,required=True)
    parser.add_argument('--qa-facts-sha256',required=True)
    parser.add_argument('--proofs',type=Path,default=core.PROOFS)
    parser.add_argument('--execute',action='store_true')
    args = parser.parse_args()
    EXPECTED_FACTS_SHA256 = args.qa_facts_sha256
    require(core.SHA256.fullmatch(EXPECTED_FACTS_SHA256),'Full closed facts SHA256 required')
    require(args.proofs.is_absolute() and not args.proofs.is_symlink()
            and args.proofs.resolve() == args.proofs and args.proofs.is_relative_to(Path('/workspace')),
            'Root publication proof folder must be an exact owned workspace path')
    core.PROOFS = args.proofs
    core.publish(args)


if __name__ == '__main__':main()
