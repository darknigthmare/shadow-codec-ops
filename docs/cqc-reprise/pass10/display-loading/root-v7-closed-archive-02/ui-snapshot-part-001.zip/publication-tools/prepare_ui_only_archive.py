#!/usr/bin/env python3
"""Inventory/pack UI-only snapshots in isolation; Root alone may stage closed docs."""
import sys
sys.dont_write_bytecode=True
import argparse,datetime,hashlib,importlib.util,json,pathlib,re,stat,zlib,zipfile
B=pathlib.Path('/workspace/cqc-pass10-ui-publication-preparation')
R=pathlib.Path('/workspace/cqc-game-working/cqc-versus-v056')
S=pathlib.Path('/workspace/shadow-codec-recovered')
DOC_PREFIX='docs/cqc-reprise/pass10/display-loading/'
MODULE='modules/unified-versus-v055.html'
RUNTIME=[MODULE,'src/chronicles-art-v056.js','src/chronicles-cinema-v056.js',
         'src/chronicles-portraits-v056.js','src/chronicles-v056.js',
         'src/cqc-sprite-renderer.js','src/cqc-stage-layers.js']
ROOTS={
 'ui-history':pathlib.Path('/workspace/cqc-pass10-display-loading-implementation'),
 'before-audit':pathlib.Path('/workspace/cqc-pass10-display-loading-audit'),
 'renderer-history':pathlib.Path('/workspace/cqc-pass10-renderer-preparation'),
 'story-browser-history':pathlib.Path('/workspace/cqc-pass10-story-loading-browser-QA'),
 'publication-tools':B,
}
SUFFIXES={'.py','.js','.mjs','.cjs','.json','.jsonl','.ndjson','.css','.html','.md','.txt','.log','.jpg','.jpeg','.png'}
FORBIDDEN={'assets','art','gen','generated_images','native-attempts','references','catalogs','node_modules','.git','__pycache__'}
MAX_SEGMENT=7_500_000
MAX_SOURCE=64*1024*1024
PUBLISHER=B/'publish_verified_display_loading_ui_v2.py'
PUBLISHER_SHA='1db10d532070f9314e5223a0de5d2376c9553211ade6272560051369609fa9a7'

def require(value,message):
 if not value:raise RuntimeError(message)
def digest(raw):return hashlib.sha256(raw).hexdigest()
def blob(raw):return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def pin(p):
 require(p.is_absolute()and p.is_file()and not p.is_symlink()and p.resolve()==p,'Regular absolute source required: '+str(p))
 require(p.stat().st_size<=MAX_SOURCE,'UI-only source unexpectedly large: '+str(p))
 raw=p.read_bytes()
 return {'path':str(p),'bytes':len(raw),'sha256':digest(raw),'gitBlobSHA1':blob(raw)}
def read_pin(row):
 p=pathlib.Path(row['path']);seen=pin(p)
 require(all(seen[k]==row[k]for k in ('bytes','sha256')),'Pinned bytes drifted: '+str(p))
 return p.read_bytes()
def safe_name(name):
 require(type(name)is str and name and not name.startswith('/')and '\\'not in name
         and ':'not in name and all(x and x not in ('.','..')for x in name.split('/'))
         and not any(ord(x)<32 or ord(x)==127 for x in name),'Unsafe archive/document name')
 return name
def pair(value):
 require('='in value,'Use LABEL=/absolute/path')
 label,path=value.split('=',1);safe_name(label);p=pathlib.Path(path)
 require(p.is_absolute()and p.resolve()==p,'Exact absolute path required')
 return label,p
def permitted(relative):
 if set(relative.parts)&FORBIDDEN:return False
 if any(x.startswith('.env')for x in relative.parts):return False
 if relative.name in ('combat-sprite-catalog-v1.json','cqc-sprite-catalog.js'):return False
 if relative.name.startswith('close_root_'):return False
 return relative.suffix.lower()in SUFFIXES
def write_new(path,data):
 with path.open('x')as f:json.dump(data,f,ensure_ascii=False,indent=2);f.write('\n')
def collect(a,out):
 entries={}
 def add(name,p,role):
  safe_name(name);require(name not in entries,'Duplicate snapshot member: '+name)
  require(permitted(pathlib.Path(name)),'Forbidden non-UI source: '+name)
  entries[name]={'member':name,'role':role,**pin(p)}
 for name in RUNTIME:add('current-R/'+name,R/name,'current-ui-source')
 add('current-R/docs/ALBUM_LOCAL_354_RECITS_v0.56.html',R/'docs/ALBUM_LOCAL_354_RECITS_v0.56.html','current-album-source')
 for name in ['test_native_preview_loading_pass10.cjs','test_stage_story_loading_pass10.cjs',
              'test_static_portrait_refresh_reprise.cjs','test_static_sprite_readiness_reprise.cjs',
              'test_combat_sprite_contours_pass7.py','test_chronicles_layer_fallback.cjs']:
  add('current-R/tests/'+name,R/'tests'/name,'current-ui-test-source')
 roots=dict(ROOTS)
 for value in a.baseline_root:
  label,p=pair(value);roots['baseline-T/'+label]=p
 for label,root in roots.items():
  require(root.is_dir()and not root.is_symlink(),'Missing regular UI/baseline root: '+str(root))
  for p in sorted(root.rglob('*')):
   if not p.is_file():continue
   require(not p.is_symlink(),'Symlink inside snapshot source: '+str(p))
   relative=p.relative_to(root)
   if p.is_relative_to(out)or set(relative.parts)&{'archive-candidates','archive-runs','publication'}:continue
   if label=='publication-tools'and relative.parts[0].startswith('archive-'):continue
   if permitted(relative):add(label+'/'+relative.as_posix(),p,'history-or-tool-not-QA-reclassification')
 for value in a.extra_file:
  label,p=pair(value);add('explicit-closed/'+label,p,'Root-explicit-log-or-proof')
 return [entries[name]for name in sorted(entries)]
def root_qa(a):
 require(a.qa_root and a.qa_root_sha256 and a.runtime_candidate_sha256,'Closed QA Root and final module SHA required for pack mode')
 require(re.fullmatch('[0-9a-f]{64}',a.qa_root_sha256)and re.fullmatch('[0-9a-f]{64}',a.runtime_candidate_sha256),'Complete SHA256 required')
 q=pin(a.qa_root);require(q['sha256']==a.qa_root_sha256,'Root QA bytes changed')
 d=json.loads(a.qa_root.read_bytes())
 require(d.get('status')=='passed'and d.get('confirmedByRoot')is True and d.get('sourceState')=='frozen','Root must close actual final-source local QA')
 candidate=d.get('runtimeCandidateSHA256',d.get('candidateSHA256'))
 require(candidate==a.runtime_candidate_sha256 and pin(R/MODULE)['sha256']==candidate,'Final Root QA must bind actual current R module')
 require(pin(PUBLISHER)['sha256']==PUBLISHER_SHA,'Closed publisher validator changed')
 spec=importlib.util.spec_from_file_location('isolated_archive_report_validator',PUBLISHER)
 pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 reports=d.get('reports');require(type(reports)is list and reports,'Actual closed QA role pins required')
 roles=set();names=set()
 for row in reports:
  require(row.get('name')and row['name']not in names,'Duplicate actual report name');names.add(row['name'])
  actual=pub.validate_actual_report(row);roles.add(row.get('role'))
  if row.get('role')=='actual-local-browser':require(actual.get('candidateSHA256')==candidate,'Actual final browser module SHA differs')
 require(pub.REQUIRED_ROLES<=roles,'Actual browser/Root physical/source-preservation roles missing')
 return q,d,reports
def pack_segments(entries,out):
 groups=[];group=[];estimated=1024
 for row in entries:
  raw=read_pin(row);estimate=len(zlib.compress(raw,9))+len(row['member'].encode())*2+256
  require(estimate+1024<MAX_SEGMENT,'One UI snapshot member cannot fit a bounded ZIP: '+row['member'])
  if group and estimated+estimate>=MAX_SEGMENT:groups.append(group);group=[];estimated=1024
  group.append(row);estimated+=estimate
 if group:groups.append(group)
 parts=[]
 for i,group in enumerate(groups,1):
  p=out/('ui-snapshot-part-'+str(i).zfill(3)+'.zip')
  with zipfile.ZipFile(p,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=False)as z:
   for row in group:
    info=zipfile.ZipInfo(row['member'],date_time=(2026,10,2,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
    info.create_system=3;info.external_attr=(stat.S_IFREG|0o644)<<16
    z.writestr(info,read_pin(row),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
  require(p.stat().st_size<MAX_SEGMENT,'Compressed ZIP exceeds the conservative segment cap')
  with zipfile.ZipFile(p)as z:
   require(z.namelist()==[r['member']for r in group],'ZIP member set/order changed')
   for row in group:
    raw=z.read(row['member']);require(len(raw)==row['bytes']and digest(raw)==row['sha256'],'ZIP roundtrip byte mismatch')
  parts.append({**pin(p),'members':[r['member']for r in group],'compressedBytesBelow8MiB':True,'allMembersSHA256RoundtripVerified':True})
 return parts
def prepare(a):
 out=a.output
 require(out.is_absolute()and out.resolve()==out and (out.is_relative_to(B)or out.is_relative_to(pathlib.Path('/tmp'))),'Candidate output must stay in isolated preparation/TMP')
 safe_name(a.label);require('/'not in a.label,'Use one archive-run label component')
 out.mkdir(parents=True,exist_ok=False)
 try:
  entries=collect(a,out)
  if a.mode=='inventory':
   data={'schema':'cqc.pass10-ui-only.source-inventory-preparation/1','status':'inventory-only-not-QA','label':a.label,'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'entries':entries,'sourceBytes':sum(r['bytes']for r in entries),'sourceState':'not-certified-frozen','RorSWritten':False,'GitOrAPIUsed':False,'limits':'Discovery only. Future V6/final reports/logs may be absent; actual Root QA is required before packing or staging.'}
   p=out/'SOURCE_INVENTORY_PREPARATION.json';write_new(p,data);print(json.dumps({'inventory':pin(p),'files':len(entries),'sourceBytes':data['sourceBytes']}));return
  qa,qa_data,reports=root_qa(a)
  extra=[{'member':'closed-final-QA/QA_FINAL_ROOT.json','role':'actual-root-closed-QA-input',**qa}]
  for row in reports:extra.append({'member':'closed-final-QA/reports/'+safe_name(row['name'])+'.json','role':'actual-QA-role',**pin(pathlib.Path(row['path']))})
  require(len({r['member']for r in entries+extra})==len(entries+extra),'Duplicate final QA archive member')
  entries=sorted(entries+extra,key=lambda r:r['member'])
  inventory={'schema':'cqc.pass10-ui-only.closed-source-snapshot-inventory/1','status':'source-bytes-frozen-after-root-local-QA','label':a.label,'closedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rootQA':qa,'runtimeCandidateSHA256':a.runtime_candidate_sha256,'sourcePixelsEdited':False,'entries':entries,'nativeAssetsAndCatalogsIncluded':False,'historyPreserved':True,'scope':'UI source and exact archived evidence only; retained preparation/failed reports are history, never relabelled as passing actual roles.'}
  p=out/'UI_SOURCE_SNAPSHOT_INVENTORY.json';write_new(p,inventory)
  parts=pack_segments(entries,out)
  for row in entries:require(pin(pathlib.Path(row['path']))['sha256']==row['sha256'],'Source drift after complete ZIP roundtrip')
  require(pin(a.qa_root)['sha256']==qa['sha256'],'Root QA changed while packing')
  files=[]
  for p in [out/'UI_SOURCE_SNAPSHOT_INVENTORY.json']+[pathlib.Path(x['path'])for x in parts]:
   row=pin(p);require(row['bytes']<8*1024*1024,'One document exceeds publisher inspection cap')
   files.append({'source':str(p),'targetPath':DOC_PREFIX+a.label+'/'+p.name,'bytes':row['bytes'],'sha256':row['sha256'],'gitBlobSHA1':row['gitBlobSHA1'],'mode':'100644'})
  plan={'schema':'cqc.pass10-display-loading.closed-archive-plan/1','status':'closed-after-root-local-QA','sourceState':'frozen','expectedParent':'11b04442ec1e26d8962ac65289c0b020e2bd91d9','rootLocalQAConfirmed':True,'rootQA':qa,'runtimeCandidateSHA256':a.runtime_candidate_sha256,'closedReportPins':[{k:r[k]for k in ('name','role','path','bytes','sha256')}for r in reports],'files':files,'parts':parts,'sourceInventory':pin(out/'UI_SOURCE_SNAPSHOT_INVENTORY.json'),'allSourcePinsRecheckedAfterPacking':True,'allZIPMembersSHA256RoundtripVerified':True,'SWritten':False,'GitOrAPIUsed':False,'productionVerified':False,'entireProjectRestored':False}
  p=out/'CLOSED_ARCHIVE_PLAN.json';write_new(p,plan);print(json.dumps({'plan':pin(p),'parts':len(parts),'files':len(entries),'compressedBytes':sum(x['bytes']for x in parts),'SWritten':False}))
 except BaseException as exc:
  p=out/'FAILED_ATTEMPT.json'
  if not p.exists():write_new(p,{'status':'failed','error':repr(exc),'allProducedArtifactsRetained':True,'SWritten':False,'GitOrAPIUsed':False})
  raise
def stage(a):
 require(a.execute_stage_to_shadow,'Root must explicitly authorize staging with --execute-stage-to-shadow')
 require(a.archive_plan and re.fullmatch('[0-9a-f]{64}',a.archive_plan_sha256 or ''),'Exact closed plan path/SHA required')
 p=pin(a.archive_plan);require(p['sha256']==a.archive_plan_sha256,'Closed archive plan changed')
 plan=json.loads(a.archive_plan.read_bytes())
 require(plan.get('schema')=='cqc.pass10-display-loading.closed-archive-plan/1'and plan.get('status')=='closed-after-root-local-QA'and plan.get('sourceState')=='frozen'and plan.get('rootLocalQAConfirmed')is True,'Preparation plan cannot stage publishable evidence')
 require(pin(R/MODULE)['sha256']==plan['runtimeCandidateSHA256'],'Current R module differs from closed final UI source')
 qa=json.loads(read_pin(plan['rootQA']));require(qa.get('status')=='passed'and qa.get('confirmedByRoot')is True,'Root final QA changed')
 inventory=json.loads(read_pin(plan['sourceInventory']))
 for row in inventory['entries']:require(pin(pathlib.Path(row['path']))['sha256']==row['sha256'],'Snapshot source drift before Root staging')
 targets=[]
 for row in plan['files']:
  name=safe_name(row['targetPath']);require(name.startswith(DOC_PREFIX),'Only new display/loading documentation may be staged')
  target=S/name;require(target.resolve()==target and not target.exists()and not target.is_symlink(),'Never overwrite an existing document')
  raw=read_pin({'path':row['source'],'bytes':row['bytes'],'sha256':row['sha256']});require(blob(raw)==row['gitBlobSHA1']and row['mode']=='100644','Archive document blob/mode mismatch')
  targets.append((target,row))
 receipt=[]
 for target,row in targets:
  target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('xb')as f:f.write(read_pin({'path':row['source'],'bytes':row['bytes'],'sha256':row['sha256']}))
  target.chmod(0o644);require(pin(target)['sha256']==row['sha256'],'Staged document bytes differ');receipt.append(pin(target))
 output=a.stage_receipt;require(output and output.is_absolute()and (output.is_relative_to(B)or output.is_relative_to(pathlib.Path('/tmp'))),'Root staging receipt stays outside S')
 write_new(output,{'schema':'cqc.pass10-ui-only.closed-docs-staging/1','status':'staged-new-documents','archivePlan':p,'files':receipt,'historicalFilesOverwritten':0,'GitOrAPIUsed':False,'productionVerified':False})
 print(json.dumps(pin(output)))
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--mode',choices=['inventory','pack','stage'],default='inventory')
 p.add_argument('--output',type=pathlib.Path);p.add_argument('--label')
 p.add_argument('--baseline-root',action='append',default=[]);p.add_argument('--extra-file',action='append',default=[])
 p.add_argument('--qa-root',type=pathlib.Path);p.add_argument('--qa-root-sha256');p.add_argument('--runtime-candidate-sha256')
 p.add_argument('--archive-plan',type=pathlib.Path);p.add_argument('--archive-plan-sha256')
 p.add_argument('--execute-stage-to-shadow',action='store_true');p.add_argument('--stage-receipt',type=pathlib.Path)
 a=p.parse_args()
 if a.mode=='stage':stage(a)
 else:require(a.output and a.label,'Inventory/pack require a new isolated output and label');prepare(a)
if __name__=='__main__':main()
