"""Synthetic isolated guard cases only; never Git/API publication or actual QA."""
import sys
sys.dont_write_bytecode=True
import copy,hashlib,importlib.util,json,pathlib,tempfile,unittest,datetime
B=pathlib.Path('/workspace/cqc-pass10-ui-publication-preparation')
s=importlib.util.spec_from_file_location('ui_guard_under_test',B/'publish_verified_display_loading_ui_v2.py')
pub=importlib.util.module_from_spec(s);s.loader.exec_module(pub)
api_calls=[]
def forbid_api(*args,**kwargs):
    api_calls.append(args)
    raise AssertionError('No API calls permitted in synthetic guard cases')
pub.core.api=forbid_api

def facts():
    runtime=[]
    for i,name in enumerate(sorted(pub.RUNTIME_PATHS)):
        runtime.append({'path':name,'rootApproved':True,'previousVersion':pub.PARENT,
                        'mode':'100644','previousBytes':10,'previousSha256':'a'*64,
                        'previousGitBlobSHA1':format(i+1,'040x'),'bytes':11,'sha256':'b'*64,
                        'gitBlobSHA1':format(i+101,'040x')})
    target=pub.DOC_PREFIX+'fixture-preservation-only.txt'
    doc={'targetPath':target,'bytes':4,'sha256':'c'*64,'gitBlobSHA1':'d'*40,'mode':'100644'}
    return {'approvedRuntimeChanges':runtime,'documentationPins':[doc],
            'expectedNewDocumentationPaths':[target]}

def trees(f):
    base={r['path']:{'path':r['path'],'mode':'100644','type':'blob','sha':r['previousGitBlobSHA1']}for r in f['approvedRuntimeChanges']}
    for name in ['src/app/App.tsx','public/cqc/src/cqc-sprite-catalog.js','public/cqc/assets/combat-sprites/old/png.png','docs/cqc-reprise/pass9/old.txt']:
        base[name]={'path':name,'mode':'100644','type':'blob','sha':'f'*40}
    candidate=copy.deepcopy(base)
    for r in f['approvedRuntimeChanges']:candidate[r['path']]['sha']=r['gitBlobSHA1']
    for r in f['documentationPins']:candidate[r['targetPath']]={'path':r['targetPath'],'mode':r['mode'],'type':'blob','sha':r['gitBlobSHA1']}
    changes=[candidate[n]for n in sorted(candidate)if candidate[n]!=base.get(n)]
    return base,candidate,changes

class Guards(unittest.TestCase):
    def transport_fixture(self, replies):
        from unittest.mock import patch
        from types import SimpleNamespace
        objects=[SimpleNamespace(returncode=1,stderr='gh: HTTP '+str(code),stdout='') if code!=200 else SimpleNamespace(returncode=0,stderr='',stdout='{"sha":"fixture"}')for code in replies]
        return patch.object(pub.core.subprocess,'run',side_effect=objects)
    def test_transport_retries_500_and_599_then_success(self):
        from unittest.mock import patch
        with self.transport_fixture([500,599,200])as transport,patch.object(pub.core.time,'sleep')as delay,patch.object(pub,'announce'):
            result=pub.api('GET','fixture-only')
            self.assertEqual(result,{'sha':'fixture'});self.assertEqual(transport.call_count,3);self.assertEqual([c.args[0]for c in delay.call_args_list],[10,20])
    def test_transport_retries_429_exactly_four_attempts(self):
        from unittest.mock import patch
        with self.transport_fixture([429,429,429,429])as transport,patch.object(pub.core.time,'sleep')as delay,patch.object(pub,'announce'):
            with self.assertRaises(RuntimeError):pub.api('GET','fixture-only')
            self.assertEqual(transport.call_count,4);self.assertEqual([c.args[0]for c in delay.call_args_list],[10,20,30])
    def test_transport_does_not_retry_authentication_error(self):
        from unittest.mock import patch
        with self.transport_fixture([401])as transport,patch.object(pub.core.time,'sleep')as delay:
            with self.assertRaises(RuntimeError):pub.api('GET','fixture-only')
            self.assertEqual(transport.call_count,1);delay.assert_not_called()
    def test_exact_eight_changes_and_new_doc_allowed(self):
        f=facts();base,candidate,changes=trees(f)
        pub.validate_pass9_scope(changes,base,f)
        pub.validate_catalog_candidate('not-an-actual-commit',base,candidate,f)
    def test_ninth_runtime_change_rejected(self):
        f=facts();base,candidate,changes=trees(f);row=copy.deepcopy(candidate['public/cqc/src/cqc-sprite-catalog.js']);row['sha']='1'*40;changes.append(row)
        with self.assertRaises(RuntimeError):pub.validate_pass9_scope(changes,base,f)
    def test_runtime_path_replacement_rejected(self):
        f=facts();f['approvedRuntimeChanges'][0]['path']='public/cqc/index.html'
        with self.assertRaises(RuntimeError):pub.runtime_map(f)
    def test_seventh_only_without_manifest_rejected(self):
        f=facts();f['approvedRuntimeChanges']=[r for r in f['approvedRuntimeChanges']if r['path']!=pub.MANIFEST]
        with self.assertRaises(RuntimeError):pub.runtime_map(f)
    def test_duplicate_runtime_pin_rejected(self):
        f=facts();f['approvedRuntimeChanges'][-1]=copy.deepcopy(f['approvedRuntimeChanges'][0])
        with self.assertRaises(RuntimeError):pub.runtime_map(f)
    def test_unapproved_runtime_pin_rejected(self):
        f=facts();f['approvedRuntimeChanges'][0]['rootApproved']=False
        with self.assertRaises(RuntimeError):pub.runtime_map(f)
    def test_wrong_previous_version_rejected(self):
        f=facts();f['approvedRuntimeChanges'][0]['previousVersion']='2'*40
        with self.assertRaises(RuntimeError):pub.runtime_map(f)
    def test_unknown_future_sha_is_parameterized(self):
        f=facts();f['approvedRuntimeChanges'][0]['sha256']='9'*64;pub.runtime_map(f)
    def test_same_old_new_blob_is_not_a_modification(self):
        f=facts();r=f['approvedRuntimeChanges'][0];r['gitBlobSHA1']=r['previousGitBlobSHA1']
        with self.assertRaises(RuntimeError):pub.runtime_map(f)
    def test_executable_mode_rejected(self):
        f=facts();f['approvedRuntimeChanges'][0]['mode']='100755'
        with self.assertRaises(RuntimeError):pub.runtime_map(f)
    def test_changed_blob_rejected(self):
        f=facts();base,candidate,changes=trees(f);changes[0]=dict(changes[0],sha='3'*40)
        with self.assertRaises(RuntimeError):pub.validate_pass9_scope(changes,base,f)
    def test_wrong_parent_blob_rejected(self):
        f=facts();base,candidate,changes=trees(f);base[next(iter(pub.RUNTIME_PATHS))]['sha']='4'*40
        with self.assertRaises(RuntimeError):pub.validate_pass9_scope(changes,base,f)
    def test_historical_documentation_edit_rejected(self):
        f=facts();base,candidate,changes=trees(f);name=f['documentationPins'][0]['targetPath'];base[name]=copy.deepcopy(candidate[name])
        with self.assertRaises(RuntimeError):pub.validate_pass9_scope(changes,base,f)
    def test_new_documentation_outside_scope_rejected(self):
        f=facts();f['documentationPins'][0]['targetPath']='docs/cqc-reprise/pass9/new.txt'
        with self.assertRaises(RuntimeError):pub.documentation_map(f)
    def test_documentation_traversal_rejected(self):
        f=facts();f['documentationPins'][0]['targetPath']=pub.DOC_PREFIX+'../old.txt'
        with self.assertRaises(RuntimeError):pub.documentation_map(f)
    def test_delete_rejected(self):
        f=facts();base,candidate,changes=trees(f);del candidate['docs/cqc-reprise/pass9/old.txt']
        with self.assertRaises(RuntimeError):pub.validate_catalog_candidate('fixture',base,candidate,f)
    def test_shadow_app_change_rejected(self):
        f=facts();base,candidate,changes=trees(f);candidate['src/app/App.tsx']['sha']='5'*40
        with self.assertRaises(RuntimeError):pub.validate_catalog_candidate('fixture',base,candidate,f)
    def test_native_png_change_rejected(self):
        f=facts();base,candidate,changes=trees(f);candidate['public/cqc/assets/combat-sprites/old/png.png']['sha']='5'*40
        with self.assertRaises(RuntimeError):pub.validate_catalog_candidate('fixture',base,candidate,f)
    def test_catalog_change_rejected(self):
        f=facts();base,candidate,changes=trees(f);candidate['public/cqc/src/cqc-sprite-catalog.js']['sha']='5'*40
        with self.assertRaises(RuntimeError):pub.validate_catalog_candidate('fixture',base,candidate,f)
    def test_unchanged_historical_paths_not_enough_if_new_unplanned_path(self):
        f=facts();base,candidate,changes=trees(f);candidate['package.json']={'path':'package.json','mode':'100644','type':'blob','sha':'a'*40}
        with self.assertRaises(RuntimeError):pub.validate_catalog_candidate('fixture',base,candidate,f)
    def actual_row(self,out,actual):
        p=out/'synthetic-report.json';p.write_text(json.dumps(actual))
        return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'status':'passed','actualRun':True,'closed':True}
    def test_preparation_schema_cannot_certify_actual_qa(self):
        with tempfile.TemporaryDirectory(dir=B) as tmp:
            r=self.actual_row(pathlib.Path(tmp),{'status':'passed','schema':'cqc.fixture-qa/1'})
            with self.assertRaises(RuntimeError):pub.validate_actual_report(r)
    def test_failed_status_cannot_be_reclassified_by_true_flag(self):
        with tempfile.TemporaryDirectory(dir=B) as tmp:
            r=self.actual_row(pathlib.Path(tmp),{'status':'failed','verified':True});r['actualStatusField']='verified';r['actualReportStatus']=True
            with self.assertRaises(RuntimeError):pub.validate_actual_report(r)
    def test_observed_before_audit_cannot_be_called_passing(self):
        with tempfile.TemporaryDirectory(dir=B) as tmp:
            r=self.actual_row(pathlib.Path(tmp),{'status':'observed','verified':True});r['actualStatusField']='verified';r['actualReportStatus']=True
            with self.assertRaises(RuntimeError):pub.validate_actual_report(r)
    def test_prepared_flag_cannot_certify_actual_qa(self):
        with tempfile.TemporaryDirectory(dir=B) as tmp:
            r=self.actual_row(pathlib.Path(tmp),{'status':'passed','prepared':True})
            with self.assertRaises(RuntimeError):pub.validate_actual_report(r)
    def test_unclosed_role_rejected(self):
        with tempfile.TemporaryDirectory(dir=B) as tmp:
            r=self.actual_row(pathlib.Path(tmp),{'status':'passed'});r['closed']=False
            with self.assertRaises(RuntimeError):pub.validate_actual_report(r)
    def test_qa_report_byte_change_rejected(self):
        with tempfile.TemporaryDirectory(dir=B) as tmp:
            r=self.actual_row(pathlib.Path(tmp),{'status':'passed'});pathlib.Path(r['path']).write_text('{}')
            with self.assertRaises(RuntimeError):pub.validate_actual_report(r)
    def test_rejected_publication_qualifies_no_live_restoration_claim(self):
        v=pub.qualify_publication({'schema':'cqc.github.pass9-publication/1','status':'published'})
        self.assertFalse(v['productionVerified']);self.assertFalse(v['entireProjectRestored']);self.assertEqual(v['schema'],'cqc.github.pass10-display-loading-publication/1')

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Guards))
    report={'schema':'cqc.pass10-ui-publication-preparation.synthetic-fixture-tests/1','status':'passed'if result.wasSuccessful()else'failed','fixtureOnly':True,'actualProductQA':False,'gitMutations':0,'APIRequests':len(api_calls),'testsRun':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'toolSHA256':hashlib.sha256((B/'publish_verified_display_loading_ui_v2.py').read_bytes()).hexdigest(),'immutableCoreSHA256':hashlib.sha256(pub.BASE.read_bytes()).hexdigest(),'limits':'Synthetic validation cases only. They cannot authorize publication or certify final-source runtime QA.'}
    p=B/'SYNTHETIC_GUARD_TESTS_02.json'
    with p.open('x')as f:json.dump(report,f,indent=2);f.write('\n')
    print(json.dumps(report));sys.exit(0 if result.wasSuccessful()and not api_calls else 1)
