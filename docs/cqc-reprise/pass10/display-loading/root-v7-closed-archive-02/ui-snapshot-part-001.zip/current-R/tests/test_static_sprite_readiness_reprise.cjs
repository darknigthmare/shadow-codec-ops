'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const fs = require('node:fs'), vm = require('node:vm');
const renderer = fs.readFileSync(require.resolve('../src/cqc-sprite-renderer.js'), 'utf8');
const cinema = fs.readFileSync(require.resolve('../src/chronicles-cinema-v056.js'), 'utf8');
function fixture() {
  const images = [], calls = [], ctx = {};
  for (const method of ['save','restore','translate','scale','rotate','beginPath','closePath','moveTo','lineTo','stroke','fill','arc','ellipse','fillRect','clearRect','drawImage'])
    ctx[method] = (...args) => calls.push([method,...args]);
  ctx.createLinearGradient = () => ({addColorStop(){}});
  const canvas = {id:'sceneArt',dataset:{},width:1280,height:720,isConnected:true,getContext:()=>ctx};
  class Image {
    set src(value) {
      this.url = value;
      if (value.includes('/combat-sprites/')) images.push(this);
      else {this.complete=true; this.naturalWidth=1280; this.naturalHeight=720; this.onload?.();}
    }
  }
  const f = {uid:'core__test',visual:{weapon:'rifle'}};
  const sandbox = {URL,Image,performance:{now:()=>0},CQC56_PLATE_CATALOG:{test:{file:'assets/test.png'}},CQC56_PORTRAITS:{cancel(){},draw(){return true;}}};
  sandbox.window=sandbox; vm.runInNewContext(renderer,sandbox);
  const entry = {uid:f.uid,name:'Test',game:'Test',incarnation:'original',coverage:'action-frames',displayHeight:220,facing:1,mirror:true,
    review:{status:'approved',reviewer:'test',reviewedAt:'2026-10-01',sourceKind:'original-game-capture',sources:[{url:'https://example.com/original'}],limits:['fixture'],checks:{identity:true,costume:true,equipment:true,anatomicalSides:true,singleFigure:true,transparentBackground:true}},
    actions:{idle:{fps:0,loop:true,frames:[{file:'assets/combat-sprites/test.png',sha256:'a'.repeat(64),rect:[0,0,100,200],pivot:[.5,1]}]}}};
  sandbox.CQC_COMBAT_SPRITES.configure({schema:'cqc.combat-sprites/1',entries:{[f.uid]:entry}},{baseURL:'http://localhost/cqc/'});
  sandbox.CQC55_ART = {drawStageLayers:()=>true,drawStageForeground(){},drawStage(){},drawFighter(){},drawSprite:(...args)=>sandbox.CQC_COMBAT_SPRITES.draw(...args)};
  vm.runInNewContext(cinema,sandbox);
  const story = {uid:f.uid,intro:[{stage:'big_shell',camera:'wide',visual:{set:'test',tile:0}}],outro:[],route:[]};
  const draw = () => sandbox.CQC56_CINEMA.draw(canvas,story,'intro',0,0,{motion:false,fighters:{[f.uid]:f},stages:{big_shell:{id:'big_shell'}}});
  const finish = ok => {for(const image of images){image.complete=true;image.naturalWidth=ok?100:0;image.naturalHeight=ok?200:0;ok?image.onload():image.onerror();}};
  return {sandbox,canvas,calls,draw,finish,images};
}
const flush = async () => {for(let i=0;i<6;i++) await Promise.resolve();};
test('actual renderer readiness resolves one shared native image and does not reload it',async()=>{
  const h=fixture(),api=h.sandbox.CQC_COMBAT_SPRITES;
  const ready=api.whenReady('core__test');api.preload('core__test');assert.equal(h.images.length,1);
  h.finish(true);assert.equal(await ready,true);assert.equal(api.status('core__test').ready,true);
  assert.equal(await api.whenReady('unknown'),false);
});
test('actual static cinema draws no substitute then renders the decoded native PNG',async()=>{
  const h=fixture();for(let i=0;i<12;i++)h.draw();
  assert.equal(h.canvas.dataset.actorRenderer,'loading-combat-png');assert.equal(h.images.length,1);
  const before=h.calls.filter(c=>c[0]==='clearRect').length;h.finish(true);await flush();
  assert.equal(h.canvas.dataset.actorRenderer,'approved-combat-png');
  assert.equal(h.calls.filter(c=>c[0]==='clearRect').length,before+1);
});
test('a failed PNG reports native failure once without a substitute or request loop',async()=>{
  const h=fixture();h.draw();const before=h.calls.filter(c=>c[0]==='clearRect').length;h.finish(false);await flush();
  assert.equal(h.canvas.dataset.actorRenderer,'failed-combat-png');assert.equal(h.calls.filter(c=>c[0]==='clearRect').length,before+1);
  h.draw();assert.equal(h.images.length,1);assert.equal(await h.sandbox.CQC_COMBAT_SPRITES.whenReady('core__test'),false);
});
test('a pending sprite cannot overwrite a scene switched to autonomous full artwork',async()=>{
  const h=fixture();h.draw();h.sandbox.CQC56_PLATE_CATALOG.test.fullScene=true;h.draw();
  const before=h.calls.length;h.finish(true);await flush();assert.equal(h.calls.length,before);assert.equal(h.canvas.dataset.fullScene,'true');
});
test('a pending sprite cannot redraw a detached canvas',async()=>{
  const h=fixture();h.draw();h.canvas.isConnected=false;const before=h.calls.length;
  h.finish(true);await flush();assert.equal(h.calls.length,before);
});
test('a direct clean plate invalidates the pending actor callback',async()=>{
  const h=fixture();h.draw();h.sandbox.CQC56_CINEMA.drawPlate(h.canvas,{set:'test'},{motion:false});
  const before=h.calls.length;h.finish(true);await flush();assert.equal(h.calls.length,before);assert.equal(h.canvas.dataset.composition,'clean-art');
});
test('the shipped static album contains the corrected cinema source exactly once',()=>{
  const album=fs.readFileSync(require.resolve('../docs/ALBUM_LOCAL_354_RECITS_v0.56.html'),'utf8');
  assert.equal(album.split(cinema).length-1,1);
});
