'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const root=require('node:path').resolve(__dirname,'..');
const {createRenderer}=require(root+'/src/cqc-stage-layers.js');
const stage=JSON.parse(fs.readFileSync(root+'/data/stage-layer-catalog-reprise.json','utf8')).stages.find(s=>s.approved);
function stageFixture(value=stage){
 const images=[],decodes=[],sizes=new Map(value.layers.map(l=>[l.file,l]));
 class Image{
  constructor(){images.push(this);}
  set src(file){this.file=file;if(!file)return;const l=sizes.get(file);this.naturalWidth=l.width;this.naturalHeight=l.height;}
  decode(){return new Promise((resolve,reject)=>decodes.push({resolve,reject}));}
 }
 return{renderer:createRenderer({stages:[value]},{Image,baseURL:''}),images,decodes};
}
test('an approved stage remains pending until every layer is decoded',async()=>{
 const f=stageFixture(),p=f.renderer.preload(stage.id);for(const i of f.images)i.onload();
 assert.equal(f.renderer.status(stage.id).state,'loading');for(const d of f.decodes.slice(0,-1))d.resolve();
 await Promise.resolve();assert.equal(f.renderer.status(stage.id).state,'loading');f.decodes.at(-1).resolve();
 assert.equal(await p,true);assert.equal(f.renderer.status(stage.id).state,'ready');
});
test('stage retry shares an in-flight load and restarts only a failed approved stage',async()=>{
 const f=stageFixture(),p=f.renderer.preload(stage.id),n=f.images.length;
 assert.equal(f.renderer.preload(stage.id,{retry:true}),p);assert.equal(f.images.length,n);
 for(const i of f.images)i.onload();f.decodes[0].reject(Error('failed decode'));for(const d of f.decodes.slice(1))d.resolve();
 assert.equal(await p,false);assert.equal(f.renderer.status(stage.id).state,'error');
 const retry=f.renderer.preload(stage.id,{retry:true});assert.equal(f.images.length,n*2);
 for(const i of f.images.slice(n))i.onload();for(const d of f.decodes.slice(n))d.resolve();
 assert.equal(await retry,true);assert.deepEqual(f.renderer.status(stage.id).errors,[]);
 await f.renderer.preload(stage.id,{retry:true});assert.equal(f.images.length,n*2);
});
test('retry never makes a rejected stage eligible',async()=>{
 const value=structuredClone(stage);value.layers[0].file='../outside.png';const f=stageFixture(value);
 assert.equal(await f.renderer.preload(value.id,{retry:true}),false);assert.equal(f.renderer.status(value.id).state,'invalid');assert.equal(f.images.length,0);
});
function parentFixture(){
 const text=fs.readFileSync(root+'/src/chronicles-v056.js','utf8'),start=text.indexOf("addEventListener('message',e=>"),end=text.indexOf('\n',start);
 const engine={},wait={},pause={},timeouts=new Map([[7,{ms:7000}]]),failures=[];
 const box={pending:{token:'current',started:false},diag:{rejected:0},ackTimer:7,
  $:selector=>selector==='#engine'?{contentWindow:engine}:selector==='#wait'?wait:pause,
  addEventListener:(_,handler)=>box.listener=handler,clearTimeout:id=>timeouts.delete(id),
  setTimeout:(callback,ms)=>{const id=next++;timeouts.set(id,{callback,ms});return id;},
  failure:message=>failures.push(message)};let next=8;
 vm.runInNewContext(text.slice(start,end),box);
 return{box,wait,pause,timeouts,failures,send:(data,source=engine)=>box.listener({source,data})};
}
test('a validated loading message extends the actual ACK wait once and started ends it',()=>{
 const f=parentFixture();f.send({type:'cqc55.loading',token:'current'});
 assert.equal(f.box.pending.loading,true);assert.equal(f.timeouts.has(7),false);assert.equal(f.timeouts.get(8).ms,60000);
 assert.match(f.wait.textContent,/Chargement/);f.send({type:'cqc55.loading',token:'current'});assert.equal(f.timeouts.size,1);
 f.send({type:'cqc55.started',token:'current'});assert.equal(f.box.pending.started,true);assert.equal(f.wait.hidden,true);assert.equal(f.timeouts.size,0);
});
test('wrong source, stale token and late timeout cannot affect a different chapter request',()=>{
 const f=parentFixture();f.send({type:'cqc55.loading',token:'current'},{});f.send({type:'cqc55.loading',token:'old'});
 assert.equal(f.box.pending.loading,undefined);assert.equal(f.timeouts.get(7).ms,7000);assert.equal(f.box.diag.rejected,2);
 f.send({type:'cqc55.loading',token:'current'});const callback=f.timeouts.get(8).callback;f.box.pending={token:'new',started:false};callback();assert.deepEqual(f.failures,[]);
});
