# Audit PASS10 — affichage et premier chargement

Audit en lecture seule, terminé sur le HEAD `11b04442ec1e26d8962ac65289c0b020e2bd91d9`. Aucune source applicative, image, entrée native, sauvegarde partagée, règle CSS ou moteur n’a été modifiée. Une session Chromium indépendante a été fermée après les observations ; son cache disque était borné à 1 octet. Les 334 fichiers du gel source à 43 entrées ont été vérifiés avant et après, sans changement.

## Défauts réellement observés

Les rapports ci-dessous comparent le rapport de l’image du canvas à celui de sa boîte CSS. Avec `object-fit: fill`, un facteur différent de 1 signifie une déformation des pixels affichés. Avec `contain` ou `cover`, les dimensions de la boîte ne suffisent pas à conclure à une déformation : ces modes conservent le rapport des pixels.

| Zone | Canvas intrinsèque | Boîte réelle | Mode actuel | Facteur horizontal / vertical |
| --- | --- | --- | --- | --- |
| P1/P2, desktop 1366×768 | 480×520 | 268×232 | fill | 1,2514 |
| Finisher, desktop | 480×520 | 300×260 | fill | 1,2500 |
| Roster, desktop | 260×150 | 118,5×72 | fill | 0,9495 |
| Roster, mobile 390×844 | 260×150 | ~108,66×57 | fill | ~1,0998 |
| Mini-stage, desktop | 1280×720 | 268×79 | fill | 1,9082 |
| Galerie de stage, desktop | 1280×720 | 1008×678 | fill | 0,8363 |
| Galerie de stage, mobile | 1280×720 | 364×383,375 | fill | 0,5341 |
| Techniques, desktop | 480×520 | 250×205 | contain | La boîte est différente ; les pixels restent proportionnés |
| Hero du launcher, desktop | 1200×760 | ~841,56×522,23 | fill | 1,0206 |

La capture desktop complète a été physiquement examinée. Les cartes du roster font 149 px de haut ; le dessin reste dans un canvas de 72 px, suivi des noms et d’une grande zone vide. Les panneaux P1/P2 ont aussi une grande zone vide sous leurs informations. Agrandir arbitrairement les acteurs en conservant leurs anciens canvases puis étirer ces canvases reproduirait le défaut.

Le premier chargement a été observé sans mock et sans remplacement de méthode : à 661,2 ms les sprites de `core__boss` et `core__snake` étaient en état `loading`, et leurs portraits avaient déjà été peints. À 1069 ms ils étaient `ready`, avec de nouvelles empreintes de pixels pour les deux portraits. Le code explique cette transition : le renderer renvoie `false` pendant le chargement, puis le module peint immédiatement le mannequin procédural ; le callback de readiness le remplace ensuite par les PNG. Le premier intervalle observé entre ces états est d’environ 408 ms. Cela mesure ce chargement réel local, sans prétendre certifier une durée universelle.

## Emplacements exacts

- `modules/unified-versus-v055.html:3` : `.portrait canvas` est forcé à `width:100%;height:100%` dans une zone de 232 px ; les deux canvases ont les attributs 480×520.
- Ligne 4 : `.fighter-card canvas` garde une hauteur fixe de 72 px, `.roster` utilise des rangées flexibles ; `.stage-mini canvas` est forcé aux dimensions d’une zone de 80 px.
- Ligne 6 : `.stage-preview canvas` est forcé à `width:100%;height:100%` dans une boîte de galerie de rapport variable.
- Ligne 10 : la hauteur du canvas de carte passe à 57 px sur petit écran.
- Ligne 12 : le portrait du répertoire de techniques utilise déjà `object-fit:contain`.
- Ligne 16 : `.finish-bio46 canvas` a une hauteur forcée de 260 px et aucun mode de conservation du rapport.
- Ligne 19 : le mode original remplace les rangées par 150 px et les canvases par 95 px ; ce mode doit aussi entrer dans les tests après changement.
- Ligne 422 : `drawFighter` bascule immédiatement au procédural si `CQC_COMBAT_SPRITES.draw` renvoie `false`.
- Lignes 423–429 : `refreshPortraitWhenReadyReprise` attend les sources natives et redessine avec un token pour éviter de redessiner une ancienne sélection.
- Ligne 430 : `drawPortrait` utilise `min(w/260,h/300)*.95`, donc la taille du vieux mannequin pour tous les acteurs, puis appelle `drawFighter`.
- Ligne 437 : chaque carte crée un canvas fixe de 260×150, indépendamment de sa boîte CSS.
- Ligne 473 : entrée de `startMatch`, à préserver comme point de lancement synchrone pour les appels moteur existants.
- Ligne 590 : la galerie réutilise `drawStage` et `drawFighter`, donc elle peut aussi montrer les décors/acteurs hérités pendant leur chargement.
- `src/cqc-sprite-renderer.js:61–73` : création à la demande d’un Image et états loading/ready/failed.
- Lignes 95–106 : `preload` et `whenReady(uid)` demandent toutes les feuilles/actions des deux directions, et non seulement le portrait idle.
- Lignes 129–148 : une image non prête renvoie false ; les tailles natives utilisent déjà un facteur uniforme correct dans le canvas. La déformation se produit ensuite dans la présentation CSS.
- `src/cqc-stage-layers.js:313–315` : le dessin de stage renvoie false si les plans ne sont pas prêts ; `status` et `preload` sont exposés aux lignes 335–342.
- `index.html:2` : le hero 1200×760 est étiré à sa boîte. Ligne 25 : `drawHero` est actuellement un dessin procédural permanent, pas une illustration native qui apparaît après chargement ; `frame.onload` masque le chargement sans attendre un état UI spécifique du module.
- `src/chronicles-portraits-v056.js:51–54` : les portraits d’atlas adaptent déjà leur cadrage par crop à l’intérieur de la cellule, sans mélange de cellules ni étirement.
- `src/chronicles-cinema-v056.js:89–100` : les plates utilisent contain ou un crop de rapport équivalent, sans étirement ; leur contenu natif n’est pas la cause principale des déformations Versus.
- `src/chronicles-v056.css:1` : les petits portraits et le hero utilisent `object-fit:cover`. Ligne 25 : le sceneArt mobile utilise aussi cover. Cela peut rogner le cadrage, mais ne déforme pas les pixels.

## Proposition minimale de correction

1. Donner aux cartes un canvas qui occupe l’espace disponible au-dessus de leurs libellés ; garder les libellés dans une zone courte distincte. Ajuster les rangées et leur overflow pour qu’une page reste entièrement accessible sur desktop/mobile. Le mode original doit partager cette règle plutôt que conserver sa hauteur d’image fixe séparée.
2. Adapter les dimensions du buffer des portraits à leur boîte affichée, puis appliquer une échelle uniforme à l’acteur idle. La taille utile se calcule avec la frame native, son pivot et son facteur source ; aucune modification de `displayHeight`, des rects ou des pivots de combat n’est nécessaire. Un ResizeObserver ou un redessin au changement de taille permet d’éviter que le buffer correct à l’initialisation soit ensuite étiré.
3. Utiliser une marge proportionnée et un centrage de la frame complète. Les corps humains hauts, Crying Wolf, Raven et Mantis n’ont pas le même rapport : un zoom universel couperait du matériel ou des appendices. La frame complète peut être agrandie jusqu’à la limite de la boîte avec `min(largeur disponible/largeur native, hauteur disponible/hauteur native)`, sans échelle X/Y différente. Un fond ou un cadrage de portrait distinct peut remplir le reste sans déformer la silhouette.
4. Donner au mini-stage et à la galerie une présentation 16/9 cohérente, ou un mode contain explicite. Préserver les coordonnées 1280×720, le sol, la caméra et les plans du vrai jeu. Le canvas de combat possède déjà son contain 16/9 et ne doit pas recevoir le traitement des portraits.
5. Pour une UID native approuvée encore en cours de chargement, présenter un état calme « Chargement du portrait… » plutôt que dessiner le mannequin qui sera remplacé. Conserver les tokens qui annulent les callbacks d’une sélection quittée. Les profils sans illustration native restent distincts des images natives en chargement ; ne pas les mettre dans une attente permanente.
6. Ne pas redéfinir la signification de `whenReady(uid)` pour les tests et le gameplay existants. Si une readiness de portrait seulement est ajoutée, elle doit être explicite, indépendante, et ne pas provoquer une boucle de microtasks lorsque idle est prêt mais que d’autres actions ne le sont pas encore.
7. Préparer les deux acteurs et le stage avant l’affichage d’un premier combat lancé par l’interface. Le combat ne doit pas avancer invisiblement derrière un chargement : attendre avant son lancement, ou garder son avance inactive pendant cette préparation. Préserver le contrat synchrone du moteur/API actuel et les valeurs des profils. Un échec doit rendre la main à une UI lisible au lieu d’un écran de chargement infini.

## Vérification proposée après RootGO

Mesurer les rapports des pixels réellement peints, pas seulement les dimensions des éléments lorsque contain/cover est actif. Vérifier des acteurs humain, quadrupède et à appendices larges ; portraits P1/P2, vignettes, répertoire et finishers ; galerie et mini-stage ; desktop, mobile et mode original. Un chargement froid et un retour au module doivent montrer la transition chargement → image finale sans mannequin temporaire. Une sélection rapide A → B doit empêcher le callback A de remplacer B. Les contrôles, paginations, recherche, lancements et retours de module doivent rester atteignables. Réhash des PNG et vérification des paramètres de combat inchangés avant/après.

## Preuves conservées

- `actual-local-02/REAL_BROWSER_AUDIT.json` : 135 089 octets, SHA256 `8eb4b4aa75a6fa839df9ca874b169b3fa4dfd000d99a2aaac6d276e277d08d38` ; 7 observations de page, 24 commandes réelles réussies, sources avant/après et session fermée.
- `actual-local-02/desktop-versus-selection.jpg` : 91 785 octets, SHA256 `15ca0c59790b7deb1e01343c51e8e05f2dc13bac3bbca9ca91a6783f365b2196` ; capture complète physiquement examinée.
- `REAL_BROWSER_AUDIT.json` : premier lancement du daemon refusé avant toute page, conservé séparément ; 5 151 octets, SHA256 `3cf0b8afd50cd76a497710270b5285646bf9eebfc042dda88503a5d5207319a6`.
- Les deux scripts d’audit et l’observateur passif restent indépendants des sources applicatives. Le premier essai a été relancé avec l’accès réseau normal du navigateur ; aucun mock ni contournement de TLS/proxy n’a été utilisé.

Ce bilan ne prétend pas qu’un correctif est déjà appliqué. Aucun commit, déploiement ou mutation de source n’a été effectué par cet audit.
