(() => {
  const rows = [];
  window.__cqcDisplayLoadingAudit = rows;
  let previous = '', samples = 0;
  function observe() {
    const api = window.__CQC053Versus, sprites = window.CQC_COMBAT_SPRITES;
    if (api && sprites) {
      const names = ['p1Info', 'p2Info'].map(id => document.getElementById(id)?.querySelector('h2')?.textContent);
      const selected = names.map(name => api.fighters.find(f => f.name === name)).filter(Boolean);
      const states = selected.map(f => { const s = sprites.status(f.uid); return {uid: f.uid, renderer: s.renderer, ready: s.ready, states: s.states}; });
      const key = JSON.stringify(states);
      if (key !== previous && rows.length < 10) {
        previous = key;
        const pixels = ['p1Portrait', 'p2Portrait'].map(id => {
          const canvas = document.getElementById(id);
          if (!canvas) return null;
          const rgba = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height).data;
          let fingerprint = 2166136261;
          for (let i = 0; i < rgba.length; i += 16) fingerprint = Math.imul(fingerprint ^ rgba[i], 16777619) >>> 0;
          return {id, sampledPixelFingerprint: fingerprint, sampleStride: 16};
        });
        rows.push({at: performance.now(), states, pixels});
      }
    }
    if (++samples < 360) requestAnimationFrame(observe);
  }
  requestAnimationFrame(observe);
})();
