"""Read-only geometry/loading audit; no app edits, mocks or synthetic engine frames."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
import importlib.util, hashlib, json, subprocess, datetime

OUT = Path('/workspace/cqc-pass10-display-loading-audit')
S = Path('/workspace/shadow-codec-recovered')
R = Path('/workspace/cqc-game-working/cqc-versus-v056')
FREEZE = Path('/workspace/cqc-pass9-final-qa/actual43-source-freeze.json')
HEAD = '11b04442ec1e26d8962ac65289c0b020e2bd91d9'
def pin(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
def guard():
    f = json.loads(FREEZE.read_text())
    assert f['entryCount'] == 43 and len(f['files']) == 334
    for item in f['files']:
        p = Path(item['path'])
        assert p.stat().st_size == item['bytes'] and pin(p)['sha256'] == item['sha256'], str(p)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=S, text=True).strip() == HEAD
    return [pin(R/'modules/unified-versus-v055.html'), pin(R/'src/cqc-sprite-renderer.js'), pin(R/'index.html'), pin(R/'src/chronicles-cinema-v056.js'), pin(R/'src/chronicles-portraits-v056.js'), pin(S/'public/cqc/runtime-manifest.json')]

GEOMETRY = r'''(() => {
 const selectors=['#p1Portrait','#p2Portrait','.fighter-card canvas','#stageMini','#stagePreview','#techPortrait45','#finishPortrait46','#heroCanvas'];
 const rows=[];
 for(const selector of selectors) for(const canvas of [...document.querySelectorAll(selector)].slice(0,6)) {
  const rect=canvas.getBoundingClientRect(),style=getComputedStyle(canvas),parent=canvas.parentElement.getBoundingClientRect();
  if(!rect.width||!rect.height)continue;
  rows.push({selector,id:canvas.id||null,label:canvas.closest('.fighter-card')?.querySelector('b')?.textContent,intrinsic:{width:canvas.width,height:canvas.height,ratio:canvas.width/canvas.height},css:{width:rect.width,height:rect.height,ratio:rect.width/rect.height,objectFit:style.objectFit,display:style.display},sourceScale:{x:rect.width/canvas.width,y:rect.height/canvas.height,anisotropy:(rect.width/canvas.width)/(rect.height/canvas.height)},parent:{width:parent.width,height:parent.height},bounds:{top:rect.top,bottom:rect.bottom,left:rect.left,right:rect.right}});
 }
 return {url:location.href,viewport:{width:innerWidth,height:innerHeight},bodyClass:document.body.className,canvases:rows,rosterCardCount:document.querySelectorAll('.fighter-card').length,rosterBox:(()=>{const e=document.querySelector('.roster');if(!e)return null;const r=e.getBoundingClientRect(),c=getComputedStyle(e);return{height:r.height,width:r.width,rows:c.gridTemplateRows,columns:c.gridTemplateColumns,overflowY:c.overflowY,scrollHeight:e.scrollHeight}})(),loadingObservations:window.__cqcDisplayLoadingAudit||[]};
})()'''

before=guard()
spec=importlib.util.spec_from_file_location('readonly_common','/workspace/cqc-pass6-browser-common.py')
C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)
b=C.Browser(OUT,'cqc-pass10-display-audit')
b.env['AGENT_BROWSER_INIT_SCRIPTS']=str(OUT/'passive-loading-observer.js')
b.env['AGENT_BROWSER_SCREENSHOT_FORMAT']='jpeg'
b.env['AGENT_BROWSER_SCREENSHOT_QUALITY']='45'
b.prefix[b.prefix.index('--args')+1]='--no-sandbox,--disk-cache-size=1,--media-cache-size=1'
rows=[];failure=None;shots=[]
def capture(name): rows.append({'name':name,'result':b.evaluate(GEOMETRY)})
try:
 b.call('set','viewport','1366','768')
 b.call('open','http://127.0.0.1:5179/cqc/modules/unified-versus-v055.html')
 b.call('wait','--load','networkidle')
 capture('desktop-versus-selection')
 b.call('screenshot',str(OUT/'desktop-versus-selection.jpg'))
 shots.append(pin(OUT/'desktop-versus-selection.jpg'))
 b.call('click','#techSelect45');capture('desktop-technique-portrait')
 b.call('click','#techClose45')
 b.call('click','#finishSelect46');capture('desktop-finisher-portrait')
 b.call('click','#finishClose46')
 b.call('click','#openGallery');capture('desktop-stage-gallery')
 b.call('click','#closeGallery')
 b.call('set','viewport','390','844');capture('mobile-versus-selection')
 b.call('click','#openGallery');capture('mobile-stage-gallery')
 b.call('click','#closeGallery')
 b.call('set','viewport','1366','768')
 b.call('open','http://127.0.0.1:5179/cqc/index.html')
 b.call('wait','--load','networkidle');capture('desktop-command-launcher')
except Exception as e: failure=repr(e)
finally: b.close()
after=guard()
assert before==after,'Read-only audit sources changed'
proof={'schema':'cqc-pass10-read-only-display-loading-browser/v1','status':'failed' if failure else 'observed','failure':failure,'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':HEAD,'sourcePinsBefore':before,'sourcePinsAfter':after,'native334FilesByteUnchanged':True,'actualBrowserPrefix':b.prefix,'ownedSession':b.session,'observations':rows,'commands':b.commands,'screenshots':shots,'tool':pin(Path(__file__)),'passiveInitObserver':pin(OUT/'passive-loading-observer.js'),'limits':['Audit records existing behavior, including defects; it does not certify a fix.','Passive requestAnimationFrame observer reads sprite readiness and canvas pixels; no method wrapping, CSS injection, mocked image/network response or source edit.','CSS anisotropy describes canvas element scaling; object-fit contain can preserve painted pixels despite unequal element dimensions.','Cold initial navigation belongs to this fresh browser session; later navigation/viewport changes can reuse in-memory assets.']}
p=OUT/'REAL_BROWSER_AUDIT.json'
with p.open('x') as h:json.dump(proof,h,indent=2,ensure_ascii=False);h.write('\n')
total=sum(x.stat().st_size for x in OUT.rglob('*') if x.is_file())
print(json.dumps({'status':proof['status'],'failure':failure,'observations':len(rows),'proof':pin(p),'totalOutputBytes':total,'budgetBytes':300*1024,'screenshots':shots},indent=2))
assert total<=300*1024,'Audit output exceeds ROOT budget; preserve outputs and notify ROOT'
if failure:raise SystemExit(1)
