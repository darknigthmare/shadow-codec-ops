from pathlib import Path
import hashlib,json
R=Path('/workspace/cqc-game-working/cqc-versus-v056');T=Path('/workspace/cqc-pass10-renderer-preparation')
manifest=[]
def prepare(name,changes):
 p=R/'src'/name;original=p.read_bytes();code=original.decode()
 for old,new in changes:
  assert code.count(old)==1,(name,old[:120]);code=code.replace(old,new)
 for prefix,data in [('BASELINE_',original),('REVIEWED_CANDIDATE_',code.encode())]:
  with (T/(prefix+name)).open('xb') as f:f.write(data)
 manifest.append({'path':str(p),'originalSha256':hashlib.sha256(original).hexdigest(),'candidateSha256':hashlib.sha256(code.encode()).hexdigest(),'activeSourceWrites':0})
prepare('chronicles-portraits-v056.js',[
 ("function finish(entry,ok){\n    entry.status=", "function finish(entry,ok){\n    if(entry.status!=='loading')return;\n    entry.status="),
 ("img.onload=()=>finish(entry,true);", "let decoding=false;const loaded=()=>{if(decoding||entry.status!=='loading')return;decoding=true;if(typeof img.decode!=='function'){finish(entry,true);return;}try{Promise.resolve(img.decode()).then(()=>finish(entry,true),()=>finish(entry,false));}catch(_){finish(entry,false);}};img.decoding='async';img.onload=loaded;"),
 ("entry.status==='loading')finish(entry,true);", "entry.status==='loading')loaded();"),
 ("if(draw(c,f.uid,0,0,canvas.width,canvas.height,{small:true})){canvas.dataset.painted='true';return;}\n    original(canvas,f);", "if(draw(c,f.uid,0,0,canvas.width,canvas.height,{small:true})){canvas.dataset.painted='true';canvas.dataset.artState='ready';return;}\n    if(mapping[f.uid]){c.fillStyle='#07110d';c.fillRect(0,0,canvas.width,canvas.height);const unavailable=failed.has(mapping[f.uid].atlas);canvas.dataset.painted='false';canvas.dataset.artState=unavailable?'failed':'loading';canvas.setAttribute?.('aria-label',f.name+' · '+(unavailable?'Portrait indisponible':'Chargement du portrait'));}\n    else original(canvas,f);")
])
prepare('chronicles-art-v056.js',[
 ("if(drawSprite(c,f,x,y,face,scale,pose))return true;c.save();", "if(drawSprite(c,f,x,y,face,scale,pose))return true;if(window.CQC_COMBAT_SPRITES?.has?.(f.uid))return false;c.save();"),
 ("if(drawStageLayers(c,stage,time,cam,preview,options))return true;const w=1280", "if(drawStageLayers(c,stage,time,cam,preview,options))return true;if(options.layers!==false&&window.CQC_STAGE_LAYERS?.status(stage||STAGES[0]).approved){c.fillStyle='#07110d';c.fillRect(0,0,1280,720);return false;}const w=1280")
])
prepare('chronicles-cinema-v056.js',[
 ("if (entry.cancelled) return;\n    entry.status =", "if (entry.cancelled || entry.status !== 'loading') return;\n    entry.status ="),
 ("img.onload = () => finish(entry, true);", "let decoding = false;\n    const loaded = () => {\n      if (decoding || entry.cancelled || entry.status !== 'loading') return;\n      decoding = true;\n      if (typeof img.decode !== 'function') { finish(entry, true); return; }\n      try { Promise.resolve(img.decode()).then(() => finish(entry, true), () => finish(entry, false)); }\n      catch (_) { finish(entry, false); }\n    };\n    img.onload = loaded;"),
 ("entry.status === 'loading') finish(entry, true);", "entry.status === 'loading') loaded();"),
 ("const ready = !!(img.complete && img.naturalWidth && img.naturalHeight);", "const ready = entry.status === 'loaded' && !!(img.complete && img.naturalWidth && img.naturalHeight);"),
 ("if (!ready) return false;", "if (!ready) {\n      c.fillStyle = '#07110d'; c.fillRect(0, 0, width, height);\n      canvas.dataset.artState = entry.status === 'failed' ? 'failed' : 'loading';\n      canvas.setAttribute?.('aria-label', entry.status === 'failed' ? 'Illustration indisponible' : 'Chargement de l’illustration');\n      return false;\n    }\n    canvas.dataset.artState = 'ready';"),
 ("if (!ready && !layered) {\n      A.drawStage", "if (!ready && !layered && !info.fullScene) {\n      A.drawStage"),
 ("const illustrated=!sprite && window.CQC56_PORTRAITS", "const nativeActor = camera !== 'overhead' && actor.visual?.weapon === f.visual?.weapon && !!window.CQC_COMBAT_SPRITES?.has?.(f.uid);\n      const illustrated=!sprite && !nativeActor && window.CQC56_PORTRAITS"),
 ("if (!illustrated && !sprite) pendingPortraits.push(f.uid);", "if (!illustrated && !sprite && !nativeActor) pendingPortraits.push(f.uid);"),
 ("canvas.dataset.actorRenderer=sprite?'approved-combat-png':illustrated?'portrait':'procedural-canvas';", "canvas.dataset.actorRenderer=sprite?'approved-combat-png':nativeActor?'loading-combat-png':illustrated?'portrait':'procedural-canvas';"),
 ("if (!illustrated && !sprite && camera !== 'overhead') {", "if (!illustrated && !sprite && !nativeActor && camera !== 'overhead') {"),
 ("const drawn=sprite||window.CQC56_PORTRAITS?.draw(c,card.opponent", "const nativeOpponent=!!window.CQC_COMBAT_SPRITES?.has?.(card.opponent);const drawn=sprite||(!nativeOpponent&&window.CQC56_PORTRAITS?.draw(c,card.opponent"),
 ("{ending:phase==='post'});if(!drawn){pendingPortraits.push(card.opponent);", "{ending:phase==='post'}));if(!drawn&&!nativeOpponent){pendingPortraits.push(card.opponent);")
])
with (T/'PARENT_LOADING_CANDIDATE_MANIFEST.json').open('x') as f:json.dump(manifest,f,indent=2)
print(json.dumps({'candidates':manifest,'activeSourceWrites':0}))
