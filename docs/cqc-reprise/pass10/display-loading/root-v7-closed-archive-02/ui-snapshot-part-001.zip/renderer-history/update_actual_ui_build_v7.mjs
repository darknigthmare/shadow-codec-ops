import {verifyRuntime} from '/workspace/shadow-codec-recovered/scripts/sync-cqc-runtime.mjs';
import {readFile,writeFile,mkdir,rename,stat} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const hash=b=>createHash('sha256').update(b).digest('hex');
const source='/workspace/shadow-codec-recovered/public/cqc',target='/tmp/cqc-pass10-ui-build/cqc',before='/tmp/cqc-pass10-ui-build-before-v7',receipt='/workspace/cqc-pass10-renderer-preparation/BUILD_V7_RUNTIME_DELTA.json';
const rows=[];
for(const relative of ['modules/unified-versus-v055.html','runtime-manifest.json']){
 const old=await readFile(target+'/'+relative),next=await readFile(source+'/'+relative);await mkdir(before+'/'+relative.split('/').slice(0,-1).join('/'),{recursive:true});await writeFile(before+'/'+relative,old,{flag:'wx'});
 await writeFile(target+'/'+relative+'.pass10-independent',next,{flag:'wx'});await rename(target+'/'+relative+'.pass10-independent',target+'/'+relative);
 if((await stat(target+'/'+relative)).nlink!==1||hash(await readFile(target+'/'+relative))!==hash(next))throw Error('Delta copied mismatch');rows.push({relative,previousBytes:old.length,previousSHA256:hash(old),bytes:next.length,sha256:hash(next)});
}
const verified=await verifyRuntime(target);const result={schema:'cqc.pass10.actual-build-runtime-delta/1',status:'passed',actualRun:true,closed:true,baseBuild:'Actual npm run build V3 in /tmp/cqc-pass10-ui-build; global app/source/bundles unchanged. V4 and then V6/V7 CSS-only CQC module + manifest independently copied from verified S runtime.',fullV7RebuildClaimed:false,changes:rows,verifiedRuntimeFiles:1017,unchangedGlobalBundles:true,beforeArchive:before};await writeFile(receipt,JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
