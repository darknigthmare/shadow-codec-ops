from pathlib import Path
import hashlib, json
R=Path('/workspace/cqc-game-working/cqc-versus-v056');T=Path('/workspace/cqc-pass10-renderer-preparation')
manifest=[]
def prepare(name,changes):
 p=R/'src'/name;original=p.read_bytes();code=original.decode()
 for old,new in changes:
  assert code.count(old)==1,(name,old[:150]);code=code.replace(old,new)
 for label,data in [('BASELINE_',original),('REVIEWED_CANDIDATE_',code.encode())]:
  with (T/(label+name)).open('xb') as f:f.write(data)
 manifest.append({'path':str(p),'originalSha256':hashlib.sha256(original).hexdigest(),'candidateSha256':hashlib.sha256(code.encode()).hexdigest(),'activeSourceWrites':0})
prepare('cqc-stage-layers.js',[
 ('function load(record) {\n      if (record) touch(record);', '''function load(record, options = {}) {
      if (record) touch(record);
      // Only an explicit retry resets a failed approved load. Invalid art stays rejected.
      if (options.retry === true && record?.state === 'error' && record.stage.approved) {
        releaseImages(record); record.errors = []; record.promise = null; record.state = 'unloaded';
      }'''),
 ('''        image.onload = () => {
          if ((image.naturalWidth || image.width) !== layer.width || (image.naturalHeight || image.height) !== layer.height) {
            record.errors.push('Unexpected dimensions: ' + layer.file); resolve(false);
          } else resolve(true);
        };
        image.onerror = () => { record.errors.push('Missing or unreadable image: ' + layer.file); resolve(false); };''', '''        let settled = false;
        const finish = (ok, message) => {
          if (settled) return;
          settled = true; if (message) record.errors.push(message); resolve(ok);
        };
        image.decoding = 'async';
        image.onload = () => {
          if ((image.naturalWidth || image.width) !== layer.width || (image.naturalHeight || image.height) !== layer.height) {
            finish(false, 'Unexpected dimensions: ' + layer.file); return;
          }
          if (typeof image.decode !== 'function') { finish(true); return; }
          const failed = () => finish(false, 'Undecodable image: ' + layer.file);
          try { Promise.resolve(image.decode()).then(() => finish(true), failed); }
          catch (_) { failed(); }
        };
        image.onerror = () => finish(false, 'Missing or unreadable image: ' + layer.file);'''),
 ('preload: stage => load(recordFor(stage)), status,','preload: (stage, options = {}) => load(recordFor(stage), options), status,')
])
prepare('chronicles-v056.js',[
 ("setScreen('fight');$('#wait').hidden=false;$('#pauseBtn').disabled=true;", "setScreen('fight');$('#wait').hidden=false;$('#wait').textContent='Préparation du duel…';$('#pauseBtn').disabled=true;"),
 ("if(d.type==='cqc55.started'){if(d.token===pending?.token)", "if(d.type==='cqc55.loading'){if(pending&&d.token===pending.token&&!pending.started){if(!pending.loading){pending.loading=true;clearTimeout(ackTimer);ackTimer=setTimeout(()=>{if(pending?.token===d.token&&!pending.started)failure('Le chargement du duel a dépassé le délai. Aucune reprise n’est consommée.');},60000);}$('#wait').textContent='Chargement des sprites et de la scène…';}else diag.rejected++;return;}if(d.type==='cqc55.started'){if(d.token===pending?.token)")
])
with (T/'STAGE_STORY_CANDIDATE_MANIFEST.json').open('x') as f:json.dump(manifest,f,indent=2)
print(json.dumps({'candidates':manifest,'activeSourceWrites':0}))
