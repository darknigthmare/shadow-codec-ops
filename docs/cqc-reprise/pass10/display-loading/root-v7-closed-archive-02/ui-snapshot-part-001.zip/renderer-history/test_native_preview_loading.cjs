'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const code=fs.readFileSync(__dirname+'/REVIEWED_CANDIDATE_RENDERER.js','utf8');
function fixture(rect=[0,0,600,120],pivot=[.2,.8]){
 const images=[],decoded=[];
 class Image{
  constructor(){this.naturalWidth=2048;this.naturalHeight=2048;images.push(this);}
  set src(v){this.url=v;}
  decode(){return new Promise((resolve,reject)=>decoded.push({resolve,reject}));}
 }
 const box={URL,Image};vm.runInNewContext(code,box);const api=box.CQC_COMBAT_SPRITES;
 const frame=(file,r=rect,p=pivot)=>({file:'assets/combat-sprites/'+file+'.png',sha256:'a'.repeat(64),rect:r,pivot:p});
 const e={uid:'core__fixture',name:'Fixture',game:'Fixture',incarnation:'Fixture',coverage:'action-frames',displayHeight:230,baseFrameHeight:100,facing:1,mirror:false,
  review:{status:'approved',reviewer:'fixture',reviewedAt:'2026-10-02',sourceKind:'original-game-capture',sources:[{url:'https://example.com/ref'}],limits:['test fixture'],checks:{identity:true,costume:true,equipment:true,anatomicalSides:true,singleFigure:true,transparentBackground:true}},
  actions:{idle:{fps:0,loop:true,frames:[frame('idle-right')]},attack:{fps:0,loop:false,frames:[frame('attack-right')]}},
  oppositeActions:{idle:{fps:0,loop:true,frames:[frame('idle-left')]},attack:{fps:0,loop:false,frames:[frame('attack-left')]}}};
 assert.equal(api.configure({schema:'cqc.combat-sprites/1',entries:{[e.uid]:e}},{baseURL:'https://example.com/'}).accepted,1);
 const calls=[],ctx={save(){},restore(){},scale(...a){calls.push(['scale',...a]);},translate(...a){calls.push(['translate',...a]);},drawImage(...a){calls.push(['drawImage',...a]);}};
 return{api,e,images,decoded,ctx,calls};
}
test('native readiness waits for decoding and repeated preparation shares requests',async()=>{
 const f=fixture(),p=f.api.whenReady(f.e.uid);
 f.api.preload(f.e.uid);assert.equal(f.images.length,4);
 for(const i of f.images)i.onload();assert.equal(f.api.status(f.e.uid).ready,false);
 for(const d of f.decoded)d.resolve();assert.equal(await p,true);
 assert.equal(f.api.status(f.e.uid).ready,true);assert.equal(f.api.has(f.e.uid),true);assert.equal(f.api.has('legacy'),false);
});
test('a roster portrait requests one facing idle sheet, not all combat actions',async()=>{
 const f=fixture(),options={action:'idle',face:-1},p=f.api.whenReady(f.e.uid,options);
 assert.equal(f.images.length,1);assert.match(f.images[0].url,/idle-left\.png$/);
 f.images[0].onload();f.decoded[0].resolve();assert.equal(await p,true);
 assert.equal(f.api.status(f.e.uid,options).ready,true);assert.equal(f.api.status(f.e.uid).ready,false);
});
test('failed decoding can be retried without reloading ready or in-flight sheets',async()=>{
 const f=fixture(),p=f.api.whenReady(f.e.uid);for(const i of f.images)i.onload();
 f.decoded[0].reject(Error('decode failure'));for(const d of f.decoded.slice(1))d.resolve();
 assert.equal(await p,false);const retry=f.api.whenReady(f.e.uid,{retry:true});
 assert.equal(f.images.length,5);f.api.preload(f.e.uid,{retry:true});assert.equal(f.images.length,5);
 f.images.at(-1).onload();f.decoded.at(-1).resolve();assert.equal(await retry,true);
});
for(const rect of [[0,0,600,120],[0,0,120,600]])test('complete '+rect[2]+'×'+rect[3]+' native silhouette fits uniformly with equipment and asymmetric pivot',async()=>{
 const f=fixture(rect),p=f.api.whenReady(f.e.uid,{action:'idle',face:-1});
 f.images[0].onload();f.decoded[0].resolve();await p;
 assert.equal(f.api.drawFitted(f.ctx,{uid:f.e.uid},{x:10,y:20,width:300,height:180,padding:9},-1,{time:0}),true);
 const transform=f.calls.find(c=>c[0]==='translate'),scale=f.calls.find(c=>c[0]==='scale'),draw=f.calls.find(c=>c[0]==='drawImage');
 assert.equal(scale[1],scale[2]);const x=transform[1]+draw[6]*scale[1],y=transform[2]+draw[7]*scale[2],w=draw[8]*scale[1],h=draw[9]*scale[2];
 assert(Math.abs(w/h-rect[2]/rect[3])<1e-10);
 assert(x>=19-1e-8&&y>=29-1e-8&&x+w<=301+1e-8&&y+h<=191+1e-8);
 assert(Math.abs(w-282)<1e-8||Math.abs(h-162)<1e-8);
 assert.equal(f.e.displayHeight,230);assert.deepEqual(f.e.actions.idle.frames[0].pivot,[.2,.8]);
});
test('pending native image draws no substitute and unsupported UID stays distinguishable',()=>{
 const f=fixture();assert.equal(f.api.drawFitted(f.ctx,{uid:f.e.uid},{x:0,y:0,width:300,height:180},-1),false);
 assert.equal(f.calls.length,0);assert.equal(f.api.has(f.e.uid),true);assert.equal(f.api.has('legacy'),false);
});
