from pathlib import Path
import json,hashlib
T=Path('/workspace/cqc-pass10-renderer-preparation');rows=[]
def refine(name,changes):
 p=T/('REVIEWED_CANDIDATE_'+name);code=p.read_text()
 for old,new in changes:
  assert code.count(old)==1,(name,old[:100]);code=code.replace(old,new)
 out=T/('REVIEWED_CANDIDATE_V2_'+name)
 with out.open('xb') as f:f.write(code.encode())
 rows.append({'path':str(out),'sha256':hashlib.sha256(code.encode()).hexdigest(),'previousCandidatePreserved':str(p)})
refine('chronicles-portraits-v056.js',[
 ("const c=canvas.getContext('2d');c.clearRect(0,0,canvas.width,canvas.height);", "const c=canvas.getContext('2d');c.clearRect(0,0,canvas.width,canvas.height);canvas.setAttribute?.('aria-label',f.name);canvas.setAttribute?.('aria-busy',status(f.uid).state==='loading'?'true':'false');"),
 ("canvas.dataset.artState='ready';return;", "canvas.dataset.artState='ready';canvas.setAttribute?.('aria-busy','false');return;"),
 ("canvas.setAttribute?.('aria-label',f.name+' · '+(unavailable?'Portrait indisponible':'Chargement du portrait'));", "canvas.setAttribute?.('aria-busy',unavailable?'false':'true');"),
 ("window.CQC56_PORTRAITS={draw,portrait,whenReady,cancel,diagnostics:", "function status(uid){const item=mapping[uid];return {mapped:!!item,state:item?(cache.get(item.atlas)?.status||'not-requested'):'unmapped'};}\n  window.CQC56_PORTRAITS={draw,portrait,whenReady,cancel,status,diagnostics:")
])
refine('chronicles-art-v056.js',[])
refine('chronicles-cinema-v056.js',[
 ("canvas.dataset.fullScene = String(info.fullScene);", "canvas.dataset.fullScene = String(info.fullScene);\n    canvas.setAttribute?.('aria-busy', entry.status === 'loading' ? 'true' : 'false');"),
 ("      canvas.setAttribute?.('aria-label', entry.status === 'failed' ? 'Illustration indisponible' : 'Chargement de l’illustration');\n", ""),
 ("const nativeActor = camera !== 'overhead'", "const atlasActor = !!window.CQC56_PORTRAIT_MAP?.[f.uid];\n      const nativeActor = camera !== 'overhead'"),
 ("canvas.dataset.actorRenderer=sprite?'approved-combat-png':nativeActor?'loading-combat-png':illustrated?'portrait':'procedural-canvas';", "const nativeFailed = nativeActor && window.CQC_COMBAT_SPRITES.status(f.uid).states?.some(state => state === 'failed' || state === 'unavailable');\n      canvas.dataset.actorRenderer=sprite?'approved-combat-png':nativeActor?(nativeFailed?'failed-combat-png':'loading-combat-png'):illustrated?'portrait':atlasActor?(window.CQC56_PORTRAITS?.status?.(f.uid).state==='failed'?'failed-portrait':'loading-portrait'):'procedural-canvas';"),
 ("if (!illustrated && !sprite && !nativeActor && camera !== 'overhead') {", "if (!illustrated && !sprite && !nativeActor && !atlasActor && camera !== 'overhead') {"),
 ("if(!drawn&&!nativeOpponent){pendingPortraits.push(card.opponent);A.drawFighter(c,opponent,640,628,-1,1.1,opponentPose);}", "if(!drawn&&!nativeOpponent){pendingPortraits.push(card.opponent);if(!window.CQC56_PORTRAIT_MAP?.[card.opponent])A.drawFighter(c,opponent,640,628,-1,1.1,opponentPose);}"),
 ("          const partlyReady = uids.some(uid => window.CQC_COMBAT_SPRITES.status(uid).states?.includes('ready'));\n          if ((loaded.some(Boolean) || partlyReady) && canvas.isConnected !== false && canvas.dataset.sceneKey === sceneKey)", "          // A terminal failure must redraw its waiting state once as well. Failed files\n          // are excluded by waitForSprite, so this never starts an automatic retry loop.\n          if (canvas.isConnected !== false && canvas.dataset.sceneKey === sceneKey)")
])
with (T/'PARENT_LOADING_V2_CANDIDATE_MANIFEST.json').open('x') as f:json.dump({'files':rows,'activeWrites':0},f,indent=2)
print(json.dumps(rows))
