from pathlib import Path
import hashlib,json,os,shutil
R=Path('/workspace/cqc-game-working/cqc-versus-v056'); T=Path('/workspace/cqc-pass10-renderer-preparation'); A=T/'historical-tests-before-pass10'; A.mkdir(exist_ok=True)
changes=[]
def put(rel,text):
 p=R/rel; p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():
  before=p.read_bytes(); backup=A/rel; backup.parent.mkdir(parents=True,exist_ok=True)
  if not backup.exists(): backup.write_bytes(before)
  elif backup.read_bytes()!=before: raise RuntimeError('Already changed baseline '+rel)
 else: before=b''
 tmp=p.with_name(p.name+'.pass10-new');tmp.write_text(text);os.replace(tmp,p)
 changes.append({'path':rel,'beforeSha256':hashlib.sha256(before).hexdigest(),'afterSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'inode':p.stat().st_ino,'links':p.stat().st_nlink})
s=(R/'tests/test_static_sprite_readiness_reprise.cjs').read_text()
s=s.replace('actual static cinema replaces a ready portrait after the delayed PNG finishes','actual static cinema draws no substitute then renders the decoded native PNG')
s=s.replace("assert.equal(h.canvas.dataset.actorRenderer,'portrait');assert.equal(h.images.length,1);","assert.equal(h.canvas.dataset.actorRenderer,'loading-combat-png');assert.equal(h.images.length,1);")
s=s.replace("a failed PNG retains the portrait without a redraw or request loop","a failed PNG reports native failure once without a substitute or request loop")
s=s.replace("const h=fixture();h.draw();const before=h.calls.length;h.finish(false);await flush();\n  assert.equal(h.canvas.dataset.actorRenderer,'portrait');assert.equal(h.calls.length,before);","const h=fixture();h.draw();const before=h.calls.filter(c=>c[0]==='clearRect').length;h.finish(false);await flush();\n  assert.equal(h.canvas.dataset.actorRenderer,'failed-combat-png');assert.equal(h.calls.filter(c=>c[0]==='clearRect').length,before+1);")
put('tests/test_static_sprite_readiness_reprise.cjs',s)
s=(R/'tests/test_static_portrait_refresh_reprise.cjs').read_text()
old="const begin=html.indexOf('const portraitRefreshRequestsReprise='),end=html.indexOf('function drawPortrait(canvas,f)',begin);assert(begin>=0&&end>begin);const shipped=html.slice(begin,end);"
new="const begin=html.indexOf('function refreshPortraitWhenReadyReprise(canvas,f)'),end=html.indexOf('function drawPortrait(canvas,f)',begin);assert(begin>=0&&end>begin);const shipped=\"const portraitRefreshRequestsReprise=new WeakMap();const portraitOptionsPass10={action:'idle',face:-1};\\n\"+html.slice(begin,end);"
assert old in s;s=s.replace(old,new)
s=s.replace("setup(status={renderer:'png',ready:false})","setup(status={renderer:'png',ready:false,states:['loading']})")
s=s.replace("const box={window:{CQC_COMBAT_SPRITES:api},drawPortrait:","const box={window:{CQC_COMBAT_SPRITES:api},portraitStatusPass10:()=>{},drawPortrait:")
s=s.replace('failed image keeps synchronous fallback and avoids redraw loop','failed image redraws its terminal status once without a request loop')
s=s.replace("resolve(false);await settle();assert.equal(x.draws.length,0);assert.equal(x.waits.length,1);","resolve(false);await settle();assert.equal(x.draws.length,1);assert.equal(x.waits.length,1);")
put('tests/test_static_portrait_refresh_reprise.cjs',s)
s=(R/'tests/test_chronicles_layer_fallback.cjs').read_text()
s=s.replace('while a full-scene image loads its legacy fallback cannot activate new stage layers','while a full-scene image loads neutral waiting art cannot activate legacy or new layers')
s=s.replace("const fallback=h.calls.find(c=>c[0]==='legacy-stage');assert(fallback);assert.equal(fallback.at(-1).layers,false);","assert(!h.calls.some(c=>c[0]==='legacy-stage'));assert.equal(h.canvas.dataset.artState,'loading');assert(h.calls.some(c=>c[0]==='fillRect'));")
put('tests/test_chronicles_layer_fallback.cjs',s)
s=(R/'tests/test_combat_sprite_contours_pass7.py').read_text()
s=s.replace("'src/cqc-sprite-renderer.js':'bf08ed", "'recovery/pass10-before-loading/src/cqc-sprite-renderer.js':'bf08ed")
p=R/'recovery/pass10-before-loading/src/cqc-sprite-renderer.js';p.parent.mkdir(parents=True,exist_ok=True)
assert not p.exists();shutil.copyfile(T/'BASELINE_RENDERER.js',p)
assert hashlib.sha256(p.read_bytes()).hexdigest()=='bf08ed6aa762f9eef16cb2de268005bbd57d1fc2d60f8d70556f145e2f4cec25'
put('tests/test_combat_sprite_contours_pass7.py',s)
s=(T/'test_native_preview_loading.cjs').read_text().replace("__dirname+'/REVIEWED_CANDIDATE_RENDERER.js'", "require.resolve('../src/cqc-sprite-renderer.js')")
put('tests/test_native_preview_loading_pass10.cjs',s)
s=(T/'test_stage_story_loading.cjs').read_text().replace("const root='/workspace/cqc-game-working/cqc-versus-v056';","const root=require('node:path').resolve(__dirname,'..');")
put('tests/test_stage_story_loading_pass10.cjs',s)
(T/'ACTUAL_RUNTIME_TEST_PREPARATION.json').write_text(json.dumps({'changes':changes,'historicalRendererBytesPreserved':True},indent=2)+'\n')
print(json.dumps({'changedTests':len(changes),'historicalCopiesPreserved':True}))
