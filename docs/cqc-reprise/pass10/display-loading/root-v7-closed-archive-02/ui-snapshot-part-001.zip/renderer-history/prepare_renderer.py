from pathlib import Path
import hashlib, json

R = Path('/workspace/cqc-game-working/cqc-versus-v056')
T = Path('/workspace/cqc-pass10-renderer-preparation')
source = R/'src/cqc-sprite-renderer.js'
original = source.read_bytes()
code = original.decode()
def replace(old, new):
    global code
    assert code.count(old) == 1, old[:120]
    code = code.replace(old, new)

replace('/* Verified combat PNGs and animation frames. Procedural Canvas stays available while art loads. */',
        '/* Verified combat PNGs, decoded readiness and uniformly fitted native previews. */')
replace('const entries = new Map(), images = new Map(), clocks = new Map();',
        'const entries = new Map(), images = new Map(), clocks = new Map(), entryFiles = new Map();')
replace('entries.clear(); images.clear(); clocks.clear(); baseURL = resolveBase(options);',
        'entries.clear(); images.clear(); clocks.clear(); entryFiles.clear(); baseURL = resolveBase(options);')
replace('if (validateEntry(uid, entry)) entries.set(uid, entry); else rejected.push(uid);', '''if (validateEntry(uid, entry)) {
        entries.set(uid, entry);
        const files = new Map();
        for (const action of [...Object.values(entry.actions), ...Object.values(entry.oppositeActions || {})])
          for (const frame of action.frames) files.set(frame.file, frame);
        entryFiles.set(uid, [...files.values()]);
      } else rejected.push(uid);''')
replace("image.onload = () => { record.state = image.naturalWidth > 0 && image.naturalHeight > 0 ? 'ready' : 'failed'; settle(record.state === 'ready'); };\n    image.onerror = () => { record.state = 'failed'; settle(false); };", '''let settled = false;
    const finish = (ready) => {
      if (settled) return;
      settled = true; record.state = ready ? 'ready' : 'failed'; settle(ready);
    };
    image.decoding = 'async';
    image.onload = () => {
      if (!(image.naturalWidth > 0 && image.naturalHeight > 0)) { finish(false); return; }
      // A loaded response is not enough: publish readiness only after pixel decoding.
      if (typeof image.decode !== 'function') { finish(true); return; }
      try { Promise.resolve(image.decode()).then(() => finish(true), () => finish(false)); }
      catch (_) { finish(false); }
    };
    image.onerror = () => finish(false);''')
start=code.index('  function preload(uid) {')
end=code.index('  function draw(c, fighter,', start)
code=code[:start]+'''  function has(uid) { return entries.has(uid); }
  function framesFor(entry, options = {}) {
    if (!options.action) return entryFiles.get(entry.uid);
    const face = options.face === -1 || options.face === 1 ? options.face : entry.facing;
    const directional = face !== entry.facing && entry.oppositeActions ? entry.oppositeActions : entry.actions;
    return directional[options.action]?.frames || [];
  }
  function recordsFor(entry, options = {}) {
    const frames = framesFor(entry, options), records = new Set();
    if (options.retry === true) {
      for (const frame of frames) {
        const state = images.get(frame.file)?.state;
        if (state === 'failed' || state === 'unavailable') images.delete(frame.file);
      }
    }
    for (const frame of frames) records.add(getImage(frame));
    return [...records];
  }
  function preload(uid, options = {}) {
    const entry = entries.get(uid); if (!entry) return false;
    return recordsFor(entry, options).length > 0;
  }
  function whenReady(uid, options = {}) {
    const entry = entries.get(uid);
    if (!entry) return Promise.resolve(false);
    const records = recordsFor(entry, options);
    return Promise.all(records.map(record => record.promise)).then(results => results.length > 0 && results.every(Boolean));
  }
  function status(uid, options = {}) {
    const entry = entries.get(uid);
    if (!entry) return { uid, renderer: 'procedural-canvas', coverage: 'pending-art-review', ready: false };
    const states = [...new Set(framesFor(entry, options).map(f => images.get(f.file)?.state || 'not-requested'))];
    return { uid, renderer: 'png', coverage: entry.coverage, actions: Object.keys(entry.actions), oppositeActions: Object.keys(entry.oppositeActions || {}), states, ready: states.length === 1 && states[0] === 'ready', limits: entry.review.limits };
  }
  function drawFitted(c, fighter, box, face = -1, pose = {}) {
    const entry = entries.get(fighter?.uid);
    if (!entry || !box || ![box.x, box.y, box.width, box.height].every(finite) || box.width <= 0 || box.height <= 0 || ![1, -1].includes(face)) return false;
    const opposite = face !== entry.facing && entry.oppositeActions;
    if (face !== entry.facing && !opposite && entry.mirror !== true) return false;
    const directional = opposite ? { ...entry, actions: entry.oppositeActions } : entry;
    const selected = selectFrame(directional, { ...pose, actionTime: finite(pose.actionTime) ? pose.actionTime : 0 });
    const frame = selected.frame;
    const padding = finite(box.padding) ? Math.max(0, box.padding) : 0;
    const innerWidth = box.width - padding * 2, innerHeight = box.height - padding * 2;
    if (innerWidth <= 0 || innerHeight <= 0) return false;
    const factor = entry.displayHeight / (entry.sourceFrameHeights?.[frame.file] || entry.baseFrameHeight || frame.rect[3]);
    const nativeWidth = frame.rect[2] * factor, nativeHeight = frame.rect[3] * factor;
    const fit = Math.min(innerWidth / nativeWidth, innerHeight / nativeHeight);
    const width = nativeWidth * fit, height = nativeHeight * fit;
    const pivotX = face !== entry.facing && !opposite ? 1 - frame.pivot[0] : frame.pivot[0];
    const x = box.x + padding + (innerWidth - width) / 2 + width * pivotX;
    const y = box.y + padding + (innerHeight - height) / 2 + height * frame.pivot[1];
    // Preview scale is separate from combat geometry; include the complete equipment rectangle.
    return draw(c, fighter, x, y, face, fit, { ...pose, actionTime: finite(pose.actionTime) ? pose.actionTime : 0, entityKey: pose.entityKey || `portrait:${entry.uid}:${face}` });
  }
''' + code[end:]
replace('return { configure, draw, preload, whenReady, status, validateEntry, actionName, selectFrame };',
        'return { configure, draw, drawFitted, has, preload, whenReady, status, validateEntry, actionName, selectFrame };')

for name, data in [('BASELINE_RENDERER.js',original), ('REVIEWED_CANDIDATE_RENDERER.js',code.encode())]:
    p=T/name
    with p.open('xb') as f: f.write(data)
with (T/'CANDIDATE_MANIFEST.json').open('x') as f:
    json.dump({'source':str(source),'originalSha256':hashlib.sha256(original).hexdigest(),
               'candidateSha256':hashlib.sha256(code.encode()).hexdigest(),
               'activeSourceWrites':0,'pixelWrites':0},f,indent=2)
print(json.dumps({'prepared':str(T/'REVIEWED_CANDIDATE_RENDERER.js'),'bytes':len(code.encode()),'activeSourceWrites':0}))
