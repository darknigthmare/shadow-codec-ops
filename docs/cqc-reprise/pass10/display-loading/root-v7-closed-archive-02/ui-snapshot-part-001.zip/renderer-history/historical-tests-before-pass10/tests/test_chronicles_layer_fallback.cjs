'use strict';
const assert=require('node:assert/strict'),test=require('node:test'),fs=require('node:fs'),vm=require('node:vm');
const cinema=fs.readFileSync(require.resolve('../src/chronicles-cinema-v056.js'),'utf8');
function setup({fullScene=false,layers=true,sprite=true,loaded=true}={}){
 const calls=[],ctx={canvas:null};for(const key of ['save','restore','translate','scale','rotate','beginPath','closePath','moveTo','lineTo','stroke','fill','arc','ellipse','fillRect','clearRect','drawImage'])ctx[key]=(...args)=>calls.push([key,...args]);
 ctx.createLinearGradient=()=>({addColorStop(){}});
 const canvas={id:'sceneArt',dataset:{},width:1280,height:720,isConnected:true,getContext:()=>ctx};ctx.canvas=canvas;
 const fighter={uid:'canon__hero',name:'Hero',color:'#123456',visual:{weapon:'rifle'}},stage={id:'big_shell'};
 class Image{constructor(){this.complete=loaded;this.naturalWidth=loaded?1672:0;this.naturalHeight=loaded?941:0;}}
 const sandbox={Image,performance:{now:()=>1000},CQC55_ART:{drawStageLayers:(...args)=>{calls.push(['stage-background',...args.slice(1)]);return layers},drawStage:(...args)=>calls.push(['legacy-stage',...args.slice(1)]),drawStageForeground:(...args)=>calls.push(['stage-foreground',...args.slice(1)]),drawSprite:(...args)=>{calls.push(['sprite',...args.slice(1)]);return sprite},drawFighter:()=>calls.push(['procedural-fighter'])},CQC56_PLATE_CATALOG:{canonical:{file:'assets/canonical.png',fullScene}},CQC56_PORTRAITS:{cancel(){},draw:()=>{calls.push(['portrait']);return true}}};sandbox.window=sandbox;vm.runInNewContext(cinema,sandbox);
 const story={uid: fighter.uid,intro:[{stage:stage.id,camera:'wide',visual:{set:'canonical',tile:0}}],outro:[],route:[]};
 const draw=(options={})=>sandbox.CQC56_CINEMA.draw(canvas,story,'intro',0,0,{motion:false,fighters:{[fighter.uid]:fighter},stages:{[stage.id]:stage},...options});
 return {calls,canvas,draw,sandbox};
}
test('full scene painting remains autonomous with no layer, sprite or portrait overpaint',()=>{
 const h=setup({fullScene:true});h.draw();assert.equal(h.calls.filter(c=>c[0]==='drawImage').length,1);assert.equal(h.calls.filter(c=>['stage-background','stage-foreground','sprite','portrait','procedural-fighter'].includes(c[0])).length,0);assert.equal(h.canvas.dataset.fullScene,'true');assert.equal(h.canvas.dataset.stageLayers,'false');
});
test('approved stage layers render before exact-UID sprites and foreground follows actors',()=>{
 const h=setup();h.draw();const names=h.calls.map(c=>c[0]);assert(names.indexOf('stage-background')<names.indexOf('sprite'));assert(names.indexOf('sprite')<names.indexOf('stage-foreground'));assert(!names.includes('portrait'));assert(!names.includes('legacy-stage'));assert.equal(h.calls.find(c=>c[0]==='sprite')[1].uid,'canon__hero');assert.equal(h.canvas.dataset.actorRenderer,'approved-combat-png');const bg=h.calls.find(c=>c[0]==='stage-background');assert.equal(bg.at(-1).motion,false);assert.equal(bg.at(-1).layers,true);
});
test('pending layer art retains an already-loaded painting composition without partial foreground',()=>{
 const h=setup({layers:false,sprite:false});h.draw();const names=h.calls.map(c=>c[0]);assert(names.includes('drawImage'));assert(names.includes('portrait'));assert(!names.includes('stage-foreground'));assert(!names.includes('legacy-stage'));assert.equal(h.canvas.dataset.stageLayers,'false');
});
test('clean artwork requests keep their painting and omit layer or actor hooks',()=>{
 const h=setup();h.draw({cleanArt:true});assert(!h.calls.some(c=>['stage-background','stage-foreground','sprite','portrait'].includes(c[0])));assert.equal(h.canvas.dataset.composition,'clean-art');
});
test('while a full-scene image loads its legacy fallback cannot activate new stage layers',()=>{
 const h=setup({fullScene:true,loaded:false});h.draw();const fallback=h.calls.find(c=>c[0]==='legacy-stage');assert(fallback);assert.equal(fallback.at(-1).layers,false);assert(!h.calls.some(c=>['stage-background','stage-foreground','sprite','portrait'].includes(c[0])));
});
test('Chronicles sprite adapter respects the UID and authored equipment change',()=>{
 const source=fs.readFileSync(require.resolve('../src/chronicles-art-v056.js'),'utf8'),fighter={uid:'canon__hero',visual:{weapon:'rifle'}},calls=[];
 const sandbox={CQC55_DATA:{stages:[],fighters:[fighter]},CQC_COMBAT_SPRITES:{draw:(...args)=>{calls.push(args);return true}}};sandbox.window=sandbox;vm.runInNewContext(source,sandbox);
 assert.equal(sandbox.CQC55_ART.drawSprite({},fighter,10,20,-1,1,{time:0}),true);assert.equal(calls[0][1].uid,fighter.uid);
 assert.equal(sandbox.CQC55_ART.drawSprite({},{...fighter,visual:{weapon:'fists'}},10,20,-1,1,{}),false);assert.equal(calls.length,1);
 assert.equal(sandbox.CQC55_ART.drawSprite({},fighter,10,20,-1,1,{spriteAllowed:false}),false);assert.equal(calls.length,1);
});
test('static album composition redraws once when reviewed stage PNGs finish loading',async()=>{
 const h=setup({layers:false,sprite:false});let resolve,requests=0,ready=false;
 const pending=new Promise(r=>resolve=r);h.sandbox.CQC_STAGE_LAYERS={status:()=>({approved:true}),preload:()=>{requests++;return pending}};
 h.sandbox.CQC55_ART.drawStageLayers=()=>{h.calls.push(['stage-background']);return ready};
 for(let i=0;i<12;i++)h.draw();assert.equal(requests,1);
 ready=true;resolve(true);await pending;await Promise.resolve();
 assert.equal(h.canvas.dataset.stageLayers,'true');assert.equal(h.calls.filter(c=>c[0]==='stage-foreground').length,1);
});
test('a delayed layer callback cannot overwrite a canvas switched to full artwork',async()=>{
 const h=setup({layers:false});let resolve;const pending=new Promise(r=>resolve=r);
 h.sandbox.CQC_STAGE_LAYERS={status:()=>({approved:true}),preload:()=>pending};h.draw();
 h.sandbox.CQC56_PLATE_CATALOG.canonical.fullScene=true;h.draw();const count=h.calls.length;
 resolve(true);await pending;await Promise.resolve();assert.equal(h.calls.length,count);assert.equal(h.canvas.dataset.fullScene,'true');
});
test('detached album canvases do not redraw after stage image completion',async()=>{
 const h=setup({layers:false});let resolve;const pending=new Promise(r=>resolve=r);
 h.sandbox.CQC_STAGE_LAYERS={status:()=>({approved:true}),preload:()=>pending};h.draw();h.canvas.isConnected=false;const count=h.calls.length;
 resolve(true);await pending;await Promise.resolve();assert.equal(h.calls.length,count);
});
