from pathlib import Path
import json,hashlib,subprocess,os
from datetime import datetime,timezone
R=Path('/workspace/cqc-game-working/cqc-versus-v056');S=Path('/workspace/shadow-codec-recovered');T=Path('/workspace/cqc-pass10-renderer-preparation');parent='11b04442ec1e26d8962ac65289c0b020e2bd91d9';H=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=S,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0','GIT_NO_LAZY_FETCH':'1'})
allowed={'modules/unified-versus-v055.html','src/chronicles-art-v056.js','src/chronicles-cinema-v056.js','src/chronicles-portraits-v056.js','src/chronicles-v056.js','src/cqc-sprite-renderer.js','src/cqc-stage-layers.js'}
assert git('rev-parse','HEAD').decode().strip()==parent;changes=git('diff','--name-only',parent,'--').decode().splitlines();assert set(changes)=={'public/cqc/'+p for p in allowed}|{'public/cqc/runtime-manifest.json'};assert not git('ls-files','--others','--exclude-standard').strip()
freeze=json.loads(Path('/workspace/cqc-pass9-final-qa/actual43-source-freeze.json').read_text());unchanged=[];changed=[]
for p in freeze['files']:
 file=Path(p['path']);raw=file.read_bytes();relative=str(file.relative_to(R));row={'path':relative,'beforeSHA256':p['sha256'],'sha256':H(raw),'bytes':len(raw)}
 if H(raw)==p['sha256']:assert len(raw)==p['bytes'];unchanged.append(row)
 else:assert relative in allowed;assert file.stat().st_nlink==1;changed.append(row)
assert set(p['path'] for p in changed)==allowed
old=json.loads(git('show',parent+':public/cqc/runtime-manifest.json'));new=json.loads((S/'public/cqc/runtime-manifest.json').read_text());assert len(old['files'])==len(new['files'])==1017;oldmap={e['path']:e for e in old['files']};rows=[];preserved=0
for row in new['files']:
 oldrow=oldmap[row['path']];b=(S/'public/cqc'/row['path']).read_bytes();assert H(b)==row['sha256'] and len(b)==row['bytes']
 if row==oldrow:preserved+=1
 else:assert row['path'] in allowed;assert b==(R/row['path']).read_bytes();rows.append({'path':row['path'],'old':oldrow,'new':row})
assert {x['path'] for x in rows}==allowed
catalog=json.loads((R/'data/combat-sprite-catalog-v1.json').read_text());assert len(catalog['entries'])==43
nativeFiles={f['file'] for e in catalog['entries'].values() for field in ['actions','oppositeActions'] for a in e[field].values() for f in a['frames']};assert len(nativeFiles)==258
raw=(R/'data/combat-profiles-v053.json').read_bytes();assert H(raw)=='de879152b4ba00273e65ddae971c7f60dcd58c978ee9a49eb14c6c00e5a7711b'
report={'schema':'cqc.pass10.actual-source-preservation/1','status':'passed','actualRun':True,'closed':True,'confirmedByRoot':True,'checkedAt':datetime.now(timezone.utc).isoformat(),'parent':parent,'candidateSHA256':H((R/'modules/unified-versus-v055.html').read_bytes()),'actualRuntimeFilesVerified':1017,'runtimeFilesUnchangedFromParent':preserved,'approvedRuntimeSourceChanges':rows,'trackedGitChanges':changes,'preservedCatalogEntries':43,'nativePNGByteExact':258,'freezeFiles':334,'unchangedFreezeFiles':len(unchanged),'approvedFreezeChanges':changed,'sourceAndRuntimeNewTextIndependent':True,'raw354CombatSHA256':H(raw),'historicalPathDeletions':0,'oldDocumentationAndShadowSourceUnchanged':True,'noNativePNGOrCatalogChangesInThisUIPass':True}
p=T/'ACTUAL_UI_SOURCE_PRESERVATION_V7.json';b=(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode();p.write_bytes(b) if not p.exists() else (_ for _ in ()).throw(RuntimeError('Preserve closed report'));print(json.dumps({'path':str(p),'bytes':len(b),'sha256':H(b),'unchangedFreezeFiles':len(unchanged),'runtimeFilesUnchanged':preserved,'changes':len(rows)}))
