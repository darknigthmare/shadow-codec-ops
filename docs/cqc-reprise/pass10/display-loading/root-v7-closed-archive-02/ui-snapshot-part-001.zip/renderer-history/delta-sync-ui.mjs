import {buildRuntimeManifest,verifyRuntime} from '/workspace/shadow-codec-recovered/scripts/sync-cqc-runtime.mjs';
import {readFile,writeFile,mkdir,rename,stat} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
const R='/workspace/cqc-game-working/cqc-versus-v056',S='/workspace/shadow-codec-recovered/public/cqc',T='/workspace/cqc-pass10-renderer-preparation/runtime-delta-ui';
const hash=b=>createHash('sha256').update(b).digest('hex');
await mkdir(T,{recursive:true});
const oldManifestBytes=await readFile(path.join(S,'runtime-manifest.json'));const old=JSON.parse(oldManifestBytes);
const {manifest,files}=await buildRuntimeManifest(R);
if(old.files.length!==1017||manifest.files.length!==1017)throw Error('Unexpected UI-only runtime size');
const oldMap=new Map(old.files.map(e=>[e.path,e]));
const plan=[];
for(const e of manifest.files){
 if(!oldMap.has(e.path))throw Error('Unexpected new runtime file '+e.path);
 const bytes=await readFile(path.join(S,e.path));const previous=oldMap.get(e.path);
 if(hash(bytes)!==previous.sha256||bytes.length!==previous.bytes)throw Error('Unexpected S drift '+e.path);
 if(e.sha256!==previous.sha256)plan.push({path:e.path,beforeSha256:previous.sha256,afterSha256:e.sha256,beforeBytes:bytes.length,afterBytes:e.bytes});
}
const allowed=new Set(['src/cqc-sprite-renderer.js','src/cqc-stage-layers.js','src/chronicles-v056.js','src/chronicles-portraits-v056.js','src/chronicles-art-v056.js','src/chronicles-cinema-v056.js','modules/unified-versus-v055.html']);
if(plan.length!==allowed.size||plan.some(e=>!allowed.has(e.path)))throw Error('Unexpected changed set '+JSON.stringify(plan));
await writeFile(path.join(T,'PRECHECK.json'),JSON.stringify({oldManifestSHA256:hash(oldManifestBytes),plan},null,2)+'\n',{flag:'wx'});
for(const e of plan){
 const destination=path.join(S,e.path),archive=path.join(T,'before',e.path);await mkdir(path.dirname(archive),{recursive:true});
 await writeFile(archive,await readFile(destination),{flag:'wx'});
 const temp=destination+'.pass10-independent';await writeFile(temp,files.get(e.path).bytes,{flag:'wx'});await rename(temp,destination);
 const st=await stat(destination);if(st.nlink!==1||hash(await readFile(destination))!==e.afterSha256)throw Error('Post-copy mismatch '+e.path);
}
await writeFile(path.join(T,'before/runtime-manifest.json'),oldManifestBytes,{flag:'wx'});
const newBytes=Buffer.from(JSON.stringify(manifest,null,2)+'\n');const temp=path.join(S,'runtime-manifest.json.pass10-independent');
await writeFile(temp,newBytes,{flag:'wx'});await rename(temp,path.join(S,'runtime-manifest.json'));
await verifyRuntime(S);
await writeFile(path.join(T,'DELTA_SYNC_CLOSED.json'),JSON.stringify({schema:'cqc.pass10-ui-runtime-delta/1',changedFiles:plan,sourceAndRuntimeUnchangedPNG:true,baselineFilesRetained:true,noWholeRuntimeReplacement:true,manifestSHA256:hash(newBytes),verifiedFiles:manifest.files.length,totalBytes:manifest.totalBytes},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({changedFiles:plan.length,verifiedFiles:manifest.files.length,manifestSHA256:hash(newBytes)}));
